execute positioned ~ ~1.55 ~ summon minecraft:text_display run function dai_damage_indicators:display/setup_heavy with storage dai_damage_indicators:runtime
