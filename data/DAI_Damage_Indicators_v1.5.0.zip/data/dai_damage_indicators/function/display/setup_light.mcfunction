tag @s add dai_di_display
scoreboard players set @s di_age 0

# Full 26.2 display transformation. v1.2 supplied only scale, which is no longer
# a valid transformation compound. Use Minecraft's default font so this addon is
# completely resource-pack independent.
$data merge entity @s {billboard:'center',shadow:1b,see_through:1b,background:0,alignment:'center',view_range:2.5f,transformation:{translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.65f,1.65f,1.65f],right_rotation:[0.0f,0.0f,0.0f,1.0f]},text:{text:'$(whole).$(dec)',color:'#ff4d64',bold:true}}
