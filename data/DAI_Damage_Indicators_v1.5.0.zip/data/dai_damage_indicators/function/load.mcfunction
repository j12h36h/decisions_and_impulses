# DAI Damage Indicators v1.5.0
# Minecraft Java 26.2 / DAI 3.0

scoreboard objectives add di_dealt minecraft.custom:minecraft.damage_dealt
scoreboard objectives add di_prev dummy
scoreboard objectives add di_delta dummy
scoreboard objectives add di_whole dummy
scoreboard objectives add di_dec dummy
scoreboard objectives add di_age dummy
scoreboard objectives add di_tmp dummy
scoreboard objectives add di_enable dummy
scoreboard objectives add di_const dummy

scoreboard players set #ten di_const 10

# Force players to initialize from their CURRENT lifetime stat rather than
# showing all historic damage as one giant number after /reload.
tag @a remove dai_di_init

# Remove stale displays from a previous load/reload.
kill @e[type=minecraft:text_display,tag=dai_di_display]

tellraw @a [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'v1.5.0 loaded.',color:'gray'}]
