execute as @a unless score @s wt_init matches 1 run function minetrigger:player/init
scoreboard players add #clock wt_clock 1
execute if score #clock wt_clock matches 20.. run function minetrigger:second
# Visible Trigger projectiles.
execute as @e[type=minecraft:item_display,tag=mt_projectile,tag=mt_asteroid] at @s run function minetrigger:projectile/asteroid_tick
execute as @e[type=minecraft:item_display,tag=mt_projectile,tag=mt_hound] at @s run function minetrigger:projectile/hound_tick
execute as @e[type=minecraft:item_display,tag=mt_projectile,tag=mt_egret] at @s run function minetrigger:projectile/egret_tick
