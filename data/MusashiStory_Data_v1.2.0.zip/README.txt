Musashi Story Data v0.7.0
Full authored-province quality pass.
- Rebuilt major village/harbor/farm structures and roof massing.
- Added micro-relief, lived-in props and multiple cherry/cedar tree silhouettes.
- Rice paddies now use tapered/irregular footprints.
- Fixed unsupported minecraft:chain usage in harbor/coastal wreck functions.
- Existing combat, enemies, loadouts, progression and reactions preserved.
