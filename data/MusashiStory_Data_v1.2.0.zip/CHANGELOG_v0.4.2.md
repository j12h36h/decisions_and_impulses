# Musashi Story v0.4.2

## Critical Map Fix
- Fixed `musashi_story:worldgen/generate` failing to parse at startup.
- Removed the redundant malformed `setworldspawn` command; the DAI worldgen definition already owns spawn coordinates and rotation.
- Restored execution of the authored 1024×1024 staged province generator.
- Added a spawn-floor failsafe to prevent void deaths if a future world-generation function fails.

## Retained from v0.4.1
- HD custom weapon/technique item textures.
- Custom Musashi title-screen item icons.
- Correct starting weapons, techniques and armor loadouts.
- Custom enemies and combat screen reactions.
