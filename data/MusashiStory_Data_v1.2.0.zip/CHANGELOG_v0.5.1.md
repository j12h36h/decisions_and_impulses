# Musashi Story v0.5.1

- Rebuilt terrain contours to remove giant rectangular shelves and lakes.
- Rice Country is now a network of individual terraced paddies and berms.
- Moon Harbor now uses a curved authored coastline.
- Rebuilt Village Dojo and Minka houses with usable facades on all sides and pitched roofs.
- Added deep foundations to raised structures to prevent floating geometry.
- Reworked Bamboo Foothills, Castle Province, Shrine Valley, Bandit Territory, Battlefield and Mountain Temple into rounded layered terrain.
- Removed the raw-JSON waypoint sign and replaced it with a visual shrine/banner marker.
- Increased vegetation, roadside structures, and regional dressing.
- Corrected player spawn/respawn height.
- Added first-person scaling to technique item models.
- Upgraded key architectural textures to 256x256.
