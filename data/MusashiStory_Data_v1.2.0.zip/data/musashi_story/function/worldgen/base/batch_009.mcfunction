# Musashi v1.2.0 base-generation batch 090-099.
execute if score #dispatch ms_world matches 90 run function musashi_story:worldgen/base/step_090
execute if score #dispatch ms_world matches 91 run function musashi_story:worldgen/base/step_091
execute if score #dispatch ms_world matches 92 run function musashi_story:worldgen/base/step_092
execute if score #dispatch ms_world matches 93 run function musashi_story:worldgen/base/step_093
execute if score #dispatch ms_world matches 94 run function musashi_story:worldgen/base/step_094
execute if score #dispatch ms_world matches 95 run function musashi_story:worldgen/base/step_095
execute if score #dispatch ms_world matches 96 run function musashi_story:worldgen/base/step_096
execute if score #dispatch ms_world matches 97 run function musashi_story:worldgen/base/step_097
execute if score #dispatch ms_world matches 98 run function musashi_story:worldgen/base/step_098
execute if score #dispatch ms_world matches 99 run function musashi_story:worldgen/base/step_099
