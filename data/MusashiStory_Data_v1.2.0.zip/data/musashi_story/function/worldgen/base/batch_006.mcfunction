# Musashi v1.2.0 base-generation batch 060-069.
execute if score #dispatch ms_world matches 60 run function musashi_story:worldgen/base/step_060
execute if score #dispatch ms_world matches 61 run function musashi_story:worldgen/base/step_061
execute if score #dispatch ms_world matches 62 run function musashi_story:worldgen/base/step_062
execute if score #dispatch ms_world matches 63 run function musashi_story:worldgen/base/step_063
execute if score #dispatch ms_world matches 64 run function musashi_story:worldgen/base/step_064
execute if score #dispatch ms_world matches 65 run function musashi_story:worldgen/base/step_065
execute if score #dispatch ms_world matches 66 run function musashi_story:worldgen/base/step_066
execute if score #dispatch ms_world matches 67 run function musashi_story:worldgen/base/step_067
execute if score #dispatch ms_world matches 68 run function musashi_story:worldgen/base/step_068
execute if score #dispatch ms_world matches 69 run function musashi_story:worldgen/base/step_069
