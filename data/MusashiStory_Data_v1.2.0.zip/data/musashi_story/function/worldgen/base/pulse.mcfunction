# Musashi Story v1.2.0 — range-dispatched staged province construction.
scoreboard players operation #dispatch ms_world = #build_step ms_world
bossbar set musashi_story:loading players @a[tag=ms_player]
bossbar set musashi_story:loading visible true
execute store result bossbar musashi_story:loading value run scoreboard players get #build_step ms_world
execute if score #dispatch ms_world matches 0..9 run function musashi_story:worldgen/base/batch_000
execute if score #dispatch ms_world matches 10..19 run function musashi_story:worldgen/base/batch_001
execute if score #dispatch ms_world matches 20..29 run function musashi_story:worldgen/base/batch_002
execute if score #dispatch ms_world matches 30..39 run function musashi_story:worldgen/base/batch_003
execute if score #dispatch ms_world matches 40..49 run function musashi_story:worldgen/base/batch_004
execute if score #dispatch ms_world matches 50..59 run function musashi_story:worldgen/base/batch_005
execute if score #dispatch ms_world matches 60..69 run function musashi_story:worldgen/base/batch_006
execute if score #dispatch ms_world matches 70..79 run function musashi_story:worldgen/base/batch_007
execute if score #dispatch ms_world matches 80..89 run function musashi_story:worldgen/base/batch_008
execute if score #dispatch ms_world matches 90..99 run function musashi_story:worldgen/base/batch_009
execute if score #dispatch ms_world matches 100..109 run function musashi_story:worldgen/base/batch_010
execute if score #dispatch ms_world matches 110..119 run function musashi_story:worldgen/base/batch_011
execute if score #dispatch ms_world matches 120..125 run function musashi_story:worldgen/base/batch_012
