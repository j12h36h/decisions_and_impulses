# Musashi v1.2.0 base-generation batch 050-059.
execute if score #dispatch ms_world matches 50 run function musashi_story:worldgen/base/step_050
execute if score #dispatch ms_world matches 51 run function musashi_story:worldgen/base/step_051
execute if score #dispatch ms_world matches 52 run function musashi_story:worldgen/base/step_052
execute if score #dispatch ms_world matches 53 run function musashi_story:worldgen/base/step_053
execute if score #dispatch ms_world matches 54 run function musashi_story:worldgen/base/step_054
execute if score #dispatch ms_world matches 55 run function musashi_story:worldgen/base/step_055
execute if score #dispatch ms_world matches 56 run function musashi_story:worldgen/base/step_056
execute if score #dispatch ms_world matches 57 run function musashi_story:worldgen/base/step_057
execute if score #dispatch ms_world matches 58 run function musashi_story:worldgen/base/step_058
execute if score #dispatch ms_world matches 59 run function musashi_story:worldgen/base/step_059
