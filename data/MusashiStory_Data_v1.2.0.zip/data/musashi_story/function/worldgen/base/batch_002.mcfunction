# Musashi v1.2.0 base-generation batch 020-029.
execute if score #dispatch ms_world matches 20 run function musashi_story:worldgen/base/step_020
execute if score #dispatch ms_world matches 21 run function musashi_story:worldgen/base/step_021
execute if score #dispatch ms_world matches 22 run function musashi_story:worldgen/base/step_022
execute if score #dispatch ms_world matches 23 run function musashi_story:worldgen/base/step_023
execute if score #dispatch ms_world matches 24 run function musashi_story:worldgen/base/step_024
execute if score #dispatch ms_world matches 25 run function musashi_story:worldgen/base/step_025
execute if score #dispatch ms_world matches 26 run function musashi_story:worldgen/base/step_026
execute if score #dispatch ms_world matches 27 run function musashi_story:worldgen/base/step_027
execute if score #dispatch ms_world matches 28 run function musashi_story:worldgen/base/step_028
execute if score #dispatch ms_world matches 29 run function musashi_story:worldgen/base/step_029
