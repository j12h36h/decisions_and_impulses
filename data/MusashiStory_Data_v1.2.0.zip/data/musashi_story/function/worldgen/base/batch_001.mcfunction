# Musashi v1.2.0 base-generation batch 010-019.
execute if score #dispatch ms_world matches 10 run function musashi_story:worldgen/base/step_010
execute if score #dispatch ms_world matches 11 run function musashi_story:worldgen/base/step_011
execute if score #dispatch ms_world matches 12 run function musashi_story:worldgen/base/step_012
execute if score #dispatch ms_world matches 13 run function musashi_story:worldgen/base/step_013
execute if score #dispatch ms_world matches 14 run function musashi_story:worldgen/base/step_014
execute if score #dispatch ms_world matches 15 run function musashi_story:worldgen/base/step_015
execute if score #dispatch ms_world matches 16 run function musashi_story:worldgen/base/step_016
execute if score #dispatch ms_world matches 17 run function musashi_story:worldgen/base/step_017
execute if score #dispatch ms_world matches 18 run function musashi_story:worldgen/base/step_018
execute if score #dispatch ms_world matches 19 run function musashi_story:worldgen/base/step_019
