# Musashi v1.2.0 base-generation batch 070-079.
execute if score #dispatch ms_world matches 70 run function musashi_story:worldgen/base/step_070
execute if score #dispatch ms_world matches 71 run function musashi_story:worldgen/base/step_071
execute if score #dispatch ms_world matches 72 run function musashi_story:worldgen/base/step_072
execute if score #dispatch ms_world matches 73 run function musashi_story:worldgen/base/step_073
execute if score #dispatch ms_world matches 74 run function musashi_story:worldgen/base/step_074
execute if score #dispatch ms_world matches 75 run function musashi_story:worldgen/base/step_075
execute if score #dispatch ms_world matches 76 run function musashi_story:worldgen/base/step_076
execute if score #dispatch ms_world matches 77 run function musashi_story:worldgen/base/step_077
execute if score #dispatch ms_world matches 78 run function musashi_story:worldgen/base/step_078
execute if score #dispatch ms_world matches 79 run function musashi_story:worldgen/base/step_079
