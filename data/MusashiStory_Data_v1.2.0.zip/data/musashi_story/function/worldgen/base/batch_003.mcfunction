# Musashi v1.2.0 base-generation batch 030-039.
execute if score #dispatch ms_world matches 30 run function musashi_story:worldgen/base/step_030
execute if score #dispatch ms_world matches 31 run function musashi_story:worldgen/base/step_031
execute if score #dispatch ms_world matches 32 run function musashi_story:worldgen/base/step_032
execute if score #dispatch ms_world matches 33 run function musashi_story:worldgen/base/step_033
execute if score #dispatch ms_world matches 34 run function musashi_story:worldgen/base/step_034
execute if score #dispatch ms_world matches 35 run function musashi_story:worldgen/base/step_035
execute if score #dispatch ms_world matches 36 run function musashi_story:worldgen/base/step_036
execute if score #dispatch ms_world matches 37 run function musashi_story:worldgen/base/step_037
execute if score #dispatch ms_world matches 38 run function musashi_story:worldgen/base/step_038
execute if score #dispatch ms_world matches 39 run function musashi_story:worldgen/base/step_039
