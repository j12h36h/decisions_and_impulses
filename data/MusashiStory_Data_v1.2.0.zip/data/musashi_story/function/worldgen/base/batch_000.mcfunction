# Musashi v1.2.0 base-generation batch 000-009.
execute if score #dispatch ms_world matches 0 run function musashi_story:worldgen/base/step_000
execute if score #dispatch ms_world matches 1 run function musashi_story:worldgen/base/step_001
execute if score #dispatch ms_world matches 2 run function musashi_story:worldgen/base/step_002
execute if score #dispatch ms_world matches 3 run function musashi_story:worldgen/base/step_003
execute if score #dispatch ms_world matches 4 run function musashi_story:worldgen/base/step_004
execute if score #dispatch ms_world matches 5 run function musashi_story:worldgen/base/step_005
execute if score #dispatch ms_world matches 6 run function musashi_story:worldgen/base/step_006
execute if score #dispatch ms_world matches 7 run function musashi_story:worldgen/base/step_007
execute if score #dispatch ms_world matches 8 run function musashi_story:worldgen/base/step_008
execute if score #dispatch ms_world matches 9 run function musashi_story:worldgen/base/step_009
