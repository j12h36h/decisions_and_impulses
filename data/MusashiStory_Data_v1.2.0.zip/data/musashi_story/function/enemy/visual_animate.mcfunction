execute if score #anim ms_world matches 0..9 run function musashi_story:enemy/pose_a
execute if score #anim ms_world matches 10..19 run function musashi_story:enemy/pose_b
