tag @s add ms_death_seen
execute as @a[tag=ms_player,distance=..18,sort=nearest,limit=1] run function musashi_story:progress/kill_bandit_swordsman
