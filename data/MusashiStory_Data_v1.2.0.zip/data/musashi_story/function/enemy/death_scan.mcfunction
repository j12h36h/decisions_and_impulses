execute as @e[type=musashi_story:ashigaru_raider,tag=ms_enemy,tag=!ms_death_seen,nbt={DeathTime:1s}] at @s run function musashi_story:enemy/death/ashigaru_raider
execute as @e[type=musashi_story:bandit_swordsman,tag=ms_enemy,tag=!ms_death_seen,nbt={DeathTime:1s}] at @s run function musashi_story:enemy/death/bandit_swordsman
execute as @e[type=musashi_story:castle_samurai,tag=ms_enemy,tag=!ms_death_seen,nbt={DeathTime:1s}] at @s run function musashi_story:enemy/death/castle_samurai
execute as @e[type=musashi_story:oni_brute,tag=ms_enemy,tag=!ms_death_seen,nbt={DeathTime:1s}] at @s run function musashi_story:enemy/death/oni_brute
execute as @e[type=musashi_story:shrine_warden,tag=ms_enemy,tag=!ms_death_seen,nbt={DeathTime:1s}] at @s run function musashi_story:enemy/death/shrine_warden
execute as @e[type=musashi_story:tengu_duelist,tag=ms_enemy,tag=!ms_death_seen,nbt={DeathTime:1s}] at @s run function musashi_story:enemy/death/tengu_duelist
execute as @e[type=musashi_story:wandering_ronin,tag=ms_enemy,tag=!ms_death_seen,nbt={DeathTime:1s}] at @s run function musashi_story:enemy/death/wandering_ronin
execute as @e[type=musashi_story:yari_guard,tag=ms_enemy,tag=!ms_death_seen,nbt={DeathTime:1s}] at @s run function musashi_story:enemy/death/yari_guard
