function musashi_story:bootstrap/ensure
scoreboard players add #tick ms_world 0
scoreboard players add #anim ms_world 0
