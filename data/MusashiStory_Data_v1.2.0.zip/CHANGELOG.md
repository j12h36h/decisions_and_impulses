
# Musashi Story v0.4.0

- Rebuilt the experience around a Hollow-Spiral-style authored mega-province instead of vanilla terrain generation.
- The world now starts from a void preset and forges a protected 1024×1024 continuous terrain floor in staged 64×64 sectors.
- Added authored macro-terrain for Musashi Village, Village Outskirts, Rice Country, River Province, Bamboo Foothills, Fallen Shrine Valley, Bandit Territory, Castle Province, Moon Harbor Coast, Mountain Temple and Old Battlefield.
- Regions remain seamless and open-world; there are no room walls or corridor doors between map sections.
- Added deterministic roads, bridges, paddies, coast, hills, castle terraces and mountain elevation so structures always land where intended.
- Restored and populated eight DAI-native enemy archetypes across their intended territories, with ClayGrounds-style articulated visual rigs and animation syncing.
- Replaced broken custom-entity kill advancements with runtime death scanning for Honor, Resolve and bounty progression.
- Rebuilt all four loadouts with valid direct item replacement, guaranteed starting weapons, three active techniques, Wayfarer Seal, and class-specific starter armor.
- Fixed invalid loadout tellraw syntax from v0.3.
- Reworked ACTION menus into three-slot pages to match the current DAI menu slot limit.
- Added ComicEffects-inspired combat reactions: layered ink impacts + weapon-specific slash overlays on Katana, Nodachi, Naginata and Wakizashi hits.
- Active skills retain dedicated screen overlays; Iaijutsu uses an animated sprite sheet and Mountain Breaker now uses a layered impact reaction.
- Fixed Mountain Breaker's invalid block-particle command for Minecraft 26.2.
- Fixed the watchtower ladder setblock syntax error.
- Fixed the title-screen missing chest icon by switching Official Packs to a stable emerald item icon.
- Removed the invalid daylight-cycle gamerule invocation seen in the v0.3 test log.
- New save identity: Musashi Story v0.4.
