# Musashi Story v0.6.0

- Replaced the remaining superflat-looking province silhouette with authored rolling hills, ridges, valleys, coastal shoulders, and satellite mountain peaks.
- Added dense natural foliage passes to every region: cherry groves, cedar forests, bamboo thickets, meadow grass, podzol forest floors, mushrooms, rocks, and fallen logs.
- Expanded the Mountain Temple into a surrounding mountain range and strengthened forested region boundaries.
- Rice Country remains terraced rather than a square lake; River Province now sits in an actual shallow valley; Moon Harbor has inland coastal hills.
- Upgraded custom cherry, cedar, and bamboo generation to produce irregular silhouettes instead of boxy foliage.
- Keeps the v0.5.1 architecture corrections: supported foundations, two-sided dojo facade, pitched roofs, and fixed waypoint marker.
- New save id ensures fresh chronicles receive the full terrain rewrite instead of retaining old geometry.
- Resource pack adds HD terrain and foliage materials while retaining the MineTrigger-scale HD item pass.
