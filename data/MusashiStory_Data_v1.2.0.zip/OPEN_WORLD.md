# Musashi Story Open World v0.4.0

Musashi remains an open world to the player, but it no longer depends on Minecraft's random overworld generator.

The world is a controlled void preset containing one continuous authored province. There are no visible room walls or dungeon corridors. Regional boundaries are expressed through roads, rivers, hills, bamboo, coastlines, castle terraces and mountain elevation.

Current regional identities:
- Musashi Village
- Village Outskirts
- Rice Country
- River Province
- Bamboo Foothills
- Fallen Shrine Valley
- Bandit Territory
- Castle Province
- Moon Harbor Coast
- Mountain Temple
- Old Battlefield
