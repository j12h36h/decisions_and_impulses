execute as @a unless score @s wt_init matches 1 run function minetrigger:player/init
scoreboard players add #clock wt_clock 1
execute if score #clock wt_clock matches 20.. run function minetrigger:second
