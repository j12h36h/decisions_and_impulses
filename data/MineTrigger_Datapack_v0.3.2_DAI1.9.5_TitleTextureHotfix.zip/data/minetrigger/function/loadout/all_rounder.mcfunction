scoreboard players set @s wt_loadout 4
advancement revoke @s only minetrigger:state/loadout_attacker
advancement revoke @s only minetrigger:state/loadout_shooter
advancement revoke @s only minetrigger:state/loadout_sniper
advancement grant @s only minetrigger:state/loadout_all_rounder
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Trigger Set selected: All-Rounder","color":"white"}]
