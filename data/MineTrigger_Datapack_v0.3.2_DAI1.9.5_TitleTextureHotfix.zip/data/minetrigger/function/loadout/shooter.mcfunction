scoreboard players set @s wt_loadout 2
advancement revoke @s only minetrigger:state/loadout_attacker
advancement revoke @s only minetrigger:state/loadout_sniper
advancement revoke @s only minetrigger:state/loadout_all_rounder
advancement grant @s only minetrigger:state/loadout_shooter
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Trigger Set selected: Shooter","color":"white"}]
