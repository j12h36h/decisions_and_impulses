scoreboard players set @s wt_loadout 3
advancement revoke @s only minetrigger:state/loadout_attacker
advancement revoke @s only minetrigger:state/loadout_shooter
advancement revoke @s only minetrigger:state/loadout_all_rounder
advancement grant @s only minetrigger:state/loadout_sniper
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Trigger Set selected: Sniper","color":"white"}]
