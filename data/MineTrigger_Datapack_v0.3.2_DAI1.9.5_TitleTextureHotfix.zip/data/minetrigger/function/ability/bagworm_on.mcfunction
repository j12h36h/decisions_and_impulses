execute unless score @s wt_active matches 1.. run tellraw @s {"text":"[BORDER] Trigger On is required.","color":"red"}
execute if score @s wt_active matches 1.. run scoreboard players set @s wt_bagworm 1
execute if score @s wt_active matches 1.. run scoreboard players set @s wt_chameleon 0
execute if score @s wt_active matches 1.. run advancement grant @s only minetrigger:state/bagworm_on
execute if score @s wt_active matches 1.. run advancement revoke @s only minetrigger:state/chameleon_on
execute if score @s wt_active matches 1.. run effect clear @s minecraft:invisibility
execute if score @s wt_active matches 1.. run tellraw @s {"text":"[BORDER] Bagworm active: radar signature suppressed.","color":"dark_gray"}
