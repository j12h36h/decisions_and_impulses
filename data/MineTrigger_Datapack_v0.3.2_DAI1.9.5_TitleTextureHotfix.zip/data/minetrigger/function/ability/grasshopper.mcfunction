execute unless score @s wt_active matches 1.. run tellraw @s {"text":"[BORDER] Trigger On is required.","color":"red"}
execute if score @s wt_active matches 1.. unless score @s wt_trion matches 8.. run tellraw @s {"text":"[BORDER] Insufficient Trion for Grasshopper.","color":"red"}
execute if score @s wt_active matches 1.. if score @s wt_trion matches 8.. run scoreboard players remove @s wt_trion 8
execute if score @s wt_active matches 1.. if score @s wt_trion matches 0.. run function minetrigger:trigger/bailout
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run teleport @s ^ ^1.2 ^6
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run playsound minecraft:entity.breeze.jump player @s ~ ~ ~ 0.8 1.4
