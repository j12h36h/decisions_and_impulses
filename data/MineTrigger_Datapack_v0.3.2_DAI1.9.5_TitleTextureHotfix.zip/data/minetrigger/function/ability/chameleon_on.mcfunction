execute unless score @s wt_active matches 1.. run tellraw @s {"text":"[BORDER] Trigger On is required.","color":"red"}
execute if score @s wt_active matches 1.. unless score @s wt_trion matches 10.. run tellraw @s {"text":"[BORDER] Insufficient Trion for Chameleon.","color":"red"}
execute if score @s wt_active matches 1.. if score @s wt_trion matches 10.. run scoreboard players remove @s wt_trion 10
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run scoreboard players set @s wt_chameleon 1
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run scoreboard players set @s wt_bagworm 0
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run advancement grant @s only minetrigger:state/chameleon_on
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run advancement revoke @s only minetrigger:state/bagworm_on
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run effect give @s minecraft:invisibility infinite 0 true
execute if score @s wt_active matches 1.. if score @s wt_trion matches ..0 run function minetrigger:trigger/bailout
