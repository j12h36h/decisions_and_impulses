scoreboard players set @s wt_bagworm 0
scoreboard players set @s wt_chameleon 0
advancement revoke @s only minetrigger:state/bagworm_on
advancement revoke @s only minetrigger:state/chameleon_on
effect clear @s minecraft:invisibility
tellraw @s {"text":"[BORDER] Stealth Optional Trigger disabled.","color":"gray"}
