execute unless score @s wt_active matches 1.. run tellraw @s {"text":"[BORDER] Trigger On is required.","color":"red"}
execute if score @s wt_active matches 1.. unless score @s wt_trion matches 4.. run tellraw @s {"text":"[BORDER] Insufficient Trion for Radar Scan.","color":"red"}
execute if score @s wt_active matches 1.. if score @s wt_trion matches 4.. run scoreboard players remove @s wt_trion 4
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. at @s run effect give @e[tag=wt_training_dummy,distance=..64] minecraft:glowing 5 0 true
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.7 1.6
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run tellraw @s {"text":"[BORDER] Radar Scan: training signatures highlighted for 5 seconds.","color":"aqua"}
execute if score @s wt_active matches 1.. if score @s wt_trion matches ..0 run function minetrigger:trigger/bailout
