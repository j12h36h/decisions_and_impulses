# MineTrigger v0.2.2 training sector.
# Built directly on Minecraft's default flat-world surface so the player is
# never suspended ~125 blocks above the actual terrain during login/rendering.
fill -31 -61 -31 31 -61 31 minecraft:smooth_stone replace
fill -31 -60 -31 31 -60 -31 minecraft:polished_deepslate replace
fill -31 -60 31 31 -60 31 minecraft:polished_deepslate replace
fill -31 -60 -30 -31 -60 30 minecraft:polished_deepslate replace
fill 31 -60 -30 31 -60 30 minecraft:polished_deepslate replace

# Border HQ shell. Floor remains at Y=-61; player feet are at Y=-60.
fill -12 -61 -12 12 -53 12 minecraft:white_concrete hollow
fill -10 -60 -10 10 -54 10 minecraft:air replace
fill -3 -60 -12 3 -56 -12 minecraft:air replace
fill -11 -57 -11 11 -57 11 minecraft:cyan_stained_glass replace minecraft:white_concrete
fill -3 -61 -3 3 -61 3 minecraft:polished_blackstone replace
fill -1 -61 -1 1 -61 1 minecraft:sea_lantern replace

# Training lanes and corner structures.
fill -30 -61 -5 -14 -59 -3 minecraft:light_gray_concrete hollow
fill 14 -61 3 30 -59 5 minecraft:light_gray_concrete hollow
fill -5 -61 14 -3 -59 30 minecraft:gray_concrete hollow
fill 3 -61 -30 5 -59 -14 minecraft:gray_concrete hollow
fill -29 -61 20 -23 -57 26 minecraft:polished_deepslate hollow
fill 23 -61 -26 29 -57 -20 minecraft:polished_deepslate hollow
fill -29 -61 -26 -23 -57 -20 minecraft:polished_deepslate hollow
fill 23 -61 20 29 -57 26 minecraft:polished_deepslate hollow
fill -12 -52 -12 12 -52 12 minecraft:cyan_concrete replace
setblock 0 -51 0 minecraft:beacon

scoreboard players set #arena wt_world 2
