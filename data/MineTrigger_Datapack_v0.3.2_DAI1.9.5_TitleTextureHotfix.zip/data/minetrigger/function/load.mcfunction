# MineTrigger alpha objectives. Re-adding existing objectives is harmless on reload.
scoreboard objectives add wt_init dummy
scoreboard objectives add wt_active dummy
scoreboard objectives add wt_trion dummy
scoreboard objectives add wt_trion_max dummy
scoreboard objectives add wt_loadout dummy
scoreboard objectives add wt_clock dummy
scoreboard objectives add wt_bagworm dummy
scoreboard objectives add wt_chameleon dummy
scoreboard objectives add wt_rank dummy
scoreboard objectives add wt_world dummy
scoreboard players add #clock wt_clock 0
execute as @a unless score @s wt_init matches 1 run function minetrigger:player/init
