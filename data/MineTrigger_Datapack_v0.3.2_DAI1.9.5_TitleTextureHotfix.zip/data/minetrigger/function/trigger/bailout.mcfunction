scoreboard players set @s wt_active 0
scoreboard players set @s wt_bagworm 0
scoreboard players set @s wt_chameleon 0
scoreboard players operation @s wt_trion = @s wt_trion_max
advancement revoke @s only minetrigger:state/trigger_on
advancement revoke @s only minetrigger:state/bagworm_on
advancement revoke @s only minetrigger:state/chameleon_on
effect clear @s minecraft:resistance
effect clear @s minecraft:speed
effect clear @s minecraft:jump_boost
effect clear @s minecraft:invisibility
function minetrigger:trigger/clear_items
teleport @s 0.5 -60 6.5 180 0
title @s title {"text":"BAIL OUT","color":"gold","bold":true}
title @s subtitle {"text":"Trion body terminated // returning to Border HQ","color":"white"}
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 1.0 1.4
