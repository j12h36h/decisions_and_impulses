scoreboard players remove @s wt_trion 1
execute if score @s wt_trion matches ..0 run function minetrigger:trigger/bailout
