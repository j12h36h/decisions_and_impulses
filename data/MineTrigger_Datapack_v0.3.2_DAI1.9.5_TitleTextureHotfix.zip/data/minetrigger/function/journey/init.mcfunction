function minetrigger:player/init
execute unless score #arena wt_world matches 2 run function minetrigger:world/ensure_training_sector
spawnpoint @s 0 -60 6
teleport @s 0.5 -60 6.5 180 0
effect give @s minecraft:resistance 10 4 true
effect give @s minecraft:slow_falling 10 0 true
gamemode adventure @s
clear @s
kill @e[tag=wt_training_dummy]
summon minetrigger:training_trion_soldier 24 -60 0 {Tags:['wt_training_dummy'],CustomName:{text:'Training Trion Soldier',color:'aqua'},CustomNameVisible:0b,PersistenceRequired:1b,NoAI:1b,Silent:1b}
summon minetrigger:training_trion_soldier -24 -60 0 {Tags:['wt_training_dummy'],CustomName:{text:'Training Trion Soldier',color:'aqua'},CustomNameVisible:0b,PersistenceRequired:1b,NoAI:1b,Silent:1b}
summon minetrigger:training_trion_soldier 0 -60 24 {Tags:['wt_training_dummy'],CustomName:{text:'Training Trion Soldier',color:'aqua'},CustomNameVisible:0b,PersistenceRequired:1b,NoAI:1b,Silent:1b}
summon minetrigger:training_trion_soldier 0 -60 -24 {Tags:['wt_training_dummy'],CustomName:{text:'Training Trion Soldier',color:'aqua'},CustomNameVisible:0b,PersistenceRequired:1b,NoAI:1b,Silent:1b}
title @s title {"text":"BORDER","color":"aqua","bold":true}
title @s subtitle {"text":"Training Sector initialized","color":"white"}
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Press ` to open the MineTrigger command interface.","color":"white"}]
