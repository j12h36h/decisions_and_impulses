MineTrigger - Border Training v0.3.1
=====================================

Requires: Decisions & Impulses (D.A.I.) 1.9.5+
Recommended companion: MineTrigger Resource Pack v0.3.0
Namespace: minetrigger
DAI role: MAIN

0.3.1 includes the v0.3.0 modernization and fixes the first native-entity/title-screen regression.

0.3.0 modernizes MineTrigger using the newer DAI architecture proven in ClayGrounds: native registry content, native DAI entities, current experience lifecycle, and JSON world types.

MAJOR 0.3.0 CHANGES
-------------------
- Trigger equipment/projectiles are registry-backed minetrigger:* items.
- Training Trion Soldiers are registry-backed DAI entities.
- Border Training uses a DAI JSON void world.
- Title screen now has Start New / Continue + save browser.
- Official Packs is available from the MineTrigger title screen.
- Resume restores an active Trigger loadout.
- First-join/resume presentation uses the actual MineTrigger logo.
- Direct ` backtick dashboard is preserved.

INSTALL
-------
1. Install D.A.I. 1.9.5+.
2. Put the datapack ZIP in the instance-level /datapacks folder.
3. Put the resource-pack ZIP in /resourcepacks.
4. Restart Minecraft. DAI automatically enables the MineTrigger companion RP.
5. Choose START NEW TRAINING or CONTINUE TRAINING.

Press ` in-game to open the MineTrigger dashboard directly.

0.3.1 HOTFIX
------------
- Training Trion Soldier carrier changed from unsupported minecraft:husk to supported minecraft:zombie.
- Continue Training title icon changed from minecraft:recovery_compass to minecraft:compass.
- Loadout/Trigger/Abilities menu definitions were verified and retained; the failed v0.3.0 session had DAI execution suspended by the registry safety lock.
