execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
execute store result storage dai_starfall:ctx nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:ctx nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:ctx nav_z int 1 run scoreboard players get @s ds_nav_z
function dai_starfall:player/personal_tick_macro with storage dai_starfall:ctx
