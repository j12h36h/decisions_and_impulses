# Fresh-player safety while DAI 3.8 holds the server-owned first_join action behind the arrival cinematic.
# This function MUST NOT allocate a ship or mutate ds_ship; it only prevents a new player from falling through the void.
gamemode spectator @s
execute if entity @s[y=-32,dy=512] run teleport @s 0.5 80.0 0.5
