# DAI 3.8 MAIN-experience reconnect lifecycle.
# Legacy/dev worlds that predate lifecycle metadata are initialized safely here.
execute unless entity @s[tag=ds_player] run function dai_starfall:player/first_join

# Reconcile only state that can be lost outside scoreboard persistence.
execute unless entity @s[tag=ds_recall_v041] run function dai_starfall:item/migrate_recall_v041
execute if score @s ds_phase matches 1.. unless score @s ds_nav_y matches -2147483648..2147483647 run function dai_starfall:travel/init_navigation
execute if score @s ds_phase matches 3..5 unless entity @s[tag=ds_aurod_gravity_applied] run function dai_starfall:physics/apply_aurod
execute if score @s ds_phase matches 12..13 unless entity @s[tag=ds_aurod_gravity_applied] run function dai_starfall:physics/apply_aurod
execute if entity @s[tag=ds_aurod_gravity_applied] if score @s ds_phase matches ..2 run function dai_starfall:physics/restore_normal
execute if entity @s[tag=ds_aurod_gravity_applied] if score @s ds_phase matches 6..11 run function dai_starfall:physics/restore_normal
execute if entity @s[tag=ds_aurod_gravity_applied] if score @s ds_phase matches 14.. run function dai_starfall:physics/restore_normal
execute if score @s ds_phase matches 14..15 unless entity @s[tag=ds_dunoga_gravity_applied] run function dai_starfall:physics/apply_dunoga
execute if entity @s[tag=ds_dunoga_gravity_applied] unless score @s ds_phase matches 14..15 run function dai_starfall:physics/restore_normal
execute if score @s ds_phase matches 16..17 if entity @s[tag=ds_aurod_gravity_applied] run function dai_starfall:physics/restore_normal
execute if score @s ds_phase matches 16..17 if entity @s[tag=ds_dunoga_gravity_applied] run function dai_starfall:physics/restore_normal

execute if score @s ds_phase matches 10..17 run function dai_starfall:item/ensure_recall
