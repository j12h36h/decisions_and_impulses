# Flagship deployment button -> real floor hatch
$execute if score @s ds_phase matches 1 positioned $(ship_x) 0 0 if block ~-7 237 -299 minecraft:stone_button[powered=true] run function dai_starfall:scene/open_flagship_hatch
# Once below the real hull, auto-close the hatch; player continues a literal fall to private Aurod.
# phase-2 -> phase-3 is handled in the authoritative main tick using ds_y
# The visible extraction platform is authoritative. While still collecting, standing here forces a fresh carried-inventory validation.
$execute if score @s ds_phase matches 4 positioned $(ship_x) 44 -197 if entity @s[distance=..11] run function dai_starfall:scene/update_vinewood_count
execute if score @s ds_phase matches 4 if score @s ds_vines matches 12.. run function dai_starfall:scene/material_complete
# Once material is complete, the same physical platform starts the destruction sequence immediately; no leave/re-enter is required.
$execute if score @s ds_phase matches 5 positioned $(ship_x) 44 -197 if entity @s[distance=..11] run function dai_starfall:scene/destruction_request
# Cutscene timeline uses this player-specific physical flagship location.
execute if score @s ds_phase matches 6 run function dai_starfall:scene/destruction_tick_macro with storage dai_starfall:ctx
# Physical pod trigger: enter the pod and stand on its plate.
$execute if score @s ds_phase matches 7 positioned $(ship_x) 44 -154 if entity @s[distance=..4] run function dai_starfall:scene/pod_launch_start
# Follow visual shell during actual levitation ascent.
execute if score @s ds_phase matches 8 at @s run tp @e[tag=ds_pod_visual,distance=..12] ~ ~ ~
execute if score @s ds_phase matches 8 run function dai_starfall:scene/pod_launch_tick
# Escape-craft controls use the ship's current navigation origin after terminal travel.
$execute if score @s ds_phase matches 10 if score @s ds_orbit_ready matches 1 positioned $(nav_x) $(nav_y) $(nav_z) if block ~-7 ~2 ~18 minecraft:stone_button[powered=true] run function dai_starfall:travel/open_ship_hatch
$execute if score @s ds_phase matches 10 if score @s ds_orbit_ready matches 0 positioned $(nav_x) $(nav_y) $(nav_z) if block ~-7 ~2 ~18 minecraft:stone_button[powered=true] run title @s actionbar {text:"NAV // SELECT A DESTINATION AT THE COCKPIT TERMINAL",color:"gold",bold:true}
# Hidden destination handoff occurs only after the player physically jumps below the moved ship.
$execute if score @s ds_phase matches 11 positioned $(nav_x) $(nav_y) $(nav_z) positioned ~ ~-5 ~18 if entity @s[distance=..12] run function dai_starfall:travel/drop_selected
