# Space Between Blocks v0.3.0 per-player runtime.
# Called once per ds_player each server tick to avoid repeated global @a scans.

# Staged first-time construction.
execute if score @s ds_phase matches 0 run function dai_starfall:player/context_init_tick

# Pending escape-craft orbital transfer.
execute if score @s ds_travel_pending matches 1.. run function dai_starfall:travel/check_transfer

# Rotary MultiTool animation.
execute if score @s ds_mt_spin matches 4 run function dai_starfall:item/spin/frame_2
execute if score @s ds_mt_spin matches 3 run function dai_starfall:item/spin/frame_3
execute if score @s ds_mt_spin matches 2 run function dai_starfall:item/spin/frame_4
execute if score @s ds_mt_spin matches 1 run function dai_starfall:item/spin/finish
execute if score @s ds_mt_spin matches 2.. run scoreboard players remove @s ds_mt_spin 1

# Starter provisions migration.
execute if score @s ds_phase matches 1.. unless score @s ds_foodkit matches 1.. run function dai_starfall:food/ensure_starter

# Authoritative player height sample.
execute store result score @s ds_y run data get entity @s Pos[1] 1

# Death recovery.
execute unless score @s ds_seen_deaths = @s ds_deaths run function dai_starfall:player/death_recovery

# Tutorial planetfall handoff.
execute if score @s ds_phase matches 2 if score @s ds_y matches ..230 run function dai_starfall:scene/flagship_clear_hatch
execute if score @s ds_phase matches 3 at @s unless block ~ ~-1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:cave_air unless block ~ ~-1 ~ minecraft:void_air run function dai_starfall:scene/tutorial_landed
execute if score @s ds_phase matches 1..3 if score @s ds_y matches ..64 run function dai_starfall:scene/tutorial_landed

# Lower-atmosphere impact protection and touchdown.
execute if score @s ds_phase matches 4 if score @s ds_touchdown matches 0 run effect give @s minecraft:resistance 2 255 true
execute if score @s ds_phase matches 4 if score @s ds_touchdown matches 0 at @s unless block ~ ~-1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:cave_air unless block ~ ~-1 ~ minecraft:void_air run function dai_starfall:scene/tutorial_touchdown

# Inventory-authoritative Vinewood collection.
execute if score @s ds_phase matches 4 run function dai_starfall:scene/update_vinewood_count
execute if score @s ds_phase matches 4 run title @s actionbar [{"text":"VINEWOOD COLLECTED // ","color":"gold"},{"score":{"name":"@s","objective":"ds_vines"}},{"text":" / 12","color":"white"}]
execute if score @s ds_phase matches 4 if score @s ds_vines matches 12.. run function dai_starfall:scene/material_complete

# Historical save migrations.
execute if score @s ds_phase matches 1.. unless score @s ds_patch matches 17.. run function dai_starfall:player/patch_v017_context
execute if score @s ds_phase matches 1.. unless score @s ds_patch matches 112.. run function dai_starfall:player/patch_v012_context
execute if score @s ds_phase matches 1.. unless score @s ds_patch matches 113.. run function dai_starfall:player/patch_v013_context
execute unless score @s ds_coast matches 0.. run scoreboard players set @s ds_coast 0
execute unless score @s ds_coast_wait matches 0.. run scoreboard players set @s ds_coast_wait 0
execute if score @s ds_phase matches 1.. if score @s ds_coast matches ..7 if score @s ds_coast_wait matches 0 unless score @s ds_patch matches 116.. run function dai_starfall:player/patch_v016_context
execute if score @s ds_coast_wait matches 1.. run scoreboard players remove @s ds_coast_wait 1

# Private plot / scene controls.
function dai_starfall:player/context_tick
execute if score @s ds_phase matches 9 run function dai_starfall:scene/wake_ship_tick

# Starter-ship hull-breach recovery.
execute if score @s ds_phase matches 9..10 if score @s ds_y matches ..60 run function dai_starfall:player/recover_ship

# Shared Aurod landing and extraction.
execute if score @s ds_phase matches 13 at @s unless block ~ ~-1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:cave_air unless block ~ ~-1 ~ minecraft:void_air run function dai_starfall:travel/shared_landed
execute if score @s ds_phase matches 13 if score @s ds_y matches ..64 run function dai_starfall:travel/shared_landed
execute if score @s ds_phase matches 12 positioned 0.5 45 100125.5 if entity @s[distance=..6] run function dai_starfall:travel/return_ship
# Dunoga heavy-gravity landing and far-side extraction.
execute if score @s ds_phase matches 14 at @s unless block ~ ~-1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:cave_air unless block ~ ~-1 ~ minecraft:void_air run function dai_starfall:travel/dunoga_landed
execute if score @s ds_phase matches 14 if score @s ds_y matches ..39 run function dai_starfall:travel/dunoga_landed
execute if score @s ds_phase matches 15 positioned 56.5 38.0 200056.5 if entity @s[distance=..6] run function dai_starfall:travel/return_ship

# Transition HUD timer.
execute if score @s ds_ui_complete matches 1.. run scoreboard players remove @s ds_ui_complete 1

# Ship interiors are protected safe hubs.
execute if score @s ds_phase matches 9..11 run effect give @s minecraft:resistance 1 4 true
execute if score @s ds_phase matches 55 run effect give @s minecraft:resistance 1 255 true

# Virelia canopy landing / extraction.
execute if score @s ds_phase matches 16 at @s unless block ~ ~-1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:cave_air unless block ~ ~-1 ~ minecraft:void_air run function dai_starfall:travel/virelia_landed
execute if score @s ds_phase matches 16 if score @s ds_y matches ..35 run function dai_starfall:travel/virelia_landed
execute if score @s ds_phase matches 17 positioned 72.5 76.0 300072.5 if entity @s[distance=..8] run function dai_starfall:travel/return_ship
execute if score @s ds_phase matches 10..17 run function dai_starfall:item/ensure_recall
