$spawnpoint @s $(ship_x) 238 -390
