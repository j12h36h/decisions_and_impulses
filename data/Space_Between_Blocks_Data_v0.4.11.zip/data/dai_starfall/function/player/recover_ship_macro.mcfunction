$teleport @s $(nav_x).5 $(nav_y).0 $(nav_z).5 0 0
$spawnpoint @s $(nav_x) $(nav_y) $(nav_z)
