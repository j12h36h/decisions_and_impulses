# Permanent shared Aurod extraction structure protection.
# Actual structure spans x=-8..8, y=42..46, z=100117..100133.
# This box includes a reach margin so players cannot stand just outside and mine inward.
execute if entity @s[x=-13,y=38,z=100112,dx=26,dy=14,dz=26] run tag @s add ds_aurod_structure
