function dai_starfall:physics/restore_normal
effect give @s minecraft:resistance 5 255 true
effect give @s minecraft:slow_falling 3 0 true
execute store result storage dai_starfall:nav nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:nav nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:nav nav_z int 1 run scoreboard players get @s ds_nav_z
function dai_starfall:player/recover_ship_macro with storage dai_starfall:nav
tellraw @s {"text":"LIFE SUPPORT // hull-breach recovery engaged","color":"gold"}
