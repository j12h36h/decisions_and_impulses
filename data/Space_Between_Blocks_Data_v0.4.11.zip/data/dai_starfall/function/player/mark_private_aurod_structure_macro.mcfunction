# Permanent private Aurod infrastructure protection with player-reach margins.
# Extraction pad / iron / sea-lantern / lightning-rod cluster.
$execute positioned $(ship_x) 38 -208 positioned ~-11 ~ ~ if entity @s[dx=22,dy=15,dz=22] run tag @s add ds_aurod_structure
# Causeway, expanded on all sides so edge blocks cannot be reached from survival terrain.
$execute positioned $(ship_x) 38 -195 positioned ~-9 ~ ~ if entity @s[dx=18,dy=15,dz=39] run tag @s add ds_aurod_structure
# Emergency-pod structure plus reach margin.
$execute positioned $(ship_x) 38 -165 positioned ~-9 ~ ~ if entity @s[dx=18,dy=17,dz=20] run tag @s add ds_aurod_structure
