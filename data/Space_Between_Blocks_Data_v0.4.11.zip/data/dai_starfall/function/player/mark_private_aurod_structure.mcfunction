execute store result storage dai_starfall:protect ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/mark_private_aurod_structure_macro with storage dai_starfall:protect
