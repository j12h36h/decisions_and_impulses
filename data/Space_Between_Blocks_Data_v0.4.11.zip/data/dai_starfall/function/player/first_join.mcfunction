tag @s add ds_player
tag @s add ds_recall_v041
scoreboard players add #next_ship ds_global 1
scoreboard players operation @s ds_ship = #next_ship ds_global
scoreboard players operation @s ds_ship_x = @s ds_ship
scoreboard players operation @s ds_ship_x *= #ship_spacing ds_global
scoreboard players set @s ds_phase 0
scoreboard players set @s ds_scene 0
scoreboard players set @s ds_init 0
scoreboard players set @s ds_vines 0
scoreboard players set @s ds_touchdown 0
scoreboard players set @s ds_coast 0
scoreboard players set @s ds_coast_wait 0
scoreboard players set @s ds_patch 112
scoreboard players set @s ds_vines_inventory 0
scoreboard players set @s ds_foodkit 0
scoreboard players set @s ds_mt_spin 0
# Initial escape-craft navigation origin. The craft begins in the private shipyard, not planetary orbit.
scoreboard players operation @s ds_nav_x = @s ds_ship_x
scoreboard players set @s ds_nav_y 67
scoreboard players set @s ds_nav_z 700
scoreboard players operation @s ds_orbit_x = @s ds_ship
scoreboard players remove @s ds_orbit_x 1
scoreboard players operation @s ds_orbit_x *= #orbit_spacing ds_global
scoreboard players set @s ds_destination 1
scoreboard players set @s ds_orbit_ready 0
scoreboard players set @s ds_travel_pending 0
scoreboard players set @s ds_orbit_attempt 0
scoreboard players set @s ds_module_upgrade 0
scoreboard players set @s ds_hull_upgrade 0
scoreboard players add @s ds_deaths 0
scoreboard players operation @s ds_seen_deaths = @s ds_deaths
clear @s
gamemode spectator @s
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/prepare_plot_macro with storage dai_starfall:ctx
