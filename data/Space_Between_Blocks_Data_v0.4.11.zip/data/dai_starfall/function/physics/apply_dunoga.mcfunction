# Dunoga is a heavy 1.75g cavern world. Modifiers are idempotent and isolated.
attribute @s minecraft:gravity modifier remove dai_starfall:dunoga_gravity
attribute @s minecraft:fall_damage_multiplier modifier remove dai_starfall:dunoga_fall
attribute @s minecraft:gravity modifier add dai_starfall:dunoga_gravity 0.75 add_multiplied_total
attribute @s minecraft:fall_damage_multiplier modifier add dai_starfall:dunoga_fall 0.30 add_multiplied_total
tag @s add ds_dunoga_gravity_applied
