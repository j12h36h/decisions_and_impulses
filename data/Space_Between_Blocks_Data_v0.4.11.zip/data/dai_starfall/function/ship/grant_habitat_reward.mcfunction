scoreboard players set @s ds_hab_master 1
function dai_starfall:food/give_parcel
function dai_starfall:food/give_parcel
function dai_starfall:food/give_parcel
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
tellraw @s [{"text":"ARK // ","color":"green","bold":true},{"text":"All three habitats installed. Your ship now carries a preserved living-ark collection.","color":"white"}]
title @s title {"text":"LIVING ARK COMPLETE","color":"green","bold":true}
