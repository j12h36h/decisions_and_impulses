$execute positioned $(nav_x) $(nav_y) $(nav_z) positioned ~0 ~0 ~146 run function dai_starfall:module/habitat_dunoga
