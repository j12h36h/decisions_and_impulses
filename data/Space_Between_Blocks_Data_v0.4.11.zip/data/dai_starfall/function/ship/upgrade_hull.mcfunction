execute if score @s ds_hull_upgrade matches 1.. run tellraw @s [{"text":"SHIP STATUS // ","color":"gold","bold":true},{"text":"Hull Reinforcement I already installed.","color":"gray"}]
execute if score @s ds_hull_upgrade matches 1.. run return 1
scoreboard players set @s ds_resource_count 0
execute store result score @s ds_resource_count run clear @s dai_starfall:coal_shard 0
execute if score @s ds_resource_count matches 18.. run function dai_starfall:ship/upgrade_hull_apply
execute unless score @s ds_resource_count matches 18.. run tellraw @s [{"text":"SHIP STATUS // ","color":"red","bold":true},{"text":"Hull Reinforcement requires 18 Coal Shards.","color":"gray"}]
