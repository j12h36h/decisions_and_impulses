$execute positioned $(ship_x) 0 0 positioned ~-150 225 -450 run tag @a[dx=300,dy=45,dz=310] add ds_in_ship
