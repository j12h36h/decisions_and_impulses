clear @s dai_starfall:stone_shard 36
clear @s dai_starfall:coal_shard 27
clear @s dai_starfall:wood_shard 18
clear @s dai_starfall:glass_shard 18
clear @s dai_starfall:crystal_shard 9
scoreboard players set @s ds_module_upgrade 1
execute store result storage dai_starfall:nav nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:nav nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:nav nav_z int 1 run scoreboard players get @s ds_nav_z
function dai_starfall:ship/build_fabrication_module_macro with storage dai_starfall:nav
playsound minecraft:block.anvil.land master @s ~ ~ ~ 1.0 0.8
tellraw @s [{"text":"SHIP STATUS // ","color":"green","bold":true},{"text":"Fabrication Module attached to the rear frame.","color":"white"}]
