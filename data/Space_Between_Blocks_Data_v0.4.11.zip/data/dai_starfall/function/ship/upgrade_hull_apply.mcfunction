clear @s dai_starfall:coal_shard 18
scoreboard players set @s ds_hull_upgrade 1
execute store result storage dai_starfall:nav nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:nav nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:nav nav_z int 1 run scoreboard players get @s ds_nav_z
function dai_starfall:ship/hull_upgrade_macro with storage dai_starfall:nav
playsound minecraft:block.anvil.use master @s ~ ~ ~ 1.0 0.7
tellraw @s [{"text":"SHIP STATUS // ","color":"green","bold":true},{"text":"Hull Reinforcement I installed.","color":"white"}]
