$execute positioned $(nav_x) $(nav_y) $(nav_z) positioned ~ ~ ~33 run function dai_starfall:module/fabrication
$execute positioned $(nav_x) $(nav_y) $(nav_z) run fill ~-2 ~1 ~26 ~2 ~4 ~26 minecraft:air
$execute positioned $(nav_x) $(nav_y) $(nav_z) positioned ~ ~ ~48 run function dai_starfall:module/backbone
