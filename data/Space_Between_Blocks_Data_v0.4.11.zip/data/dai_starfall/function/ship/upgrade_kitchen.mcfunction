scoreboard players set @s ds_patch 1
execute unless score @s ds_module_upgrade matches 1.. run scoreboard players set @s ds_patch 0
execute unless score @s ds_module_upgrade matches 1.. run tellraw @s [{"text":"MODULES // ","color":"red","bold":true},{"text":"Install the Fabrication Module first.","color":"gray"}]
execute if score @s ds_mod_kitchen matches 1.. run scoreboard players set @s ds_patch 0
execute if score @s ds_mod_kitchen matches 1.. run tellraw @s [{"text":"MODULES // ","color":"gold","bold":true},{"text":"Kitchen already installed.","color":"gray"}]
execute store result score @s ds_resource_count run clear @s dai_starfall:wood_shard 0
execute unless score @s ds_resource_count matches 9.. run scoreboard players set @s ds_patch 0
execute unless score @s ds_resource_count matches 9.. run tellraw @s [{"text":"MODULES // ","color":"red","bold":true},{"text":"Kitchen requires 9 Wood Shard.","color":"gray"}]
execute store result score @s ds_resource_count run clear @s dai_starfall:stone_shard 0
execute unless score @s ds_resource_count matches 9.. run scoreboard players set @s ds_patch 0
execute unless score @s ds_resource_count matches 9.. run tellraw @s [{"text":"MODULES // ","color":"red","bold":true},{"text":"Kitchen requires 9 Stone Shard.","color":"gray"}]
execute store result score @s ds_resource_count run clear @s dai_starfall:glass_shard 0
execute unless score @s ds_resource_count matches 9.. run scoreboard players set @s ds_patch 0
execute unless score @s ds_resource_count matches 9.. run tellraw @s [{"text":"MODULES // ","color":"red","bold":true},{"text":"Kitchen requires 9 Glass Shard.","color":"gray"}]
execute if score @s ds_patch matches 1 run clear @s dai_starfall:wood_shard 9
execute if score @s ds_patch matches 1 run clear @s dai_starfall:stone_shard 9
execute if score @s ds_patch matches 1 run clear @s dai_starfall:glass_shard 9
execute if score @s ds_patch matches 1 run scoreboard players set @s ds_mod_kitchen 1
execute if score @s ds_patch matches 1 store result storage dai_starfall:nav nav_x int 1 run scoreboard players get @s ds_nav_x
execute if score @s ds_patch matches 1 store result storage dai_starfall:nav nav_y int 1 run scoreboard players get @s ds_nav_y
execute if score @s ds_patch matches 1 store result storage dai_starfall:nav nav_z int 1 run scoreboard players get @s ds_nav_z
execute if score @s ds_patch matches 1 run function dai_starfall:ship/build_kitchen_macro with storage dai_starfall:nav
execute if score @s ds_patch matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1.0 1.0
execute if score @s ds_patch matches 1 run tellraw @s [{"text":"MODULES // ","color":"green","bold":true},{"text":"Kitchen installed.","color":"white"}]
