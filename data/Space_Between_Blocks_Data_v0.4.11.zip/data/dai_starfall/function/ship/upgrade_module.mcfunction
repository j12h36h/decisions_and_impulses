scoreboard players set @s ds_patch 1
execute if score @s ds_module_upgrade matches 1.. run scoreboard players set @s ds_patch 0
execute if score @s ds_module_upgrade matches 1.. run tellraw @s [{"text":"SHIP STATUS // ","color":"gold","bold":true},{"text":"Fabrication Module already attached.","color":"gray"}]
execute store result score @s ds_resource_count run clear @s dai_starfall:stone_shard 0
execute unless score @s ds_resource_count matches 36.. run scoreboard players set @s ds_patch 0
execute unless score @s ds_resource_count matches 36.. run tellraw @s [{"text":"SHIP STATUS // ","color":"red","bold":true},{"text":"Fabrication Module requires 36 Stone Shards.","color":"gray"}]
execute store result score @s ds_resource_count run clear @s dai_starfall:coal_shard 0
execute unless score @s ds_resource_count matches 27.. run scoreboard players set @s ds_patch 0
execute unless score @s ds_resource_count matches 27.. run tellraw @s [{"text":"SHIP STATUS // ","color":"red","bold":true},{"text":"Fabrication Module requires 27 Coal Shards.","color":"gray"}]
execute store result score @s ds_resource_count run clear @s dai_starfall:wood_shard 0
execute unless score @s ds_resource_count matches 18.. run scoreboard players set @s ds_patch 0
execute unless score @s ds_resource_count matches 18.. run tellraw @s [{"text":"SHIP STATUS // ","color":"red","bold":true},{"text":"Fabrication Module requires 18 Wood Shards.","color":"gray"}]
execute store result score @s ds_resource_count run clear @s dai_starfall:glass_shard 0
execute unless score @s ds_resource_count matches 18.. run scoreboard players set @s ds_patch 0
execute unless score @s ds_resource_count matches 18.. run tellraw @s [{"text":"SHIP STATUS // ","color":"red","bold":true},{"text":"Fabrication Module requires 18 Glass Shards.","color":"gray"}]
execute store result score @s ds_resource_count run clear @s dai_starfall:crystal_shard 0
execute unless score @s ds_resource_count matches 9.. run scoreboard players set @s ds_patch 0
execute unless score @s ds_resource_count matches 9.. run tellraw @s [{"text":"SHIP STATUS // ","color":"red","bold":true},{"text":"Fabrication Module requires 9 Crystal Shards.","color":"gray"}]
execute if score @s ds_patch matches 1 run function dai_starfall:ship/upgrade_module_apply
