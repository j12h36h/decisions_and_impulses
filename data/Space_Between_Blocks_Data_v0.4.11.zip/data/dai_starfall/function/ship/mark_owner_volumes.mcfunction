execute store result storage dai_starfall:protect nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:protect nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:protect nav_z int 1 run scoreboard players get @s ds_nav_z
execute store result storage dai_starfall:protect ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:ship/mark_escape_macro with storage dai_starfall:protect
function dai_starfall:ship/mark_flagship_macro with storage dai_starfall:protect
