$execute positioned $(nav_x) $(nav_y) $(nav_z) run fill ~-8 ~ ~-6 ~-8 ~2 ~23 minecraft:polished_deepslate replace minecraft:iron_block
$execute positioned $(nav_x) $(nav_y) $(nav_z) run fill ~8 ~ ~-6 ~8 ~2 ~23 minecraft:polished_deepslate replace minecraft:iron_block
