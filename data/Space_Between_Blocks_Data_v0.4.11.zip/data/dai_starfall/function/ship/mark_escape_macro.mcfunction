$execute positioned $(nav_x) $(nav_y) $(nav_z) positioned ~-28 ~-2 ~-10 run tag @a[dx=56,dy=18,dz=190] add ds_in_ship
