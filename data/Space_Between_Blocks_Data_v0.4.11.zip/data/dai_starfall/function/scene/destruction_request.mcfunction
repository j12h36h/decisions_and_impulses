# Server latch: cinematic must complete before physical flagship destruction begins.
scoreboard players set @s ds_phase 55
advancement grant @s only dai_starfall:state/destruction_pending
effect give @s minecraft:resistance 20 255 true
effect give @s minecraft:slowness 15 255 true
title @s actionbar {text:"EXTRACTION PLATFORM // UNKNOWN ENERGY SIGNATURE",color:"red",bold:true}
