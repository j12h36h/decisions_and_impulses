gamemode adventure @s
scoreboard players set @s ds_scene 0
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/teleport_ship_macro with storage dai_starfall:ctx
function dai_starfall:player/set_ship_spawn_macro with storage dai_starfall:ctx
effect clear @s minecraft:slow_falling
effect give @s minecraft:darkness 4 0 true
title @s times 20 60 20
title @s title {text:"...",color:"gray"}
tellraw @s {text:"LIFE SUPPORT // occupant response detected",color:"dark_gray"}
