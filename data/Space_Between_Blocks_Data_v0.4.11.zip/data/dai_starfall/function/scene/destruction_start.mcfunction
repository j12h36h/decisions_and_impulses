advancement revoke @s only dai_starfall:state/destruction_pending
scoreboard players set @s ds_phase 6
function dai_starfall:physics/restore_normal
scoreboard players set @s ds_scene 0
effect give @s minecraft:slowness 6 255 true
effect give @s minecraft:resistance 20 255 true
teleport @s ~ ~ ~ 180 -55
title @s times 5 35 10
title @s title {text:"EXTRACTION SIGNAL LOST",color:"red",bold:true}
title @s subtitle {text:"...look up",color:"gray"}
