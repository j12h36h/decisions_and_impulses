scoreboard players set @s ds_phase 10
scoreboard players set @s ds_scene 0
effect clear @s minecraft:darkness
effect clear @s minecraft:resistance
tellraw @s [{"text":"OBJECTIVE // ","color":"dark_purple","bold":true},{"text":"Use the cockpit navigation terminal to select Aurod, Dunoga, or Virelia and execute orbital transfer. Then use the rear DROP control.","color":"white"}]

function dai_starfall:item/give_recall
