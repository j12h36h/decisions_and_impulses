gamemode survival @s
# Landing recovery also seals the flagship hatch, even if an earlier phase transition was missed.
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:scene/close_flagship_hatch_macro with storage dai_starfall:ctx
scoreboard players set @s ds_phase 4
function dai_starfall:physics/apply_aurod
scoreboard players set @s ds_vines 0
scoreboard players set @s ds_vines_aux 0
scoreboard players set @s ds_vines_inventory 0
scoreboard players set @s ds_vines_seen 0
scoreboard players set @s ds_ui_complete 0
scoreboard players set @s ds_touchdown 0
function dai_starfall:scene/update_vinewood_count
function dai_starfall:ui/sync_quest_bars
title @s times 5 40 10
title @s title {text:"SURFACE DETAIL",color:"gold",bold:true}
title @s subtitle {text:"Collect and carry 12 Aurod Vinewood",color:"white"}
tellraw @s [{"text":"OBJECTIVE // ","color":"gold","bold":true},{"text":"Collect and carry 12 Aurod Vinewood. Progress tracks what is in your inventory.","color":"white"}]
effect give @s minecraft:resistance 3 255 true
