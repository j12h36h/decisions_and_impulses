clear @s dai_starfall:ship_recall
execute if score @s ds_phase matches 10..17 run give @s dai_starfall:ship_recall 1
tag @s add ds_recall_v041
