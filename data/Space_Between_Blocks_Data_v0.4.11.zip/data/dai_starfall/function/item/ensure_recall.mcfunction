# Maintain exactly one recall beacon once the escape craft is online.
scoreboard players set @s ds_resource_count 0
execute if score @s ds_phase matches 10..17 store result score @s ds_resource_count run clear @s dai_starfall:ship_recall 0
execute if score @s ds_phase matches 10..17 if score @s ds_resource_count matches 0 run give @s dai_starfall:ship_recall 1
execute if score @s ds_phase matches 10..17 if score @s ds_resource_count matches 2.. run clear @s dai_starfall:ship_recall
execute if score @s ds_phase matches 10..17 if score @s ds_resource_count matches 2.. run give @s dai_starfall:ship_recall 1
