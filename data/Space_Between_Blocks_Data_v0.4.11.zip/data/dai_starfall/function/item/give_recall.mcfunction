function dai_starfall:item/ensure_recall
execute if score @s ds_phase matches 10..17 run tellraw @s [{"text":"SHIP LINK // ","color":"light_purple","bold":true},{"text":"Escape Recall Beacon online. Right-click from a planetary surface to return to this craft.","color":"white"}]
