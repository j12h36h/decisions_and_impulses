# v0.3.0: return prevents the newly replaced tool from matching the next branch in the same tick.
execute if items entity @s weapon.mainhand minecraft:iron_axe[minecraft:custom_data~{dai_starfall:{multitool:1b,mode:'axe'}}] run return run function dai_starfall:item/to_pickaxe
execute if items entity @s weapon.mainhand minecraft:iron_pickaxe[minecraft:custom_data~{dai_starfall:{multitool:1b,mode:'pickaxe'}}] run return run function dai_starfall:item/to_shovel
execute if items entity @s weapon.mainhand minecraft:iron_shovel[minecraft:custom_data~{dai_starfall:{multitool:1b,mode:'shovel'}}] run return run function dai_starfall:item/to_axe
scoreboard players set @s ds_mt_spin 0
