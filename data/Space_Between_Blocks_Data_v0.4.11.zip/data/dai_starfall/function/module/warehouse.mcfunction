function dai_starfall:module/core
setblock ~-4 ~1 ~1 minecraft:chest[facing=north,type=left]
setblock ~-3 ~1 ~1 minecraft:chest[facing=north,type=right]
setblock ~2 ~1 ~1 minecraft:chest[facing=north,type=left]
setblock ~3 ~1 ~1 minecraft:chest[facing=north,type=right]
setblock ~-4 ~2 ~2 minecraft:oak_sign[rotation=8]{front_text:{messages:['{"text":"RAW"}','{"text":"Storage"}','{"text":""}','{"text":""}']}}
setblock ~2 ~2 ~2 minecraft:oak_sign[rotation=8]{front_text:{messages:['{"text":"TOOLS"}','{"text":"Storage"}','{"text":""}','{"text":""}']}}
fill ~-5 ~1 ~5 ~5 ~3 ~5 minecraft:barrel[facing=up]
