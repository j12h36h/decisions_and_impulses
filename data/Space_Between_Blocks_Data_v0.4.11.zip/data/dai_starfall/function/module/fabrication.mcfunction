# 15x10 fabrication module attached behind the escape-craft drop bay.
function dai_starfall:module/core
setblock ~-4 ~1 ~1 minecraft:crafting_table
setblock ~4 ~1 ~1 minecraft:smithing_table
setblock ~-4 ~1 ~4 minecraft:barrel[facing=up]
setblock ~4 ~1 ~4 minecraft:barrel[facing=up]
setblock ~0 ~1 ~4 minecraft:stonecutter
setblock ~0 ~5 ~6 minecraft:light[level=15]
fill ~-4 ~1 ~-5 ~4 ~1 ~-4 minecraft:copper_block
