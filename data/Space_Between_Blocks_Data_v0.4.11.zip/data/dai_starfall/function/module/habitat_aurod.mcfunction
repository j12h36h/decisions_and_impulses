function dai_starfall:module/core
fill ~-5 ~1 ~-4 ~5 ~5 ~4 minecraft:air
fill ~-5 ~1 ~-4 ~5 ~1 ~4 minecraft:dirt
fill ~-5 ~2 ~-4 ~5 ~5 ~-4 minecraft:glass_pane
fill ~-5 ~2 ~4 ~5 ~5 ~4 minecraft:glass_pane
fill ~-5 ~2 ~-3 ~-5 ~5 ~3 minecraft:glass_pane
fill ~5 ~2 ~-3 ~5 ~5 ~3 minecraft:glass_pane
fill ~-4 ~2 ~-3 ~4 ~5 ~3 minecraft:air
setblock ~0 ~1 ~0 minecraft:stripped_jungle_wood
setblock ~0 ~2 ~0 minecraft:jungle_leaves[persistent=true]
setblock ~1 ~1 ~0 minecraft:mangrove_roots
setblock ~-1 ~1 ~1 minecraft:mangrove_roots
