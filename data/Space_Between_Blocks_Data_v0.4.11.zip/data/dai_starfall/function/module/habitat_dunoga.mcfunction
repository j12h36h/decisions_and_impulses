function dai_starfall:module/core
fill ~-5 ~1 ~-4 ~5 ~5 ~4 minecraft:air
fill ~-5 ~1 ~-4 ~5 ~1 ~4 minecraft:blackstone
fill ~-5 ~2 ~-4 ~5 ~5 ~-4 minecraft:glass_pane
fill ~-5 ~2 ~4 ~5 ~5 ~4 minecraft:glass_pane
fill ~-5 ~2 ~-3 ~-5 ~5 ~3 minecraft:glass_pane
fill ~5 ~2 ~-3 ~5 ~5 ~3 minecraft:glass_pane
setblock ~0 ~1 ~0 dai_starfall:dunoga_crystallite
setblock ~2 ~1 ~1 dai_starfall:dunoga_coal_block
setblock ~-2 ~1 ~-1 dai_starfall:dunoga_coal_block
