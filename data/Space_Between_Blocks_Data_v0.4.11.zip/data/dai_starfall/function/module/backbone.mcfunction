# Central module backbone corridor for v0.4.3 expansions.
fill ~-3 ~ ~-6 ~3 ~ ~116 minecraft:polished_blackstone
fill ~-4 ~1 ~-6 ~4 ~6 ~116 minecraft:iron_block
fill ~-3 ~1 ~-5 ~3 ~5 ~115 minecraft:air
fill ~-4 ~7 ~-6 ~4 ~7 ~116 minecraft:smooth_quartz
setblock ~0 ~4 ~0 minecraft:light[level=15]
setblock ~0 ~4 ~15 minecraft:light[level=15]
setblock ~0 ~4 ~30 minecraft:light[level=15]
setblock ~0 ~4 ~45 minecraft:light[level=15]
setblock ~0 ~4 ~60 minecraft:light[level=15]
setblock ~0 ~4 ~75 minecraft:light[level=15]
setblock ~0 ~4 ~90 minecraft:light[level=15]
setblock ~0 ~4 ~105 minecraft:light[level=15]
