function dai_starfall:module/core
setblock ~-4 ~1 ~0 minecraft:smoker
setblock ~4 ~1 ~0 minecraft:furnace
setblock ~0 ~1 ~3 minecraft:crafting_table
setblock ~-4 ~1 ~4 minecraft:barrel[facing=up]
setblock ~4 ~1 ~4 minecraft:barrel[facing=up]
setblock ~0 ~1 ~-2 minecraft:water_cauldron[level=3]
fill ~-3 ~1 ~6 ~3 ~2 ~6 minecraft:copper_block
