function dai_starfall:module/core
setblock ~-3 ~1 ~2 minecraft:red_bed[facing=south,part=foot]
setblock ~-3 ~1 ~3 minecraft:red_bed[facing=south,part=head]
setblock ~3 ~1 ~2 minecraft:red_bed[facing=south,part=foot]
setblock ~3 ~1 ~3 minecraft:red_bed[facing=south,part=head]
setblock ~0 ~1 ~-2 minecraft:loom
setblock ~0 ~1 ~4 minecraft:chiseled_bookshelf[slot_0_occupied=false,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=false,slot_5_occupied=false,facing=north]
