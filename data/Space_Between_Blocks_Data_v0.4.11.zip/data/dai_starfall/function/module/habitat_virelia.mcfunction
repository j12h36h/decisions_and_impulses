function dai_starfall:module/core
fill ~-5 ~1 ~-4 ~5 ~5 ~4 minecraft:air
fill ~-5 ~1 ~-4 ~5 ~1 ~4 minecraft:moss_block
fill ~-5 ~2 ~-4 ~5 ~5 ~-4 minecraft:glass_pane
fill ~-5 ~2 ~4 ~5 ~5 ~4 minecraft:glass_pane
fill ~-5 ~2 ~-3 ~-5 ~5 ~3 minecraft:glass_pane
fill ~5 ~2 ~-3 ~5 ~5 ~3 minecraft:glass_pane
setblock ~0 ~1 ~0 minecraft:mangrove_log
setblock ~1 ~1 ~1 minecraft:mangrove_roots
setblock ~-1 ~2 ~-1 dai_starfall:aexi_cluster
