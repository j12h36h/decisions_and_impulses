function dai_starfall:module/core
setblock ~-4 ~1 ~0 minecraft:smithing_table
setblock ~4 ~1 ~0 minecraft:grindstone[facing=north]
setblock ~0 ~1 ~3 minecraft:anvil
setblock ~-4 ~1 ~4 minecraft:barrel[facing=up]
setblock ~4 ~1 ~4 minecraft:barrel[facing=up]
fill ~-3 ~2 ~6 ~3 ~4 ~6 minecraft:iron_bars
