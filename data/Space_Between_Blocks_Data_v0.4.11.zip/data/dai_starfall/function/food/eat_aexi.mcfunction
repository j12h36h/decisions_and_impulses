clear @s dai_starfall:aexi 1
effect give @s minecraft:saturation 1 1 true
effect give @s minecraft:regeneration 3 0 true
playsound minecraft:entity.generic.eat player @s ~ ~ ~ 0.7 1.3
tellraw @s [{"text":"AEXI // ","color":"gold","bold":true},{"text":"sweet citrus fibers restore you.","color":"white"}]
