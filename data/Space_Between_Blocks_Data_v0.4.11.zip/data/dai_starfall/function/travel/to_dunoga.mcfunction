gamemode survival @s
effect clear @s minecraft:slow_falling
function dai_starfall:physics/apply_dunoga
effect give @s minecraft:resistance 35 255 true
teleport @s -55.5 80.0 199944.5 135 72
scoreboard players set @s ds_phase 14
execute store result storage dai_starfall:nav nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:nav nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:nav nav_z int 1 run scoreboard players get @s ds_nav_z
function dai_starfall:travel/close_ship_hatch_macro with storage dai_starfall:nav
title @s times 5 30 5
title @s title {text:"DUNOGA",color:"light_purple",bold:true}
title @s subtitle {text:"1.75G // CHARCOAL CRYSTALLITE CAVERNS",color:"gray"}
playsound minecraft:entity.elytra.flying master @s ~ ~ ~ 1.3 0.55
