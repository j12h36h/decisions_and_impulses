# Migration-safe navigation state initialization for pre-v0.3.0 saves.
scoreboard players operation @s ds_nav_x = @s ds_ship_x
scoreboard players set @s ds_nav_y 67
scoreboard players set @s ds_nav_z 700
scoreboard players operation @s ds_orbit_x = @s ds_ship
scoreboard players remove @s ds_orbit_x 1
scoreboard players operation @s ds_orbit_x *= #orbit_spacing ds_global
scoreboard players set @s ds_destination 1
scoreboard players set @s ds_orbit_ready 0
scoreboard players set @s ds_travel_pending 0

scoreboard players set @s ds_orbit_attempt 0
