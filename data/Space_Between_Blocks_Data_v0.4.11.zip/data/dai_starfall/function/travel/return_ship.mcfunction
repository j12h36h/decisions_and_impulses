gamemode adventure @s
function dai_starfall:physics/restore_normal
execute store result storage dai_starfall:nav nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:nav nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:nav nav_z int 1 run scoreboard players get @s ds_nav_z
function dai_starfall:travel/return_ship_macro with storage dai_starfall:nav
scoreboard players set @s ds_phase 10
scoreboard players set @s ds_orbit_ready 1
effect give @s minecraft:resistance 2 255 true
title @s title {text:"SHIP LINK RESTORED",color:"gold",bold:true}
execute if score @s ds_destination matches 1 run title @s subtitle {text:"AUROD ORBIT",color:"gray"}
execute if score @s ds_destination matches 2 run title @s subtitle {text:"DUNOGA ORBIT",color:"light_purple"}

execute if score @s ds_destination matches 3 run title @s subtitle {text:"VIRELIA ORBIT",color:"green"}
