scoreboard players set @s ds_phase 15
effect give @s minecraft:resistance 3 255 true
particle minecraft:ash ~ ~0.2 ~ 2.2 0.5 2.2 0.04 80 force @a[distance=..96]
playsound minecraft:block.basalt.break master @s ~ ~ ~ 0.9 0.55
tellraw @s [{"text":"DUNOGA // ","color":"light_purple","bold":true},{"text":"1.75G gravity lock. Navigate the cavern maze; crystallite growths are harvestable with the MultiTool pickaxe.","color":"white"}]
tellraw @s [{"text":"OBJECTIVE // ","color":"dark_purple","bold":true},{"text":"Reach the extraction beacon at the far side of the cavern when ready to return.","color":"gold"}]
