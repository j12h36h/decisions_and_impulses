# Aurod orbital target.
scoreboard players operation @s ds_target_x = @s ds_orbit_x
scoreboard players set @s ds_target_y 220
scoreboard players set @s ds_target_z 100000
scoreboard players set @s ds_travel_pending 1
execute if score @s ds_target_x = @s ds_nav_x if score @s ds_target_y = @s ds_nav_y if score @s ds_target_z = @s ds_nav_z run function dai_starfall:travel/already_in_orbit
execute if score @s ds_travel_pending matches 1 run function dai_starfall:travel/begin_transfer
