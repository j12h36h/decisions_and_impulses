effect give @s minecraft:slow_falling 2 0 true
title @s actionbar {text:"NAV // DESTINATION SURFACE SYNCHRONIZING",color:"gold",bold:true}
