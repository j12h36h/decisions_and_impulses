scoreboard players set @s ds_phase 17
spawnpoint @s -72 60 299928
effect clear @s minecraft:resistance
title @s times 5 35 8
title @s title {text:"VIRELIA CANOPY",color:"green",bold:true}
title @s subtitle {text:"Reach the far extraction crown. Watch the swamp below.",color:"gold"}
tellraw @s [{"text":"FIELD NOTE // ","color":"green","bold":true},{"text":"Aexi fruit hangs beneath orange-forked canopy clusters. Space Gators patrol the waterline.","color":"white"}]
