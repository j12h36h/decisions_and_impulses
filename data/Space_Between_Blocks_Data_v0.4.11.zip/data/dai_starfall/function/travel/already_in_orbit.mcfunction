scoreboard players operation @s ds_destination = @s ds_travel_pending
scoreboard players set @s ds_travel_pending 0
scoreboard players set @s ds_orbit_ready 1
tellraw @s [{"text":"NAV // ","color":"dark_purple","bold":true},{"text":"Escape craft is already in the selected orbital slot.","color":"gold"}]
