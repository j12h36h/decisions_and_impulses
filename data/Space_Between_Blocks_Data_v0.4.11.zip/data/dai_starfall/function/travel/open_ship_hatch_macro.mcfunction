$execute positioned $(nav_x) $(nav_y) $(nav_z) run fill ~-3 ~-1 ~15 ~3 ~-1 ~21 minecraft:air
