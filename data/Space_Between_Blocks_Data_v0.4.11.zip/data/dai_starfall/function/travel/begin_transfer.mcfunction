scoreboard players set @s ds_orbit_attempt 0
execute store result storage dai_starfall:nav target_x int 1 run scoreboard players get @s ds_target_x
execute store result storage dai_starfall:nav target_y int 1 run scoreboard players get @s ds_target_y
execute store result storage dai_starfall:nav target_z int 1 run scoreboard players get @s ds_target_z
function dai_starfall:travel/forceload_target_macro with storage dai_starfall:nav
effect give @s minecraft:resistance 8 255 true
title @s times 5 30 5
title @s title {text:"ORBITAL TRANSFER",color:"light_purple",bold:true}
title @s subtitle {text:"Relocating escape craft...",color:"gray"}
