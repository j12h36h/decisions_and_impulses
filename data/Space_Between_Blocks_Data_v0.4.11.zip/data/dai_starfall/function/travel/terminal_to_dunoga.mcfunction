# Dunoga orbital target and lazy surface preparation.
scoreboard players operation @s ds_target_x = @s ds_orbit_x
scoreboard players set @s ds_target_y 220
scoreboard players set @s ds_target_z 200000
scoreboard players set @s ds_travel_pending 2
scoreboard players set @s ds_destination 2
execute unless score #dunoga_built ds_global matches 1 unless score #dunoga_preparing ds_global matches 1 run function dai_starfall:build/prepare_shared_dunoga
execute if score @s ds_target_x = @s ds_nav_x if score @s ds_target_y = @s ds_nav_y if score @s ds_target_z = @s ds_nav_z run function dai_starfall:travel/already_in_orbit
execute if score @s ds_travel_pending matches 2 run function dai_starfall:travel/begin_transfer
