scoreboard players set @s ds_phase 11
execute store result storage dai_starfall:nav nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:nav nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:nav nav_z int 1 run scoreboard players get @s ds_nav_z
function dai_starfall:travel/open_ship_hatch_macro with storage dai_starfall:nav
effect give @s minecraft:resistance 18 255 true
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 2 0.65
title @s actionbar {text:"DROP HATCH OPEN // JUMP",color:"gold",bold:true}
