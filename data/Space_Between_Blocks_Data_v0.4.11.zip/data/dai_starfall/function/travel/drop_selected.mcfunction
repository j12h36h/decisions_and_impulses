execute if score @s ds_destination matches 1 if score #aurod_built ds_global matches 1 run function dai_starfall:travel/to_aurod
execute if score @s ds_destination matches 1 unless score #aurod_built ds_global matches 1 run function dai_starfall:travel/surface_not_ready
execute if score @s ds_destination matches 2 if score #dunoga_built ds_global matches 1 run function dai_starfall:travel/to_dunoga
execute if score @s ds_destination matches 2 unless score #dunoga_built ds_global matches 1 run function dai_starfall:travel/surface_not_ready
execute if score @s ds_destination matches 3 if score #virelia_built ds_global matches 1 run function dai_starfall:travel/to_virelia
execute if score @s ds_destination matches 3 unless score #virelia_built ds_global matches 1 run function dai_starfall:travel/surface_not_ready
