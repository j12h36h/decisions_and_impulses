# Compute full-craft relocation offsets.
scoreboard players operation @s ds_shift_x = @s ds_target_x
scoreboard players operation @s ds_shift_x -= @s ds_nav_x
scoreboard players operation @s ds_shift_y = @s ds_target_y
scoreboard players operation @s ds_shift_y -= @s ds_nav_y
scoreboard players operation @s ds_shift_z = @s ds_target_z
scoreboard players operation @s ds_shift_z -= @s ds_nav_z
scoreboard players operation @s ds_delta_x = @s ds_shift_x
scoreboard players remove @s ds_delta_x 8
scoreboard players operation @s ds_delta_y = @s ds_shift_y
scoreboard players remove @s ds_delta_y 1
scoreboard players operation @s ds_delta_z = @s ds_shift_z
scoreboard players remove @s ds_delta_z 7
execute store result storage dai_starfall:nav source_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:nav source_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:nav source_z int 1 run scoreboard players get @s ds_nav_z
execute store result storage dai_starfall:nav target_x int 1 run scoreboard players get @s ds_target_x
execute store result storage dai_starfall:nav target_y int 1 run scoreboard players get @s ds_target_y
execute store result storage dai_starfall:nav target_z int 1 run scoreboard players get @s ds_target_z
execute store result storage dai_starfall:nav delta_x int 1 run scoreboard players get @s ds_delta_x
execute store result storage dai_starfall:nav delta_y int 1 run scoreboard players get @s ds_delta_y
execute store result storage dai_starfall:nav delta_z int 1 run scoreboard players get @s ds_delta_z
execute store result storage dai_starfall:nav shift_x int 1 run scoreboard players get @s ds_shift_x
execute store result storage dai_starfall:nav shift_y int 1 run scoreboard players get @s ds_shift_y
execute store result storage dai_starfall:nav shift_z int 1 run scoreboard players get @s ds_shift_z
function dai_starfall:travel/move_ship_macro with storage dai_starfall:nav
scoreboard players operation @s ds_nav_x = @s ds_target_x
scoreboard players operation @s ds_nav_y = @s ds_target_y
scoreboard players operation @s ds_nav_z = @s ds_target_z
scoreboard players operation @s ds_orbit_x = @s ds_target_x
scoreboard players operation @s ds_destination = @s ds_travel_pending
scoreboard players set @s ds_travel_pending 0
scoreboard players set @s ds_orbit_ready 1
title @s title {text:"ORBIT ESTABLISHED",color:"gold",bold:true}
execute if score @s ds_destination matches 1 run title @s subtitle {text:"AUROD // T:16950",color:"light_purple"}
execute if score @s ds_destination matches 2 run title @s subtitle {text:"DUNOGA // HEAVY GRAVITY",color:"light_purple"}
execute if score @s ds_destination matches 3 run title @s subtitle {text:"VIRELIA // CANOPY SWAMP",color:"green"}
