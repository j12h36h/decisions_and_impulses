execute if score @s ds_phase matches 10..17 run function dai_starfall:travel/return_ship
execute unless score @s ds_phase matches 10..17 run tellraw @s [{"text":"SHIP LINK // ","color":"red","bold":true},{"text":"Recall unavailable until the escape craft is online.","color":"gray"}]
