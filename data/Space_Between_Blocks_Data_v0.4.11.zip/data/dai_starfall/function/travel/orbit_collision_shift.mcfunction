# Another physical escape craft occupies this orbital lane. Release it and probe the next lane.
execute store result storage dai_starfall:nav target_x int 1 run scoreboard players get @s ds_target_x
execute store result storage dai_starfall:nav target_z int 1 run scoreboard players get @s ds_target_z
function dai_starfall:travel/release_target_macro with storage dai_starfall:nav
scoreboard players add @s ds_target_x 48
scoreboard players add @s ds_orbit_attempt 1
execute if score @s ds_orbit_attempt matches 32.. run tellraw @s [{"text":"NAV // ","color":"red","bold":true},{"text":"Orbital allocation saturated; transfer aborted.","color":"gray"}]
execute if score @s ds_orbit_attempt matches 32.. run scoreboard players set @s ds_travel_pending 0
execute if score @s ds_orbit_attempt matches 32.. run return 1
execute store result storage dai_starfall:nav target_x int 1 run scoreboard players get @s ds_target_x
execute store result storage dai_starfall:nav target_y int 1 run scoreboard players get @s ds_target_y
execute store result storage dai_starfall:nav target_z int 1 run scoreboard players get @s ds_target_z
function dai_starfall:travel/forceload_target_macro with storage dai_starfall:nav
tellraw @s [{"text":"NAV // ","color":"gold","bold":true},{"text":"Occupied orbital lane detected. Aligning next multiplayer slot...","color":"gray"}]
