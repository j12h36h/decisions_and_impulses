$execute positioned $(target_x) $(target_y) $(target_z) if loaded ~ ~ ~ if block ~ ~-1 ~ minecraft:air run function dai_starfall:travel/move_ship_commit
$execute positioned $(target_x) $(target_y) $(target_z) if loaded ~ ~ ~ unless block ~ ~-1 ~ minecraft:air run function dai_starfall:travel/orbit_collision_shift
