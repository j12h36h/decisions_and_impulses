scoreboard players operation @s ds_target_x = @s ds_orbit_x
scoreboard players set @s ds_target_y 220
scoreboard players set @s ds_target_z 300000
scoreboard players set @s ds_travel_pending 3
scoreboard players set @s ds_destination 3
execute unless score #virelia_built ds_global matches 1 unless score #virelia_preparing ds_global matches 1 run function dai_starfall:build/prepare_shared_virelia
execute if score @s ds_target_x = @s ds_nav_x if score @s ds_target_y = @s ds_nav_y if score @s ds_target_z = @s ds_nav_z run function dai_starfall:travel/already_in_orbit
execute if score @s ds_travel_pending matches 3 run function dai_starfall:travel/begin_transfer
