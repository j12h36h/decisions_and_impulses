# Clone the complete escape craft, including optional rear module, while both source and destination are loaded.
$execute positioned $(source_x) $(source_y) $(source_z) run clone ~-8 ~-1 ~-7 ~8 ~11 ~40 ~$(delta_x) ~$(delta_y) ~$(delta_z) replace force
# Every player physically aboard moves with the ship, not only the owner who pressed TRAVEL.
$execute positioned $(source_x) $(source_y) $(source_z) positioned ~-8 ~-1 ~-7 as @a[dx=16,dy=12,dz=47] at @s run teleport @s ~$(shift_x) ~$(shift_y) ~$(shift_z)
$spawnpoint @s $(target_x) $(target_y) $(target_z)
$execute positioned $(source_x) $(source_y) $(source_z) run fill ~-8 ~-1 ~-7 ~8 ~11 ~40 minecraft:air
$execute positioned $(target_x) 0 $(target_z) run forceload remove ~-32 ~-32 ~32 ~32
