execute store result storage dai_starfall:nav target_x int 1 run scoreboard players get @s ds_target_x
execute store result storage dai_starfall:nav target_y int 1 run scoreboard players get @s ds_target_y
execute store result storage dai_starfall:nav target_z int 1 run scoreboard players get @s ds_target_z
function dai_starfall:travel/check_transfer_macro with storage dai_starfall:nav
