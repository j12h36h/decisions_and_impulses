$execute positioned $(target_x) 0 $(target_z) run forceload remove ~-32 ~-32 ~32 ~32
