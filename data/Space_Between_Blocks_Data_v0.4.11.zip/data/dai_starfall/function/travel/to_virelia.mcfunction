effect clear @s minecraft:slow_falling
function dai_starfall:physics/restore_normal
gamemode survival @s
effect give @s minecraft:resistance 25 255 true
teleport @s -72.5 86.0 299928.5 45 72
scoreboard players set @s ds_phase 16
execute store result storage dai_starfall:nav nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:nav nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:nav nav_z int 1 run scoreboard players get @s ds_nav_z
function dai_starfall:travel/close_ship_hatch_macro with storage dai_starfall:nav
title @s times 5 30 5
title @s title {text:"VIRELIA",color:"green",bold:true}
title @s subtitle {text:"CANOPY PARKOUR // AEXI SWAMP",color:"gold"}
playsound minecraft:entity.elytra.flying master @s ~ ~ ~ 1.3 0.8
