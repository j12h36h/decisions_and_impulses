gamemode survival @s
effect clear @s minecraft:slow_falling
function dai_starfall:physics/apply_aurod
effect give @s minecraft:resistance 35 255 true
# Planetfall is deliberately offset from the z=100000 orbital ship line; the old center drop landed on the ship roof.
teleport @s -80.5 270.0 99960.5 35 78
scoreboard players set @s ds_phase 13
execute store result storage dai_starfall:nav nav_x int 1 run scoreboard players get @s ds_nav_x
execute store result storage dai_starfall:nav nav_y int 1 run scoreboard players get @s ds_nav_y
execute store result storage dai_starfall:nav nav_z int 1 run scoreboard players get @s ds_nav_z
function dai_starfall:travel/close_ship_hatch_macro with storage dai_starfall:nav
title @s times 5 30 5
title @s title {text:"AUROD",color:"gold",bold:true}
title @s subtitle {text:"T:16950 // SHARED",color:"light_purple"}
playsound minecraft:entity.elytra.flying master @s ~ ~ ~ 1.3 0.7
