# Runtime-side companion to the flattened DAI action id used by aexi.events.use.
function dai_starfall:food/eat_aexi
