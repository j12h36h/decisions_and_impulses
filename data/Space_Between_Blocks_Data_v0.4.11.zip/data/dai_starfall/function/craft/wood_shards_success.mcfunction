give @s dai_starfall:wood_shard 9
playsound minecraft:block.wood.break player @s ~ ~ ~ 0.55 1.4
tellraw @s [{"text":"CRAFT // ","color":"gold","bold":true},{"text":"Aurod Vinewood -> Wood Shard x9","color":"white"}]
