scoreboard players set @s ds_resource_count 0
execute store result score @s ds_resource_count run clear @s dai_starfall:dunoga_coal_block 0
execute if score @s ds_resource_count matches 1.. run clear @s dai_starfall:dunoga_coal_block 1
execute if score @s ds_resource_count matches 1.. run give @s dai_starfall:coal_shard 9
execute if score @s ds_resource_count matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.6 1.35
execute if score @s ds_resource_count matches 1.. run tellraw @s [{"text":"CRAFT // ","color":"gold","bold":true},{"text":"Dunoga Coal Block -> Coal Shard x9","color":"white"}]
execute unless score @s ds_resource_count matches 1.. run tellraw @s [{"text":"CRAFT // ","color":"red","bold":true},{"text":"Requires 1 Dunoga Coal Block.","color":"gray"}]
