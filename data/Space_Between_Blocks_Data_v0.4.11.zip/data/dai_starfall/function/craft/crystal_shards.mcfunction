scoreboard players set @s ds_resource_count 0
execute store result score @s ds_resource_count run clear @s dai_starfall:dunoga_crystallite 0
execute if score @s ds_resource_count matches 1.. run clear @s dai_starfall:dunoga_crystallite 1
execute if score @s ds_resource_count matches 1.. run give @s dai_starfall:crystal_shard 9
execute if score @s ds_resource_count matches 1.. run playsound minecraft:block.amethyst_cluster.break player @s ~ ~ ~ 0.65 1.1
execute if score @s ds_resource_count matches 1.. run tellraw @s [{"text":"CRAFT // ","color":"gold","bold":true},{"text":"Crystallite -> Crystal Shard x9","color":"white"}]
execute unless score @s ds_resource_count matches 1.. run tellraw @s [{"text":"CRAFT // ","color":"red","bold":true},{"text":"Requires 1 Crystallite block.","color":"gray"}]
