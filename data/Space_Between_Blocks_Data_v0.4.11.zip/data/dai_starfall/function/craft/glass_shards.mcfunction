scoreboard players set @s ds_resource_count 0
execute store result score @s ds_resource_count run clear @s minecraft:sand 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:sand 1
execute if score @s ds_resource_count matches 1.. run give @s dai_starfall:glass_shard 9
execute if score @s ds_resource_count matches 1.. run playsound minecraft:block.glass.break player @s ~ ~ ~ 0.65 1.2
execute if score @s ds_resource_count matches 1.. run tellraw @s [{"text":"CRAFT // ","color":"gold","bold":true},{"text":"Sand -> Glass Shard x9","color":"white"}]
execute unless score @s ds_resource_count matches 1.. run tellraw @s [{"text":"CRAFT // ","color":"red","bold":true},{"text":"Requires 1 Sand block.","color":"gray"}]
