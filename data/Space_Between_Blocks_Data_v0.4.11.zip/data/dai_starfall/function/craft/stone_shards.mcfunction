scoreboard players set @s ds_resource_count 0
execute store result score @s ds_resource_count run clear @s minecraft:stone 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:stone 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:cobblestone 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:cobblestone 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:andesite 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:andesite 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:diorite 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:diorite 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:granite 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:granite 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:deepslate 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:deepslate 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:cobbled_deepslate 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:cobbled_deepslate 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:tuff 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:tuff 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:calcite 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:calcite 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:dripstone_block 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:dripstone_block 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:blackstone 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:blackstone 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:basalt 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:basalt 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:smooth_basalt 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:smooth_basalt 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:stone_bricks 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:stone_bricks 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:cracked_stone_bricks 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:cracked_stone_bricks 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:polished_blackstone 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:polished_blackstone 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:polished_andesite 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:polished_andesite 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:polished_diorite 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:polished_diorite 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:polished_granite 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:polished_granite 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:end_stone 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:end_stone 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/stone_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
tellraw @s [{"text":"CRAFT // ","color":"red","bold":true},{"text":"Requires 1 stone-family block (Stone, Cobblestone, Deepslate, Blackstone, Tuff, Granite, Diorite, Andesite, Basalt, etc.).","color":"gray"}]
