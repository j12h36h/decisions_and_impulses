give @s dai_starfall:stone_shard 9
playsound minecraft:block.stone.break player @s ~ ~ ~ 0.65 1.0
tellraw @s [{"text":"CRAFT // ","color":"gold","bold":true},{"text":"Stone-family block -> Stone Shard x9","color":"white"}]
