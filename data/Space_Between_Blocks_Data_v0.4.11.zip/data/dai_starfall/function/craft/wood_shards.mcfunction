scoreboard players set @s ds_resource_count 0
execute store result score @s ds_resource_count run clear @s minecraft:stripped_jungle_wood 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:stripped_jungle_wood 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/wood_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:mangrove_roots 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:mangrove_roots 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/wood_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:jungle_leaves 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:jungle_leaves 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/wood_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
execute store result score @s ds_resource_count run clear @s minecraft:stripped_jungle_log 0
execute if score @s ds_resource_count matches 1.. run clear @s minecraft:stripped_jungle_log 1
execute if score @s ds_resource_count matches 1.. run function dai_starfall:craft/wood_shards_success
execute if score @s ds_resource_count matches 1.. run return 1
tellraw @s [{"text":"CRAFT // ","color":"red","bold":true},{"text":"Requires 1 Aurod vinewood/log/vine/leaf block.","color":"gray"}]
