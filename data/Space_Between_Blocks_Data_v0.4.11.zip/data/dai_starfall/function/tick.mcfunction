# Space Between Blocks v0.4.2 / DAI 3.8 runtime.

# DAI plays the first-join cinematic before dispatching the server-owned first_join action.
# Untagged players therefore receive safety-only spectator handling without consuming a ship slot.
execute as @a[tag=!ds_player] run function dai_starfall:player/prejoin_safety

# Historical shared-terrain migration.
execute if score #aurod_built ds_global matches 1 unless score #terrain_v114 ds_global matches 1 run scoreboard players set #aurod_built ds_global 0
execute unless score #terrain_v114 ds_global matches 1 if entity @a[tag=ds_player,scores={ds_phase=9..}] run scoreboard players set #terrain_v114 ds_global 1

# Do not build the enormous shared post-crash planet during server startup.
execute if entity @a[tag=ds_player,scores={ds_phase=9..}] unless score #aurod_built ds_global matches 1 unless score #aurod_preparing ds_global matches 1 run function dai_starfall:build/prepare_shared_aurod

# Complete shared Aurod only after every remote chunk band is loaded.
execute if score #aurod_preparing ds_global matches 1 if loaded -220 40 99780 if loaded 220 40 99887 if loaded -220 40 99888 if loaded 220 40 99999 if loaded -220 40 100000 if loaded 220 40 100111 if loaded -220 40 100112 if loaded 220 40 100220 run function dai_starfall:build/finish_shared_aurod


# Dunoga is built lazily only after the first navigation request.
execute if entity @a[tag=ds_player,scores={ds_destination=2}] unless score #dunoga_built ds_global matches 1 unless score #dunoga_preparing ds_global matches 1 run function dai_starfall:build/prepare_shared_dunoga
execute if score #dunoga_preparing ds_global matches 1 if loaded -96 40 199904 if loaded 96 40 200096 run function dai_starfall:build/finish_shared_dunoga


# Virelia gators are amphibious; existing instances receive a breathing guard after pack upgrades.
execute as @e[type=dai_starfall:space_gator,tag=ds_virelia_gator] if entity @s[nbt={OnGround:0b}] at @s if block ~ ~ ~ minecraft:water run effect give @s minecraft:water_breathing 3 0 true

# Virelia builds lazily on first navigation request.
execute if entity @a[tag=ds_player,scores={ds_destination=3}] unless score #virelia_built ds_global matches 1 unless score #virelia_preparing ds_global matches 1 run function dai_starfall:build/prepare_shared_virelia
execute if score #virelia_preparing ds_global matches 1 if loaded -96 40 299904 if loaded 96 40 300096 run function dai_starfall:build/finish_shared_virelia

execute if score #virelia_built ds_global matches 1 unless entity @e[type=dai_starfall:space_gator,tag=ds_virelia_gator,limit=1] run function dai_starfall:build/virelia_spawn_gators

# Existing v0.3 Dunoga worlds migrate vanilla coal blocks to the native resource block once.
execute if score #dunoga_built ds_global matches 1 unless score #dunoga_coal_v040 ds_global matches 1 unless score #dunoga_coal_migrating ds_global matches 1 run function dai_starfall:build/prepare_dunoga_coal_migration
execute if score #dunoga_coal_migrating ds_global matches 1 if loaded -96 40 199904 if loaded 96 40 200096 run function dai_starfall:build/finish_dunoga_coal_migration

# One authoritative player pass replaces the old repeated global @a scans.
execute as @a[tag=ds_player] run function dai_starfall:player/runtime_tick
# Ship volumes are multiplayer-protected regardless of which player owns or visits them.
tag @a remove ds_in_ship
execute as @a[tag=ds_player] run function dai_starfall:ship/mark_owner_volumes

# Aurod artificial infrastructure is protected while natural terrain remains editable.
tag @a remove ds_aurod_structure
execute as @a[tag=ds_player] run function dai_starfall:player/mark_private_aurod_structure
execute as @a[tag=ds_player] run function dai_starfall:player/mark_shared_aurod_structure
execute as @a[tag=ds_in_ship,gamemode=survival] run gamemode adventure @s
execute as @a[tag=ds_aurod_structure,gamemode=survival] run gamemode adventure @s
execute as @a[tag=ds_player,tag=!ds_in_ship,tag=!ds_aurod_structure,scores={ds_phase=4..17},gamemode=adventure] run gamemode survival @s


# Shared Aurod shoreline migration remains global and staged.
execute if score #aurod_built ds_global matches 1 unless score #coast_v116 ds_global matches 0.. run scoreboard players set #coast_v116 ds_global 0
execute if score #aurod_built ds_global matches 1 unless score #coast_wait_v116 ds_global matches 0.. run scoreboard players set #coast_wait_v116 ds_global 0
execute if score #aurod_built ds_global matches 1 if score #coast_v116 ds_global matches ..7 if score #coast_wait_v116 ds_global matches 0 run function dai_starfall:build/patch_shared_coast_v116
execute if score #coast_wait_v116 ds_global matches 1.. run scoreboard players remove #coast_wait_v116 ds_global 1

# Quest bossbars only need 10 Hz viewer synchronization; values remain authoritative.
execute if score #ui_pulse ds_global matches 0 run function dai_starfall:ui/sync_quest_bars
scoreboard players add #ui_pulse ds_global 1
execute if score #ui_pulse ds_global matches 2.. run scoreboard players set #ui_pulse ds_global 0

# v0.4.10 emergency anti-embed recovery for Virelia gators.
execute as @e[type=dai_starfall:space_gator,tag=ds_virelia_gator] at @s unless block ~ ~ ~ minecraft:water unless block ~ ~ ~ minecraft:air if block ~ ~0.6 ~ minecraft:water run tp @s ~ ~0.5 ~
