# Runtime-side companion to the flattened DAI action id used by ship_recall.events.use.
function dai_starfall:travel/recall
