scoreboard objectives add ds_phase dummy
scoreboard objectives add ds_scene dummy
scoreboard objectives add ds_ship dummy
scoreboard objectives add ds_ship_x dummy
scoreboard objectives add ds_vines dummy
scoreboard objectives add ds_vines_aux dummy
scoreboard objectives add ds_vines_inventory dummy
scoreboard objectives add ds_vines_seen dummy
scoreboard objectives add ds_ui_complete dummy
scoreboard objectives add ds_deaths deathCount
scoreboard objectives add ds_seen_deaths dummy
scoreboard objectives add ds_global dummy
scoreboard objectives add ds_init dummy
execute unless score #next_ship ds_global matches -2147483648..2147483647 run scoreboard players set #next_ship ds_global 0
scoreboard players set #ship_spacing ds_global 2048
scoreboard players set #one ds_global 1
scoreboard players set #ui_pulse ds_global 0
scoreboard objectives add ds_patch dummy
scoreboard objectives add ds_y dummy
scoreboard objectives add ds_touchdown dummy
scoreboard objectives add ds_coast dummy
scoreboard objectives add ds_coast_wait dummy

# v0.3.0 navigation / Dunoga state.
scoreboard objectives add ds_nav_x dummy
scoreboard objectives add ds_nav_y dummy
scoreboard objectives add ds_nav_z dummy
scoreboard objectives add ds_orbit_x dummy
scoreboard objectives add ds_destination dummy
scoreboard objectives add ds_orbit_ready dummy
scoreboard objectives add ds_travel_pending dummy
scoreboard objectives add ds_target_x dummy
scoreboard objectives add ds_target_y dummy
scoreboard objectives add ds_target_z dummy
scoreboard objectives add ds_delta_x dummy
scoreboard objectives add ds_delta_y dummy
scoreboard objectives add ds_delta_z dummy
scoreboard players set #orbit_spacing ds_global 48
execute unless score #dunoga_built ds_global matches 0.. run scoreboard players set #dunoga_built ds_global 0
execute unless score #dunoga_preparing ds_global matches 0.. run scoreboard players set #dunoga_preparing ds_global 0

# Persistent multiplayer-safe quest HUD bars are created once per world.
execute unless score #quest_bars ds_global matches 1 run function dai_starfall:ui/init_quest_bars

# Keep collection semantics explicit even when upgrading an existing world with pre-created bossbars.
bossbar set dai_starfall:vinewood_0 name {"text":"AUROD // VINEWOOD COLLECTED 0 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_1 name {"text":"AUROD // VINEWOOD COLLECTED 1 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_2 name {"text":"AUROD // VINEWOOD COLLECTED 2 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_3 name {"text":"AUROD // VINEWOOD COLLECTED 3 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_4 name {"text":"AUROD // VINEWOOD COLLECTED 4 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_5 name {"text":"AUROD // VINEWOOD COLLECTED 5 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_6 name {"text":"AUROD // VINEWOOD COLLECTED 6 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_7 name {"text":"AUROD // VINEWOOD COLLECTED 7 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_8 name {"text":"AUROD // VINEWOOD COLLECTED 8 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_9 name {"text":"AUROD // VINEWOOD COLLECTED 9 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_10 name {"text":"AUROD // VINEWOOD COLLECTED 10 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_11 name {"text":"AUROD // VINEWOOD COLLECTED 11 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_12 name {"text":"AUROD // VINEWOOD COLLECTED 12 / 12","color":"gold","bold":true}

scoreboard objectives add ds_mt_spin dummy
scoreboard objectives add ds_foodkit dummy
scoreboard objectives add ds_feast_ray dummy
scoreboard objectives add ds_feast_state dummy
# DAI 3.8 owns first-join dispatch. Never initialize an untagged player here:
# doing so races on_first_join and allocates/prepares the player twice.
# Existing DAI players may still be reconciled safely during /reload.
execute as @a[tag=ds_player] run function dai_starfall:player/join


# v0.4.1 multiplayer ship / crafting / upgrade state.
scoreboard objectives add ds_orbit_attempt dummy
scoreboard objectives add ds_shift_x dummy
scoreboard objectives add ds_shift_y dummy
scoreboard objectives add ds_shift_z dummy
scoreboard objectives add ds_resource_count dummy
scoreboard objectives add ds_hull_upgrade dummy
scoreboard objectives add ds_module_upgrade dummy
execute unless score #virelia_built ds_global matches 0.. run scoreboard players set #virelia_built ds_global 0
execute unless score #virelia_preparing ds_global matches 0.. run scoreboard players set #virelia_preparing ds_global 0
execute unless score #dunoga_coal_v040 ds_global matches 0.. run scoreboard players set #dunoga_coal_v040 ds_global 0
execute unless score #dunoga_coal_migrating ds_global matches 0.. run scoreboard players set #dunoga_coal_migrating ds_global 0
gamerule minecraft:keep_inventory true

scoreboard objectives add ds_mod_kitchen dummy
scoreboard objectives add ds_mod_armory dummy
scoreboard objectives add ds_mod_barracks dummy
scoreboard objectives add ds_mod_warehouse dummy
scoreboard objectives add ds_hab_aurod dummy
scoreboard objectives add ds_hab_dunoga dummy
scoreboard objectives add ds_hab_virelia dummy
scoreboard objectives add ds_hab_master dummy
