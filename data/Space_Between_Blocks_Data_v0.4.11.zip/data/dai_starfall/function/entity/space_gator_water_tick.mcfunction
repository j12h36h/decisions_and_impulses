# v0.4.10 collision-safe amphibious steering.
# The visual mesh stays large, but the physical hitbox is narrower and every swim step checks body/head clearance.
data merge entity @s {Air:300s}
effect give @s minecraft:water_breathing 3 0 true

# Stop land navigation from fighting the water steering layer.
stopsound @s master minecraft:entity.generic.swim

# Face the nearest player every swim tick so the rendered mesh follows pursuit direction.
execute if entity @p[distance=..40,gamemode=!spectator] run tp @s ~ ~ ~ facing entity @p[distance=..40,gamemode=!spectator,sort=nearest,limit=1] eyes

# Recover only when the entity center is actually embedded in terrain and the space immediately above is open.
execute unless block ~ ~ ~ minecraft:water unless block ~ ~ ~ minecraft:air if block ~ ~0.45 ~ minecraft:water run tp @s ~ ~0.32 ~
execute unless block ~ ~ ~ minecraft:water unless block ~ ~ ~ minecraft:air if block ~ ~0.45 ~ minecraft:air run tp @s ~ ~0.32 ~

# Begin with a candidate pursuit step, then reject it if any sampled point in the gator's physical envelope is solid.
tag @s remove ds_gator_swim_step
execute if entity @p[distance=..40,gamemode=!spectator] run tag @s add ds_gator_swim_step

# Centerline body/head samples.
execute at @s facing entity @p[distance=..40,gamemode=!spectator,sort=nearest,limit=1] eyes unless block ^ ^0.10 ^0.20 minecraft:water unless block ^ ^0.10 ^0.20 minecraft:air run tag @s remove ds_gator_swim_step
execute at @s facing entity @p[distance=..40,gamemode=!spectator,sort=nearest,limit=1] eyes unless block ^ ^0.70 ^0.20 minecraft:water unless block ^ ^0.70 ^0.20 minecraft:air run tag @s remove ds_gator_swim_step
# Left/right body samples cover the actual collision width instead of checking only the center point.
execute at @s facing entity @p[distance=..40,gamemode=!spectator,sort=nearest,limit=1] eyes unless block ^0.52 ^0.10 ^0.20 minecraft:water unless block ^0.52 ^0.10 ^0.20 minecraft:air run tag @s remove ds_gator_swim_step
execute at @s facing entity @p[distance=..40,gamemode=!spectator,sort=nearest,limit=1] eyes unless block ^-0.52 ^0.10 ^0.20 minecraft:water unless block ^-0.52 ^0.10 ^0.20 minecraft:air run tag @s remove ds_gator_swim_step
execute at @s facing entity @p[distance=..40,gamemode=!spectator,sort=nearest,limit=1] eyes unless block ^0.52 ^0.70 ^0.20 minecraft:water unless block ^0.52 ^0.70 ^0.20 minecraft:air run tag @s remove ds_gator_swim_step
execute at @s facing entity @p[distance=..40,gamemode=!spectator,sort=nearest,limit=1] eyes unless block ^-0.52 ^0.70 ^0.20 minecraft:water unless block ^-0.52 ^0.70 ^0.20 minecraft:air run tag @s remove ds_gator_swim_step

# Move only after all clearance samples pass. Small steps prevent the hitbox from tunnelling through roots between ticks.
execute if entity @s[tag=ds_gator_swim_step] at @s facing entity @p[distance=..40,gamemode=!spectator,sort=nearest,limit=1] eyes run tp @s ^ ^ ^0.105

# If a player is above a clear shoreline, make a controlled rise rather than ramming the bank.
execute at @s unless entity @s[tag=ds_gator_swim_step] if entity @p[distance=..40,gamemode=!spectator] facing entity @p[distance=..40,gamemode=!spectator,sort=nearest,limit=1] feet if block ^ ^0.15 ^0.16 minecraft:air if block ^ ^0.75 ^0.16 minecraft:air if block ~ ~-0.2 ~ minecraft:water run tp @s ^ ^0.035 ^0.055

# Idle gators float gently instead of sinking into the swamp floor.
execute unless entity @p[distance=..40,gamemode=!spectator] if block ~ ~0.75 ~ minecraft:water run tp @s ~ ~0.025 ~
tag @s remove ds_gator_swim_step
