# Space Between Blocks v0.4.3

DAI Engine 3.8 main experience. Includes the ship module catalog, expanded shard crafting, updated Aurod/Virelia visual pass, and Virelia restoration fixes.
