execute anchored eyes positioned ^ ^-0.08 ^1.05 run summon minecraft:item_display ~ ~ ~ {Tags:["bd_projectile","bd_ult_knife","bd_ult_new"],billboard:"fixed",view_range:1.5f,shadow_radius:0.0f,item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.5f,0.5f,0.5f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]},item:{id:"blink_daggers:kitty_dagger",count:1}}
scoreboard players operation @e[type=minecraft:item_display,tag=bd_ult_new,limit=1,sort=nearest,distance=..4] bd_owner = @s bd_pid
scoreboard players set @e[type=minecraft:item_display,tag=bd_ult_new,limit=1,sort=nearest,distance=..4] bd_age 0
scoreboard players set @e[type=minecraft:item_display,tag=bd_ult_new,limit=1,sort=nearest,distance=..4] bd_spin 0
execute positioned as @e[type=minecraft:item_display,tag=bd_ult_new,limit=1,sort=nearest,distance=..4] run tp @e[type=minecraft:item_display,tag=bd_ult_new,limit=1,sort=nearest,distance=..4] ~ ~ ~ ~ ~
tag @e[type=minecraft:item_display,tag=bd_ult_new,limit=1,sort=nearest,distance=..4] remove bd_ult_new
