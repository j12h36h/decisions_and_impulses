# [DAI] Kitty's Dagger v0.6.0 / DAI 3.3 addon tick

# One player selection handles bootstrap, cooldowns, combined-input state, legacy migration and selected-item UI.
execute as @a run function blink_daggers:runtime/player_tick

# One shared projectile selection handles normal dagger anchors and ultimate knives at full 20 TPS.
execute as @e[type=minecraft:item_display,tag=bd_projectile] at @s run function blink_daggers:projectile/dispatch

# Multiplayer maintenance remains intentionally low-frequency: every 10 seconds remove projectiles whose owner disconnected.
scoreboard players add #maintenance bd_tmp 1
execute if score #maintenance bd_tmp matches 200.. as @e[type=minecraft:item_display,tag=bd_projectile] at @s run function blink_daggers:maintenance/orphan_check
execute if score #maintenance bd_tmp matches 200.. run scoreboard players set #maintenance bd_tmp 0
