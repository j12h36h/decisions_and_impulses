# v0.6.0 consolidated player bootstrap/migration gate.
execute unless entity @s[tag=bd_items_v030] run function blink_daggers:internal/init_player_v030
execute unless entity @s[tag=bd_items_v050] run function blink_daggers:internal/migrate_player_v050
execute unless entity @s[tag=bd_items_v051] run function blink_daggers:internal/migrate_player_v051
execute unless score @s bd_pid matches 1.. run function blink_daggers:internal/assign_player_id
tag @s add bd_runtime_v060
