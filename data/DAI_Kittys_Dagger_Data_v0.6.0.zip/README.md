# [DAI] Kitty's Dagger v0.6.0

A **DAI 3.3 addon** implementing Kitty's combined three-skill dagger kit plus three standalone right-click skill items.

## Combined item: Kitty's Dagger
- **LMB:** directional dagger throw fires immediately on the physical attack press.
- **RMB:** immediately aim at an owned dagger to blink/reclaim; otherwise place a dagger at your feet and gain Speed III.
- **Hold LMB + RMB together for 20 ticks (~1 second):** cast the five-knife ultimate.
- Simultaneous dual-input is edge-routed; holding both no longer dispatches a DAI action every tick.
- Directional cooldown is shown by durability.
- Up/drop cooldown safely uses the base dagger visual in this datapack-only build; the optional red-flash model is not referenced unless a resource asset is later supplied.
- Ultimate readiness is shown by enchantment glint.

## Recall
- Recall range: 35 blocks with a 0.75-block aim tolerance.
- The recall ray passes through lightweight foliage such as leaves, short/tall grass, ferns, flowers, vines, moss carpets, roots and similar plants.
- Solid terrain still blocks the ray.

## Ultimate
- Throws exactly five knife projectiles.
- If entities exist within 15 blocks, unique nearby targets are preferred and remaining knives reuse the nearest target when fewer than five exist.
- If no valid targets exist, five knives fire horizontally in a randomized circular fan around the player's facing direction.
- Each ultimate knife deals 6 projectile damage.

## Standalone skill items
- **Kitty's Directional Throw:** right-click Q; durability bar = Q cooldown.
- **Kitty's Up Throw:** right-click W; durability bar = W cooldown.
- **Kitty's Ultimate:** right-click R; durability bar = R cooldown.
- Cooldowns are shared with the combined item.

## Defaults
- Q cooldown: 100 ticks / 5 seconds.
- W cooldown: 100 ticks / 5 seconds.
- R cooldown: 300 ticks / 15 seconds.
- Normal dagger anchors live about 100 ticks / 5 seconds.
- Directional projectile speed: 0.715 blocks/tick.
- Disconnected-owner projectile cleanup: every 200 ticks / 10 seconds.

## DAI 3.3
- Uses native DAI item IDs and DAI reaction events.
- Uses `player_attack_input` for instant/cancelled LMB, and edge-triggered `keybind_pressed` / `keybind_released` routing for combined-item input state.
- Registered as a DAI **addon**, so it does not claim Experience saves, world generation, or title-screen ownership.
- Existing v0.5.x worlds/players remain non-destructive; cooldowns and active dagger projectiles are preserved across reloads.
- v0.6.0 consolidates all per-player tick work into one local runtime pass and all display projectiles into one shared dispatcher.
- Adds structured DAI 3.3 projectile profiles for directional and ultimate knives while preserving the proven command-driven movement/recall behavior.
- Stable `blink_daggers:kitty_dagger` and `blink_daggers:kitty_ultimate` identities remain unchanged for recognized World of Addons integration.

Requires **Decisions & Impulses (D.A.I.) 3.3** and Minecraft **26.2**.
