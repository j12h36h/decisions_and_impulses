execute if score @s cg_class matches 0 run function claygrounds:kit/adventurer
execute if score @s cg_class matches 1 run function claygrounds:kit/fighter
execute if score @s cg_class matches 2 run function claygrounds:kit/ranger
execute if score @s cg_class matches 3 run function claygrounds:kit/mystic
