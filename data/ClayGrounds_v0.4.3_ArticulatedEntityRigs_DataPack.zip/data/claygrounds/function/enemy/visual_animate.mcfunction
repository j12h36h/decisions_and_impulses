# ClayGrounds v0.4.3 — articulated animation dispatcher.
execute if score #anim cg_world matches 0 run function claygrounds:enemy/anim/pose_0
execute if score #anim cg_world matches 4 run function claygrounds:enemy/anim/pose_1
execute if score #anim cg_world matches 8 run function claygrounds:enemy/anim/pose_2
execute if score #anim cg_world matches 12 run function claygrounds:enemy/anim/pose_3
execute if score #anim cg_world matches 16 run function claygrounds:enemy/anim/pose_4
execute if score #anim cg_world matches 20 run function claygrounds:enemy/anim/pose_5
execute if score #anim cg_world matches 24 run function claygrounds:enemy/anim/pose_6
execute if score #anim cg_world matches 28 run function claygrounds:enemy/anim/pose_7
