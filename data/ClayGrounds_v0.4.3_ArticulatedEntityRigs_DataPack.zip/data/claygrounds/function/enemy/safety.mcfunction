# Keep custom enemies on their authored hunting-ground elevations.
execute as @e[tag=cg_spawn_s1,y=-64,dy=121] run teleport @s 72.5 63 -13.5
execute as @e[tag=cg_spawn_s2,y=-64,dy=121] run teleport @s 88.5 63 13.5
execute as @e[tag=cg_spawn_s3,y=-64,dy=121] run teleport @s 104.5 63 -12.5
execute as @e[tag=cg_spawn_s4,y=-64,dy=121] run teleport @s 119.5 65 13.5
execute as @e[tag=cg_spawn_s5,y=-64,dy=121] run teleport @s 132.5 65 -6.5
execute as @e[tag=cg_spawn_v1,y=-64,dy=121] run teleport @s -17.5 63 -69.5
execute as @e[tag=cg_spawn_v2,y=-64,dy=121] run teleport @s 17.5 63 -77.5
execute as @e[tag=cg_spawn_v3,y=-64,dy=121] run teleport @s -12.5 65 -100.5
execute as @e[tag=cg_spawn_v4,y=-64,dy=121] run teleport @s 14.5 65 -109.5
execute as @e[tag=cg_spawn_v5,y=-64,dy=121] run teleport @s 0.5 67 -115.5
execute as @e[tag=cg_spawn_r1,y=-64,dy=121] run teleport @s -69.5 63 -15.5
execute as @e[tag=cg_spawn_r2,y=-64,dy=121] run teleport @s -85.5 63 14.5
execute as @e[tag=cg_spawn_r3,y=-64,dy=121] run teleport @s -103.5 63 -7.5
execute as @e[tag=cg_spawn_r4,y=-64,dy=121] run teleport @s -119.5 63 12.5
execute as @e[tag=cg_spawn_r5,y=-64,dy=121] run teleport @s -133.5 63 -13.5
# Clear carrier fire state every tick so invisible undead never render stray daylight flames.
execute as @e[tag=cg_enemy] run data merge entity @s {Fire:-20s}

# v0.4.0: Claycrest Archer uses a skeleton renderer; clear any native held item so the
# transparent carrier cannot leave a vanilla bow floating through the custom body.
item replace entity @e[type=claygrounds:claycrest_archer] weapon.mainhand with minecraft:air

# v0.3.9: carrier renderers use transparent resource-pack skins so F3 hitboxes remain visible.

# Clear legacy v0.3.8 invisibility while retaining transparent carrier skins for rendering.
effect clear @e[tag=cg_enemy] minecraft:invisibility
execute as @e[tag=cg_enemy] run data merge entity @s {Invisible:0b}
