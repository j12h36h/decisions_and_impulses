# Floating island foundation step 47/55
fill -32 47 108 32 47 116 minecraft:tuff
fill -40 46 -98 40 46 -83 minecraft:tuff
fill -68 46 -82 68 46 -67 minecraft:tuff
fill -85 46 -66 85 46 -51 minecraft:tuff
scoreboard players add #foundation_step cg_world 1
