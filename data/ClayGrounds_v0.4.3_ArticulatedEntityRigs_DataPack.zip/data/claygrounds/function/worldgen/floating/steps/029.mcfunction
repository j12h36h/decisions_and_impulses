# Floating island foundation step 30/55
fill -109 50 -126 109 50 -111 minecraft:stone
fill -126 50 -110 126 50 -95 minecraft:stone
fill -138 50 -94 138 50 -79 minecraft:stone
fill -148 50 -78 148 50 -63 minecraft:stone
scoreboard players add #foundation_step cg_world 1
