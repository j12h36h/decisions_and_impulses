# Floating island foundation step 12/55
fill -125 54 134 125 54 149 minecraft:dirt
fill -103 54 150 103 54 165 minecraft:dirt
fill -69 54 166 69 54 181 minecraft:dirt
fill -28 54 182 28 54 186 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
