# Floating island foundation step 21/55
fill -182 52 -32 182 52 -17 minecraft:stone
fill -183 52 -16 183 52 -1 minecraft:stone
fill -183 52 0 183 52 15 minecraft:stone
fill -182 52 16 182 52 31 minecraft:stone
scoreboard players add #foundation_step cg_world 1
