# Floating island foundation step 33/55
fill -146 50 66 146 50 81 minecraft:stone
fill -136 50 82 136 50 97 minecraft:stone
fill -123 50 98 123 50 113 minecraft:stone
fill -106 50 114 106 50 129 minecraft:stone
scoreboard players add #foundation_step cg_world 1
