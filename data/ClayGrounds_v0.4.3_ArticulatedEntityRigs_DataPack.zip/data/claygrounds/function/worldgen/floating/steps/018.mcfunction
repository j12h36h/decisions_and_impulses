# Floating island foundation step 19/55
fill -91 52 -160 91 52 -145 minecraft:stone
fill -116 52 -144 116 52 -129 minecraft:stone
fill -134 52 -128 134 52 -113 minecraft:stone
fill -148 52 -112 148 52 -97 minecraft:stone
scoreboard players add #foundation_step cg_world 1
