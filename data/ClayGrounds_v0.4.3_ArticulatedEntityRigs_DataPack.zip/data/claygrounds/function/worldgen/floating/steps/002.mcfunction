# Floating island foundation step 3/55
fill -188 55 -60 188 55 -45 minecraft:grass_block
fill -192 55 -44 192 55 -29 minecraft:grass_block
fill -194 55 -28 194 55 -13 minecraft:grass_block
fill -195 55 -12 195 55 3 minecraft:grass_block
scoreboard players add #foundation_step cg_world 1
