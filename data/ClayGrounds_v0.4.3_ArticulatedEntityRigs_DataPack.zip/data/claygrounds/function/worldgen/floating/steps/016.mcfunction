# Floating island foundation step 17/55
fill -169 53 74 169 53 89 minecraft:dirt
fill -160 53 90 160 53 105 minecraft:dirt
fill -148 53 106 148 53 121 minecraft:dirt
fill -133 53 122 133 53 137 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
