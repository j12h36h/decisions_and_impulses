# Floating island foundation step 48/55
fill -95 46 -50 95 46 -35 minecraft:tuff
fill -102 46 -34 102 46 -19 minecraft:tuff
fill -105 46 -18 105 46 -3 minecraft:tuff
fill -105 46 -2 105 46 13 minecraft:tuff
scoreboard players add #foundation_step cg_world 1
