# Floating island foundation step 11/55
fill -176 54 70 176 54 85 minecraft:dirt
fill -167 54 86 167 54 101 minecraft:dirt
fill -156 54 102 156 54 117 minecraft:dirt
fill -143 54 118 143 54 133 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
