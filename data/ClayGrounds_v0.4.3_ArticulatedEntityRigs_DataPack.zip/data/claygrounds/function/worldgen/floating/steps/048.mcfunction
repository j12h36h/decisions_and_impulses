# Floating island foundation step 49/55
fill -103 46 14 103 46 29 minecraft:tuff
fill -97 46 30 97 46 45 minecraft:tuff
fill -88 46 46 88 46 61 minecraft:tuff
fill -74 46 62 74 46 77 minecraft:tuff
scoreboard players add #foundation_step cg_world 1
