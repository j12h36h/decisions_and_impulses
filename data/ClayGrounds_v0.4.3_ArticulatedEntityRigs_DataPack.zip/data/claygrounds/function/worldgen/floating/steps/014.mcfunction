# Floating island foundation step 15/55
fill -183 53 -54 183 53 -39 minecraft:dirt
fill -187 53 -38 187 53 -23 minecraft:dirt
fill -189 53 -22 189 53 -7 minecraft:dirt
fill -189 53 -6 189 53 9 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
