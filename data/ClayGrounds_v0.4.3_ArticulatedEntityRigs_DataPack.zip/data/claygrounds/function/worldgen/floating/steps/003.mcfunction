# Floating island foundation step 4/55
fill -195 55 4 195 55 19 minecraft:grass_block
fill -193 55 20 193 55 35 minecraft:grass_block
fill -190 55 36 190 55 51 minecraft:grass_block
fill -185 55 52 185 55 67 minecraft:grass_block
scoreboard players add #foundation_step cg_world 1
