# Floating island foundation step 18/55
fill -114 53 138 114 53 153 minecraft:dirt
fill -87 53 154 87 53 169 minecraft:dirt
fill -48 53 170 48 53 182 minecraft:dirt
fill -53 52 -176 53 52 -161 minecraft:stone
scoreboard players add #foundation_step cg_world 1
