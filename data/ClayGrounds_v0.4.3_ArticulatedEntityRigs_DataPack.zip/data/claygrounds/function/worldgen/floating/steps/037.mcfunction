# Floating island foundation step 38/55
fill -124 49 78 124 49 93 minecraft:andesite
fill -110 49 94 110 49 109 minecraft:andesite
fill -91 49 110 91 49 125 minecraft:andesite
fill -62 49 126 62 49 141 minecraft:andesite
scoreboard players add #foundation_step cg_world 1
