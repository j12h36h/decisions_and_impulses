# Floating island foundation step 23/55
fill -148 52 96 148 52 111 minecraft:stone
fill -135 52 112 135 52 127 minecraft:stone
fill -117 52 128 117 52 143 minecraft:stone
fill -93 52 144 93 52 159 minecraft:stone
scoreboard players add #foundation_step cg_world 1
