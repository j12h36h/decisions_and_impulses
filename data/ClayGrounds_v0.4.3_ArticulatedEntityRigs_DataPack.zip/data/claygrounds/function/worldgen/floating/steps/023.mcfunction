# Floating island foundation step 24/55
fill -56 52 160 56 52 175 minecraft:stone
fill -51 51 -168 51 51 -153 minecraft:stone
fill -89 51 -152 89 51 -137 minecraft:stone
fill -113 51 -136 113 51 -121 minecraft:stone
scoreboard players add #foundation_step cg_world 1
