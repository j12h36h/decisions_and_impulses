# Floating island foundation step 5/55
fill -179 55 68 179 55 83 minecraft:grass_block
fill -171 55 84 171 55 99 minecraft:grass_block
fill -160 55 100 160 55 115 minecraft:grass_block
fill -147 55 116 147 55 131 minecraft:grass_block
scoreboard players add #foundation_step cg_world 1
