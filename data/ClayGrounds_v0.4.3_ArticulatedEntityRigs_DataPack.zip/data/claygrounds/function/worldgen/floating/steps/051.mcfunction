# Floating island foundation step 52/55
fill -81 45 18 81 45 33 minecraft:deepslate
fill -72 45 34 72 45 49 minecraft:deepslate
fill -58 45 50 58 45 65 minecraft:deepslate
fill -33 45 66 33 45 78 minecraft:deepslate
scoreboard players add #foundation_step cg_world 1
