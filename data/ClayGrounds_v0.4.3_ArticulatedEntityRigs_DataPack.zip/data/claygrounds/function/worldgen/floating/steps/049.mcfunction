# Floating island foundation step 50/55
fill -51 46 78 51 46 93 minecraft:tuff
fill -21 46 94 21 46 98 minecraft:tuff
fill -36 45 -78 36 45 -63 minecraft:deepslate
fill -61 45 -62 61 45 -47 minecraft:deepslate
scoreboard players add #foundation_step cg_world 1
