# Floating island foundation step 39/55
fill -25 49 142 25 49 146 minecraft:andesite
fill -46 48 -132 46 48 -117 minecraft:stone
fill -79 48 -116 79 48 -101 minecraft:stone
fill -99 48 -100 99 48 -85 minecraft:stone
scoreboard players add #foundation_step cg_world 1
