# Floating island foundation step 42/55
fill -128 48 44 128 48 59 minecraft:stone
fill -120 48 60 120 48 75 minecraft:stone
fill -108 48 76 108 48 91 minecraft:stone
fill -91 48 92 91 48 107 minecraft:stone
scoreboard players add #foundation_step cg_world 1
