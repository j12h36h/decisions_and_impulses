# Floating island foundation step 16/55
fill -189 53 10 189 53 25 minecraft:dirt
fill -186 53 26 186 53 41 minecraft:dirt
fill -182 53 42 182 53 57 minecraft:dirt
fill -177 53 58 177 53 73 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
