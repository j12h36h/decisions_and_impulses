# Floating island foundation step 51/55
fill -74 45 -46 74 45 -31 minecraft:deepslate
fill -82 45 -30 82 45 -15 minecraft:deepslate
fill -85 45 -14 85 45 1 minecraft:deepslate
fill -85 45 2 85 45 17 minecraft:deepslate
scoreboard players add #foundation_step cg_world 1
