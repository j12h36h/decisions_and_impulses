# Floating island foundation step 31/55
fill -155 50 -62 155 50 -47 minecraft:stone
fill -160 50 -46 160 50 -31 minecraft:stone
fill -164 50 -30 164 50 -15 minecraft:stone
fill -165 50 -14 165 50 1 minecraft:stone
scoreboard players add #foundation_step cg_world 1
