# Floating island foundation step 41/55
fill -139 48 -20 139 48 -5 minecraft:stone
fill -139 48 -4 139 48 11 minecraft:stone
fill -138 48 12 138 48 27 minecraft:stone
fill -134 48 28 134 48 43 minecraft:stone
scoreboard players add #foundation_step cg_world 1
