# Floating island foundation step 40/55
fill -114 48 -84 114 48 -69 minecraft:stone
fill -124 48 -68 124 48 -53 minecraft:stone
fill -131 48 -52 131 48 -37 minecraft:stone
fill -136 48 -36 136 48 -21 minecraft:stone
scoreboard players add #foundation_step cg_world 1
