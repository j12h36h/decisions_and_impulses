# Floating island foundation step 35/55
fill -105 49 -114 105 49 -99 minecraft:andesite
fill -120 49 -98 120 49 -83 minecraft:andesite
fill -132 49 -82 132 49 -67 minecraft:andesite
fill -141 49 -66 141 49 -51 minecraft:andesite
scoreboard players add #foundation_step cg_world 1
