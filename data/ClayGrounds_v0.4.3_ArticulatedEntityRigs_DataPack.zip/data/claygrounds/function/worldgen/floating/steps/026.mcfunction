# Floating island foundation step 27/55
fill -175 51 8 175 51 23 minecraft:stone
fill -172 51 24 172 51 39 minecraft:stone
fill -168 51 40 168 51 55 minecraft:stone
fill -162 51 56 162 51 71 minecraft:stone
scoreboard players add #foundation_step cg_world 1
