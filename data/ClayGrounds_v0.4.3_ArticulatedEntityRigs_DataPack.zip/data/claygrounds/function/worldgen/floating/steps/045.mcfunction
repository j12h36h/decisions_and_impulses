# Floating island foundation step 46/55
fill -111 47 44 111 47 59 minecraft:tuff
fill -100 47 60 100 47 75 minecraft:tuff
fill -86 47 76 86 47 91 minecraft:tuff
fill -63 47 92 63 47 107 minecraft:tuff
scoreboard players add #foundation_step cg_world 1
