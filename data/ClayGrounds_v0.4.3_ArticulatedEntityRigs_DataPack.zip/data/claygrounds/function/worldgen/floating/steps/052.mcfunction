# Floating island foundation step 53/55
fill -31 44 -54 31 44 -39 minecraft:deepslate
fill -51 44 -38 51 44 -23 minecraft:deepslate
fill -59 44 -22 59 44 -7 minecraft:deepslate
fill -61 44 -6 61 44 9 minecraft:deepslate
scoreboard players add #foundation_step cg_world 1
