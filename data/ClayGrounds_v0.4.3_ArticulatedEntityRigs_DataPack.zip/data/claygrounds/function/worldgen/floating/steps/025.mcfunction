# Floating island foundation step 26/55
fill -168 51 -56 168 51 -41 minecraft:stone
fill -172 51 -40 172 51 -25 minecraft:stone
fill -175 51 -24 175 51 -9 minecraft:stone
fill -175 51 -8 175 51 7 minecraft:stone
scoreboard players add #foundation_step cg_world 1
