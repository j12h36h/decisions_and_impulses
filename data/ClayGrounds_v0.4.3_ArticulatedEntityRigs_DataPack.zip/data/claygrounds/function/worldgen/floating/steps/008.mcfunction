# Floating island foundation step 9/55
fill -186 54 -58 186 54 -43 minecraft:dirt
fill -190 54 -42 190 54 -27 minecraft:dirt
fill -193 54 -26 193 54 -11 minecraft:dirt
fill -193 54 -10 193 54 5 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
