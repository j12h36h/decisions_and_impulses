# Floating island foundation step 44/55
fill -93 47 -84 93 47 -69 minecraft:tuff
fill -105 47 -68 105 47 -53 minecraft:tuff
fill -114 47 -52 114 47 -37 minecraft:tuff
fill -120 47 -36 120 47 -21 minecraft:tuff
scoreboard players add #foundation_step cg_world 1
