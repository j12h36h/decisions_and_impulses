# Floating island foundation step 8/55
fill -152 54 -122 152 54 -107 minecraft:dirt
fill -164 54 -106 164 54 -91 minecraft:dirt
fill -173 54 -90 173 54 -75 minecraft:dirt
fill -181 54 -74 181 54 -59 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
