# Floating island foundation step 55/55
fill -33 43 -12 33 43 3 minecraft:deepslate
fill -30 43 4 30 43 19 minecraft:deepslate
fill -17 43 20 17 43 28 minecraft:deepslate
scoreboard players add #foundation_step cg_world 1
