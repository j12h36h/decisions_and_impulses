# Floating island foundation step 6/55
fill -131 55 132 131 55 147 minecraft:grass_block
fill -110 55 148 110 55 163 minecraft:grass_block
fill -80 55 164 80 55 179 minecraft:grass_block
fill -40 55 180 40 55 188 minecraft:grass_block
scoreboard players add #foundation_step cg_world 1
