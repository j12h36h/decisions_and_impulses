# Floating island foundation step 20/55
fill -159 52 -96 159 52 -81 minecraft:stone
fill -167 52 -80 167 52 -65 minecraft:stone
fill -174 52 -64 174 52 -49 minecraft:stone
fill -179 52 -48 179 52 -33 minecraft:stone
scoreboard players add #foundation_step cg_world 1
