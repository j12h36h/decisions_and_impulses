# Floating island foundation step 10/55
fill -193 54 6 193 54 21 minecraft:dirt
fill -191 54 22 191 54 37 minecraft:dirt
fill -188 54 38 188 54 53 minecraft:dirt
fill -183 54 54 183 54 69 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
