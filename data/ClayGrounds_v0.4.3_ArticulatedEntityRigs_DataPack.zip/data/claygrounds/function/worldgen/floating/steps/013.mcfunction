# Floating island foundation step 14/55
fill -150 53 -118 150 53 -103 minecraft:dirt
fill -162 53 -102 162 53 -87 minecraft:dirt
fill -171 53 -86 171 53 -71 minecraft:dirt
fill -178 53 -70 178 53 -55 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
