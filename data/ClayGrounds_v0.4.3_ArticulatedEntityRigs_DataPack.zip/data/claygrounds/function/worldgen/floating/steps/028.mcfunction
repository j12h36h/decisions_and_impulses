# Floating island foundation step 29/55
fill -91 51 136 91 51 151 minecraft:stone
fill -55 51 152 55 51 167 minecraft:stone
fill -50 50 -158 50 50 -143 minecraft:stone
fill -87 50 -142 87 50 -127 minecraft:stone
scoreboard players add #foundation_step cg_world 1
