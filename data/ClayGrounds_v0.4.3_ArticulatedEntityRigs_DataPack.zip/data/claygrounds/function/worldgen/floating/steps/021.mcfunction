# Floating island foundation step 22/55
fill -179 52 32 179 52 47 minecraft:stone
fill -174 52 48 174 52 63 minecraft:stone
fill -168 52 64 168 52 79 minecraft:stone
fill -159 52 80 159 52 95 minecraft:stone
scoreboard players add #foundation_step cg_world 1
