# Floating island foundation step 32/55
fill -165 50 2 165 50 17 minecraft:stone
fill -163 50 18 163 50 33 minecraft:stone
fill -160 50 34 160 50 49 minecraft:stone
fill -154 50 50 154 50 65 minecraft:stone
scoreboard players add #foundation_step cg_world 1
