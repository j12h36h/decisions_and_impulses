# Floating island foundation step 43/55
fill -67 48 108 67 48 123 minecraft:stone
fill -34 48 124 34 48 132 minecraft:stone
fill -43 47 -116 43 47 -101 minecraft:tuff
fill -74 47 -100 74 47 -85 minecraft:tuff
scoreboard players add #foundation_step cg_world 1
