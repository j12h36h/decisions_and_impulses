# Floating island foundation step 34/55
fill -81 50 130 81 50 145 minecraft:stone
fill -45 50 146 45 50 158 minecraft:stone
fill -48 49 -146 48 49 -131 minecraft:andesite
fill -83 49 -130 83 49 -115 minecraft:andesite
scoreboard players add #foundation_step cg_world 1
