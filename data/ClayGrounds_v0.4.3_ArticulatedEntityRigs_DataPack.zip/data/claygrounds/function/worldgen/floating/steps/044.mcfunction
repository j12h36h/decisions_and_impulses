# Floating island foundation step 45/55
fill -123 47 -20 123 47 -5 minecraft:tuff
fill -123 47 -4 123 47 11 minecraft:tuff
fill -122 47 12 122 47 27 minecraft:tuff
fill -118 47 28 118 47 43 minecraft:tuff
scoreboard players add #foundation_step cg_world 1
