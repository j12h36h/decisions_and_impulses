# Floating island foundation step 13/55
fill -53 53 -182 53 53 -167 minecraft:dirt
fill -93 53 -166 93 53 -151 minecraft:dirt
fill -118 53 -150 118 53 -135 minecraft:dirt
fill -136 53 -134 136 53 -119 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
