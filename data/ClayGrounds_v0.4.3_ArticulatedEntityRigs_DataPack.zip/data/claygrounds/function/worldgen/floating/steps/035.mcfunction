# Floating island foundation step 36/55
fill -147 49 -50 147 49 -35 minecraft:andesite
fill -151 49 -34 151 49 -19 minecraft:andesite
fill -153 49 -18 153 49 -3 minecraft:andesite
fill -153 49 -2 153 49 13 minecraft:andesite
scoreboard players add #foundation_step cg_world 1
