# Floating island foundation step 2/55
fill -153 55 -124 153 55 -109 minecraft:grass_block
fill -165 55 -108 165 55 -93 minecraft:grass_block
fill -175 55 -92 175 55 -77 minecraft:grass_block
fill -182 55 -76 182 55 -61 minecraft:grass_block
scoreboard players add #foundation_step cg_world 1
