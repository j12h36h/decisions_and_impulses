# Floating island foundation step 7/55
fill -54 54 -186 54 54 -171 minecraft:dirt
fill -94 54 -170 94 54 -155 minecraft:dirt
fill -119 54 -154 119 54 -139 minecraft:dirt
fill -138 54 -138 138 54 -123 minecraft:dirt
scoreboard players add #foundation_step cg_world 1
