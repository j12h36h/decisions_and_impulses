# Floating island foundation step 25/55
fill -130 51 -120 130 51 -105 minecraft:stone
fill -144 51 -104 144 51 -89 minecraft:stone
fill -154 51 -88 154 51 -73 minecraft:stone
fill -162 51 -72 162 51 -57 minecraft:stone
scoreboard players add #foundation_step cg_world 1
