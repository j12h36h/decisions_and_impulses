# Floating island foundation step 28/55
fill -155 51 72 155 51 87 minecraft:stone
fill -144 51 88 144 51 103 minecraft:stone
fill -131 51 104 131 51 119 minecraft:stone
fill -114 51 120 114 51 135 minecraft:stone
scoreboard players add #foundation_step cg_world 1
