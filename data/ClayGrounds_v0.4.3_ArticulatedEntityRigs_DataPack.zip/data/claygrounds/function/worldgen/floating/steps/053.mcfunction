# Floating island foundation step 54/55
fill -58 44 10 58 44 25 minecraft:deepslate
fill -48 44 26 48 44 41 minecraft:deepslate
fill -28 44 42 28 44 54 minecraft:deepslate
fill -23 43 -28 23 43 -13 minecraft:deepslate
scoreboard players add #foundation_step cg_world 1
