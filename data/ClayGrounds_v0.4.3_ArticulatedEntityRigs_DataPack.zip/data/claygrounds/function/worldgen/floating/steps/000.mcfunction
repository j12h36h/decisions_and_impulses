# Floating island foundation step 1/55
fill -54 55 -188 54 55 -173 minecraft:grass_block
fill -94 55 -172 94 55 -157 minecraft:grass_block
fill -120 55 -156 120 55 -141 minecraft:grass_block
fill -139 55 -140 139 55 -125 minecraft:grass_block
scoreboard players add #foundation_step cg_world 1
