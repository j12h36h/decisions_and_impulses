# Floating island foundation step 37/55
fill -152 49 14 152 49 29 minecraft:andesite
fill -148 49 30 148 49 45 minecraft:andesite
fill -143 49 46 143 49 61 minecraft:andesite
fill -135 49 62 135 49 77 minecraft:andesite
scoreboard players add #foundation_step cg_world 1
