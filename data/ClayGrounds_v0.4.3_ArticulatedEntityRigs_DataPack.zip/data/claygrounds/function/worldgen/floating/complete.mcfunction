# Foundation complete; begin authored ClayGrounds terrain construction.
scoreboard players set #foundation_step cg_world 55
scoreboard players set #gen_phase cg_world 1
scoreboard players set #build_clock cg_world 0
title @a times 3 25 3
title @a title {"text":"ISLAND FOUNDATION READY","color":"green","bold":true}
title @a subtitle {"text":"Building Solmere and the surrounding terrain...","color":"aqua"}
