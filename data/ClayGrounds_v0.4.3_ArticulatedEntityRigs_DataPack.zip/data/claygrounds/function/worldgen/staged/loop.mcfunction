# v0.2.4 compatibility callback. v0.2.5 construction is tick-driven; do not reschedule.
