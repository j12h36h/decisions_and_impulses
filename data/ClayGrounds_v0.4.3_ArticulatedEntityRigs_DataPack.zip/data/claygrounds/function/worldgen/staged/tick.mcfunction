# v0.2.4 compatibility entry.
execute if score #gen_active cg_world matches 1 run function claygrounds:worldgen/build/tick
