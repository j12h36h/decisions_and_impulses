# ClayGrounds v0.2.1 — Solmere
# Thick tapered island, low-rise town, open sightlines. No giant hollow boxes.
fill -1 55 -47 1 55 -47 minecraft:sandstone
fill -8 55 -46 8 55 -46 minecraft:sandstone
fill -12 55 -45 12 55 -45 minecraft:sandstone
fill -16 55 -44 16 55 -44 minecraft:sandstone
fill -20 55 -43 20 55 -42 minecraft:sandstone
fill -24 55 -41 24 55 -39 minecraft:sandstone
fill -28 55 -38 28 55 -37 minecraft:sandstone
fill -32 55 -36 32 55 -33 minecraft:sandstone
fill -36 55 -32 36 55 -29 minecraft:sandstone
fill -40 55 -28 40 55 -23 minecraft:sandstone
fill -44 55 -22 44 55 -14 minecraft:sandstone
fill -48 55 -13 48 55 13 minecraft:sandstone
fill -44 55 14 44 55 22 minecraft:sandstone
fill -40 55 23 40 55 28 minecraft:sandstone
fill -36 55 29 36 55 32 minecraft:sandstone
fill -32 55 33 32 55 36 minecraft:sandstone
fill -28 55 37 28 55 38 minecraft:sandstone
fill -24 55 39 24 55 41 minecraft:sandstone
fill -20 55 42 20 55 43 minecraft:sandstone
fill -16 55 44 16 55 44 minecraft:sandstone
fill -12 55 45 12 55 45 minecraft:sandstone
fill -8 55 46 8 55 46 minecraft:sandstone
fill -1 55 47 1 55 47 minecraft:sandstone
fill -1 56 -46 1 56 -46 minecraft:sandstone
fill -8 56 -45 8 56 -45 minecraft:sandstone
fill -12 56 -44 12 56 -44 minecraft:sandstone
fill -16 56 -43 16 56 -42 minecraft:sandstone
fill -20 56 -41 20 56 -41 minecraft:sandstone
fill -24 56 -40 24 56 -38 minecraft:sandstone
fill -28 56 -37 28 56 -35 minecraft:sandstone
fill -32 56 -34 32 56 -32 minecraft:sandstone
fill -36 56 -31 36 56 -27 minecraft:sandstone
fill -40 56 -26 40 56 -21 minecraft:sandstone
fill -44 56 -20 44 56 -10 minecraft:sandstone
fill -48 56 -9 48 56 9 minecraft:sandstone
fill -44 56 10 44 56 20 minecraft:sandstone
fill -40 56 21 40 56 26 minecraft:sandstone
fill -36 56 27 36 56 31 minecraft:sandstone
fill -32 56 32 32 56 34 minecraft:sandstone
fill -28 56 35 28 56 37 minecraft:sandstone
fill -24 56 38 24 56 40 minecraft:sandstone
fill -20 56 41 20 56 41 minecraft:sandstone
fill -16 56 42 16 56 43 minecraft:sandstone
fill -12 56 44 12 56 44 minecraft:sandstone
fill -8 56 45 8 56 45 minecraft:sandstone
fill -1 56 46 1 56 46 minecraft:sandstone
fill -1 57 -45 1 57 -45 minecraft:sandstone
fill -8 57 -44 8 57 -44 minecraft:sandstone
fill -12 57 -43 12 57 -43 minecraft:sandstone
fill -16 57 -42 16 57 -41 minecraft:sandstone
fill -20 57 -40 20 57 -39 minecraft:sandstone
fill -24 57 -38 24 57 -37 minecraft:sandstone
fill -28 57 -36 28 57 -34 minecraft:sandstone
fill -32 57 -33 32 57 -30 minecraft:sandstone
fill -36 57 -29 36 57 -25 minecraft:sandstone
fill -40 57 -24 40 57 -18 minecraft:sandstone
fill -44 57 -17 44 57 -1 minecraft:sandstone
fill -48 57 0 48 57 0 minecraft:sandstone
fill -44 57 1 44 57 17 minecraft:sandstone
fill -40 57 18 40 57 24 minecraft:sandstone
fill -36 57 25 36 57 29 minecraft:sandstone
fill -32 57 30 32 57 33 minecraft:sandstone
fill -28 57 34 28 57 36 minecraft:sandstone
fill -24 57 37 24 57 38 minecraft:sandstone
fill -20 57 39 20 57 40 minecraft:sandstone
fill -16 57 41 16 57 42 minecraft:sandstone
fill -12 57 43 12 57 43 minecraft:sandstone
fill -8 57 44 8 57 44 minecraft:sandstone
fill -1 57 45 1 57 45 minecraft:sandstone
fill -1 58 -44 1 58 -44 minecraft:sandstone
fill -8 58 -43 8 58 -43 minecraft:sandstone
fill -12 58 -42 12 58 -42 minecraft:sandstone
fill -16 58 -41 16 58 -40 minecraft:sandstone
fill -20 58 -39 20 58 -38 minecraft:sandstone
fill -24 58 -37 24 58 -36 minecraft:sandstone
fill -28 58 -35 28 58 -33 minecraft:sandstone
fill -32 58 -32 32 58 -29 minecraft:sandstone
fill -36 58 -28 36 58 -24 minecraft:sandstone
fill -40 58 -23 40 58 -16 minecraft:sandstone
fill -44 58 -15 44 58 15 minecraft:sandstone
fill -40 58 16 40 58 23 minecraft:sandstone
fill -36 58 24 36 58 28 minecraft:sandstone
fill -32 58 29 32 58 32 minecraft:sandstone
fill -28 58 33 28 58 35 minecraft:sandstone
fill -24 58 36 24 58 37 minecraft:sandstone
fill -20 58 38 20 58 39 minecraft:sandstone
fill -16 58 40 16 58 41 minecraft:sandstone
fill -12 58 42 12 58 42 minecraft:sandstone
fill -8 58 43 8 58 43 minecraft:sandstone
fill -1 58 44 1 58 44 minecraft:sandstone
fill -1 59 -43 1 59 -43 minecraft:sandstone
fill -8 59 -42 8 59 -42 minecraft:sandstone
fill -12 59 -41 12 59 -41 minecraft:sandstone
fill -16 59 -40 16 59 -39 minecraft:sandstone
fill -20 59 -38 20 59 -37 minecraft:sandstone
fill -24 59 -36 24 59 -35 minecraft:sandstone
fill -28 59 -34 28 59 -31 minecraft:sandstone
fill -32 59 -30 32 59 -27 minecraft:sandstone
fill -36 59 -26 36 59 -22 minecraft:sandstone
fill -40 59 -21 40 59 -13 minecraft:sandstone
fill -44 59 -12 44 59 12 minecraft:sandstone
fill -40 59 13 40 59 21 minecraft:sandstone
fill -36 59 22 36 59 26 minecraft:sandstone
fill -32 59 27 32 59 30 minecraft:sandstone
fill -28 59 31 28 59 34 minecraft:sandstone
fill -24 59 35 24 59 36 minecraft:sandstone
fill -20 59 37 20 59 38 minecraft:sandstone
fill -16 59 39 16 59 40 minecraft:sandstone
fill -12 59 41 12 59 41 minecraft:sandstone
fill -8 59 42 8 59 42 minecraft:sandstone
fill -1 59 43 1 59 43 minecraft:sandstone
fill -1 60 -42 1 60 -42 minecraft:sand
fill -8 60 -41 8 60 -41 minecraft:sand
fill -12 60 -40 12 60 -40 minecraft:sand
fill -16 60 -39 16 60 -38 minecraft:sand
fill -20 60 -37 20 60 -36 minecraft:sand
fill -24 60 -35 24 60 -33 minecraft:sand
fill -28 60 -32 28 60 -30 minecraft:sand
fill -32 60 -29 32 60 -26 minecraft:sand
fill -36 60 -25 36 60 -20 minecraft:sand
fill -40 60 -19 40 60 -9 minecraft:sand
fill -44 60 -8 44 60 8 minecraft:sand
fill -40 60 9 40 60 19 minecraft:sand
fill -36 60 20 36 60 25 minecraft:sand
fill -32 60 26 32 60 29 minecraft:sand
fill -28 60 30 28 60 32 minecraft:sand
fill -24 60 33 24 60 35 minecraft:sand
fill -20 60 36 20 60 37 minecraft:sand
fill -16 60 38 16 60 39 minecraft:sand
fill -12 60 40 12 60 40 minecraft:sand
fill -8 60 41 8 60 41 minecraft:sand
fill -1 60 42 1 60 42 minecraft:sand
fill -1 61 -41 1 61 -41 minecraft:sand
fill -8 61 -40 8 61 -40 minecraft:sand
fill -12 61 -39 12 61 -39 minecraft:sand
fill -16 61 -38 16 61 -37 minecraft:sand
fill -20 61 -36 20 61 -35 minecraft:sand
fill -24 61 -34 24 61 -32 minecraft:sand
fill -28 61 -31 28 61 -29 minecraft:sand
fill -32 61 -28 32 61 -24 minecraft:sand
fill -36 61 -23 36 61 -18 minecraft:sand
fill -40 61 -17 40 61 -1 minecraft:sand
fill -44 61 0 44 61 0 minecraft:sand
fill -40 61 1 40 61 17 minecraft:sand
fill -36 61 18 36 61 23 minecraft:sand
fill -32 61 24 32 61 28 minecraft:sand
fill -28 61 29 28 61 31 minecraft:sand
fill -24 61 32 24 61 34 minecraft:sand
fill -20 61 35 20 61 36 minecraft:sand
fill -16 61 37 16 61 38 minecraft:sand
fill -12 61 39 12 61 39 minecraft:sand
fill -8 61 40 8 61 40 minecraft:sand
fill -1 61 41 1 61 41 minecraft:sand
fill -1 62 -37 1 62 -37 minecraft:smooth_sandstone
fill -8 62 -36 8 62 -36 minecraft:smooth_sandstone
fill -12 62 -35 12 62 -34 minecraft:smooth_sandstone
fill -16 62 -33 16 62 -33 minecraft:smooth_sandstone
fill -20 62 -32 20 62 -30 minecraft:smooth_sandstone
fill -24 62 -29 24 62 -27 minecraft:smooth_sandstone
fill -28 62 -26 28 62 -23 minecraft:smooth_sandstone
fill -32 62 -22 32 62 -17 minecraft:smooth_sandstone
fill -36 62 -16 36 62 -1 minecraft:smooth_sandstone
fill -40 62 0 40 62 0 minecraft:smooth_sandstone
fill -36 62 1 36 62 16 minecraft:smooth_sandstone
fill -32 62 17 32 62 22 minecraft:smooth_sandstone
fill -28 62 23 28 62 26 minecraft:smooth_sandstone
fill -24 62 27 24 62 29 minecraft:smooth_sandstone
fill -20 62 30 20 62 32 minecraft:smooth_sandstone
fill -16 62 33 16 62 33 minecraft:smooth_sandstone
fill -12 62 34 12 62 35 minecraft:smooth_sandstone
fill -8 62 36 8 62 36 minecraft:smooth_sandstone
fill -1 62 37 1 62 37 minecraft:smooth_sandstone
fill -36 62 -4 36 62 4 minecraft:cut_sandstone
fill -4 62 -34 4 62 34 minecraft:cut_sandstone
fill -5 62 -15 5 62 -7 minecraft:smooth_sandstone
fill -5 62 8 5 62 16 minecraft:smooth_sandstone
# Solmere fountain: solid floor + visible rim + contained center feature.
fill 18 62 -3 26 62 5 minecraft:stone_bricks
fill 18 63 -3 26 63 5 minecraft:cut_sandstone
fill 19 63 -2 25 63 4 minecraft:water
setblock 22 63 1 minecraft:sea_lantern
fill 22 64 1 22 65 1 minecraft:cut_sandstone
setblock 22 66 1 minecraft:water
# Invisible catches keep the top fountain source from escaping past the basin.
fill 17 64 -4 27 64 -4 minecraft:barrier
fill 17 64 6 27 64 6 minecraft:barrier
fill 17 64 -3 17 64 5 minecraft:barrier
fill 27 64 -3 27 64 5 minecraft:barrier
fill -29 63 -24 -18 66 -15 minecraft:orange_terracotta hollow
fill -30 67 -25 -17 67 -14 minecraft:jungle_planks
fill -25 63 -24 -23 65 -24 minecraft:air
setblock -28 64 -24 minecraft:lantern
setblock -19 64 -24 minecraft:lantern
fill 18 63 -24 29 66 -15 minecraft:yellow_terracotta hollow
fill 17 67 -25 30 67 -14 minecraft:jungle_planks
fill 22 63 -24 24 65 -24 minecraft:air
setblock 19 64 -24 minecraft:lantern
setblock 28 64 -24 minecraft:lantern
fill -29 63 13 -18 66 22 minecraft:light_blue_terracotta hollow
fill -30 67 12 -17 67 23 minecraft:dark_oak_planks
fill -25 63 13 -23 65 13 minecraft:air
setblock -28 64 13 minecraft:lantern
setblock -19 64 13 minecraft:lantern
fill 18 63 13 29 66 22 minecraft:red_terracotta hollow
fill 17 67 12 30 67 23 minecraft:dark_oak_planks
fill 22 63 13 24 65 13 minecraft:air
setblock 19 64 13 minecraft:lantern
setblock 28 64 13 minecraft:lantern
fill -14 62 17 14 62 34 minecraft:stone_bricks
fill -13 63 18 -13 68 33 minecraft:mud_bricks
fill 13 63 18 13 68 33 minecraft:mud_bricks
fill -13 63 33 13 68 33 minecraft:mud_bricks
fill -13 68 18 13 68 33 minecraft:jungle_planks
fill -15 69 16 15 69 35 minecraft:dark_oak_planks
fill -10 63 18 -8 66 18 minecraft:mud_bricks
fill 8 63 18 10 66 18 minecraft:mud_bricks
fill -3 63 18 3 66 18 minecraft:air
setblock -6 63 26 minecraft:red_glazed_terracotta
setblock 0 63 26 minecraft:green_glazed_terracotta
setblock 6 63 26 minecraft:purple_glazed_terracotta
summon minecraft:text_display 0 67 20 {Tags:['cg_static'],text:{text:'SOLMERE GUILD HALL',color:'aqua',bold:true},billboard:'center'}
summon minecraft:text_display -6 65 26 {Tags:['cg_static'],text:{text:'FIGHTER',color:'red',bold:true},billboard:'center'}
summon minecraft:text_display 0 65 26 {Tags:['cg_static'],text:{text:'RANGER',color:'green',bold:true},billboard:'center'}
summon minecraft:text_display 6 65 26 {Tags:['cg_static'],text:{text:'MYSTIC',color:'light_purple',bold:true},billboard:'center'}
fill 32 62 -10 36 71 -6 minecraft:white_concrete hollow
fill 31 72 -11 37 72 -5 minecraft:red_terracotta
setblock 34 73 -8 minecraft:sea_lantern
fill 33 63 -10 35 65 -10 minecraft:air
fill 37 62 -4 50 62 4 minecraft:smooth_sandstone
fill -50 62 -4 -37 62 4 minecraft:smooth_sandstone
fill -4 62 -50 4 62 -37 minecraft:smooth_sandstone
fill -4 62 37 4 62 55 minecraft:smooth_sandstone
fill -38 63 -25 -38 66 -25 minecraft:stripped_jungle_log
fill -40 67 -25 -36 67 -25 minecraft:green_concrete
fill -38 67 -27 -38 67 -23 minecraft:green_concrete
fill -39 68 -26 -37 68 -24 minecraft:green_concrete
setblock -38 69 -25 minecraft:green_concrete
fill 38 63 -24 38 66 -24 minecraft:stripped_jungle_log
fill 36 67 -24 40 67 -24 minecraft:green_concrete
fill 38 67 -26 38 67 -22 minecraft:green_concrete
fill 37 68 -25 39 68 -23 minecraft:green_concrete
setblock 38 69 -24 minecraft:green_concrete
fill -38 63 25 -38 66 25 minecraft:stripped_jungle_log
fill -40 67 25 -36 67 25 minecraft:green_concrete
fill -38 67 23 -38 67 27 minecraft:green_concrete
fill -39 68 24 -37 68 26 minecraft:green_concrete
setblock -38 69 25 minecraft:green_concrete
fill 38 63 25 38 66 25 minecraft:stripped_jungle_log
fill 36 67 25 40 67 25 minecraft:green_concrete
fill 38 67 23 38 67 27 minecraft:green_concrete
fill 37 68 24 39 68 26 minecraft:green_concrete
setblock 38 69 25 minecraft:green_concrete
fill -31 63 -34 -31 66 -34 minecraft:stripped_jungle_log
fill -33 67 -34 -29 67 -34 minecraft:green_concrete
fill -31 67 -36 -31 67 -32 minecraft:green_concrete
fill -32 68 -35 -30 68 -33 minecraft:green_concrete
setblock -31 69 -34 minecraft:green_concrete
fill 31 63 34 31 66 34 minecraft:stripped_jungle_log
fill 29 67 34 33 67 34 minecraft:green_concrete
fill 31 67 32 31 67 36 minecraft:green_concrete
fill 30 68 33 32 68 35 minecraft:green_concrete
setblock 31 69 34 minecraft:green_concrete
setblock -10 63 -10 minecraft:lantern
setblock 10 63 -10 minecraft:lantern
setblock -10 63 10 minecraft:lantern
setblock 10 63 10 minecraft:lantern
setblock -34 63 0 minecraft:lantern
setblock 34 63 0 minecraft:lantern
setblock 0 63 -28 minecraft:lantern
setblock 0 63 15 minecraft:lantern
# Keep encounter/player spawn volumes open after all decorative terrain is placed.
fill -1 63 -9 1 66 -7 minecraft:air
