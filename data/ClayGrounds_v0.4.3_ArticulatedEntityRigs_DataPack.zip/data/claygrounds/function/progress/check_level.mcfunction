execute if score @s cg_level matches 10.. run return 0
scoreboard players operation @s cg_need = @s cg_level
scoreboard players operation @s cg_need *= #60 cg_world
scoreboard players operation @s cg_need += #40 cg_world
execute if score @s cg_xp >= @s cg_need run function claygrounds:progress/level_up
