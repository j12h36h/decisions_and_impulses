scoreboard players operation @s cg_xp -= @s cg_need
scoreboard players add @s cg_level 1
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1
particle minecraft:happy_villager ~ ~1 ~ 1 1 1 0.12 35 force @s
title @s title {"text":"LEVEL UP","color":"yellow","bold":true}
title @s subtitle [{"text":"Class Level ","color":"white"},{"score":{"name":"@s","objective":"cg_level"},"color":"aqua"}]
function claygrounds:progress/check_level
