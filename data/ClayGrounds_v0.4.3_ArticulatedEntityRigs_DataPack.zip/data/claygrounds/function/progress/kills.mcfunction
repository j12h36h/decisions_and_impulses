execute unless score @s cg_seen_kills = @s cg_kills run function claygrounds:progress/new_kills
