scoreboard players operation @s cg_delta = @s cg_kills
scoreboard players operation @s cg_delta -= @s cg_seen_kills
scoreboard players operation @s cg_seen_kills = @s cg_kills
scoreboard players operation @s cg_gain = @s cg_delta
scoreboard players operation @s cg_gain *= #40 cg_world
scoreboard players operation @s cg_xp += @s cg_gain
scoreboard players operation @s cg_gain = @s cg_delta
scoreboard players operation @s cg_gain *= #40 cg_world
scoreboard players operation @s cg_gold += @s cg_gain
function claygrounds:progress/check_level
