execute if score @s cg_story matches 0 if score @s cg_kills matches 8.. run function claygrounds:story/contract_one_clear
