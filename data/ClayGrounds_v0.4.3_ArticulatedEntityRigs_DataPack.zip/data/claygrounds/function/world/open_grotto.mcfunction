fill -3 63 67 3 67 67 minecraft:air
setblock -4 63 67 minecraft:sea_lantern
setblock 4 63 67 minecraft:sea_lantern
