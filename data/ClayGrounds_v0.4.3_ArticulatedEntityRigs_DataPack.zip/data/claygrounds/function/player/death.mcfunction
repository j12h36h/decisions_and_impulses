scoreboard players operation @s cg_seen_deaths = @s cg_deaths
effect give @s minecraft:regeneration 4 2 true
effect give @s minecraft:resistance 3 4 true
teleport @s 0.5 63 -8.5 0 0
function claygrounds:kit/current
title @s title {"text":"RETURNED TO SOLMERE","color":"aqua","bold":true}
title @s subtitle {"text":"Your character and every class keep their progress.","color":"white"}
