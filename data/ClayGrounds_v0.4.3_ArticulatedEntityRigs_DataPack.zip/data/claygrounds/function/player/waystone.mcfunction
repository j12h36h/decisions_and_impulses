scoreboard players set #boss cg_world 0
bossbar set claygrounds:shorewarden visible false
kill @e[tag=cg_boss]
teleport @s 0.5 63 -8.5 0 0
effect give @s minecraft:regeneration 2 2 true
title @s actionbar {"text":"Solmere Waystone — returned to town","color":"aqua"}
