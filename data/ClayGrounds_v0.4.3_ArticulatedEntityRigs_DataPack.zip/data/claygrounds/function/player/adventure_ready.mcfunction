# Called once generation completes, or immediately when joining an already-built ClayGrounds save.
spawnpoint @s 0 63 -8
teleport @s 0.5 63 -8.5 0 0
effect clear @s minecraft:resistance
title @s times 10 50 10
title @s title {"text":"CLAYGROUNDS","color":"yellow","bold":true}
title @s subtitle {"text":"Welcome to Solmere — the islands are awake.","color":"aqua"}
tellraw @s {"text":"FIRST CONTRACT: Head east to Sunwash Strand and defeat 8 creatures. Your class level rises from combat EXP.","color":"gold"}
tellraw @s {"text":"At Lv.5, return to the Guild Hall and right-click one of the three profession altars.","color":"yellow"}
