function claygrounds:combat/cooldowns
function claygrounds:class/sync
function claygrounds:progress/kills
function claygrounds:progress/story
function claygrounds:hud/show
execute unless score @s cg_seen_deaths = @s cg_deaths run function claygrounds:player/death
execute if score @s cg_story matches 2.. if block 0 64 67 minecraft:iron_bars run function claygrounds:world/open_grotto
execute if score @s cg_story matches 2 if entity @s[x=-18,y=60,z=105,dx=36,dy=20,dz=45] if score #boss cg_world matches 0 run function claygrounds:boss/start
# ClayGrounds custom mob visual cleanup.
execute as @e[tag=cg_enemy,nbt={DeathTime:1s}] at @s run kill @e[type=minecraft:item_display,tag=cg_visual,distance=..0.75,limit=1,sort=nearest]
execute as @e[type=minecraft:item_display,tag=cg_visual] at @s unless entity @e[tag=cg_enemy,distance=..0.75] run kill @s

