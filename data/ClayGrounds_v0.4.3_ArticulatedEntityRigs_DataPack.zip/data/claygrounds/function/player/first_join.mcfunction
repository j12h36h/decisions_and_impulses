gamerule minecraft:keep_inventory true
gamerule minecraft:immediate_respawn true
gamerule minecraft:spawn_mobs false
gamerule minecraft:mob_griefing false
tag @s add cg_player
scoreboard players set @s cg_class 0
scoreboard players set @s cg_main 0
scoreboard players set @s cg_level 1
scoreboard players set @s cg_xp 0
scoreboard players set @s cg_gold 0
scoreboard players set @s cg_story 0
scoreboard players set @s cg_subclass 0
scoreboard players set @s cg_a_lv 1
scoreboard players set @s cg_a_xp 0
scoreboard players set @s cg_f_lv 1
scoreboard players set @s cg_f_xp 0
scoreboard players set @s cg_r_lv 1
scoreboard players set @s cg_r_xp 0
scoreboard players set @s cg_m_lv 1
scoreboard players set @s cg_m_xp 0
scoreboard players set @s cg_f_un 0
scoreboard players set @s cg_r_un 0
scoreboard players set @s cg_m_un 0
scoreboard players add @s cg_deaths 0
scoreboard players operation @s cg_seen_deaths = @s cg_deaths
scoreboard players add @s cg_kills 0
scoreboard players operation @s cg_seen_kills = @s cg_kills
scoreboard players set @s cg_cd_atk 0
scoreboard players set @s cg_cd1 0
scoreboard players set @s cg_cd2 0
scoreboard players set @s cg_cd3 0
scoreboard players set @s cg_cdpot 0
clear @s
function claygrounds:kit/current
spawnpoint @s 0 63 -8
teleport @s 0.5 63 -8.5 0 0
gamemode adventure @s
effect give @s minecraft:saturation 2 5 true
execute unless score #built cg_world matches 1 run title @s times 0 40 10
execute unless score #built cg_world matches 1 run title @s title {"text":"BUILDING CLAYGROUNDS","color":"aqua","bold":true}
execute unless score #built cg_world matches 1 run title @s subtitle {"text":"The ocean already exists; the islands are rising around Solmere — watch the live build timer.","color":"yellow"}
execute if score #built cg_world matches 1 run function claygrounds:player/adventure_ready
