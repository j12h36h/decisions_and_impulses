execute unless entity @s[tag=cg_player] run function claygrounds:player/first_join
tag @s add cg_player
scoreboard players add @s cg_deaths 0
scoreboard players operation @s cg_seen_deaths = @s cg_deaths
scoreboard players add @s cg_kills 0
scoreboard players operation @s cg_seen_kills = @s cg_kills
spawnpoint @s 0 63 -8
teleport @s 0.5 63 -8.5 0 0
gamemode adventure @s
function claygrounds:kit/current
bossbar set claygrounds:shorewarden players @s
tellraw @s {"text":"Returned to Solmere. Class, subclass, story, EXP and gold are persistent.","color":"aqua"}
