scoreboard players set #boss cg_world 1
bossbar set claygrounds:shorewarden players @a[tag=cg_player]
bossbar set claygrounds:shorewarden visible true
summon claygrounds:shorewarden 0 64 129 {Tags:['cg_enemy','cg_boss'],CustomName:{text:'Shorewarden',color:'dark_aqua',bold:true},CustomNameVisible:0b,PersistenceRequired:1b,Silent:1b}
title @s title {"text":"SHOREWARDEN","color":"dark_aqua","bold":true}
title @s subtitle {"text":"Break the guardian of the Sunken Grotto.","color":"white"}
playsound minecraft:entity.ravager.roar hostile @s ~ ~ ~ 1 0.8
effect give @e[tag=cg_boss,limit=1] minecraft:fire_resistance 999999 0 true
