scoreboard players set #boss cg_world 2
bossbar set claygrounds:shorewarden visible false
scoreboard players set @a[tag=cg_player,scores={cg_story=2}] cg_story 3
scoreboard players set @a[tag=cg_player,scores={cg_story=3}] cg_subclass 1
scoreboard players add @a[tag=cg_player,scores={cg_story=3}] cg_gold 1000
scoreboard players add @a[tag=cg_player,scores={cg_story=3}] cg_xp 400
title @a[tag=cg_player,scores={cg_story=3}] title {"text":"SUBCLASS LICENSE EARNED","color":"gold","bold":true}
title @a[tag=cg_player,scores={cg_story=3}] subtitle {"text":"Return to the Guild Hall. All three professions can now coexist on this character.","color":"aqua"}
tellraw @a[tag=cg_player,scores={cg_story=3}] {"text":"Subclassing unlocked: right-click any Guild Hall profession altar to switch. Each class stores its own level and EXP.","color":"yellow"}
execute as @a[tag=cg_player,scores={cg_story=3}] run function claygrounds:progress/check_level
kill @e[type=minecraft:item_display,tag=cg_boss_visual]
