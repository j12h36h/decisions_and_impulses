execute if score @s cg_class matches 0 run function claygrounds:hud/adventurer
execute if score @s cg_class matches 1 run function claygrounds:hud/fighter
execute if score @s cg_class matches 2 run function claygrounds:hud/ranger
execute if score @s cg_class matches 3 run function claygrounds:hud/mystic
