scoreboard players set @s cg_cd2 65
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 1 1.2
particle minecraft:enchanted_hit ~ ~1 ~ 3 1 3 0.15 70 force @s
tag @s add cg_attack_source
execute as @e[tag=cg_enemy,distance=..5] run damage @s 9 minecraft:magic by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
