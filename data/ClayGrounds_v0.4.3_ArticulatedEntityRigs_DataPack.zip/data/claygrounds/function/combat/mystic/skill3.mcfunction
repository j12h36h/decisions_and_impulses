scoreboard players set @s cg_cd3 125
playsound minecraft:entity.blaze.shoot player @s ~ ~ ~ 0.8 0.8
particle minecraft:flame ^ ^2 ^4 3 2 3 0.08 90 force @s
tag @s add cg_attack_source
execute anchored eyes positioned ^ ^ ^4 as @e[tag=cg_enemy,distance=..5.5] run damage @s 13 minecraft:magic by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
