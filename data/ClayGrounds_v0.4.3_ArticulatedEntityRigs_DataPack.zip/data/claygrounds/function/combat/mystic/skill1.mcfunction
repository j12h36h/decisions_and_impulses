scoreboard players set @s cg_cd1 40
effect give @s minecraft:speed 2 4 true
particle minecraft:portal ~ ~1 ~ 0.7 1 0.7 0.2 40 force @s
