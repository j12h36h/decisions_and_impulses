execute unless score @s cg_cdpot matches 0 run return 0
scoreboard players set @s cg_cdpot 160
effect give @s minecraft:regeneration 4 2 true
effect give @s minecraft:saturation 1 1 true
playsound minecraft:item.honey_bottle.drink player @s ~ ~ ~ 0.7 1.2
title @s actionbar {"text":"Tide Tonic used — 8s cooldown","color":"green"}
