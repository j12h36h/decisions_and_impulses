scoreboard players set @s cg_cd2 55
particle minecraft:crit ^ ^1 ^2 1 0.5 1 0.15 24 force @s
tag @s add cg_attack_source
execute anchored eyes positioned ^ ^ ^2 as @e[tag=cg_enemy,distance=..2.5] run damage @s 5 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
