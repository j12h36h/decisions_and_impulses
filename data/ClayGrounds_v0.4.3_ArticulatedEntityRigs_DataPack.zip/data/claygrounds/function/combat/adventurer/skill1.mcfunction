scoreboard players set @s cg_cd1 35
effect give @s minecraft:speed 2 2 true
particle minecraft:cloud ~ ~1 ~ 0.3 0.1 0.3 0.03 12 force @s
