scoreboard players set @s cg_cd3 100
particle minecraft:dust_plume ~ ~1 ~ 2 0.5 2 0.08 35 force @s
tag @s add cg_attack_source
execute as @e[tag=cg_enemy,distance=..4] run damage @s 6 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
