execute unless score @s cg_cd3 matches 0 run return 0
execute if score @s cg_class matches 0 run function claygrounds:combat/adventurer/skill3
execute if score @s cg_class matches 1 run function claygrounds:combat/fighter/skill3
execute if score @s cg_class matches 2 run function claygrounds:combat/ranger/skill3
execute if score @s cg_class matches 3 run function claygrounds:combat/mystic/skill3
