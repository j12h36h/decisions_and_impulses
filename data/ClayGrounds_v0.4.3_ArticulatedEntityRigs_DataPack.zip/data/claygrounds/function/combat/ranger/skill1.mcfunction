scoreboard players set @s cg_cd1 40
effect give @s minecraft:speed 3 3 true
effect give @s minecraft:jump_boost 2 1 true
particle minecraft:cloud ~ ~1 ~ 0.5 0.2 0.5 0.04 20 force @s
