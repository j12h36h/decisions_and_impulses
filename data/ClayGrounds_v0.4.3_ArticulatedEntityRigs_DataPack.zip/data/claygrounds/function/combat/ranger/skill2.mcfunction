scoreboard players set @s cg_cd2 65
playsound minecraft:entity.arrow.shoot player @s ~ ~ ~ 1 1.6
particle minecraft:electric_spark ^ ^1.4 ^5 0.3 0.3 4 0 24 force @s
tag @s add cg_attack_source
execute anchored eyes positioned ^ ^ ^4 as @e[tag=cg_enemy,distance=..2] run damage @s 8 minecraft:arrow by @a[tag=cg_attack_source,limit=1]
execute anchored eyes positioned ^ ^ ^8 as @e[tag=cg_enemy,distance=..2] run damage @s 8 minecraft:arrow by @a[tag=cg_attack_source,limit=1]
execute anchored eyes positioned ^ ^ ^12 as @e[tag=cg_enemy,distance=..2] run damage @s 8 minecraft:arrow by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
