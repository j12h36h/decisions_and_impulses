scoreboard players set @s cg_cd3 120
playsound minecraft:entity.firework_rocket.launch player @s ~ ~ ~ 0.8 1.4
particle minecraft:firework ^ ^5 ^6 4 4 4 0.08 70 force @s
tag @s add cg_attack_source
execute anchored eyes positioned ^ ^ ^6 as @e[tag=cg_enemy,distance=..6] run damage @s 10 minecraft:arrow by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
