execute unless score @s cg_cd_atk matches 0 run return 0
scoreboard players set @s cg_cd_atk 6
particle minecraft:sweep_attack ^ ^1 ^2 1.1 0.5 1.1 0.0 14 force @s
tag @s add cg_attack_source
execute if score @s cg_level matches ..5 as @e[tag=cg_enemy,distance=..3.4] run damage @s 5 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
execute if score @s cg_level matches 6.. as @e[tag=cg_enemy,distance=..3.7] run damage @s 7 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
