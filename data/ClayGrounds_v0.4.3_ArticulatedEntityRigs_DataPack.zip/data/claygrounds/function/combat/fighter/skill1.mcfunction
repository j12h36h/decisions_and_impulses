scoreboard players set @s cg_cd1 45
effect give @s minecraft:speed 2 3 true
effect give @s minecraft:resistance 2 1 true
particle minecraft:cloud ~ ~1 ~ 0.5 0.2 0.5 0.05 18 force @s
