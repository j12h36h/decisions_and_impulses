scoreboard players set @s cg_cd3 120
playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.7 0.8
particle minecraft:dust_plume ~ ~0.5 ~ 3 0.8 3 0.15 70 force @s
tag @s add cg_attack_source
execute as @e[tag=cg_enemy,distance=..6] run damage @s 12 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
effect give @s minecraft:resistance 3 2 true
tag @s remove cg_attack_source
