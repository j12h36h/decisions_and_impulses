scoreboard players set @s cg_cd2 70
particle minecraft:sweep_attack ~ ~1 ~ 1.8 0.5 1.8 0 32 force @s
tag @s add cg_attack_source
execute as @e[tag=cg_enemy,distance=..4.5] run damage @s 9 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
