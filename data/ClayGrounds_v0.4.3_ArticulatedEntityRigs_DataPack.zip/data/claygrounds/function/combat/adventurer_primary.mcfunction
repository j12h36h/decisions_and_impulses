execute unless score @s cg_cd_atk matches 0 run return 0
scoreboard players set @s cg_cd_atk 8
particle minecraft:sweep_attack ^ ^1 ^2 0.7 0.4 0.7 0.0 8 force @s
tag @s add cg_attack_source
execute as @e[tag=cg_enemy,distance=..2.8] run damage @s 3 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
