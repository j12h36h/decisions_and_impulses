execute if score @s cg_class matches 0 if items entity @s weapon.mainhand minecraft:wooden_sword run function claygrounds:combat/adventurer_primary
execute if score @s cg_class matches 1 if items entity @s weapon.mainhand minecraft:iron_sword run function claygrounds:combat/fighter_primary
