execute unless score @s cg_class matches 3 run return 0
execute unless score @s cg_cd_atk matches 0 run return 0
scoreboard players set @s cg_cd_atk 9
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.8 1.6
particle minecraft:witch ^ ^1 ^3 0.8 0.8 0.8 0.04 22 force @s
tag @s add cg_attack_source
execute anchored eyes positioned ^ ^ ^3 if score @s cg_level matches ..5 as @e[tag=cg_enemy,distance=..2.3] run damage @s 5 minecraft:magic by @a[tag=cg_attack_source,limit=1]
execute anchored eyes positioned ^ ^ ^3 if score @s cg_level matches 6.. as @e[tag=cg_enemy,distance=..2.7] run damage @s 7 minecraft:magic by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
