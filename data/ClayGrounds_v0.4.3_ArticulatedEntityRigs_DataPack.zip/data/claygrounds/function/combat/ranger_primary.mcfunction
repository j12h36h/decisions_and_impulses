execute unless score @s cg_class matches 2 run return 0
execute unless score @s cg_cd_atk matches 0 run return 0
scoreboard players set @s cg_cd_atk 7
playsound minecraft:entity.arrow.shoot player @s ~ ~ ~ 0.7 1.3
particle minecraft:electric_spark ^ ^1.35 ^2 0.15 0.15 0.15 0 4 force @s
particle minecraft:electric_spark ^ ^1.35 ^5 0.15 0.15 0.15 0 4 force @s
particle minecraft:electric_spark ^ ^1.35 ^8 0.15 0.15 0.15 0 4 force @s
particle minecraft:electric_spark ^ ^1.35 ^11 0.15 0.15 0.15 0 4 force @s
tag @s add cg_attack_source
execute anchored eyes positioned ^ ^ ^2 as @e[tag=cg_enemy,distance=..1.3] run damage @s 4 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
execute anchored eyes positioned ^ ^ ^5 as @e[tag=cg_enemy,distance=..1.3] run damage @s 4 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
execute anchored eyes positioned ^ ^ ^8 as @e[tag=cg_enemy,distance=..1.3] run damage @s 4 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
execute anchored eyes positioned ^ ^ ^11 as @e[tag=cg_enemy,distance=..1.3] run damage @s 4 minecraft:player_attack by @a[tag=cg_attack_source,limit=1]
tag @s remove cg_attack_source
