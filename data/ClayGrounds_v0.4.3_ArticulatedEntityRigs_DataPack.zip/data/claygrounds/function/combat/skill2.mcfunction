execute unless score @s cg_cd2 matches 0 run return 0
execute if score @s cg_class matches 0 run function claygrounds:combat/adventurer/skill2
execute if score @s cg_class matches 1 run function claygrounds:combat/fighter/skill2
execute if score @s cg_class matches 2 run function claygrounds:combat/ranger/skill2
execute if score @s cg_class matches 3 run function claygrounds:combat/mystic/skill2
