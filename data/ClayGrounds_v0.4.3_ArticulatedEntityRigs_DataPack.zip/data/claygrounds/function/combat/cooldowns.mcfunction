execute if score @s cg_cd_atk matches 1.. run scoreboard players remove @s cg_cd_atk 1
execute if score @s cg_cd1 matches 1.. run scoreboard players remove @s cg_cd1 1
execute if score @s cg_cd2 matches 1.. run scoreboard players remove @s cg_cd2 1
execute if score @s cg_cd3 matches 1.. run scoreboard players remove @s cg_cd3 1
execute if score @s cg_cdpot matches 1.. run scoreboard players remove @s cg_cdpot 1
