execute if score @s cg_main matches 0 if score @s cg_level matches ..4 run tellraw @s {"text":"Profession advancement requires Adventurer Lv.5.","color":"red"}
execute if score @s cg_main matches 0 if score @s cg_level matches 5.. run function claygrounds:class/advance/fighter
execute if score @s cg_main matches 1.. if score @s cg_subclass matches 0 run tellraw @s {"text":"Subclassing unlocks after defeating the Shorewarden.","color":"gold"}
execute if score @s cg_main matches 1.. if score @s cg_subclass matches 1.. unless score @s cg_class matches 1 run function claygrounds:class/switch/fighter
execute if score @s cg_class matches 1 if score @s cg_main matches 1.. run title @s actionbar {"text":"Fighter is already active.","color":"gray"}
