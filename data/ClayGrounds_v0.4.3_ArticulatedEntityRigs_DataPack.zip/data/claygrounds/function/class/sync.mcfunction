execute if score @s cg_class matches 0 run scoreboard players operation @s cg_a_lv = @s cg_level
execute if score @s cg_class matches 0 run scoreboard players operation @s cg_a_xp = @s cg_xp
execute if score @s cg_class matches 1 run scoreboard players operation @s cg_f_lv = @s cg_level
execute if score @s cg_class matches 1 run scoreboard players operation @s cg_f_xp = @s cg_xp
execute if score @s cg_class matches 2 run scoreboard players operation @s cg_r_lv = @s cg_level
execute if score @s cg_class matches 2 run scoreboard players operation @s cg_r_xp = @s cg_xp
execute if score @s cg_class matches 3 run scoreboard players operation @s cg_m_lv = @s cg_level
execute if score @s cg_class matches 3 run scoreboard players operation @s cg_m_xp = @s cg_xp
