function claygrounds:class/save_current
execute if score @s cg_r_un matches 0 run scoreboard players set @s cg_r_lv 1
execute if score @s cg_r_un matches 0 run scoreboard players set @s cg_r_xp 0
scoreboard players set @s cg_r_un 1
scoreboard players set @s cg_class 2
scoreboard players operation @s cg_level = @s cg_r_lv
scoreboard players operation @s cg_xp = @s cg_r_xp
function claygrounds:kit/ranger
title @s title {"text":"RANGER","color":"green","bold":true}
title @s subtitle {"text":"Subclass switched — story and character progress retained.","color":"white"}
