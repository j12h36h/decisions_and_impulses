function claygrounds:class/save_current
execute if score @s cg_m_un matches 0 run scoreboard players set @s cg_m_lv 1
execute if score @s cg_m_un matches 0 run scoreboard players set @s cg_m_xp 0
scoreboard players set @s cg_m_un 1
scoreboard players set @s cg_class 3
scoreboard players operation @s cg_level = @s cg_m_lv
scoreboard players operation @s cg_xp = @s cg_m_xp
function claygrounds:kit/mystic
title @s title {"text":"MYSTIC","color":"light_purple","bold":true}
title @s subtitle {"text":"Subclass switched — story and character progress retained.","color":"white"}
