function claygrounds:class/save_current
execute if score @s cg_f_un matches 0 run scoreboard players set @s cg_f_lv 1
execute if score @s cg_f_un matches 0 run scoreboard players set @s cg_f_xp 0
scoreboard players set @s cg_f_un 1
scoreboard players set @s cg_class 1
scoreboard players operation @s cg_level = @s cg_f_lv
scoreboard players operation @s cg_xp = @s cg_f_xp
function claygrounds:kit/fighter
title @s title {"text":"FIGHTER","color":"red","bold":true}
title @s subtitle {"text":"Subclass switched — story and character progress retained.","color":"white"}
