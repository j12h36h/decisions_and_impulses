function claygrounds:class/sync
