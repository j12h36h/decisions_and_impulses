function claygrounds:class/save_current
scoreboard players set @s cg_main 3
scoreboard players set @s cg_class 3
scoreboard players set @s cg_m_un 1
scoreboard players operation @s cg_m_lv = @s cg_a_lv
scoreboard players operation @s cg_m_xp = @s cg_a_xp
scoreboard players operation @s cg_level = @s cg_m_lv
scoreboard players operation @s cg_xp = @s cg_m_xp
scoreboard players set @s cg_story 2
function claygrounds:kit/mystic
function claygrounds:world/open_grotto
title @s title {"text":"MYSTIC AWAKENED","color":"light_purple","bold":true}
title @s subtitle {"text":"The Sunken Grotto is now open.","color":"aqua"}
tellraw @s {"text":"NEXT CONTRACT: Enter the Sunken Grotto south of Solmere and defeat the Shorewarden.","color":"gold"}
