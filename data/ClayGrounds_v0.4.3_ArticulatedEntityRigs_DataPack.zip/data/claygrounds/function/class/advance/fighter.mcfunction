function claygrounds:class/save_current
scoreboard players set @s cg_main 1
scoreboard players set @s cg_class 1
scoreboard players set @s cg_f_un 1
scoreboard players operation @s cg_f_lv = @s cg_a_lv
scoreboard players operation @s cg_f_xp = @s cg_a_xp
scoreboard players operation @s cg_level = @s cg_f_lv
scoreboard players operation @s cg_xp = @s cg_f_xp
scoreboard players set @s cg_story 2
function claygrounds:kit/fighter
function claygrounds:world/open_grotto
title @s title {"text":"FIGHTER AWAKENED","color":"red","bold":true}
title @s subtitle {"text":"The Sunken Grotto is now open.","color":"aqua"}
tellraw @s {"text":"NEXT CONTRACT: Enter the Sunken Grotto south of Solmere and defeat the Shorewarden.","color":"gold"}
