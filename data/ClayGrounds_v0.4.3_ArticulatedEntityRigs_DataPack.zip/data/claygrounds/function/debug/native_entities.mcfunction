# ClayGrounds v0.3.4 native entity registration smoke test.
# Run: /function claygrounds:debug/native_entities
execute if entity @e[type=claygrounds:clayling] run tellraw @s {"text":"FOUND claygrounds:clayling","color":"green"}
execute if entity @e[type=claygrounds:sunscorched] run tellraw @s {"text":"FOUND claygrounds:sunscorched","color":"green"}
execute if entity @e[type=claygrounds:vinecrawler] run tellraw @s {"text":"FOUND claygrounds:vinecrawler","color":"green"}
execute if entity @e[type=claygrounds:mossbound] run tellraw @s {"text":"FOUND claygrounds:mossbound","color":"green"}
execute if entity @e[type=claygrounds:canopy_fang] run tellraw @s {"text":"FOUND claygrounds:canopy_fang","color":"green"}
execute if entity @e[type=claygrounds:claycrest_archer] run tellraw @s {"text":"FOUND claygrounds:claycrest_archer","color":"green"}
execute if entity @e[type=claygrounds:ruins_sentinel] run tellraw @s {"text":"FOUND claygrounds:ruins_sentinel","color":"green"}
execute if entity @e[type=claygrounds:kilnbound] run tellraw @s {"text":"FOUND claygrounds:kilnbound","color":"green"}
execute if entity @e[type=claygrounds:shorewarden] run tellraw @s {"text":"FOUND claygrounds:shorewarden","color":"green"}
tellraw @s {"text":"Native entity smoke test complete. Spawn-cycle entities will appear after world construction.","color":"aqua"}
