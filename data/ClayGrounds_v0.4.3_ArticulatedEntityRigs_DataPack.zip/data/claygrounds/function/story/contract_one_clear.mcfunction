scoreboard players set @s cg_story 1
title @s title {"text":"CONTRACT COMPLETE","color":"gold","bold":true}
title @s subtitle {"text":"Reach Lv.5 and choose your profession at the Solmere Guild Hall.","color":"yellow"}
tellraw @s {"text":"Guild Advancement unlocked. Right-click the Fighter, Ranger, or Mystic altar once you reach Lv.5.","color":"aqua"}
