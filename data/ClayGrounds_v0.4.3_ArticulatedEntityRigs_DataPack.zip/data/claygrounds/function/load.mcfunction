# ClayGrounds v0.3.2 load — floating island + resumable construction.
function claygrounds:bootstrap/ensure
scoreboard players set #tick cg_world 0
scoreboard players set #anim cg_world 0
scoreboard players set #boss cg_world 0
scoreboard players set #2 cg_world 2
scoreboard players set #3 cg_world 3
scoreboard players set #20 cg_world 20
scoreboard players set #40 cg_world 40
scoreboard players set #60 cg_world 60
scoreboard players set #100 cg_world 100
scoreboard players set #105 cg_world 105
scoreboard players set #344 cg_world 344
scoreboard players set #foundation_total cg_world 55
scoreboard players set #total_work cg_world 399
bossbar set claygrounds:loading max 399
bossbar set claygrounds:loading color blue
bossbar set claygrounds:loading style progress
bossbar set claygrounds:shorewarden max 100
bossbar set claygrounds:shorewarden visible false
schedule clear claygrounds:worldgen/staged/loop
execute if score #gen_active cg_world matches 1 unless score #built cg_world matches 1 unless score #foundation_step cg_world matches 0..55 run scoreboard players set #foundation_step cg_world 0
execute if score #gen_active cg_world matches 1 unless score #built cg_world matches 1 unless score #build_step cg_world matches 0..344 run scoreboard players set #build_step cg_world 0
execute if score #gen_active cg_world matches 1 unless score #built cg_world matches 1 if score #foundation_step cg_world matches ..54 run scoreboard players set #gen_phase cg_world 0
execute if score #gen_active cg_world matches 1 unless score #built cg_world matches 1 if score #foundation_step cg_world matches 55.. run scoreboard players set #gen_phase cg_world 1
execute if score #gen_active cg_world matches 1 unless score #built cg_world matches 1 unless score #build_clock cg_world matches -1000..1000 run scoreboard players set #build_clock cg_world -40
execute if score #gen_active cg_world matches 1 unless score #built cg_world matches 1 run bossbar set claygrounds:loading visible true

# v0.3.8: purge stale legacy display bodies; visual_sync recreates them with modern item_model routing.
kill @e[tag=cg_visual]
