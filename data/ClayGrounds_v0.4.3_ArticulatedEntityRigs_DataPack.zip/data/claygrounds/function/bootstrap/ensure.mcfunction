# ClayGrounds v0.2.8 — order-independent runtime bootstrap.
# DAI can invoke worldgen before Minecraft's normal load-tag tick, so worldgen must be able to create its own state.
execute unless data storage claygrounds:runtime {bootstrap:1b} run function claygrounds:bootstrap/create
