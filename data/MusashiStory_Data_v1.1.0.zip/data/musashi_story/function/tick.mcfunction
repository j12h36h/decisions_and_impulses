
function musashi_story:bootstrap/ensure
scoreboard players add #tick ms_world 1
scoreboard players add #anim ms_world 1
execute if score #region_cd ms_world matches 1.. run scoreboard players remove #region_cd ms_world 1
execute if score #anim ms_world matches 20.. run scoreboard players set #anim ms_world 0
execute if score #gen_active ms_world matches 1 run function musashi_story:worldgen/base/pulse
execute if score #built ms_world matches 1 unless score #quality_v050 ms_world matches 1 run function musashi_story:worldgen/quality_pass
execute if score #tick ms_world matches 5.. as @a[tag=ms_player] at @s run function musashi_story:player/tick
execute if score #tick ms_world matches 10.. as @a[tag=ms_player] if score @s ms_resolve matches ..99 run scoreboard players add @s ms_resolve 1
execute if score #tick ms_world matches 20.. as @a[tag=ms_player] run function musashi_story:player/hud
execute if score #tick ms_world matches 20.. as @a[tag=ms_player] at @s run function musashi_story:worldgen/regions/pulse
execute if score #tick ms_world matches 100.. run function musashi_story:enemy/spawn_cycle
execute if score #tick ms_world matches 100.. run scoreboard players set #tick ms_world 0
function musashi_story:enemy/death_scan
function musashi_story:enemy/safety
function musashi_story:enemy/visual_sync
function musashi_story:enemy/visual_animate
