# ClayGrounds v0.4.6 — restrained first-pass decoration outside Solmere.
# Route markers are placed beside, not inside, the main travel lanes.

# Sunwash Strand approach — warm lantern marker and beach driftwood accents.
fill 47 63 -7 47 65 -7 minecraft:stripped_jungle_log
setblock 47 66 -7 minecraft:lantern
setblock 56 63 10 minecraft:stripped_oak_wood[axis=x]
setblock 58 63 12 minecraft:stripped_oak_wood[axis=z]

# Verdant Steps approach — mossy cairns and flowering markers.
fill -7 63 -48 -7 65 -48 minecraft:mossy_cobblestone
setblock -7 66 -48 minecraft:lantern
setblock 8 63 -56 minecraft:moss_block
setblock 8 64 -56 minecraft:flowering_azalea
setblock -10 63 -60 minecraft:moss_block
setblock -10 64 -60 minecraft:azalea

# Claycrest Ruins approach — broken masonry rather than pristine decoration.
setblock -48 63 -7 minecraft:cracked_stone_bricks
setblock -49 63 -7 minecraft:mossy_stone_bricks
setblock -49 64 -7 minecraft:stone_brick_wall
setblock -56 63 9 minecraft:cracked_stone_bricks
setblock -57 63 9 minecraft:mossy_cobblestone

# Sunken Grotto approach — low prismarine light markers.
setblock -6 63 48 minecraft:prismarine_bricks
setblock -6 64 48 minecraft:sea_lantern
setblock 6 63 48 minecraft:prismarine_bricks
setblock 6 64 48 minecraft:sea_lantern
