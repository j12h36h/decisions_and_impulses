# ClayGrounds v0.4.6 map polish entrypoint.
function claygrounds:worldgen/polish/solmere
function claygrounds:worldgen/polish/routes
scoreboard players set #map_revision cg_world 46
data modify storage claygrounds:runtime map_revision set value 46
