# ClayGrounds v0.3.2 — reliable vanilla-flat bootstrap + one connected floating island.
function claygrounds:bootstrap/ensure
scoreboard players set #2 cg_world 2
scoreboard players set #3 cg_world 3
scoreboard players set #4 cg_world 4
scoreboard players set #5 cg_world 5
scoreboard players set #7 cg_world 7
scoreboard players set #8 cg_world 8
scoreboard players set #20 cg_world 20
scoreboard players set #40 cg_world 40
scoreboard players set #100 cg_world 100
scoreboard players set #344 cg_world 344
scoreboard players set #foundation_total cg_world 55
scoreboard players set #total_work cg_world 399
data modify storage claygrounds:runtime generation_requested set value 1b
data modify storage claygrounds:runtime generation_complete set value 0b

kill @e[tag=cg_static]
kill @e[tag=cg_enemy]
kill @e[tag=cg_visual]
# Safe arrival pad. The actual connected island foundation forms underneath it first.
fill -8 62 -16 8 62 0 minecraft:smooth_sandstone
fill -8 63 -16 8 68 0 minecraft:air
setworldspawn 0 63 -8
scoreboard players set #built cg_world 0
scoreboard players set #gen_active cg_world 1
scoreboard players set #gen_phase cg_world 0
scoreboard players set #foundation_step cg_world 0
scoreboard players set #build_step cg_world 0
scoreboard players set #build_clock cg_world -20
scoreboard players set #ui_clock cg_world 0
scoreboard players set #build_eta cg_world 31
scoreboard players set #build_pct cg_world 0
scoreboard players set #work_done cg_world 0
scoreboard players set #gen_idx cg_world 0
schedule clear claygrounds:worldgen/staged/loop
bossbar set claygrounds:loading max 399
bossbar set claygrounds:loading players @a
bossbar set claygrounds:loading value 0
bossbar set claygrounds:loading visible true

title @a times 5 40 5
title @a title {"text":"BUILDING CLAYGROUNDS","color":"aqua","bold":true}
title @a subtitle {"text":"Forming the floating island...","color":"gold"}
