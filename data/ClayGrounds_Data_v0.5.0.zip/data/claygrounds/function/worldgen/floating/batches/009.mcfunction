# ClayGrounds v0.4.6 fast generation batch 10/11
# Compiled from authored steps 045..049; visual-only per-step effects omitted.
fill -111 47 44 111 47 59 minecraft:tuff
fill -100 47 60 100 47 75 minecraft:tuff
fill -86 47 76 86 47 91 minecraft:tuff
fill -63 47 92 63 47 107 minecraft:tuff
fill -32 47 108 32 47 116 minecraft:tuff
fill -40 46 -98 40 46 -83 minecraft:tuff
fill -68 46 -82 68 46 -67 minecraft:tuff
fill -85 46 -66 85 46 -51 minecraft:tuff
fill -95 46 -50 95 46 -35 minecraft:tuff
fill -102 46 -34 102 46 -19 minecraft:tuff
fill -105 46 -18 105 46 -3 minecraft:tuff
fill -105 46 -2 105 46 13 minecraft:tuff
fill -103 46 14 103 46 29 minecraft:tuff
fill -97 46 30 97 46 45 minecraft:tuff
fill -88 46 46 88 46 61 minecraft:tuff
fill -74 46 62 74 46 77 minecraft:tuff
fill -51 46 78 51 46 93 minecraft:tuff
fill -21 46 94 21 46 98 minecraft:tuff
fill -36 45 -78 36 45 -63 minecraft:deepslate
fill -61 45 -62 61 45 -47 minecraft:deepslate
scoreboard players set #foundation_step cg_world 50
