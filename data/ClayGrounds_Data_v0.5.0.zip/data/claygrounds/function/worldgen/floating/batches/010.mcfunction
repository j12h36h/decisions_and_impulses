# ClayGrounds v0.4.6 fast generation batch 11/11
# Compiled from authored steps 050..054; visual-only per-step effects omitted.
fill -74 45 -46 74 45 -31 minecraft:deepslate
fill -82 45 -30 82 45 -15 minecraft:deepslate
fill -85 45 -14 85 45 1 minecraft:deepslate
fill -85 45 2 85 45 17 minecraft:deepslate
fill -81 45 18 81 45 33 minecraft:deepslate
fill -72 45 34 72 45 49 minecraft:deepslate
fill -58 45 50 58 45 65 minecraft:deepslate
fill -33 45 66 33 45 78 minecraft:deepslate
fill -31 44 -54 31 44 -39 minecraft:deepslate
fill -51 44 -38 51 44 -23 minecraft:deepslate
fill -59 44 -22 59 44 -7 minecraft:deepslate
fill -61 44 -6 61 44 9 minecraft:deepslate
fill -58 44 10 58 44 25 minecraft:deepslate
fill -48 44 26 48 44 41 minecraft:deepslate
fill -28 44 42 28 44 54 minecraft:deepslate
fill -23 43 -28 23 43 -13 minecraft:deepslate
fill -33 43 -12 33 43 3 minecraft:deepslate
fill -30 43 4 30 43 19 minecraft:deepslate
fill -17 43 20 17 43 28 minecraft:deepslate
scoreboard players set #foundation_step cg_world 55
