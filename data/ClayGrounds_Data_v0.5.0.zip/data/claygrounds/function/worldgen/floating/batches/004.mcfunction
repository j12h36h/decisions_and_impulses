# ClayGrounds v0.4.6 fast generation batch 5/11
# Compiled from authored steps 020..024; visual-only per-step effects omitted.
fill -182 52 -32 182 52 -17 minecraft:stone
fill -183 52 -16 183 52 -1 minecraft:stone
fill -183 52 0 183 52 15 minecraft:stone
fill -182 52 16 182 52 31 minecraft:stone
fill -179 52 32 179 52 47 minecraft:stone
fill -174 52 48 174 52 63 minecraft:stone
fill -168 52 64 168 52 79 minecraft:stone
fill -159 52 80 159 52 95 minecraft:stone
fill -148 52 96 148 52 111 minecraft:stone
fill -135 52 112 135 52 127 minecraft:stone
fill -117 52 128 117 52 143 minecraft:stone
fill -93 52 144 93 52 159 minecraft:stone
fill -56 52 160 56 52 175 minecraft:stone
fill -51 51 -168 51 51 -153 minecraft:stone
fill -89 51 -152 89 51 -137 minecraft:stone
fill -113 51 -136 113 51 -121 minecraft:stone
fill -130 51 -120 130 51 -105 minecraft:stone
fill -144 51 -104 144 51 -89 minecraft:stone
fill -154 51 -88 154 51 -73 minecraft:stone
fill -162 51 -72 162 51 -57 minecraft:stone
scoreboard players set #foundation_step cg_world 25
