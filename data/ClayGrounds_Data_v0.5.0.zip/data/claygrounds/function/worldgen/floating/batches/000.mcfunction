# ClayGrounds v0.4.6 fast generation batch 1/11
# Compiled from authored steps 000..004; visual-only per-step effects omitted.
fill -54 55 -188 54 55 -173 minecraft:grass_block
fill -94 55 -172 94 55 -157 minecraft:grass_block
fill -120 55 -156 120 55 -141 minecraft:grass_block
fill -139 55 -140 139 55 -125 minecraft:grass_block
fill -153 55 -124 153 55 -109 minecraft:grass_block
fill -165 55 -108 165 55 -93 minecraft:grass_block
fill -175 55 -92 175 55 -77 minecraft:grass_block
fill -182 55 -76 182 55 -61 minecraft:grass_block
fill -188 55 -60 188 55 -45 minecraft:grass_block
fill -192 55 -44 192 55 -29 minecraft:grass_block
fill -194 55 -28 194 55 -13 minecraft:grass_block
fill -195 55 -12 195 55 3 minecraft:grass_block
fill -195 55 4 195 55 19 minecraft:grass_block
fill -193 55 20 193 55 35 minecraft:grass_block
fill -190 55 36 190 55 51 minecraft:grass_block
fill -185 55 52 185 55 67 minecraft:grass_block
fill -179 55 68 179 55 83 minecraft:grass_block
fill -171 55 84 171 55 99 minecraft:grass_block
fill -160 55 100 160 55 115 minecraft:grass_block
fill -147 55 116 147 55 131 minecraft:grass_block
scoreboard players set #foundation_step cg_world 5
