# ClayGrounds v0.4.6 fast generation batch 7/11
# Compiled from authored steps 030..034; visual-only per-step effects omitted.
fill -155 50 -62 155 50 -47 minecraft:stone
fill -160 50 -46 160 50 -31 minecraft:stone
fill -164 50 -30 164 50 -15 minecraft:stone
fill -165 50 -14 165 50 1 minecraft:stone
fill -165 50 2 165 50 17 minecraft:stone
fill -163 50 18 163 50 33 minecraft:stone
fill -160 50 34 160 50 49 minecraft:stone
fill -154 50 50 154 50 65 minecraft:stone
fill -146 50 66 146 50 81 minecraft:stone
fill -136 50 82 136 50 97 minecraft:stone
fill -123 50 98 123 50 113 minecraft:stone
fill -106 50 114 106 50 129 minecraft:stone
fill -81 50 130 81 50 145 minecraft:stone
fill -45 50 146 45 50 158 minecraft:stone
fill -48 49 -146 48 49 -131 minecraft:andesite
fill -83 49 -130 83 49 -115 minecraft:andesite
fill -105 49 -114 105 49 -99 minecraft:andesite
fill -120 49 -98 120 49 -83 minecraft:andesite
fill -132 49 -82 132 49 -67 minecraft:andesite
fill -141 49 -66 141 49 -51 minecraft:andesite
scoreboard players set #foundation_step cg_world 35
