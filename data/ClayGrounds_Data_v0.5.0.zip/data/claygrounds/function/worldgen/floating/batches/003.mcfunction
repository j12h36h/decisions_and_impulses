# ClayGrounds v0.4.6 fast generation batch 4/11
# Compiled from authored steps 015..019; visual-only per-step effects omitted.
fill -189 53 10 189 53 25 minecraft:dirt
fill -186 53 26 186 53 41 minecraft:dirt
fill -182 53 42 182 53 57 minecraft:dirt
fill -177 53 58 177 53 73 minecraft:dirt
fill -169 53 74 169 53 89 minecraft:dirt
fill -160 53 90 160 53 105 minecraft:dirt
fill -148 53 106 148 53 121 minecraft:dirt
fill -133 53 122 133 53 137 minecraft:dirt
fill -114 53 138 114 53 153 minecraft:dirt
fill -87 53 154 87 53 169 minecraft:dirt
fill -48 53 170 48 53 182 minecraft:dirt
fill -53 52 -176 53 52 -161 minecraft:stone
fill -91 52 -160 91 52 -145 minecraft:stone
fill -116 52 -144 116 52 -129 minecraft:stone
fill -134 52 -128 134 52 -113 minecraft:stone
fill -148 52 -112 148 52 -97 minecraft:stone
fill -159 52 -96 159 52 -81 minecraft:stone
fill -167 52 -80 167 52 -65 minecraft:stone
fill -174 52 -64 174 52 -49 minecraft:stone
fill -179 52 -48 179 52 -33 minecraft:stone
scoreboard players set #foundation_step cg_world 20
