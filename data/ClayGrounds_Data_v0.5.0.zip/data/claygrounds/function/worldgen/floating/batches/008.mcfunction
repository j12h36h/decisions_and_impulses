# ClayGrounds v0.4.6 fast generation batch 9/11
# Compiled from authored steps 040..044; visual-only per-step effects omitted.
fill -139 48 -20 139 48 -5 minecraft:stone
fill -139 48 -4 139 48 11 minecraft:stone
fill -138 48 12 138 48 27 minecraft:stone
fill -134 48 28 134 48 43 minecraft:stone
fill -128 48 44 128 48 59 minecraft:stone
fill -120 48 60 120 48 75 minecraft:stone
fill -108 48 76 108 48 91 minecraft:stone
fill -91 48 92 91 48 107 minecraft:stone
fill -67 48 108 67 48 123 minecraft:stone
fill -34 48 124 34 48 132 minecraft:stone
fill -43 47 -116 43 47 -101 minecraft:tuff
fill -74 47 -100 74 47 -85 minecraft:tuff
fill -93 47 -84 93 47 -69 minecraft:tuff
fill -105 47 -68 105 47 -53 minecraft:tuff
fill -114 47 -52 114 47 -37 minecraft:tuff
fill -120 47 -36 120 47 -21 minecraft:tuff
fill -123 47 -20 123 47 -5 minecraft:tuff
fill -123 47 -4 123 47 11 minecraft:tuff
fill -122 47 12 122 47 27 minecraft:tuff
fill -118 47 28 118 47 43 minecraft:tuff
scoreboard players set #foundation_step cg_world 45
