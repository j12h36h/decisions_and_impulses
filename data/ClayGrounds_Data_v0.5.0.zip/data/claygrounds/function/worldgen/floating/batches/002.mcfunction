# ClayGrounds v0.4.6 fast generation batch 3/11
# Compiled from authored steps 010..014; visual-only per-step effects omitted.
fill -176 54 70 176 54 85 minecraft:dirt
fill -167 54 86 167 54 101 minecraft:dirt
fill -156 54 102 156 54 117 minecraft:dirt
fill -143 54 118 143 54 133 minecraft:dirt
fill -125 54 134 125 54 149 minecraft:dirt
fill -103 54 150 103 54 165 minecraft:dirt
fill -69 54 166 69 54 181 minecraft:dirt
fill -28 54 182 28 54 186 minecraft:dirt
fill -53 53 -182 53 53 -167 minecraft:dirt
fill -93 53 -166 93 53 -151 minecraft:dirt
fill -118 53 -150 118 53 -135 minecraft:dirt
fill -136 53 -134 136 53 -119 minecraft:dirt
fill -150 53 -118 150 53 -103 minecraft:dirt
fill -162 53 -102 162 53 -87 minecraft:dirt
fill -171 53 -86 171 53 -71 minecraft:dirt
fill -178 53 -70 178 53 -55 minecraft:dirt
fill -183 53 -54 183 53 -39 minecraft:dirt
fill -187 53 -38 187 53 -23 minecraft:dirt
fill -189 53 -22 189 53 -7 minecraft:dirt
fill -189 53 -6 189 53 9 minecraft:dirt
scoreboard players set #foundation_step cg_world 15
