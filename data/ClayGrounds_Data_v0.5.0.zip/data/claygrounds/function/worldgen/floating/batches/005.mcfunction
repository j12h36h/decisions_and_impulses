# ClayGrounds v0.4.6 fast generation batch 6/11
# Compiled from authored steps 025..029; visual-only per-step effects omitted.
fill -168 51 -56 168 51 -41 minecraft:stone
fill -172 51 -40 172 51 -25 minecraft:stone
fill -175 51 -24 175 51 -9 minecraft:stone
fill -175 51 -8 175 51 7 minecraft:stone
fill -175 51 8 175 51 23 minecraft:stone
fill -172 51 24 172 51 39 minecraft:stone
fill -168 51 40 168 51 55 minecraft:stone
fill -162 51 56 162 51 71 minecraft:stone
fill -155 51 72 155 51 87 minecraft:stone
fill -144 51 88 144 51 103 minecraft:stone
fill -131 51 104 131 51 119 minecraft:stone
fill -114 51 120 114 51 135 minecraft:stone
fill -91 51 136 91 51 151 minecraft:stone
fill -55 51 152 55 51 167 minecraft:stone
fill -50 50 -158 50 50 -143 minecraft:stone
fill -87 50 -142 87 50 -127 minecraft:stone
fill -109 50 -126 109 50 -111 minecraft:stone
fill -126 50 -110 126 50 -95 minecraft:stone
fill -138 50 -94 138 50 -79 minecraft:stone
fill -148 50 -78 148 50 -63 minecraft:stone
scoreboard players set #foundation_step cg_world 30
