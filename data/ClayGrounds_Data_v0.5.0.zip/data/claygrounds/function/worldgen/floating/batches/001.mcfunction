# ClayGrounds v0.4.6 fast generation batch 2/11
# Compiled from authored steps 005..009; visual-only per-step effects omitted.
fill -131 55 132 131 55 147 minecraft:grass_block
fill -110 55 148 110 55 163 minecraft:grass_block
fill -80 55 164 80 55 179 minecraft:grass_block
fill -40 55 180 40 55 188 minecraft:grass_block
fill -54 54 -186 54 54 -171 minecraft:dirt
fill -94 54 -170 94 54 -155 minecraft:dirt
fill -119 54 -154 119 54 -139 minecraft:dirt
fill -138 54 -138 138 54 -123 minecraft:dirt
fill -152 54 -122 152 54 -107 minecraft:dirt
fill -164 54 -106 164 54 -91 minecraft:dirt
fill -173 54 -90 173 54 -75 minecraft:dirt
fill -181 54 -74 181 54 -59 minecraft:dirt
fill -186 54 -58 186 54 -43 minecraft:dirt
fill -190 54 -42 190 54 -27 minecraft:dirt
fill -193 54 -26 193 54 -11 minecraft:dirt
fill -193 54 -10 193 54 5 minecraft:dirt
fill -193 54 6 193 54 21 minecraft:dirt
fill -191 54 22 191 54 37 minecraft:dirt
fill -188 54 38 188 54 53 minecraft:dirt
fill -183 54 54 183 54 69 minecraft:dirt
scoreboard players set #foundation_step cg_world 10
