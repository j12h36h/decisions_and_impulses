# ClayGrounds v0.4.6 fast generation batch 8/11
# Compiled from authored steps 035..039; visual-only per-step effects omitted.
fill -147 49 -50 147 49 -35 minecraft:andesite
fill -151 49 -34 151 49 -19 minecraft:andesite
fill -153 49 -18 153 49 -3 minecraft:andesite
fill -153 49 -2 153 49 13 minecraft:andesite
fill -152 49 14 152 49 29 minecraft:andesite
fill -148 49 30 148 49 45 minecraft:andesite
fill -143 49 46 143 49 61 minecraft:andesite
fill -135 49 62 135 49 77 minecraft:andesite
fill -124 49 78 124 49 93 minecraft:andesite
fill -110 49 94 110 49 109 minecraft:andesite
fill -91 49 110 91 49 125 minecraft:andesite
fill -62 49 126 62 49 141 minecraft:andesite
fill -25 49 142 25 49 146 minecraft:andesite
fill -46 48 -132 46 48 -117 minecraft:stone
fill -79 48 -116 79 48 -101 minecraft:stone
fill -99 48 -100 99 48 -85 minecraft:stone
fill -114 48 -84 114 48 -69 minecraft:stone
fill -124 48 -68 124 48 -53 minecraft:stone
fill -131 48 -52 131 48 -37 minecraft:stone
fill -136 48 -36 136 48 -21 minecraft:stone
scoreboard players set #foundation_step cg_world 40
