# ClayGrounds v0.4.6 — 5 authored foundation steps per safe bulk batch.
# Range matching intentionally supports upgrading/resuming worlds that stopped mid-batch.
execute if score #foundation_step cg_world matches 50..54 run function claygrounds:worldgen/floating/batches/010
execute if score #foundation_step cg_world matches 45..49 run function claygrounds:worldgen/floating/batches/009
execute if score #foundation_step cg_world matches 40..44 run function claygrounds:worldgen/floating/batches/008
execute if score #foundation_step cg_world matches 35..39 run function claygrounds:worldgen/floating/batches/007
execute if score #foundation_step cg_world matches 30..34 run function claygrounds:worldgen/floating/batches/006
execute if score #foundation_step cg_world matches 25..29 run function claygrounds:worldgen/floating/batches/005
execute if score #foundation_step cg_world matches 20..24 run function claygrounds:worldgen/floating/batches/004
execute if score #foundation_step cg_world matches 15..19 run function claygrounds:worldgen/floating/batches/003
execute if score #foundation_step cg_world matches 10..14 run function claygrounds:worldgen/floating/batches/002
execute if score #foundation_step cg_world matches 5..9 run function claygrounds:worldgen/floating/batches/001
execute if score #foundation_step cg_world matches 0..4 run function claygrounds:worldgen/floating/batches/000
