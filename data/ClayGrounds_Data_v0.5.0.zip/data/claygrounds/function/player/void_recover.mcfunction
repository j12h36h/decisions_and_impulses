effect give @s minecraft:resistance 4 4 true
effect give @s minecraft:regeneration 3 2 true
teleport @s 0.5 63 -8.5 0 0
spawnpoint @s 0 63 -8
title @s actionbar {"text":"SOLMERE WAYSTONE // terrain recovery","color":"aqua"}
