# ClayGrounds global tick — v0.4.3 floating-island world + articulated custom entity rigs
scoreboard players add #tick cg_world 1
scoreboard players add #anim cg_world 1
execute if score #anim cg_world matches 32.. run scoreboard players set #anim cg_world 0

# Startup watchdog: if DAI created the safe arrival platform but the worldgen scores were lost before load initialization, recover once.
execute if entity @a unless score #built cg_world matches 1 unless score #gen_active cg_world matches 1 if block 0 62 -8 minecraft:smooth_sandstone run function claygrounds:worldgen/build/recover

# v0.4.6 proven bounded-batch pattern: persistent normal-tick generation without schedules or giant dispatch scans.
execute if entity @a if score #gen_active cg_world matches 1 unless score #built cg_world matches 1 run function claygrounds:worldgen/build/tick

# Keep the player on the safe arrival pad while the visible world build runs; preserve camera rotation.
execute unless score #built cg_world matches 1 as @a run teleport @s 0.5 63 -8.5
execute unless score #built cg_world matches 1 as @a run effect give @s minecraft:resistance 2 255 true
execute unless score #built cg_world matches 1 as @a run effect give @s minecraft:saturation 2 5 true

# Gameplay remains dormant until the complete map exists.
execute if score #built cg_world matches 1 if score #tick cg_world matches 100.. run function claygrounds:enemy/spawn_cycle
execute if score #tick cg_world matches 100.. run scoreboard players set #tick cg_world 0
execute if score #built cg_world matches 1 run function claygrounds:enemy/safety
execute if score #built cg_world matches 1 run function claygrounds:enemy/visual_sync
execute if score #built cg_world matches 1 run function claygrounds:enemy/visual_animate
execute if score #built cg_world matches 1 as @a[tag=cg_player] run function claygrounds:player/tick

# Boss lifecycle
execute if score #built cg_world matches 1 if score #boss cg_world matches 1 unless entity @e[tag=cg_boss] run function claygrounds:boss/clear
execute if score #built cg_world matches 1 if score #boss cg_world matches 1 store result bossbar claygrounds:shorewarden value run data get entity @e[tag=cg_boss,limit=1] Health 1
