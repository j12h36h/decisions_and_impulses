ClayGrounds v0.4.6 — DAI 1.9.9 Fast Worldgen + Town Polish

CURRENT PACK PAIR
- Datapack: ClayGrounds v0.4.6
- Resource Pack: ClayGrounds v0.4.6
- Minecraft Java: 26.2
- DAI: 1.9.9
- This datapack explicitly declares itself as a DAI MAIN experience.
- Stable DAI datapack identity: `claygrounds`.
- Managed datapack version: `0.4.6`.
- The paired resource pack uses stable companion id `claygrounds` and requests automatic enablement through DAI 1.9.9.
- v0.4.6 preserves gameplay/progression and adds bounded fast generation, corrected Solmere house elevation, a rebuilt fountain, and the first map-decoration pass.

ClayGrounds v0.3.3 — Floating Island Edition

ClayGrounds v0.3.3 — Floating Island Patch

- Replaced the unresolved custom native-ocean world preset with proven minecraft:flat save creation.
- Removed the ocean requirement entirely.
- ClayGrounds now forms one large connected floating island beneath the existing authored map.
- The island top is an ellipse roughly 392 x 376 blocks at Y55, large enough to support all current authored terrain (map extents are about +/-176).
- The underside tapers through 13 solid layers down to Y43 for an actual hanging-island silhouette.
- Foundation is generated in 55 conservative steps, four modest fills per tick after a 2-second settle period.
- Existing Solmere, Sunwash Strand, Verdant Steps, Claycrest Ruins, Sunken Grotto, class altars, encounters, boss arena, and coordinates are preserved.
- Existing terrain still builds at the proven two-steps-per-three-ticks TamaCrafti-style cadence.
- Total visible work units: 399 (55 foundation + 344 authored terrain).
- No broad ocean-fill phase exists. Only the existing small fountain/Verdant decorative water remains.
- Custom claygrounds_ocean/claygrounds_void Create World presets were removed from this pack because the latest DAI log proved they are unavailable to Minecraft's Create World registry at experience creation time.

ClayGrounds v0.2.8

ClayGrounds v0.2.0 — DAI 1.9.1 / Minecraft 26.2 gameplay hotfix

HOTFIX APPLIED AFTER LIVE TEST
- Updated every custom_model_data item component to Minecraft 26.2's structured floats map.
- Updated custom enemy/boss item_display passenger stacks to the same 26.2 component format.
- Reworked all multi-target combat damage so /damage receives one entity at a time while still crediting the player source.
- Added enemy fall recovery and daylight fire resistance to stop the repeated Y=-60 death/respawn loop.
- Rebuilt the generated landscape again with thick tapered islands, connected encounter fields, broader safe spawn clearings, lower Solmere buildings, and a compact Grotto arena.
- Preserved the paired v0.2.0 resource-pack model numbers and all progression anchor coordinates.

DAI Engine datapack game vertical slice.

This version REQUIRES the paired ClayGrounds v0.2.0 Resource Pack.
The datapack keeps the v0.2.0 CustomModelData IDs, enemy display-model IDs, class items, reactions, HUD hooks, and gameplay coordinates intact.

PATCHED NEW ADVENTURE FLOW
- START NEW ADVENTURE now targets the ClayGrounds DAI experience as before.
- DAI creates the save with the built-in minecraft:flat preset, which is resolvable before the experience datapack is installed into the new save.
- On DAI first-start worldgen, claygrounds:worldgen/generate constructs the ClayGrounds island layer at its existing gameplay elevation.
- player/first_join no longer blindly runs the whole map build a second time; it only falls back to generation if the DAI worldgen marker is missing.

WORLD PATCH
- Replaced the giant rectangular Solmere/Strand/Verdant/Ruins/Grotto land plates with deterministic organic contour generation.
- Preserved all combat spawn anchors, the 0 63 -8 player spawn, the exact three class altar coordinates, the Sunken Grotto gate, and the Shorewarden arena.
- Retained authored buildings/dungeon architecture while making the surrounding landscape irregular and vertically layered.
- Added ClayGrounds recognition definitions for Solmere, Sunwash Strand, Verdant Steps, Claycrest Ruins, and Sunken Grotto so DAI recognition can classify the generated landmarks at runtime.

Core loop:
- Explore Solmere and three tropical hunting grounds.
- Level Adventurer to 5.
- Choose Fighter, Ranger, or Mystic at the Guild Hall altars.
- Enter the Sunken Grotto and defeat the Shorewarden.
- Unlock subclassing and switch among all three professions on the same character.
- Every class keeps its own level and EXP while story, gold, and exploration remain character-wide.

Requires the DAI Engine Mod version supplied with this project and the paired ClayGrounds v0.2.0 Resource Pack.


v0.2.8 BUILD SYSTEM
- Replaced the v0.2.4 scheduled 64-cell generator with TamaCrafti's proven normal-tick clock/step pattern.
- Uses 374 persistent visual build steps, matching the scale of TamaCrafti's 374-step home build.
- Calls the step routine twice every 3 ticks, approximately 2x TamaCrafti's construction cadence.
- Groups the existing 2,892 authored ClayGrounds commands into 7-8-command visual steps; final map geometry is preserved.
- Terrain and structures assemble before water; water fills use replace-air so completed land is not overwritten.
- No worldgen force-load grid and no recurring schedule callback are used.
- Live bossbar + actionbar show true step progress, percent, and ~seconds remaining.


v0.3.0 OCEAN-FIRST BUILD
- The ocean now exists before island construction instead of being filled at the end.
- 64 safe ocean cells form a 384x384 shallow sea around the map.
- Sand seabed: Y=55. Ocean water: Y=56..61.
- Terrain then builds into the sea at ~2x TamaCrafti cadence.
- Broad final ocean fills were removed; only tiny local fountain/waterfall fills remain at finalization.
- Combined loading progress is 409 units and is phase-labelled OCEAN FORMATION / ISLAND CONSTRUCTION.


v0.3.1 NATIVE OCEAN WORLD
- Ocean is generated by claygrounds:claygrounds_ocean before gameplay/bootstrap commands run.
- Runtime ocean fill phase removed.
- 344-step island build remains at ~2x TamaCrafti cadence.
- Sea geometry remains sand Y55 / water Y56..61 so all authored Y coordinates stay unchanged.


=== v0.3.4 Native DAI Entities ===
All nine ClayGrounds enemy identities are now registry-backed DAI EntityTypes. Vanilla mobs are used only as DAI implementation templates; the registered identity and loot table are ClayGrounds-owned. CustomModelData item-display bodies remain the visible presentation.


=== v0.3.5 Native Entity Visual Sync ===
Native entities remain the authoritative gameplay bodies. Their CustomModelData presentation is no longer mounted as a passenger; independent item_display bodies are synchronized to the native entity position and rotation each tick to eliminate carrier seat-offset distortion.
