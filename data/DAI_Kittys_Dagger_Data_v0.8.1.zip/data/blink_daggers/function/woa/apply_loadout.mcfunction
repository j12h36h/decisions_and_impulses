# World of Addons HUD integration: default Minecraft hotbar keys become MOBA ability keys.
# 1=Q, 2=W, 3=E/main kit, 4=R/ultimate. Slots 5-9 remain available for utility, wards and items.
clear @s blink_daggers:kitty_dagger
clear @s blink_daggers:kitty_directional_throw
clear @s blink_daggers:kitty_up_throw
clear @s blink_daggers:kitty_ultimate
item replace entity @s hotbar.0 with blink_daggers:kitty_directional_throw[minecraft:damage=1]
item replace entity @s hotbar.1 with blink_daggers:kitty_up_throw[minecraft:damage=1]
item replace entity @s hotbar.2 with blink_daggers:kitty_dagger[minecraft:damage=1]
item replace entity @s hotbar.3 with blink_daggers:kitty_ultimate[minecraft:damage=1]
title @s actionbar [{"text":"KITTY CLAWS  ","color":"light_purple","bold":true},{"text":"1/Q Throw · 2/W Up Throw · 3/E Dagger · 4/R Ultimate","color":"gray"}]
