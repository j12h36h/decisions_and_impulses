# Standalone behavior is preserved. World of Addons players receive a fixed MOBA hotbar layout.
execute if entity @s[tag=woa_joined] run function blink_daggers:woa/apply_loadout
execute unless entity @s[tag=woa_joined] run give @s blink_daggers:kitty_dagger[minecraft:damage=1] 1
execute unless entity @s[tag=woa_joined] run give @s blink_daggers:kitty_directional_throw[minecraft:damage=1] 1
execute unless entity @s[tag=woa_joined] run give @s blink_daggers:kitty_up_throw[minecraft:damage=1] 1
execute unless entity @s[tag=woa_joined] run give @s blink_daggers:kitty_ultimate[minecraft:damage=1] 1
