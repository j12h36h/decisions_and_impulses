# Kitty's Dagger v0.8.1 — World of Addons HUD Integration

- Preserves the existing standalone `blink_daggers:give` behavior outside World of Addons.
- Detects the World of Addons `woa_joined` player context.
- In a Rift, maps Kitty's four kit items to hotbar slots 1–4:
  - 1 / Q — Directional Throw
  - 2 / W — Up Throw
  - 3 / E — Kitty's Dagger / combined kit
  - 4 / R — Ultimate
- Leaves slots 5–9 free for utility, wards and purchased items.
