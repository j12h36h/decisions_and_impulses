# ClayGrounds global tick — v0.6.0 DAI 3.1 runtime cadence modernization
scoreboard players add #tick cg_world 1
scoreboard players add #anim cg_world 1
scoreboard players add #visual_clock cg_world 1
scoreboard players add #ensure_clock cg_world 1
scoreboard players add #safety_clock cg_world 1
execute if score #anim cg_world matches 32.. run scoreboard players set #anim cg_world 0

# Startup watchdog: if DAI created the safe arrival platform but the worldgen scores were lost before load initialization, recover once.
execute if entity @a unless score #built cg_world matches 1 unless score #gen_active cg_world matches 1 if block 0 62 -8 minecraft:smooth_sandstone run function claygrounds:worldgen/build/recover

# v0.4.6 proven bounded-batch pattern: persistent normal-tick generation without schedules or giant dispatch scans.
execute if entity @a if score #gen_active cg_world matches 1 unless score #built cg_world matches 1 run function claygrounds:worldgen/build/tick

# Keep the player on the safe arrival pad while the visible world build runs; preserve camera rotation.
execute unless score #built cg_world matches 1 as @a run teleport @s 0.5 63 -8.5
execute unless score #built cg_world matches 1 as @a run effect give @s minecraft:resistance 2 255 true
execute unless score #built cg_world matches 1 as @a run effect give @s minecraft:saturation 2 5 true

# Gameplay remains dormant until the complete map exists.
execute if score #built cg_world matches 1 if score #tick cg_world matches 100.. run function claygrounds:enemy/spawn_cycle
execute if score #tick cg_world matches 100.. run scoreboard players set #tick cg_world 0
# Expensive global scans are cadence-limited; responsive player/combat logic remains 20 TPS.
execute if score #built cg_world matches 1 if score #safety_clock cg_world matches 10.. run function claygrounds:enemy/safety
execute if score #safety_clock cg_world matches 10.. run scoreboard players set #safety_clock cg_world 0
execute if score #built cg_world matches 1 if score #visual_clock cg_world matches 2.. run function claygrounds:enemy/visual_follow
execute if score #visual_clock cg_world matches 2.. run scoreboard players set #visual_clock cg_world 0
execute if score #built cg_world matches 1 if score #ensure_clock cg_world matches 20.. run function claygrounds:enemy/visual_ensure
execute if score #built cg_world matches 1 if score #ensure_clock cg_world matches 20.. run function claygrounds:enemy/visual_cleanup
execute if score #ensure_clock cg_world matches 20.. run scoreboard players set #ensure_clock cg_world 0
execute if score #built cg_world matches 1 run function claygrounds:enemy/visual_animate
execute if score #built cg_world matches 1 as @a[tag=cg_player] run function claygrounds:player/tick

# Boss lifecycle
execute if score #built cg_world matches 1 if score #boss cg_world matches 1 unless entity @e[tag=cg_boss] run function claygrounds:boss/clear
execute if score #built cg_world matches 1 if score #boss cg_world matches 1 store result bossbar claygrounds:shorewarden value run data get entity @e[tag=cg_boss,limit=1] Health 1
