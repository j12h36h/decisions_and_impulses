function claygrounds:combat/cooldowns
function claygrounds:class/sync
function claygrounds:progress/kills
function claygrounds:progress/story
function claygrounds:hud/show
execute unless score @s cg_seen_deaths = @s cg_deaths run function claygrounds:player/death
execute if score @s cg_story matches 2.. if block 0 64 67 minecraft:iron_bars run function claygrounds:world/open_grotto
execute if score @s cg_story matches 2 if entity @s[x=-18,y=60,z=105,dx=36,dy=20,dz=45] if score #boss cg_world matches 0 run function claygrounds:boss/start


# v0.5.0 physical-location recovery: below Y45 is beneath every authored island/ocean floor.
execute if entity @s[y=-64,dy=108] run function claygrounds:player/void_recover
