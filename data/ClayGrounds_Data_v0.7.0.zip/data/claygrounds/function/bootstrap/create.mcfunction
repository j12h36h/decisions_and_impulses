# ClayGrounds v0.2.8 — create persistent objectives and bossbars exactly once per world.
scoreboard objectives add cg_class dummy
scoreboard objectives add cg_main dummy
scoreboard objectives add cg_level dummy
scoreboard objectives add cg_xp dummy
scoreboard objectives add cg_gold dummy
scoreboard objectives add cg_story dummy
scoreboard objectives add cg_subclass dummy
scoreboard objectives add cg_seen_deaths dummy
scoreboard objectives add cg_seen_kills dummy
scoreboard objectives add cg_delta dummy
scoreboard objectives add cg_gain dummy
scoreboard objectives add cg_need dummy
scoreboard objectives add cg_cd_atk dummy
scoreboard objectives add cg_cd1 dummy
scoreboard objectives add cg_cd2 dummy
scoreboard objectives add cg_cd3 dummy
scoreboard objectives add cg_cdpot dummy
scoreboard objectives add cg_a_lv dummy
scoreboard objectives add cg_a_xp dummy
scoreboard objectives add cg_f_lv dummy
scoreboard objectives add cg_f_xp dummy
scoreboard objectives add cg_r_lv dummy
scoreboard objectives add cg_r_xp dummy
scoreboard objectives add cg_m_lv dummy
scoreboard objectives add cg_m_xp dummy
scoreboard objectives add cg_f_un dummy
scoreboard objectives add cg_r_un dummy
scoreboard objectives add cg_m_un dummy
scoreboard objectives add cg_world dummy
scoreboard objectives add cg_deaths deathCount
scoreboard objectives add cg_kills totalKillCount

scoreboard players set #tick cg_world 0
scoreboard players set #anim cg_world 0
scoreboard players set #visual_clock cg_world 0
scoreboard players set #ensure_clock cg_world 0
scoreboard players set #safety_clock cg_world 0
scoreboard players set #gen_cadence cg_world 0
scoreboard players set #boss cg_world 0
scoreboard players set #40 cg_world 40
scoreboard players set #60 cg_world 60
scoreboard players set #100 cg_world 100
scoreboard players set #2 cg_world 2
scoreboard players set #3 cg_world 3
scoreboard players set #4 cg_world 4
scoreboard players set #5 cg_world 5
scoreboard players set #7 cg_world 7
scoreboard players set #8 cg_world 8
scoreboard players set #20 cg_world 20
scoreboard players set #344 cg_world 344
scoreboard players set #foundation_total cg_world 55
scoreboard players set #total_work cg_world 399
scoreboard players set #105 cg_world 105

bossbar add claygrounds:loading {"text":"Building ClayGrounds","color":"aqua","bold":true}
bossbar set claygrounds:loading max 399
bossbar set claygrounds:loading value 0
bossbar set claygrounds:loading color blue
bossbar set claygrounds:loading style progress
bossbar set claygrounds:loading visible false
bossbar add claygrounds:shorewarden {"text":"Shorewarden","color":"dark_aqua","bold":true}
bossbar set claygrounds:shorewarden max 100
bossbar set claygrounds:shorewarden visible false

data modify storage claygrounds:runtime bootstrap set value 1b
