# ClayGrounds v0.5.0 canonical shoreline-access repair.
function claygrounds:worldgen/polish/routes
function claygrounds:worldgen/polish/shorelines
scoreboard players set #map_revision cg_world 50
data modify storage claygrounds:runtime modernization_v050 set value 1b
tellraw @a[tag=cg_player] [{"text":"CLAYGROUNDS // ","color":"aqua","bold":true},{"text":"shoreline access and critical routes updated in place.","color":"gray"}]
