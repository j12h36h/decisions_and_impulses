# ClayGrounds v0.6.0 in-place DAI 3.1 town/runtime repair.
# Re-run the canonical Solmere pass now that its fountain block id is valid in Minecraft 26.2.
function claygrounds:worldgen/polish/solmere
# Preserve the v0.5 shoreline/accessibility work as part of the new revision.
function claygrounds:worldgen/polish/routes
function claygrounds:worldgen/polish/shorelines
# Remove legacy articulated visual bodies; the new runtime recreates only what is needed.
kill @e[tag=cg_visual]
scoreboard players set #map_revision cg_world 60
data modify storage claygrounds:runtime map_revision set value 60
data modify storage claygrounds:runtime modernization_v060 set value 1b
tellraw @a[tag=cg_player] [{"text":"CLAYGROUNDS // ","color":"aqua","bold":true},{"text":"DAI 3.1 town geometry and runtime modernization applied.","color":"gray"}]
