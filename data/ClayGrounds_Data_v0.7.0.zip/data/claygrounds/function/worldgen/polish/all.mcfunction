# ClayGrounds v0.6.0 map polish entrypoint.
function claygrounds:worldgen/polish/solmere
function claygrounds:worldgen/polish/routes
function claygrounds:worldgen/polish/shorelines
scoreboard players set #map_revision cg_world 60
data modify storage claygrounds:runtime map_revision set value 60
