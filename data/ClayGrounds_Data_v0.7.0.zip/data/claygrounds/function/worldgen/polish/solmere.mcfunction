# ClayGrounds v0.6.0 — canonical Solmere grade/fountain repair + decoration pass.
# The Guild Hall/class-selection building remains untouched and is the correct Y reference.

# -----------------------------------------------------------------------------
# Four residential/shop houses: lower the shell/floor by one block to match town grade.
# Existing v0.4.5 shells are cleared first so this is safe as an in-place world migration.
# -----------------------------------------------------------------------------

# Northwest / orange house
fill -30 63 -25 -17 67 -14 minecraft:air
fill -29 62 -24 -18 62 -15 minecraft:orange_terracotta
fill -29 63 -24 -29 65 -15 minecraft:orange_terracotta
fill -18 63 -24 -18 65 -15 minecraft:orange_terracotta
fill -28 63 -24 -19 65 -24 minecraft:orange_terracotta
fill -28 63 -15 -19 65 -15 minecraft:orange_terracotta
fill -28 63 -23 -19 65 -16 minecraft:air
fill -30 66 -25 -17 66 -14 minecraft:jungle_planks
fill -25 63 -24 -23 65 -24 minecraft:air
setblock -28 64 -24 minecraft:lantern
setblock -19 64 -24 minecraft:lantern
setblock -29 64 -20 minecraft:light_blue_stained_glass_pane
setblock -18 64 -20 minecraft:light_blue_stained_glass_pane
fill -25 62 -26 -23 62 -25 minecraft:smooth_sandstone

# Northeast / yellow house
fill 17 63 -25 30 67 -14 minecraft:air
fill 18 62 -24 29 62 -15 minecraft:yellow_terracotta
fill 18 63 -24 18 65 -15 minecraft:yellow_terracotta
fill 29 63 -24 29 65 -15 minecraft:yellow_terracotta
fill 19 63 -24 28 65 -24 minecraft:yellow_terracotta
fill 19 63 -15 28 65 -15 minecraft:yellow_terracotta
fill 19 63 -23 28 65 -16 minecraft:air
fill 17 66 -25 30 66 -14 minecraft:jungle_planks
fill 22 63 -24 24 65 -24 minecraft:air
setblock 19 64 -24 minecraft:lantern
setblock 28 64 -24 minecraft:lantern
setblock 18 64 -20 minecraft:light_blue_stained_glass_pane
setblock 29 64 -20 minecraft:light_blue_stained_glass_pane
fill 22 62 -26 24 62 -25 minecraft:smooth_sandstone

# Southwest / light-blue house
fill -30 63 12 -17 67 23 minecraft:air
fill -29 62 13 -18 62 22 minecraft:light_blue_terracotta
fill -29 63 13 -29 65 22 minecraft:light_blue_terracotta
fill -18 63 13 -18 65 22 minecraft:light_blue_terracotta
fill -28 63 13 -19 65 13 minecraft:light_blue_terracotta
fill -28 63 22 -19 65 22 minecraft:light_blue_terracotta
fill -28 63 14 -19 65 21 minecraft:air
fill -30 66 12 -17 66 23 minecraft:dark_oak_planks
fill -25 63 13 -23 65 13 minecraft:air
setblock -28 64 13 minecraft:lantern
setblock -19 64 13 minecraft:lantern
setblock -29 64 18 minecraft:light_blue_stained_glass_pane
setblock -18 64 18 minecraft:light_blue_stained_glass_pane
fill -25 62 11 -23 62 12 minecraft:smooth_sandstone

# Southeast / red house
fill 17 63 12 30 67 23 minecraft:air
fill 18 62 13 29 62 22 minecraft:red_terracotta
fill 18 63 13 18 65 22 minecraft:red_terracotta
fill 29 63 13 29 65 22 minecraft:red_terracotta
fill 19 63 13 28 65 13 minecraft:red_terracotta
fill 19 63 22 28 65 22 minecraft:red_terracotta
fill 19 63 14 28 65 21 minecraft:air
fill 17 66 12 30 66 23 minecraft:dark_oak_planks
fill 22 63 13 24 65 13 minecraft:air
setblock 19 64 13 minecraft:lantern
setblock 28 64 13 minecraft:lantern
setblock 18 64 18 minecraft:light_blue_stained_glass_pane
setblock 29 64 18 minecraft:light_blue_stained_glass_pane
fill 22 62 11 24 62 12 minecraft:smooth_sandstone

# -----------------------------------------------------------------------------
# Fountain rebuild: contained lower basin + raised reflecting bowl.
# Removes the old invisible barrier catch-ring and the loose top water source.
# -----------------------------------------------------------------------------
fill 17 63 -4 27 68 6 minecraft:air
fill 18 62 -3 26 62 5 minecraft:stone_bricks
fill 18 63 -3 26 63 5 minecraft:cut_sandstone
fill 19 63 -2 25 63 4 minecraft:water
# Center pedestal and raised bowl
fill 21 63 0 23 64 2 minecraft:smooth_sandstone
setblock 22 64 1 minecraft:sea_lantern
fill 20 65 -1 24 65 3 minecraft:cut_sandstone
fill 21 65 0 23 65 2 minecraft:water
setblock 22 65 1 minecraft:sandstone_wall
setblock 22 66 1 minecraft:sea_lantern
# Basin corner lamps
setblock 18 64 -3 minecraft:lantern
setblock 26 64 -3 minecraft:lantern
setblock 18 64 5 minecraft:lantern
setblock 26 64 5 minecraft:lantern

# -----------------------------------------------------------------------------
# Plaza furniture and landscaping. Keep the two main cross-town travel lanes open.
# -----------------------------------------------------------------------------
# Fountain benches
fill 19 63 -6 25 63 -6 minecraft:jungle_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
fill 19 63 8 25 63 8 minecraft:jungle_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
# Small west-plaza benches
fill -27 63 -7 -21 63 -7 minecraft:jungle_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
fill -27 63 8 -21 63 8 minecraft:jungle_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]

# Flower/greenery planters beside the Guild Hall approach
fill -17 62 17 -15 62 30 minecraft:mud_bricks
fill 15 62 17 17 62 30 minecraft:mud_bricks
fill -16 63 18 -16 63 29 minecraft:moss_block
fill 16 63 18 16 63 29 minecraft:moss_block
setblock -16 64 20 minecraft:flowering_azalea
setblock -16 64 26 minecraft:azalea
setblock 16 64 20 minecraft:azalea
setblock 16 64 26 minecraft:flowering_azalea

# Decorative lamp posts around the plaza and town exits
fill -34 63 0 -34 65 0 minecraft:stripped_jungle_log
setblock -34 66 0 minecraft:lantern
fill 34 63 0 34 65 0 minecraft:stripped_jungle_log
setblock 34 66 0 minecraft:lantern
fill 0 63 -28 0 65 -28 minecraft:stripped_jungle_log
setblock 0 66 -28 minecraft:lantern
fill 0 63 15 0 65 15 minecraft:stripped_jungle_log
setblock 0 66 15 minecraft:lantern

# Two compact open-air market awnings off the main road
fill -29 62 5 -20 62 10 minecraft:smooth_sandstone
fill -28 63 6 -28 66 9 minecraft:stripped_jungle_log
fill -21 63 6 -21 66 9 minecraft:stripped_jungle_log
fill -28 66 6 -21 66 9 minecraft:orange_wool
fill -27 66 6 -26 66 9 minecraft:yellow_wool
fill -23 66 6 -22 66 9 minecraft:yellow_wool
fill -27 63 7 -22 65 8 minecraft:air

# Crate-like town details without inventories/interactable containers
fill -32 63 -12 -31 64 -11 minecraft:stripped_oak_wood
setblock 31 63 -12 minecraft:hay_block
setblock 32 63 -12 minecraft:hay_block
setblock -33 63 12 minecraft:hay_block
setblock 32 63 11 minecraft:stripped_oak_wood

# Keep important spawn and class-selection approach volumes explicitly open.
fill -1 63 -9 1 66 -7 minecraft:air
fill -3 63 16 3 66 18 minecraft:air
