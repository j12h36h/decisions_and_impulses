# ClayGrounds v0.6.0 — canonical shallow-water exit shelves.
# Shared by new-world finalization and in-place migrations.
# Solmere cardinal swim-out shelves — broad enough to remain usable if approached diagonally.
fill 45 60 -5 49 60 5 minecraft:sand replace minecraft:water
fill 49 59 -6 53 59 6 minecraft:sandstone replace minecraft:water
fill -49 60 -5 -45 60 5 minecraft:sand replace minecraft:water
fill -53 59 -6 -49 59 6 minecraft:sandstone replace minecraft:water
fill -5 60 45 5 60 49 minecraft:sand replace minecraft:water
fill -6 59 49 6 59 53 minecraft:sandstone replace minecraft:water
fill -5 60 -49 5 60 -45 minecraft:sand replace minecraft:water
fill -6 59 -53 6 59 -49 minecraft:sandstone replace minecraft:water

# Sunwash Strand cardinal shelves. The strand is centered near X=100.
fill 151 60 -6 157 60 6 minecraft:sand replace minecraft:water
fill 157 59 -7 161 59 7 minecraft:sandstone replace minecraft:water
fill 39 60 -6 45 60 6 minecraft:sand replace minecraft:water
fill 35 59 -7 39 59 7 minecraft:sandstone replace minecraft:water
fill 94 60 39 106 60 45 minecraft:sand replace minecraft:water
fill 93 59 45 107 59 49 minecraft:sandstone replace minecraft:water
fill 94 60 -45 106 60 -39 minecraft:sand replace minecraft:water
fill 93 59 -49 107 59 -45 minecraft:sandstone replace minecraft:water

