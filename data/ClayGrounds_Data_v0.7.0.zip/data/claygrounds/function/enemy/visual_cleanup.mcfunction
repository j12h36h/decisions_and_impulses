# ClayGrounds v0.6.0 — low-frequency orphan visual cleanup.
execute as @e[tag=cg_enemy,nbt={DeathTime:1s}] at @s run kill @e[type=minecraft:item_display,tag=cg_visual,distance=..0.75,limit=1,sort=nearest]
execute as @e[type=minecraft:item_display,tag=cg_visual] at @s unless entity @e[tag=cg_enemy,distance=..0.90] run kill @s
