# ClayGrounds v0.6.0 — interpolated rig following (10 TPS).
# item_display teleport interpolation keeps motion smooth between updates.
execute as @e[tag=cg_spawn_s1,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_s1,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_s2,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_s2,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_s3,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_s3,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_s4,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_s4,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_s5,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_s5,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_v1,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_v1,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_v2,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_v2,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_v3,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_v3,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_v4,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_v4,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_v5,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_v5,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_r1,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_r1,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_r2,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_r2,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_r3,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_r3,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_r4,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_r4,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_spawn_r5,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_vis_r5,tag=cg_visual] ~ ~ ~ ~ 0
execute as @e[tag=cg_boss,tag=cg_enemy,limit=1] at @s rotated as @s run teleport @e[tag=cg_boss_visual,tag=cg_visual] ~ ~ ~ ~ 0
