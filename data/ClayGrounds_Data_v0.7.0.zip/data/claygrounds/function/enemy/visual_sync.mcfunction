# ClayGrounds v0.6.0 compatibility visual sync wrapper.
function claygrounds:enemy/visual_ensure
function claygrounds:enemy/visual_follow
