# World of Addons HUD integration: default Minecraft hotbar keys become MOBA ability keys.
# 1=Q, 2=W, 3=E, 4=R. Slots 5-9 remain available for utility, wards and items.
clear @s dai_time_reverse:temporal_recall
clear @s dai_time_reverse:chrono_anchor
clear @s dai_time_reverse:reversal_field
clear @s dai_time_reverse:temporal_stream
item replace entity @s hotbar.0 with dai_time_reverse:temporal_recall
item replace entity @s hotbar.1 with dai_time_reverse:chrono_anchor
item replace entity @s hotbar.2 with dai_time_reverse:reversal_field
item replace entity @s hotbar.3 with dai_time_reverse:temporal_stream
tag @s add tr_items_v022
tag @s add tr_items_v024
title @s actionbar [{"text":"ECHO ANOMALY  ","color":"aqua","bold":true},{"text":"1/Q Recall · 2/W Anchor · 3/E Field · 4/R Stream","color":"gray"}]
