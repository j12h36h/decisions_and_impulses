# Manual recovery command. World of Addons receives a deterministic MOBA hotbar; standalone remains unchanged.
execute if entity @s[tag=woa_joined] run function dai_time_reverse:woa/apply_loadout
execute unless entity @s[tag=woa_joined] unless items entity @s inventory.* dai_time_reverse:temporal_recall run give @s dai_time_reverse:temporal_recall 1
execute unless entity @s[tag=woa_joined] unless items entity @s inventory.* dai_time_reverse:chrono_anchor run give @s dai_time_reverse:chrono_anchor 1
execute unless entity @s[tag=woa_joined] unless items entity @s inventory.* dai_time_reverse:reversal_field run give @s dai_time_reverse:reversal_field 1
execute unless entity @s[tag=woa_joined] unless items entity @s inventory.* dai_time_reverse:temporal_stream run give @s dai_time_reverse:temporal_stream 1
execute unless entity @s[tag=woa_joined] run tag @s add tr_items_v022
execute unless entity @s[tag=woa_joined] run tag @s add tr_items_v024
execute unless entity @s[tag=woa_joined] run tellraw @s [{"text":"[EchoTime] ","color":"aqua","bold":true},{"text":"Ability items restored: ","color":"green","bold":false},{"text":"Temporal Recall, Chrono Anchor, Reversal Field, Temporal Stream","color":"white"}]
