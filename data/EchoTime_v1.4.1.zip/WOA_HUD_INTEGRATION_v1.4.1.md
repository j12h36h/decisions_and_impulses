# EchoTime v1.4.1 — World of Addons HUD Integration

- Preserves EchoTime's existing standalone starter/recovery behavior outside World of Addons.
- Detects the World of Addons `woa_joined` player context.
- In a Rift, maps the four temporal abilities to hotbar slots 1–4:
  - 1 / Q — Temporal Recall
  - 2 / W — Chrono Anchor
  - 3 / E — Reversal Field
  - 4 / R — Temporal Stream
- Leaves slots 5–9 free for utility, wards and purchased items.
