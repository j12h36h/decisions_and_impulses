# Hollow Spiral v0.6.0 active-room dispatcher.
# Select nearby rooms once per player, then process each unique room exactly once.
execute as @a[tag=hs_player] at @s run tag @e[type=minecraft:marker,tag=hs_room,distance=..28] add hs_pulse_active
execute as @a[tag=hs_player] at @s run tag @e[type=minecraft:marker,tag=hs_room,tag=hs_farm_settle,distance=..32] add hs_farm_active

execute as @e[type=minecraft:marker,tag=hs_room,tag=hs_pulse_active] at @s run function hollow_spire:dungeon/pulse_room
execute as @e[type=minecraft:marker,tag=hs_room,tag=hs_farm_active] at @s run function hollow_spire:dungeon/farm/settle

tag @e[type=minecraft:marker,tag=hs_pulse_active] remove hs_pulse_active
tag @e[type=minecraft:marker,tag=hs_farm_active] remove hs_farm_active
