# Hollow Spiral v0.6.0 per-room maintenance.
# @s is one unique nearby hs_room marker selected by dungeon/pulse.
execute if entity @s[tag=!hs_v050_integrity] run function hollow_spire:dungeon/room/retrofit_v050_integrity
execute if entity @s[tag=!hs_v036_grotto,scores={hs_type=18,hs_ocean=4}] run function hollow_spire:dungeon/ocean/retrofit_v036_grotto
execute if entity @s[tag=!hs_v036_stairfix] run function hollow_spire:dungeon/room/retrofit_v036_stairs
execute if entity @s[tag=!hs_v036_controls] run function hollow_spire:dungeon/room/restore_controls
execute if entity @s[tag=!hs_v036_castleguard,scores={hs_type=19}] run function hollow_spire:dungeon/castle/populate_defenders
execute if entity @s[tag=!hs_v032_ritual_clean,scores={hs_type=9}] run function hollow_spire:dungeon/crypt/refresh_v032
execute if entity @s[tag=!hs_v032_wallcontrols] run function hollow_spire:dungeon/room/restore_controls
execute if entity @s[scores={hs_type=9}] run function hollow_spire:dungeon/crypt/visibility
execute if entity @s[tag=!hs_v030_ruininfest,scores={hs_type=1}] run function hollow_spire:dungeon/ruins/populate
execute if entity @s[tag=!hs_v028_farmanimals,scores={hs_type=2..3}] run function hollow_spire:dungeon/room/retrofit_v028_farm
execute if entity @s[tag=!hs_v028_groveanimals,scores={hs_type=4}] run scoreboard players set @s hs_grove 1
execute if entity @s[tag=!hs_v028_groveanimals,scores={hs_type=4}] run function hollow_spire:dungeon/grove/populate
execute if entity @s[tag=!hs_v028_stair3] run function hollow_spire:dungeon/room/retrofit_v028
execute if entity @s[tag=hs_start_room,tag=!hs_v027_homelight] run function hollow_spire:dungeon/room/home_lighting
execute if entity @s[tag=!hs_v027_lushslimes,scores={hs_type=7}] run function hollow_spire:dungeon/room/lush_slimes
execute if entity @s[tag=!hs_v026_farmlight] run function hollow_spire:dungeon/room/retrofit_v026
execute if entity @s[tag=!hs_v024_stairwide] run function hollow_spire:dungeon/room/retrofit_v024
execute if entity @s[tag=!hs_v023_stairfix] run function hollow_spire:dungeon/room/retrofit_v023
execute if entity @s[tag=!hs_v021_safe] run function hollow_spire:dungeon/room/retrofit_v021
function hollow_spire:dungeon/room/check_controls
