DAI Survival Interface v0.1
For Minecraft 26.2 + DAI 1.9.5
Role: ADDON

Purpose
- True screen-space survival/target interface.
- No floating text_display entities.
- No damage-number logic.
- Designed to stack with Damage Indicators and other DAI addons.

Target UI
- Appears before combat when you aim at a living entity.
- Shows target name.
- Native health progress bar.
- Shows current / maximum HP.
- Shows approximate range.
- 2.5 second target-lock grace window prevents flicker on brief ray misses.
- Eight isolated HUD lanes are included for local/LAN multiplayer use.

Commands
/function survival_interface:toggle
/function survival_interface:enable
/function survival_interface:disable

Important
Remove the old DAI_Damage_Indicators_HUD v0.x addon when installing this pack.
That older addon is a separate pack and will continue spawning its world-space
text displays if it remains enabled.

DAI 1.9.5 note
The current native dai_hud texture system is screen-space but static-image only.
Survival Interface therefore uses Minecraft's native bossbar HUD for dynamic text
and health values instead of faking UI with display entities.
