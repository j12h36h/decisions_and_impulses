execute if score @s si_slot matches 1 run bossbar set survival_interface:target_1 visible true
execute if score @s si_slot matches 2 run bossbar set survival_interface:target_2 visible true
execute if score @s si_slot matches 3 run bossbar set survival_interface:target_3 visible true
execute if score @s si_slot matches 4 run bossbar set survival_interface:target_4 visible true
execute if score @s si_slot matches 5 run bossbar set survival_interface:target_5 visible true
execute if score @s si_slot matches 6 run bossbar set survival_interface:target_6 visible true
execute if score @s si_slot matches 7 run bossbar set survival_interface:target_7 visible true
execute if score @s si_slot matches 8 run bossbar set survival_interface:target_8 visible true
