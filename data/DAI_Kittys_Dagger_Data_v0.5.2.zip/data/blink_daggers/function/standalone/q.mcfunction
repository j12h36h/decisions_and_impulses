function blink_daggers:ability/throw
