function blink_daggers:ultimate/cast
