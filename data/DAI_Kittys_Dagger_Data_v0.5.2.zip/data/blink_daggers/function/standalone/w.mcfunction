function blink_daggers:ability/drop
