execute unless score @s bd_pid matches 1.. run function blink_daggers:internal/assign_player_id
function blink_daggers:internal/remove_owned_daggers

# The hotbar ability item stays in place. Only a tracked display/projectile is created.
execute anchored eyes positioned ^ ^-0.12 ^1.15 run summon minecraft:item_display ~ ~ ~ {Tags:["bd_dagger","bd_flying","bd_new"],billboard:"fixed",view_range:1.5f,shadow_radius:0.0f,item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.55f,0.55f,0.55f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]},item:{id:"blink_daggers:kitty_dagger",count:1}}
data modify entity @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..4] Rotation set from entity @s Rotation
scoreboard players operation @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..4] bd_owner = @s bd_pid
scoreboard players set @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..4] bd_age 0
scoreboard players set @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..4] bd_spin 0
execute store result score @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..4] bd_pitch run data get entity @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..4] Rotation[1] 10
tag @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..4] remove bd_new
playsound minecraft:entity.arrow.shoot player @a[distance=..32] ~ ~ ~ 0.7 1.25
particle minecraft:sweep_attack ^ ^ ^0.9 0.0 0.0 0.0 0.0 1 force @a[distance=..48]
