execute unless score @s bd_cd_w matches 0 run return 0
execute unless score @s bd_pid matches 1.. run function blink_daggers:internal/assign_player_id
function blink_daggers:internal/remove_owned_daggers

summon minecraft:item_display ~ ~0.08 ~ {Tags:["bd_dagger","bd_stuck","bd_new"],billboard:"fixed",view_range:1.5f,shadow_radius:0.0f,item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.55f,0.55f,0.55f],left_rotation:[0.707107f,0.0f,0.0f,0.707107f],right_rotation:[0.0f,0.0f,0.0f,1.0f]},item:{id:"blink_daggers:kitty_dagger",count:1}}
scoreboard players operation @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..2] bd_owner = @s bd_pid
scoreboard players set @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..2] bd_age 0
scoreboard players set @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..2] bd_spin 0
tag @e[type=minecraft:item_display,tag=bd_new,limit=1,sort=nearest,distance=..2] remove bd_new
scoreboard players set @s bd_cd_w 100
effect give @s minecraft:speed 1 2 true
particle minecraft:cloud ~ ~0.15 ~ 0.22 0.04 0.22 0.03 8 force @a[distance=..32]
particle minecraft:sweep_attack ~ ~0.2 ~ 0.0 0.0 0.0 0.0 1 force @a[distance=..32]
playsound minecraft:entity.player.attack.sweep player @a[distance=..32] ~ ~ ~ 0.55 1.65
