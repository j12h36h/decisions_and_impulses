execute unless score @s bd_cd_q matches 0 run return 0
function blink_daggers:ability/throw_new
scoreboard players set @s bd_cd_q 100
