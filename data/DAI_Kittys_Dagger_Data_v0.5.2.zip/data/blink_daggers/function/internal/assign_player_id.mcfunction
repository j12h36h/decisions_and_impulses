
scoreboard players add #next_player bd_tmp 1
scoreboard players operation @s bd_pid = #next_player bd_tmp
