# v0.5.1 input hotfix migration. Preserve cooldowns/projectiles; only clear transient held-input state.
scoreboard players set @s bd_attack_ticks 0
scoreboard players set @s bd_use_ticks 0
scoreboard players set @s bd_combo_ticks 0
scoreboard players set @s bd_combo_lock 0
scoreboard players set @s bd_ray 0
tag @s add bd_items_v051
