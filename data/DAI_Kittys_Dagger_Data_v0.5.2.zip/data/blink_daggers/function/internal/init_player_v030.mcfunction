# First-time addon bootstrap: grant the combined kit plus all three standalone skill items once.
execute unless items entity @s inventory.* blink_daggers:kitty_dagger run give @s blink_daggers:kitty_dagger[minecraft:damage=1] 1
execute unless items entity @s inventory.* blink_daggers:kitty_directional_throw run give @s blink_daggers:kitty_directional_throw[minecraft:damage=1] 1
execute unless items entity @s inventory.* blink_daggers:kitty_up_throw run give @s blink_daggers:kitty_up_throw[minecraft:damage=1] 1
execute unless items entity @s inventory.* blink_daggers:kitty_ultimate run give @s blink_daggers:kitty_ultimate[minecraft:damage=1] 1
scoreboard players set @s bd_cd_q 0
scoreboard players set @s bd_cd_w 0
scoreboard players set @s bd_cd_r 0
scoreboard players set @s bd_flash 0
scoreboard players set @s bd_attack_ticks 0
scoreboard players set @s bd_use_ticks 0
scoreboard players set @s bd_combo_ticks 0
scoreboard players set @s bd_combo_lock 0
tag @s add bd_items_v030
tag @s add bd_items_v051
