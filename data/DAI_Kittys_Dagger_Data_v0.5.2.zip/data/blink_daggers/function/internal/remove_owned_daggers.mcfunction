# Replace the player's previous anchor with the new one. The ability item itself never leaves the hotbar.
tag @s add bd_action_user
execute as @e[type=minecraft:item_display,tag=bd_dagger] if score @s bd_owner = @a[tag=bd_action_user,limit=1] bd_pid run kill @s
tag @s remove bd_action_user
