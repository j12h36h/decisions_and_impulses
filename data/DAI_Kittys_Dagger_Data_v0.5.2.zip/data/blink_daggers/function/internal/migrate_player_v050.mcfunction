# v0.5.0 is a runtime/schema migration only; preserve all live cooldowns and owned projectiles.
scoreboard players add @s bd_cd_q 0
scoreboard players add @s bd_cd_w 0
scoreboard players add @s bd_cd_r 0
scoreboard players set @s bd_attack_ticks 0
scoreboard players set @s bd_use_ticks 0
scoreboard players set @s bd_combo_ticks 0
scoreboard players set @s bd_combo_lock 0
tag @s add bd_items_v050
