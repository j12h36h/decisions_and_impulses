# [DAI] Kitty's Dagger v0.5.2 / DAI 3.1 addon tick
execute as @a[tag=!bd_items_v030] run function blink_daggers:internal/init_player_v030
execute as @a[tag=!bd_items_v050] run function blink_daggers:internal/migrate_player_v050
execute as @a[tag=!bd_items_v051] run function blink_daggers:internal/migrate_player_v051
execute as @a unless score @s bd_pid matches 1.. run function blink_daggers:internal/assign_player_id

# Independent cooldowns. Q/W default to 5 seconds; R defaults to 15 seconds.
scoreboard players remove @a[scores={bd_cd_q=1..}] bd_cd_q 1
scoreboard players remove @a[scores={bd_cd_w=1..}] bd_cd_w 1
scoreboard players remove @a[scores={bd_cd_r=1..}] bd_cd_r 1

# W flash clock only runs while its visual channel is actually needed.
scoreboard players add @a[scores={bd_cd_w=1..}] bd_flash 1
execute as @a[scores={bd_cd_w=1..,bd_flash=8..}] run scoreboard players set @s bd_flash 0
scoreboard players set @a[scores={bd_cd_w=0}] bd_flash 0


# Combined-item input is edge-triggered. Clear held flags when the item is no longer selected,
# and count the 1-second dual-click chord directly here without filling DAI's action queue.
scoreboard players set @a bd_tmp 0
execute as @a if items entity @s weapon.mainhand blink_daggers:kitty_dagger run scoreboard players set @s bd_tmp 1
scoreboard players set @a[scores={bd_tmp=0}] bd_attack_ticks 0
scoreboard players set @a[scores={bd_tmp=0}] bd_use_ticks 0
scoreboard players set @a[scores={bd_tmp=0}] bd_combo_ticks 0
scoreboard players set @a[scores={bd_tmp=0}] bd_combo_lock 0
execute as @a[scores={bd_attack_ticks=1,bd_use_ticks=1}] if items entity @s weapon.mainhand blink_daggers:kitty_dagger run function blink_daggers:input/combo_tick
execute as @a[scores={bd_attack_ticks=0}] run scoreboard players set @s bd_combo_ticks 0
execute as @a[scores={bd_use_ticks=0}] run scoreboard players set @s bd_combo_ticks 0

# Seamlessly migrate a selected v0.2.x dagger while keeping the legacy native id registered for old saves.
execute as @a if items entity @s weapon.mainhand blink_daggers:blink_dagger run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=1] 1

# Update only the currently selected Kitty item. Cooldowns themselves continue globally while unselected.
execute as @a if items entity @s weapon.mainhand blink_daggers:kitty_dagger run function blink_daggers:ui/main
execute as @a if items entity @s weapon.mainhand blink_daggers:kitty_directional_throw run function blink_daggers:ui/q_item
execute as @a if items entity @s weapon.mainhand blink_daggers:kitty_up_throw run function blink_daggers:ui/w_item
execute as @a if items entity @s weapon.mainhand blink_daggers:kitty_ultimate run function blink_daggers:ui/r_item

# Active command projectiles remain 20 TPS because collision/movement responsiveness depends on it.
execute as @e[type=minecraft:item_display,tag=bd_dagger] at @s run function blink_daggers:projectile/tick
execute as @e[type=minecraft:item_display,tag=bd_ult_knife] at @s run function blink_daggers:ultimate/projectile_tick

# Multiplayer maintenance is intentionally low-frequency: every 10 seconds, remove projectiles whose owner disconnected.
scoreboard players add #maintenance bd_tmp 1
execute if score #maintenance bd_tmp matches 200.. as @e[type=minecraft:item_display,tag=bd_dagger] at @s run function blink_daggers:maintenance/orphan_check
execute if score #maintenance bd_tmp matches 200.. as @e[type=minecraft:item_display,tag=bd_ult_knife] at @s run function blink_daggers:maintenance/orphan_check
execute if score #maintenance bd_tmp matches 200.. run scoreboard players set #maintenance bd_tmp 0
