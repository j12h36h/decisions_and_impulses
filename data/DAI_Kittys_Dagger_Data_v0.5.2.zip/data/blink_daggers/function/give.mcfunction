give @s blink_daggers:kitty_dagger[minecraft:damage=1] 1
give @s blink_daggers:kitty_directional_throw[minecraft:damage=1] 1
give @s blink_daggers:kitty_up_throw[minecraft:damage=1] 1
give @s blink_daggers:kitty_ultimate[minecraft:damage=1] 1
