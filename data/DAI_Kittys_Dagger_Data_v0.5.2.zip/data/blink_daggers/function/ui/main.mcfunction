# v0.5.2 combined-item UI: Q durability + safe W fallback + R readiness glint.
# Q damage is calculated arithmetically, then one of six mutually exclusive visual branches applies it.
function blink_daggers:ui/calc_q

# W cooldown half-cycle. The datapack-only build safely falls back to the base dagger model.
execute if score @s bd_cd_w matches 1.. if score @s bd_flash matches 0..3 if score @s bd_cd_r matches 0 run function blink_daggers:ui/apply/main_red_ready with storage blink_daggers:ui
execute if score @s bd_cd_w matches 1.. if score @s bd_flash matches 0..3 unless score @s bd_cd_r matches 0 run function blink_daggers:ui/apply/main_red with storage blink_daggers:ui

# Normal visual while W is ready or during the alternate half of its cooldown cycle.
execute unless score @s bd_cd_w matches 1.. if score @s bd_cd_r matches 0 run function blink_daggers:ui/apply/main_ready with storage blink_daggers:ui
execute unless score @s bd_cd_w matches 1.. unless score @s bd_cd_r matches 0 run function blink_daggers:ui/apply/main_normal with storage blink_daggers:ui
execute if score @s bd_cd_w matches 1.. unless score @s bd_flash matches 0..3 if score @s bd_cd_r matches 0 run function blink_daggers:ui/apply/main_ready with storage blink_daggers:ui
execute if score @s bd_cd_w matches 1.. unless score @s bd_flash matches 0..3 unless score @s bd_cd_r matches 0 run function blink_daggers:ui/apply/main_normal with storage blink_daggers:ui
