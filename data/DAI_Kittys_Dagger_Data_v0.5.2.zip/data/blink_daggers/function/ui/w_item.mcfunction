# v0.5.0: arithmetic cooldown mapping replaces 20 range branches.
function blink_daggers:ui/calc_w
function blink_daggers:ui/apply/w with storage blink_daggers:ui
