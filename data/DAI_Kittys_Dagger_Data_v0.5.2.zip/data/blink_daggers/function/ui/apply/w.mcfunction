$item replace entity @s weapon.mainhand with blink_daggers:kitty_up_throw[minecraft:damage=$(damage)] 1
