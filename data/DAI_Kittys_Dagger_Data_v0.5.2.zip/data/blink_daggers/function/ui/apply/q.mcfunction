$item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=$(damage)] 1
