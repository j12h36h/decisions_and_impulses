$item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=$(damage),minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
