$item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=$(damage)] 1
