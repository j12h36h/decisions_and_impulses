scoreboard players operation @s bd_ui = @s bd_cd_q
scoreboard players add @s bd_ui 4
scoreboard players operation @s bd_ui /= #five bd_ui
scoreboard players operation @s bd_ui *= #five bd_ui
execute if score @s bd_ui matches 0 run scoreboard players set @s bd_ui 1
execute store result storage blink_daggers:ui damage int 1 run scoreboard players get @s bd_ui
