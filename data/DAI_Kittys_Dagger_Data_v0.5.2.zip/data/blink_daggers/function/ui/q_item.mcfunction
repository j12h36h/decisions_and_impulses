# v0.5.0: arithmetic cooldown mapping replaces 20 range branches.
function blink_daggers:ui/calc_q
function blink_daggers:ui/apply/q with storage blink_daggers:ui
