tag @s add bd_current_dagger
tag @a[tag=bd_owner_context] remove bd_owner_context
execute as @a if score @s bd_pid = @e[type=minecraft:item_display,tag=bd_current_dagger,limit=1] bd_owner run tag @s add bd_owner_context
scoreboard players add @s bd_age 1
scoreboard players add @s bd_spin 1
execute if score @s bd_spin matches 8.. run scoreboard players set @s bd_spin 0
execute if score @s bd_spin matches 0 run function blink_daggers:projectile/pose/0
execute if score @s bd_spin matches 1 run function blink_daggers:projectile/pose/1
execute if score @s bd_spin matches 2 run function blink_daggers:projectile/pose/2
execute if score @s bd_spin matches 3 run function blink_daggers:projectile/pose/3
execute if score @s bd_spin matches 4 run function blink_daggers:projectile/pose/4
execute if score @s bd_spin matches 5 run function blink_daggers:projectile/pose/5
execute if score @s bd_spin matches 6 run function blink_daggers:projectile/pose/6
execute if score @s bd_spin matches 7 run function blink_daggers:projectile/pose/7
particle minecraft:crit ~ ~ ~ 0.02 0.02 0.02 0.0 1 force @a[distance=..48]
execute if score @s bd_age matches 2.. if entity @e[type=!minecraft:item_display,type=!minecraft:block_display,type=!minecraft:text_display,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:interaction,type=!minecraft:armor_stand,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident,type=!minecraft:firework_rocket,type=!minecraft:area_effect_cloud,tag=!bd_owner_context,distance=..0.78,limit=1,sort=nearest] run function blink_daggers:ultimate/projectile_hit
execute if entity @s[tag=bd_ult_knife] positioned ^ ^ ^0.936 unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run kill @s
execute if entity @s[tag=bd_ult_knife] run tp @s ^ ^ ^0.715
execute if score @s bd_age matches 50.. run kill @s
tag @a[tag=bd_owner_context] remove bd_owner_context
tag @s remove bd_current_dagger
