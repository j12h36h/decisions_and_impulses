execute as @e[tag=!bd_owner_context,type=!minecraft:item_display,type=!minecraft:block_display,type=!minecraft:text_display,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:interaction,type=!minecraft:armor_stand,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident,type=!minecraft:firework_rocket,type=!minecraft:area_effect_cloud,distance=..0.78,limit=1,sort=nearest] run damage @s 6 minecraft:arrow by @a[tag=bd_owner_context,limit=1]
particle minecraft:damage_indicator ~ ~ ~ 0.18 0.18 0.18 0.06 5 force @a[distance=..48]
playsound minecraft:entity.arrow.hit_player player @a[distance=..32] ~ ~ ~ 0.45 1.55
kill @s
