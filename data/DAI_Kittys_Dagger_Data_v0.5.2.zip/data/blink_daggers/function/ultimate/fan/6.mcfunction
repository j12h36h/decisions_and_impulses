execute rotated ~-168 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-92 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~8 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~76 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~148 0 run function blink_daggers:ultimate/throw_fan
