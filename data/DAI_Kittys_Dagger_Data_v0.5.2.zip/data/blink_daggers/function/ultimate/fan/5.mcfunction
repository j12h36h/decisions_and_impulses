execute rotated ~-120 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-70 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~10 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~80 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~175 0 run function blink_daggers:ultimate/throw_fan
