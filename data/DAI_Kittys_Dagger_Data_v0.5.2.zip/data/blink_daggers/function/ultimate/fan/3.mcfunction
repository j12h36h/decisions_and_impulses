execute rotated ~-175 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-100 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-25 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~50 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~125 0 run function blink_daggers:ultimate/throw_fan
