execute rotated ~-150 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-40 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~25 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~100 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~160 0 run function blink_daggers:ultimate/throw_fan
