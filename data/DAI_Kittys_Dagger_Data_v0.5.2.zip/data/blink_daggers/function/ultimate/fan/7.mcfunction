execute rotated ~-138 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-62 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-5 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~84 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~156 0 run function blink_daggers:ultimate/throw_fan
