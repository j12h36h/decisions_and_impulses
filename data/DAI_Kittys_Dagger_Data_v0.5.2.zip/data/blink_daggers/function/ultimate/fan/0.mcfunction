execute rotated ~-144 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-72 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~0 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~72 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~144 0 run function blink_daggers:ultimate/throw_fan
