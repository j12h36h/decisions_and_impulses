execute rotated ~-130 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-55 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~18 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~95 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~170 0 run function blink_daggers:ultimate/throw_fan
