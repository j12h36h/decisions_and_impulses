execute rotated ~-162 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-88 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~-12 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~66 0 run function blink_daggers:ultimate/throw_fan
execute rotated ~138 0 run function blink_daggers:ultimate/throw_fan
