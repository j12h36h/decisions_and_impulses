execute unless score @s bd_cd_r matches 0 run return 0
execute unless score @s bd_pid matches 1.. run function blink_daggers:internal/assign_player_id
scoreboard players set @s bd_cd_r 300
tag @s add bd_ult_user
tag @e[tag=bd_ult_selected] remove bd_ult_selected
tag @e[tag=bd_ult_target] remove bd_ult_target

# If at least one target exists, launch all five knives at nearby entities. Unique targets are used first;
# with fewer than five targets the nearest valid target can receive additional knives.
execute if entity @e[type=!minecraft:item_display,type=!minecraft:block_display,type=!minecraft:text_display,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:interaction,type=!minecraft:armor_stand,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident,type=!minecraft:firework_rocket,type=!minecraft:area_effect_cloud,tag=!bd_ult_user,distance=..15] run function blink_daggers:ultimate/targeted
execute unless entity @e[type=!minecraft:item_display,type=!minecraft:block_display,type=!minecraft:text_display,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:interaction,type=!minecraft:armor_stand,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident,type=!minecraft:firework_rocket,type=!minecraft:area_effect_cloud,tag=!bd_ult_user,distance=..15] run function blink_daggers:ultimate/fallback

playsound minecraft:entity.player.attack.sweep player @a[distance=..48] ~ ~ ~ 0.85 0.75
playsound minecraft:entity.arrow.shoot player @a[distance=..48] ~ ~ ~ 0.9 1.45
particle minecraft:enchanted_hit ~ ~1.0 ~ 0.6 0.8 0.6 0.08 24 force @a[distance=..48]
tag @e[tag=bd_ult_selected] remove bd_ult_selected
tag @e[tag=bd_ult_target] remove bd_ult_target
tag @s remove bd_ult_user
