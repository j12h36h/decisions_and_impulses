# Five-second anchor lifetime. The permanent hotbar ability item is never consumed.
particle minecraft:smoke ~ ~ ~ 0.08 0.08 0.08 0.01 4 force @a[distance=..32]
playsound minecraft:block.amethyst_block.chime player @a[tag=bd_owner_context,limit=1] ~ ~ ~ 0.35 1.8
kill @s
