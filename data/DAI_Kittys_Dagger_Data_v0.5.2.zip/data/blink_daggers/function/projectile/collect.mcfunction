execute as @a[tag=bd_owner_context,limit=1] at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.55 1.65
particle minecraft:enchanted_hit ~ ~ ~ 0.12 0.12 0.12 0.03 5 force @a[distance=..32]
kill @s
