data merge entity @s {transformation:{left_rotation:[0.707107f,0.0f,0.0f,-0.707107f]}}
