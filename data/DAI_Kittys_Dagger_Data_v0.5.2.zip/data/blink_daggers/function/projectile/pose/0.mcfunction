data merge entity @s {transformation:{left_rotation:[0.000000f,0.0f,0.0f,1.000000f]}}
