data merge entity @s {transformation:{left_rotation:[1.000000f,0.0f,0.0f,0.000000f]}}
