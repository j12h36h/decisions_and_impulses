data merge entity @s {transformation:{left_rotation:[0.382683f,0.0f,0.0f,-0.923880f]}}
