
# End-over-end model rotation is independent of entity Rotation, so local ^ ^ ^ movement
# keeps following the original throw direction while the visible knife tumbles.
scoreboard players add @s bd_spin 1
execute if score @s bd_spin matches 8.. run scoreboard players set @s bd_spin 0
execute if score @s bd_spin matches 0 run function blink_daggers:projectile/pose/0
execute if score @s bd_spin matches 1 run function blink_daggers:projectile/pose/1
execute if score @s bd_spin matches 2 run function blink_daggers:projectile/pose/2
execute if score @s bd_spin matches 3 run function blink_daggers:projectile/pose/3
execute if score @s bd_spin matches 4 run function blink_daggers:projectile/pose/4
execute if score @s bd_spin matches 5 run function blink_daggers:projectile/pose/5
execute if score @s bd_spin matches 6 run function blink_daggers:projectile/pose/6
execute if score @s bd_spin matches 7 run function blink_daggers:projectile/pose/7

particle minecraft:crit ~ ~ ~ 0.015 0.015 0.015 0.0 1 force @a[distance=..48]

# Damage after a short launch grace so the thrower cannot immediately hit themself.
execute if score @s bd_age matches 3.. if entity @e[tag=!bd_owner_context,type=!minecraft:item_display,type=!minecraft:block_display,type=!minecraft:text_display,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:interaction,type=!minecraft:armor_stand,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident,type=!minecraft:firework_rocket,type=!minecraft:area_effect_cloud,distance=..0.78,limit=1,sort=nearest] run function blink_daggers:projectile/hit

# A modest downward pitch drift acts as gravity while keeping the MineTrigger-style
# command projectile deterministic.
execute if entity @s[tag=bd_flying] run scoreboard players add @s bd_pitch 4
execute if entity @s[tag=bd_flying] store result entity @s Rotation[1] float 0.1 run scoreboard players get @s bd_pitch

# Probe ahead first. A solid block makes the knife lodge just in front of the face
# instead of teleporting the display into the block volume.
execute if entity @s[tag=bd_flying] positioned ^ ^ ^0.936 unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run function blink_daggers:projectile/stick
execute if entity @s[tag=bd_flying] run tp @s ^ ^ ^0.715
