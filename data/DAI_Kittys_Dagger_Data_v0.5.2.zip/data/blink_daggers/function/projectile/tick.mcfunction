# Establish the current projectile + owning player context for this one dagger only.
tag @s add bd_current_dagger
tag @a[tag=bd_owner_context] remove bd_owner_context
execute as @a if score @s bd_pid = @e[type=minecraft:item_display,tag=bd_current_dagger,limit=1] bd_owner run tag @s add bd_owner_context

scoreboard players add @s bd_age 1

# Ground-drop daggers receive a short pickup grace period so W-style placement does not instantly self-collect.
execute if score @s bd_age matches 8.. if entity @a[tag=bd_owner_context,distance=..1.05] run function blink_daggers:projectile/collect

# Continue only if this dagger still exists after pickup.
execute if entity @s[tag=bd_flying] run function blink_daggers:projectile/flying
execute if score @s bd_age matches 100.. run function blink_daggers:projectile/expire

# Context cleanup.
tag @a[tag=bd_owner_context] remove bd_owner_context
tag @s remove bd_current_dagger
