
tag @s remove bd_flying
tag @s add bd_stuck
particle minecraft:crit ~ ~ ~ 0.05 0.05 0.05 0.02 3 force @a[distance=..48]
playsound minecraft:entity.arrow.hit player @a[distance=..32] ~ ~ ~ 0.7 1.15
