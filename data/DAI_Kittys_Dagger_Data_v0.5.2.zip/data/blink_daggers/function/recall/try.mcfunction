
# Do no ray work unless at least one dagger exists in this dimension vicinity.
execute if entity @e[type=minecraft:item_display,tag=bd_dagger,distance=..35.8] run function blink_daggers:recall/start
