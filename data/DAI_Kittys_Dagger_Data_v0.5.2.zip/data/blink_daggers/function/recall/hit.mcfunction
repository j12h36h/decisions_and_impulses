# The tagged hit is already owner-validated by the 35-block, 0.75-radius ray function.
particle minecraft:reverse_portal ~ ~1.0 ~ 0.25 0.5 0.25 0.02 10 force @a[distance=..48]
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.65 1.45
execute at @e[type=minecraft:item_display,tag=bd_ray_hit,limit=1,sort=nearest] run particle minecraft:reverse_portal ~ ~ ~ 0.28 0.35 0.28 0.02 14 force @a[distance=..48]
execute at @e[type=minecraft:item_display,tag=bd_ray_hit,limit=1,sort=nearest] run tp @s ~ ~ ~
particle minecraft:enchanted_hit ~ ~1.0 ~ 0.22 0.4 0.22 0.03 10 force @a[distance=..48]
playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.55 1.75
kill @e[type=minecraft:item_display,tag=bd_ray_hit,limit=1,sort=nearest]
scoreboard players set @s bd_ray 999
