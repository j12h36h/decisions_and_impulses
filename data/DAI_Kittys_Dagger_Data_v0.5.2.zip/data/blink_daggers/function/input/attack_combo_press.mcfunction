# LMB pressed while RMB is already down: arm the chord without spending Q.
scoreboard players set @s bd_attack_ticks 1
