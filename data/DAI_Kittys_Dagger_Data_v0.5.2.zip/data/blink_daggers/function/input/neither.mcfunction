scoreboard players set @s bd_attack_ticks 0
scoreboard players set @s bd_use_ticks 0
scoreboard players set @s bd_combo_ticks 0
scoreboard players set @s bd_combo_lock 0
