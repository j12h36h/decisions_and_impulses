# RMB pressed while LMB is already down: arm the chord without spending W.
scoreboard players set @s bd_use_ticks 1
