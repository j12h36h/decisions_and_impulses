# Instant single-LMB route.
scoreboard players set @s bd_attack_ticks 1
scoreboard players set @s bd_use_ticks 0
scoreboard players set @s bd_combo_ticks 0
scoreboard players set @s bd_combo_lock 0
function blink_daggers:ability/throw
