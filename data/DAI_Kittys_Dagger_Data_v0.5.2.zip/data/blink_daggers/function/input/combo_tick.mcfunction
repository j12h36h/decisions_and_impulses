# Count the dual-click chord directly on the server tick; no DAI action is enqueued per held tick.
execute if score @s bd_combo_lock matches 1 run return 0
scoreboard players add @s bd_combo_ticks 1
execute unless score @s bd_combo_ticks matches 20 run return 0
scoreboard players set @s bd_combo_lock 1
execute if score @s bd_cd_r matches 0 run function blink_daggers:ultimate/cast
execute unless score @s bd_cd_r matches 0 run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.45 0.65
