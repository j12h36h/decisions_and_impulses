TamaCrafti Datapack v2.2.1 - DAI 1.8.2 Experience UI Toggle

Built for D.A.I. 1.8.2+ and TamaCrafti Resource Pack v2.0.3 HD.
The resource pack does NOT need to be changed for this update.

Client/server integration:
- START JOURNEY still uses D.A.I.'s launch_experience action and the tamacrafti:journey experience definition.
- TamaCrafti keeps the same datapack/function layout; server-owned Minecraft functions remain server datapack functions.
- TamaCrafti's 21 internal D.A.I. function handoffs now use server_run_function instead of the legacy run_server_command bridge.
- The client therefore requests an explicit D.A.I. server capability instead of pretending the player typed a privileged /function command.
- The Journey HUD now explicitly owns the D.A.I. grave/backtick key while the experience is active.
- Press ` to close the TamaCrafti UI and recapture gameplay input; press ` again to reopen it and release the cursor.
- Closing the HUD with its own close button also recaptures gameplay input.
- Title presentation, care/growth systems, farming, rewards, and gradual home builder are otherwise unchanged.

Journey gameplay:
- The player begins at Y=200 on the isolated starter stage.
- The one-block-at-a-time home builder creates and repairs the TamaCrafti sky-home.
- Starter inventory remains tools + farming items only.
- Existing save recovery from v2.1.2 is retained.

Useful test functions when testing directly from an authoritative server console/source:
/function tamacrafti:journey/init
/function tamacrafti:journey/resume
/function tamacrafti:debug/rebuild_home
/function tamacrafti:debug/journey_reset_player
