title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {"text":"Your first key — and your first weapon.","color":"gray"}
function dai_auto_rpg:item/give_mineshaft_key
execute if score @s arpg2_first_weapon matches 0 run function dai_auto_rpg:item/give_first_weapon
execute if score @s arpg2_first_weapon matches 0 run scoreboard players set @s arpg2_first_weapon 1
execute if score @s arpg2_first_weapon matches 1.. run give @s minecraft:bread 1
function dai_auto_rpg:map/f1/101
tellraw @s {"text":"Room clear. Equip anything you found, then use your MineShaft Key on the gate you choose.","color":"yellow"}
