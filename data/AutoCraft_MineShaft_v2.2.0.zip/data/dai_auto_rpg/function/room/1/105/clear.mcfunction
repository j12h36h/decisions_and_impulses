scoreboard players set @s arpg2_unlock 2
function dai_auto_rpg:item/memento/floor1
tellraw @s {text:'Memento acquired: Foreman’s Core',color:'gold'}
execute unless items entity @s armor.chest minecraft:leather_chestplate run give @s minecraft:leather_chestplate[minecraft:custom_name={text:'Foreman’s Vest',color:'gold',italic:false},minecraft:enchantments={"minecraft:protection":1}] 1
function dai_auto_rpg:map/f1/105
title @s title {"text":"FLOOR 1 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 2 — Abandoned Shafts — unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {"text":"Floor 2 is unlocked. Use the Safety Rope to return Home; the north lift now descends directly to it.","color":"yellow"}
