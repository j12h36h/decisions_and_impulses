
scoreboard players set @s arpg2_room 105
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 30
function dai_auto_rpg:map/f1/105
# Reassert the boss arena floor immediately before spawning.
fill 35 -32 -25 45 -32 -15 minecraft:spruce_planks
execute positioned 40 -31 -20 run function dai_auto_rpg:spawn/f1_boss
title @s title {text:'BOSS — SLIME FOREMAN',color:'gold',bold:true}
title @s subtitle {text:'Defeat every split slime. The floor will not clear early anymore.',color:'gray'}
