title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {"text":"Red slimes yield a heavier option.","color":"gray"}
function dai_auto_rpg:item/give_mineshaft_key
execute unless score @s arpg2_loot matches 2.. run give @s minecraft:wooden_axe[minecraft:custom_name={text:'Redcap Hatchet',color:'red',italic:false}] 1
execute unless score @s arpg2_loot matches 2.. run scoreboard players set @s arpg2_loot 2
give @s minecraft:bread 1
function dai_auto_rpg:map/f1/103
tellraw @s {"text":"Room clear. Equip anything you found, then use your MineShaft Key on the gate you choose.","color":"yellow"}
