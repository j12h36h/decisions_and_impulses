
scoreboard players set @s arpg2_room 103
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f1/103
execute positioned 18 -31 0 run function dai_auto_rpg:spawn/green
execute positioned 20 -31 -2 run function dai_auto_rpg:spawn/red
execute positioned 22 -31 1 run function dai_auto_rpg:spawn/red
execute positioned 20 -31 3 run function dai_auto_rpg:spawn/green
title @s subtitle {text:'Room entered — fight manually until every slime is down.',color:'gray'}
