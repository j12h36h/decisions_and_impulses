title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {"text":"The Foreman’s key is yours.","color":"gray"}
function dai_auto_rpg:item/give_boss_key
execute unless items entity @s inventory.* minecraft:stone_sword run give @s minecraft:stone_sword[minecraft:custom_name={text:'Delver Blade',color:'aqua',italic:false}] 1
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f1/104_n
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f1/104_e
tellraw @s {"text":"Boss Key acquired. Use it to open the boss gate, then walk into the chamber.","color":"aqua"}
