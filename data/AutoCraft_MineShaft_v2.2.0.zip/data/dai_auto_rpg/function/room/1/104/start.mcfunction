
scoreboard players set @s arpg2_room 104
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f1/104_n
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f1/104_e
execute positioned 18 -31 -20 run function dai_auto_rpg:spawn/green
execute positioned 20 -31 -22 run function dai_auto_rpg:spawn/red
execute positioned 22 -31 -20 run function dai_auto_rpg:spawn/blue
execute positioned 20 -31 -18 run function dai_auto_rpg:spawn/green
title @s subtitle {text:'Final gallery — clear it to earn the Foreman key.',color:'gray'}
