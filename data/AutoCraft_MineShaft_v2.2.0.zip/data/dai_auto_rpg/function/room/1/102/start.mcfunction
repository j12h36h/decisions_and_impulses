
scoreboard players set @s arpg2_room 102
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f1/102
execute positioned -2 -31 -20 run function dai_auto_rpg:spawn/green
execute positioned 2 -31 -20 run function dai_auto_rpg:spawn/green
execute positioned 0 -31 -22 run function dai_auto_rpg:spawn/blue
execute positioned 0 -31 -18 run function dai_auto_rpg:spawn/green
title @s subtitle {text:'Room entered — fight manually until every slime is down.',color:'gray'}
