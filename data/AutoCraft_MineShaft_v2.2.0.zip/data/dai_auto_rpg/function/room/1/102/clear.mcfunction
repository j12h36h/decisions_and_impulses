title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {"text":"Blue slimes guard sturdier equipment.","color":"gray"}
function dai_auto_rpg:item/give_mineshaft_key
execute unless score @s arpg2_loot matches 1.. run give @s minecraft:leather_boots[minecraft:custom_name={text:'Slimeproof Boots',color:'green',italic:false},minecraft:enchantments={"minecraft:protection":1}] 1
execute unless score @s arpg2_loot matches 1.. run scoreboard players set @s arpg2_loot 1
give @s minecraft:bread 1
function dai_auto_rpg:map/f1/102
tellraw @s {"text":"Room clear. Equip anything you found, then use your MineShaft Key on the gate you choose.","color":"yellow"}
