title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {"text":"The shaft is occupied.","color":"gray"}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s armor.head minecraft:chainmail_helmet run give @s minecraft:chainmail_helmet[minecraft:custom_name={text:'Miner’s Chain Hood',color:'gray',italic:false}] 1
give @s minecraft:cooked_beef 1
function dai_auto_rpg:map/f2/201
tellraw @s {"text":"Room clear. Equip anything you found, then use your MineShaft Key on the gate you choose.","color":"yellow"}
