title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {"text":"A heavier weapon survived the collapse.","color":"gray"}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s inventory.* minecraft:stone_axe run give @s minecraft:stone_axe[minecraft:custom_name={text:'Shaftbreaker',color:'red',italic:false}] 1
give @s minecraft:cooked_beef 1
function dai_auto_rpg:map/f2/203
tellraw @s {"text":"Room clear. Equip anything you found, then use your MineShaft Key on the gate you choose.","color":"yellow"}
