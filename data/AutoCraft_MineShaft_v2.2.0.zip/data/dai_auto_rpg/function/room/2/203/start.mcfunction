
scoreboard players set @s arpg2_room 203
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f2/203
execute positioned 0 -47 18 run function dai_auto_rpg:spawn/zombie
execute positioned -2 -47 20 run function dai_auto_rpg:spawn/red
execute positioned 2 -47 20 run function dai_auto_rpg:spawn/red
execute positioned 0 -47 22 run function dai_auto_rpg:spawn/green
title @s subtitle {text:'Room entered — manual combat.',color:'gray'}
