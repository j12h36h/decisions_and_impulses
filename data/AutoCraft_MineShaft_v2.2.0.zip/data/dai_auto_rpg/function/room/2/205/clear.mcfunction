scoreboard players set @s arpg2_unlock 3
function dai_auto_rpg:item/memento/floor2
tellraw @s {text:'Memento acquired: Overseer’s Compass',color:'gold'}
execute unless items entity @s inventory.* minecraft:iron_sword run give @s minecraft:iron_sword[minecraft:custom_name={text:'Overseer’s Blade',color:'gold',bold:true,italic:false},minecraft:enchantments={"minecraft:sharpness":1}] 1
function dai_auto_rpg:map/f2/205
title @s title {"text":"FLOOR 2 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 3 — Flooded Excavation — unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 0.9
tellraw @s {"text":"Floor 3 is unlocked. Use the Safety Rope to return Home; the north lift now descends directly to it.","color":"yellow"}
