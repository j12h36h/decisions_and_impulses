
scoreboard players set @s arpg2_room 205
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 20
function dai_auto_rpg:map/f2/205
fill -45 -48 15 -35 -48 25 minecraft:dark_oak_planks
execute positioned -40 -47 20 run function dai_auto_rpg:spawn/f2_boss
execute positioned -37 -47 18 run function dai_auto_rpg:spawn/red
execute positioned -43 -47 22 run function dai_auto_rpg:spawn/blue
title @s title {text:'BOSS — LOST OVERSEER',color:'gold',bold:true}
title @s subtitle {text:'Manual combat. Clear the entire chamber.',color:'gray'}
