
scoreboard players set @s arpg2_room 204
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f2/204_w
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f2/204_s
execute positioned -22 -47 20 run function dai_auto_rpg:spawn/zombie
execute positioned -18 -47 20 run function dai_auto_rpg:spawn/zombie
execute positioned -20 -47 18 run function dai_auto_rpg:spawn/red
execute positioned -20 -47 22 run function dai_auto_rpg:spawn/blue
title @s subtitle {text:'Final shaft — clear it to earn the Overseer key.',color:'gray'}
