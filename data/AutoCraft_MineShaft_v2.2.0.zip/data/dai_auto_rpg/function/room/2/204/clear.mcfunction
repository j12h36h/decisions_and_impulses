title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {"text":"The Overseer’s door can now be opened.","color":"gray"}
function dai_auto_rpg:item/give_boss_key
execute unless items entity @s armor.head minecraft:iron_helmet run give @s minecraft:iron_helmet[minecraft:custom_name={text:'Deep Mine Helm',color:'aqua',italic:false}] 1
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f2/204_w
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f2/204_s
tellraw @s {"text":"Boss Key acquired. Use it to open the boss gate, then walk into the chamber.","color":"aqua"}
