
scoreboard players set @s arpg2_room 202
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f2/202
execute positioned -22 -47 0 run function dai_auto_rpg:spawn/zombie
execute positioned -18 -47 0 run function dai_auto_rpg:spawn/zombie
execute positioned -20 -47 2 run function dai_auto_rpg:spawn/green
execute positioned -20 -47 -2 run function dai_auto_rpg:spawn/blue
title @s subtitle {text:'Room entered — manual combat.',color:'gray'}
