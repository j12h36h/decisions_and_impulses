title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {"text":"The western barracks still hold armor.","color":"gray"}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s armor.feet minecraft:chainmail_boots run give @s minecraft:chainmail_boots[minecraft:custom_name={text:'Overseer’s Work Boots',color:'gray',italic:false}] 1
give @s minecraft:cooked_beef 1
function dai_auto_rpg:map/f2/202
tellraw @s {"text":"Room clear. Equip anything you found, then use your MineShaft Key on the gate you choose.","color":"yellow"}
