# Snap the player back to the logical center of the room before returning human control.
# DAI combat may finish near an opened entry door; contextual door menus are coordinate-gated,
# so this makes the human decision point deterministic after every encounter.
execute if score @s arpg2_room matches 101 run teleport @s 0.5 -31 0.5
execute if score @s arpg2_room matches 102 run teleport @s 0.5 -31 -19.5
execute if score @s arpg2_room matches 103 run teleport @s 20.5 -31 0.5
execute if score @s arpg2_room matches 104 run teleport @s 20.5 -31 -19.5
execute if score @s arpg2_room matches 105 run teleport @s 40.5 -31 -19.5
execute if score @s arpg2_room matches 201 run teleport @s 0.5 -47 0.5
execute if score @s arpg2_room matches 202 run teleport @s -19.5 -47 0.5
execute if score @s arpg2_room matches 203 run teleport @s 0.5 -47 20.5
execute if score @s arpg2_room matches 204 run teleport @s -19.5 -47 20.5
execute if score @s arpg2_room matches 205 run teleport @s -39.5 -47 20.5
