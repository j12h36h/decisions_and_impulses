scoreboard players set @s arpg2_room 805
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 20
function dai_auto_rpg:map/f8/805
fill 655 -48 15 665 -48 25 minecraft:basalt
execute positioned 660 -47 20 run function dai_auto_rpg:spawn/f8_boss
execute positioned 657 -47 22 run function dai_auto_rpg:spawn/blaze
execute positioned 663 -47 18 run function dai_auto_rpg:spawn/magma
title @s title {text:'BOSS — RIFT SUPERINTENDENT',color:'gold',bold:true}
title @s subtitle {text:'Manual combat. Clear the entire chamber.',color:'gray'}
