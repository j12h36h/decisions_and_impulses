scoreboard players set @s arpg2_unlock 9
function dai_auto_rpg:item/memento/floor8
tellraw @s {text:'Memento acquired: Rift Cinder',color:'gold'}
execute unless items entity @s armor.legs minecraft:diamond_leggings run give @s minecraft:diamond_leggings[minecraft:custom_name={text:'Riftguard Leggings',color:'red',bold:true,italic:false}] 1
function dai_auto_rpg:map/f8/805
title @s title {"text":"FLOOR 8 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 9 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 9 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
