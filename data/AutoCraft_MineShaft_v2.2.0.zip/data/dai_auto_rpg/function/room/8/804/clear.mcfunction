title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Blackstone Junction secured.',color:'gray'}
function dai_auto_rpg:item/give_boss_key
execute unless items entity @s inventory.* minecraft:diamond_axe run give @s minecraft:diamond_axe[minecraft:custom_name={text:'Riftbreaker',color:'dark_red',italic:false}] 1
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f8/804_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f8/804_b2
tellraw @s {text:'Boss Key acquired. Open the Rift Superintendent route when ready.',color:'aqua'}
