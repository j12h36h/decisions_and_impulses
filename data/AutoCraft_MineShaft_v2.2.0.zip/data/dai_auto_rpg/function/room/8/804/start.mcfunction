scoreboard players set @s arpg2_room 804
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f8/804_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f8/804_b2
execute positioned 677 -47 17 run function dai_auto_rpg:spawn/wither_skeleton
execute positioned 683 -47 23 run function dai_auto_rpg:spawn/blaze
execute positioned 677 -47 23 run function dai_auto_rpg:spawn/wither_skeleton
execute positioned 683 -47 17 run function dai_auto_rpg:spawn/magma
title @s subtitle {text:'Blackstone Junction — clear the chamber.',color:'gray'}
