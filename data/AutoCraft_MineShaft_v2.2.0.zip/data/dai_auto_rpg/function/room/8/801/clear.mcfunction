title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Breach Mouth secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:cooked_beef 2
function dai_auto_rpg:map/f8/801
tellraw @s {text:'Route choice — West: Basalt Sluice  |  South: Rift Walk',color:'yellow'}
