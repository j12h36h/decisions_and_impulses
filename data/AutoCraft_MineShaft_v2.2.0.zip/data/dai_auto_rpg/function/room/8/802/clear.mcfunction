title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Basalt Sluice secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:golden_carrot 3
function dai_auto_rpg:map/f8/802
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
