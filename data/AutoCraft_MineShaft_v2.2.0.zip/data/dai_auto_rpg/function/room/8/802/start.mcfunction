scoreboard players set @s arpg2_room 802
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f8/802
execute positioned 677 -47 -2 run function dai_auto_rpg:spawn/wither_skeleton
execute positioned 683 -47 2 run function dai_auto_rpg:spawn/blaze
execute positioned 683 -47 -2 run function dai_auto_rpg:spawn/magma
execute positioned 677 -47 2 run function dai_auto_rpg:spawn/magma
title @s subtitle {text:'Basalt Sluice — clear the chamber.',color:'gray'}
