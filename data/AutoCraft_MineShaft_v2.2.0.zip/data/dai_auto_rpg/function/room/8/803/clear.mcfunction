title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Rift Walk secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s armor.feet minecraft:diamond_boots run give @s minecraft:diamond_boots[minecraft:custom_name={text:'Breachwalker Boots',color:'red',italic:false},minecraft:enchantments={"minecraft:protection":1}] 1
function dai_auto_rpg:map/f8/803
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
