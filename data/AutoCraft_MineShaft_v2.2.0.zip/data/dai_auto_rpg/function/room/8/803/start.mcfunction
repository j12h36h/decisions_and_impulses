scoreboard players set @s arpg2_room 803
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f8/803
execute positioned 700 -47 17 run function dai_auto_rpg:spawn/blaze
execute positioned 700 -47 23 run function dai_auto_rpg:spawn/wither_skeleton
execute positioned 697 -47 20 run function dai_auto_rpg:spawn/magma
execute positioned 703 -47 20 run function dai_auto_rpg:spawn/wither_skeleton
title @s subtitle {text:'Rift Walk — clear the chamber.',color:'gray'}
