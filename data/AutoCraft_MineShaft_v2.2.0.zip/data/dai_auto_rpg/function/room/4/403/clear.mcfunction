title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Spore Garden secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:honey_bottle 1
function dai_auto_rpg:map/f4/403
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
