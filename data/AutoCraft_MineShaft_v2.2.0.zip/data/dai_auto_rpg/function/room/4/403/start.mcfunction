scoreboard players set @s arpg2_room 403
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f4/403
execute positioned 220 -47 17 run function dai_auto_rpg:spawn/spider
execute positioned 218 -47 21 run function dai_auto_rpg:spawn/cave_spider
execute positioned 222 -47 21 run function dai_auto_rpg:spawn/cave_spider
execute positioned 220 -47 23 run function dai_auto_rpg:spawn/skeleton
title @s subtitle {text:'Spore Garden — clear the chamber.',color:'gray'}
