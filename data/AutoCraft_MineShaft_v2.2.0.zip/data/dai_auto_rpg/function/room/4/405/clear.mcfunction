scoreboard players set @s arpg2_unlock 5
function dai_auto_rpg:item/memento/floor4
tellraw @s {text:'Memento acquired: Sporekeeper’s Bloom',color:'gold'}
execute unless items entity @s inventory.* minecraft:diamond_axe run give @s minecraft:diamond_axe[minecraft:custom_name={text:'Sporecleaver',color:'green',bold:true,italic:false}] 1
function dai_auto_rpg:map/f4/405
title @s title {"text":"FLOOR 4 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 5 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 5 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
