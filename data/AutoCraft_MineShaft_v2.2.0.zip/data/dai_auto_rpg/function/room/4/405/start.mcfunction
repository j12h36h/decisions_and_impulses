scoreboard players set @s arpg2_room 405
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 20
function dai_auto_rpg:map/f4/405
fill 175 -48 15 185 -48 25 minecraft:mud_bricks
execute positioned 180 -47 20 run function dai_auto_rpg:spawn/f4_boss
execute positioned 177 -47 22 run function dai_auto_rpg:spawn/cave_spider
execute positioned 183 -47 18 run function dai_auto_rpg:spawn/spider
title @s title {text:'BOSS — SPOREKEEPER',color:'gold',bold:true}
title @s subtitle {text:'Manual combat. Clear the entire chamber.',color:'gray'}
