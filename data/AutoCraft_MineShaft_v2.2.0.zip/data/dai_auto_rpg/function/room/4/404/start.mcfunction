scoreboard players set @s arpg2_room 404
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f4/404_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f4/404_b2
execute positioned 197 -47 20 run function dai_auto_rpg:spawn/cave_spider
execute positioned 203 -47 20 run function dai_auto_rpg:spawn/cave_spider
execute positioned 200 -47 17 run function dai_auto_rpg:spawn/spider
execute positioned 200 -47 23 run function dai_auto_rpg:spawn/skeleton
title @s subtitle {text:'Root Junction — clear the chamber.',color:'gray'}
