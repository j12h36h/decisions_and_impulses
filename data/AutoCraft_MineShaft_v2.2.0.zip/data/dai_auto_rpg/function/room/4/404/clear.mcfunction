title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Root Junction secured.',color:'gray'}
function dai_auto_rpg:item/give_boss_key
execute unless items entity @s armor.legs minecraft:chainmail_leggings run give @s minecraft:chainmail_leggings[minecraft:custom_name={text:'Sporeguard Leggings',color:'dark_green',italic:false},minecraft:enchantments={"minecraft:protection":1}] 1
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f4/404_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f4/404_b2
tellraw @s {text:'Boss Key acquired. Open the Sporekeeper route when ready.',color:'aqua'}
