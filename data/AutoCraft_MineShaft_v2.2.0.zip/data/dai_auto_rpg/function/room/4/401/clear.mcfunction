title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Moss Intake secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:baked_potato 2
function dai_auto_rpg:map/f4/401
tellraw @s {text:'Route choice — West: Webbed Barracks  |  South: Spore Garden',color:'yellow'}
