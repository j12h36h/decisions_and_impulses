scoreboard players set @s arpg2_room 402
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f4/402
execute positioned 198 -47 -2 run function dai_auto_rpg:spawn/cave_spider
execute positioned 202 -47 2 run function dai_auto_rpg:spawn/spider
execute positioned 202 -47 -2 run function dai_auto_rpg:spawn/cave_spider
execute positioned 198 -47 2 run function dai_auto_rpg:spawn/green
title @s subtitle {text:'Webbed Barracks — clear the chamber.',color:'gray'}
