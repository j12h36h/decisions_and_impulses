title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Webbed Barracks secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s inventory.* minecraft:iron_axe run give @s minecraft:iron_axe[minecraft:custom_name={text:'Rootcutter',color:'green',italic:false}] 1
function dai_auto_rpg:map/f4/402
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
