scoreboard players set @s arpg2_room 703
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f7/703
execute positioned 600 -47 -3 run function dai_auto_rpg:spawn/vindicator
execute positioned 600 -47 3 run function dai_auto_rpg:spawn/pillager
execute positioned 597 -47 0 run function dai_auto_rpg:spawn/pillager
execute positioned 603 -47 0 run function dai_auto_rpg:spawn/pillager
title @s subtitle {text:'Assembly Deck — clear the chamber.',color:'gray'}
