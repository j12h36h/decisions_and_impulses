title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Machine Intake secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:cooked_porkchop 2
function dai_auto_rpg:map/f7/701
tellraw @s {text:'Route choice — North: Relay Hall  |  East: Assembly Deck',color:'yellow'}
