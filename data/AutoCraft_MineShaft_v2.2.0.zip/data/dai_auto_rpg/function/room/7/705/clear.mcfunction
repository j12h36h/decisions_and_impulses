scoreboard players set @s arpg2_unlock 8
function dai_auto_rpg:item/memento/floor7
tellraw @s {text:'Memento acquired: Engineer’s Pocketwatch',color:'gold'}
execute unless items entity @s inventory.* minecraft:diamond_sword run give @s minecraft:diamond_sword[minecraft:custom_name={text:'Engineer Saber',color:'yellow',bold:true,italic:false},minecraft:enchantments={"minecraft:sharpness":1}] 1
function dai_auto_rpg:map/f7/705
title @s title {"text":"FLOOR 7 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 8 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 8 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
