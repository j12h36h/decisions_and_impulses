scoreboard players set @s arpg2_room 705
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 20
function dai_auto_rpg:map/f7/705
fill 615 -48 -25 625 -48 -15 minecraft:exposed_copper
execute positioned 620 -47 -20 run function dai_auto_rpg:spawn/f7_boss
execute positioned 617 -47 -18 run function dai_auto_rpg:spawn/pillager
execute positioned 623 -47 -22 run function dai_auto_rpg:spawn/pillager
title @s title {text:'BOSS — CHIEF ENGINEER',color:'gold',bold:true}
title @s subtitle {text:'Manual combat. Clear the entire chamber.',color:'gray'}
