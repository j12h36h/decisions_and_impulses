title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Control Junction secured.',color:'gray'}
function dai_auto_rpg:item/give_boss_key
execute unless items entity @s armor.legs minecraft:iron_leggings run give @s minecraft:iron_leggings[minecraft:custom_name={text:'Engineer Greaves',color:'gold',italic:false},minecraft:enchantments={"minecraft:protection":1}] 1
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f7/704_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f7/704_b2
tellraw @s {text:'Boss Key acquired. Open the Chief Engineer route when ready.',color:'aqua'}
