scoreboard players set @s arpg2_room 704
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f7/704_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f7/704_b2
execute positioned 597 -47 -23 run function dai_auto_rpg:spawn/vindicator
execute positioned 603 -47 -17 run function dai_auto_rpg:spawn/pillager
execute positioned 597 -47 -17 run function dai_auto_rpg:spawn/vindicator
execute positioned 603 -47 -23 run function dai_auto_rpg:spawn/pillager
title @s subtitle {text:'Control Junction — clear the chamber.',color:'gray'}
