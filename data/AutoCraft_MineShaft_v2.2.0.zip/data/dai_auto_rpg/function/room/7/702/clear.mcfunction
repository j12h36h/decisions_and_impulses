title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Relay Hall secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s inventory.* minecraft:crossbow run give @s minecraft:crossbow[minecraft:custom_name={text:'Bolt Driver',color:'yellow',italic:false}] 1
function dai_auto_rpg:map/f7/702
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
