scoreboard players set @s arpg2_room 702
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f7/702
execute positioned 577 -47 -22 run function dai_auto_rpg:spawn/pillager
execute positioned 583 -47 -18 run function dai_auto_rpg:spawn/vindicator
execute positioned 583 -47 -22 run function dai_auto_rpg:spawn/pillager
execute positioned 577 -47 -18 run function dai_auto_rpg:spawn/vindicator
title @s subtitle {text:'Relay Hall — clear the chamber.',color:'gray'}
