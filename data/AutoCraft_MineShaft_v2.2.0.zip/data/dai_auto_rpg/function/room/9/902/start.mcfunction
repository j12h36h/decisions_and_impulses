scoreboard players set @s arpg2_room 902
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f9/902
execute positioned 817 -47 -22 run function dai_auto_rpg:spawn/silverfish
execute positioned 823 -47 -18 run function dai_auto_rpg:spawn/silverfish
execute positioned 823 -47 -22 run function dai_auto_rpg:spawn/skeleton
execute positioned 817 -47 -18 run function dai_auto_rpg:spawn/enderman
effect give @s minecraft:darkness 6 0 true
title @s subtitle {text:'Silent Archive — clear the chamber.',color:'gray'}
