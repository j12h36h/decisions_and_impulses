title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Silent Archive secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:golden_apple 1
function dai_auto_rpg:map/f9/902
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
