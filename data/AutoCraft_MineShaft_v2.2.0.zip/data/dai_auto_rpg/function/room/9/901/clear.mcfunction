title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Ancient Threshold secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:cooked_salmon 2
function dai_auto_rpg:map/f9/901
tellraw @s {text:'Route choice — North: Silent Archive  |  East: Sculk Crossing',color:'yellow'}
