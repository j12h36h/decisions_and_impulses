scoreboard players set @s arpg2_room 904
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f9/904_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f9/904_b2
execute positioned 837 -47 -23 run function dai_auto_rpg:spawn/enderman
execute positioned 843 -47 -17 run function dai_auto_rpg:spawn/skeleton
execute positioned 837 -47 -17 run function dai_auto_rpg:spawn/silverfish
execute positioned 843 -47 -23 run function dai_auto_rpg:spawn/stray
effect give @s minecraft:darkness 6 0 true
title @s subtitle {text:'Forgotten Junction — clear the chamber.',color:'gray'}
