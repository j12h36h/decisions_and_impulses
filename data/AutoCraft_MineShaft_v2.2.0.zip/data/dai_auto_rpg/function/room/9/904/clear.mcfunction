title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Forgotten Junction secured.',color:'gray'}
function dai_auto_rpg:item/give_boss_key
execute unless items entity @s inventory.* minecraft:diamond_sword run give @s minecraft:diamond_sword[minecraft:custom_name={text:'Echo Blade',color:'aqua',italic:false},minecraft:enchantments={"minecraft:sharpness":1}] 1
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f9/904_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f9/904_b2
tellraw @s {text:'Boss Key acquired. Open the Deep Surveyor route when ready.',color:'aqua'}
