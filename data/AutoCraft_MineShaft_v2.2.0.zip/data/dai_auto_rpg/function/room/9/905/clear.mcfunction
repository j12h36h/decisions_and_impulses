scoreboard players set @s arpg2_unlock 10
function dai_auto_rpg:item/memento/floor9
tellraw @s {text:'Memento acquired: Deep Survey Fragment',color:'gold'}
execute unless items entity @s inventory.* minecraft:netherite_pickaxe run give @s minecraft:netherite_pickaxe[minecraft:custom_name={text:'Deep Survey Pick',color:'dark_aqua',bold:true,italic:false}] 1
function dai_auto_rpg:map/f9/905
title @s title {"text":"FLOOR 9 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 10 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 10 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
