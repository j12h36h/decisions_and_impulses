scoreboard players set @s arpg2_room 905
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 20
function dai_auto_rpg:map/f9/905
fill 855 -48 -25 865 -48 -15 minecraft:polished_deepslate
execute positioned 860 -47 -20 run function dai_auto_rpg:spawn/f9_boss
execute positioned 857 -47 -18 run function dai_auto_rpg:spawn/silverfish
execute positioned 863 -47 -22 run function dai_auto_rpg:spawn/stray
effect give @s minecraft:darkness 8 0 true
title @s title {text:'BOSS — DEEP SURVEYOR',color:'gold',bold:true}
title @s subtitle {text:'Manual combat. Clear the entire chamber.',color:'gray'}
