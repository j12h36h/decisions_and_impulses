title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Sculk Crossing secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s armor.chest minecraft:diamond_chestplate run give @s minecraft:diamond_chestplate[minecraft:custom_name={text:'Deepguard Cuirass',color:'dark_aqua',italic:false},minecraft:enchantments={"minecraft:protection":1}] 1
function dai_auto_rpg:map/f9/903
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
