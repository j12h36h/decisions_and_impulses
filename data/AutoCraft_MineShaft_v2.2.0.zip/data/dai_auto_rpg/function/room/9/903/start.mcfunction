scoreboard players set @s arpg2_room 903
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f9/903
execute positioned 840 -47 -3 run function dai_auto_rpg:spawn/enderman
execute positioned 840 -47 3 run function dai_auto_rpg:spawn/skeleton
execute positioned 837 -47 0 run function dai_auto_rpg:spawn/silverfish
execute positioned 843 -47 0 run function dai_auto_rpg:spawn/silverfish
effect give @s minecraft:darkness 6 0 true
title @s subtitle {text:'Sculk Crossing — clear the chamber.',color:'gray'}
