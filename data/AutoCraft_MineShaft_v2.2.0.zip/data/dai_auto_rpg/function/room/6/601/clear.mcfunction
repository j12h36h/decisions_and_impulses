title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Fault Mouth secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:cooked_chicken 2
function dai_auto_rpg:map/f6/601
tellraw @s {text:'Route choice — West: Shard Gallery  |  South: Echo Chamber',color:'yellow'}
