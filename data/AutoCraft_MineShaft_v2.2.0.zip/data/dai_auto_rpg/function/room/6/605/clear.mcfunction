scoreboard players set @s arpg2_unlock 7
function dai_auto_rpg:item/memento/floor6
tellraw @s {text:'Memento acquired: Resonant Lens',color:'gold'}
execute unless items entity @s inventory.* minecraft:diamond_pickaxe run give @s minecraft:diamond_pickaxe[minecraft:custom_name={text:'Resonant Pick',color:'light_purple',bold:true,italic:false}] 1
function dai_auto_rpg:map/f6/605
title @s title {"text":"FLOOR 6 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 7 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 7 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
