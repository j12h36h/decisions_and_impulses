scoreboard players set @s arpg2_room 605
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 20
function dai_auto_rpg:map/f6/605
fill 415 -48 15 425 -48 25 minecraft:calcite
execute positioned 420 -47 20 run function dai_auto_rpg:spawn/f6_boss
execute positioned 417 -47 22 run function dai_auto_rpg:spawn/skeleton
execute positioned 423 -47 18 run function dai_auto_rpg:spawn/silverfish
title @s title {text:'BOSS — RESONANT PROSPECTOR',color:'gold',bold:true}
title @s subtitle {text:'Manual combat. Clear the entire chamber.',color:'gray'}
