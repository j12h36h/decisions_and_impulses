scoreboard players set @s arpg2_room 603
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f6/603
execute positioned 460 -47 17 run function dai_auto_rpg:spawn/stray
execute positioned 460 -47 23 run function dai_auto_rpg:spawn/skeleton
execute positioned 458 -47 20 run function dai_auto_rpg:spawn/silverfish
execute positioned 462 -47 20 run function dai_auto_rpg:spawn/silverfish
title @s subtitle {text:'Echo Chamber — clear the chamber.',color:'gray'}
