title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Echo Chamber secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:arrow 16
function dai_auto_rpg:map/f6/603
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
