title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Shard Gallery secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s inventory.* minecraft:bow run give @s minecraft:bow[minecraft:custom_name={text:'Resonance Bow',color:'light_purple',italic:false},minecraft:enchantments={"minecraft:power":1}] 1
function dai_auto_rpg:map/f6/602
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
