scoreboard players set @s arpg2_room 602
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f6/602
execute positioned 437 -47 -2 run function dai_auto_rpg:spawn/skeleton
execute positioned 443 -47 2 run function dai_auto_rpg:spawn/stray
execute positioned 443 -47 -2 run function dai_auto_rpg:spawn/skeleton
execute positioned 437 -47 2 run function dai_auto_rpg:spawn/silverfish
title @s subtitle {text:'Shard Gallery — clear the chamber.',color:'gray'}
