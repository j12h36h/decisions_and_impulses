scoreboard players set @s arpg2_room 604
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f6/604_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f6/604_b2
execute positioned 437 -47 17 run function dai_auto_rpg:spawn/skeleton
execute positioned 443 -47 23 run function dai_auto_rpg:spawn/stray
execute positioned 437 -47 23 run function dai_auto_rpg:spawn/skeleton
execute positioned 443 -47 17 run function dai_auto_rpg:spawn/stray
title @s subtitle {text:'Resonance Junction — clear the chamber.',color:'gray'}
