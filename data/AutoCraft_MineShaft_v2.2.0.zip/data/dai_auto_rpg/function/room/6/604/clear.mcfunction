title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Resonance Junction secured.',color:'gray'}
function dai_auto_rpg:item/give_boss_key
execute unless items entity @s armor.head minecraft:diamond_helmet run give @s minecraft:diamond_helmet[minecraft:custom_name={text:'Crystal Delver Helm',color:'aqua',italic:false}] 1
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f6/604_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f6/604_b2
tellraw @s {text:'Boss Key acquired. Open the Resonant Prospector route when ready.',color:'aqua'}
