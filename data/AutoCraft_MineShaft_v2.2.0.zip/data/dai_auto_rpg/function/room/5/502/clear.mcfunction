title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Cooling Line secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s armor.chest minecraft:iron_chestplate run give @s minecraft:iron_chestplate[minecraft:custom_name={text:'Foundry Plate',color:'gold',italic:false}] 1
function dai_auto_rpg:map/f5/502
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
