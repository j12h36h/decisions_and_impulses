scoreboard players set @s arpg2_room 502
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f5/502
execute positioned 338 -47 -22 run function dai_auto_rpg:spawn/magma
execute positioned 342 -47 -18 run function dai_auto_rpg:spawn/magma
execute positioned 342 -47 -22 run function dai_auto_rpg:spawn/husk
execute positioned 338 -47 -18 run function dai_auto_rpg:spawn/husk
title @s subtitle {text:'Cooling Line — clear the chamber.',color:'gray'}
