title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Foundry Intake secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:cooked_beef 2
function dai_auto_rpg:map/f5/501
tellraw @s {text:'Route choice — North: Cooling Line  |  East: Smelter Deck',color:'yellow'}
