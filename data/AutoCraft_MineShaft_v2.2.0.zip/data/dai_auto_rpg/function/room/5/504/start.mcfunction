scoreboard players set @s arpg2_room 504
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f5/504_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f5/504_b2
execute positioned 357 -47 -22 run function dai_auto_rpg:spawn/magma
execute positioned 363 -47 -18 run function dai_auto_rpg:spawn/magma
execute positioned 357 -47 -18 run function dai_auto_rpg:spawn/husk
execute positioned 363 -47 -22 run function dai_auto_rpg:spawn/husk
title @s subtitle {text:'Heat Exchange — clear the chamber.',color:'gray'}
