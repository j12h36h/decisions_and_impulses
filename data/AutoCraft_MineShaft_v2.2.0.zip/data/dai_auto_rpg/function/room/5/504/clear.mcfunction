title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Heat Exchange secured.',color:'gray'}
function dai_auto_rpg:item/give_boss_key
execute unless items entity @s inventory.* minecraft:iron_sword run give @s minecraft:iron_sword[minecraft:custom_name={text:'Heat-Treated Blade',color:'red',italic:false},minecraft:enchantments={"minecraft:sharpness":1}] 1
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f5/504_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f5/504_b2
tellraw @s {text:'Boss Key acquired. Open the Furnace Foreman route when ready.',color:'aqua'}
