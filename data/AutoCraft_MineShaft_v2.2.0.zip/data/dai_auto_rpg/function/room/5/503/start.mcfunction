scoreboard players set @s arpg2_room 503
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f5/503
execute positioned 360 -47 -3 run function dai_auto_rpg:spawn/magma
execute positioned 360 -47 3 run function dai_auto_rpg:spawn/magma
execute positioned 357 -47 0 run function dai_auto_rpg:spawn/skeleton
execute positioned 363 -47 0 run function dai_auto_rpg:spawn/husk
title @s subtitle {text:'Smelter Deck — clear the chamber.',color:'gray'}
