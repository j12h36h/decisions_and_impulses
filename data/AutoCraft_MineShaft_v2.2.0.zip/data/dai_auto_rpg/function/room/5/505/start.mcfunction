scoreboard players set @s arpg2_room 505
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 20
function dai_auto_rpg:map/f5/505
fill 375 -48 -25 385 -48 -15 minecraft:smooth_basalt
execute positioned 380 -47 -20 run function dai_auto_rpg:spawn/f5_boss
execute positioned 377 -47 -18 run function dai_auto_rpg:spawn/husk
execute positioned 383 -47 -22 run function dai_auto_rpg:spawn/magma
title @s title {text:'BOSS — FURNACE FOREMAN',color:'gold',bold:true}
title @s subtitle {text:'Manual combat. Clear the entire chamber.',color:'gray'}
