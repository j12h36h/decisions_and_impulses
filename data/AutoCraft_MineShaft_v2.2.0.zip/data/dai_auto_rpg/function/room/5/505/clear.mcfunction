scoreboard players set @s arpg2_unlock 6
function dai_auto_rpg:item/memento/floor5
tellraw @s {text:'Memento acquired: Foundry Heart',color:'gold'}
execute unless items entity @s armor.chest minecraft:diamond_chestplate run give @s minecraft:diamond_chestplate[minecraft:custom_name={text:'Furnace Plate',color:'gold',bold:true,italic:false}] 1
function dai_auto_rpg:map/f5/505
title @s title {"text":"FLOOR 5 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 6 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 6 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
