title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Director Junction secured.',color:'gray'}
function dai_auto_rpg:item/give_boss_key
give @s minecraft:golden_apple 2
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f10/1004_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f10/1004_b2
tellraw @s {text:'Boss Key acquired. Open the The Mine Director route when ready.',color:'aqua'}
