scoreboard players set @s arpg2_room 1004
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f10/1004_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f10/1004_b2
execute positioned 917 -47 17 run function dai_auto_rpg:spawn/wither_skeleton
execute positioned 923 -47 23 run function dai_auto_rpg:spawn/pillager
execute positioned 917 -47 23 run function dai_auto_rpg:spawn/drowned
execute positioned 923 -47 17 run function dai_auto_rpg:spawn/magma
title @s subtitle {text:'Director Junction — clear the chamber.',color:'gray'}
