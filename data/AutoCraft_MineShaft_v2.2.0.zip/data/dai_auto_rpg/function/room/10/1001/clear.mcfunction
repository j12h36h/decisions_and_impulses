title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Central Shaft secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:golden_apple 1
function dai_auto_rpg:map/f10/1001
tellraw @s {text:'Route choice — West: Control Wing  |  South: Core Works',color:'yellow'}
