title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Core Works secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s inventory.* minecraft:netherite_sword run give @s minecraft:netherite_sword[minecraft:custom_name={text:'Core Cutter',color:'dark_red',italic:false},minecraft:enchantments={"minecraft:sharpness":1}] 1
function dai_auto_rpg:map/f10/1003
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
