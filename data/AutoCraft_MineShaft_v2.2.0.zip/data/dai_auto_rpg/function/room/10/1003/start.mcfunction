scoreboard players set @s arpg2_room 1003
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f10/1003
execute positioned 940 -47 17 run function dai_auto_rpg:spawn/blaze
execute positioned 940 -47 23 run function dai_auto_rpg:spawn/vindicator
execute positioned 937 -47 20 run function dai_auto_rpg:spawn/stray
execute positioned 943 -47 20 run function dai_auto_rpg:spawn/enderman
title @s subtitle {text:'Core Works — clear the chamber.',color:'gray'}
