scoreboard players set @s arpg2_room 1005
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 20
function dai_auto_rpg:map/f10/1005
fill 895 -48 15 905 -48 25 minecraft:polished_blackstone
scoreboard players set @s arpg2_phase 1
execute positioned 900 -47 20 run function dai_auto_rpg:spawn/f10_phase1
title @s title {text:'BOSS — EXCAVATION ENGINE',color:'gold',bold:true}
title @s subtitle {text:'Three phases stand between you and the Heart.',color:'gray'}
