scoreboard players set @s arpg2_unlock 10
function dai_auto_rpg:item/memento/floor10
tellraw @s {text:'Memento acquired: Heart of the Mine',color:'gold'}
tag @s add arpg2_campaign_clear
function dai_auto_rpg:map/f10/1005
title @s title {"text":"MINESHAFT CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"All 10 floors conquered.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 0.8
playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.8 1.2
tellraw @s {text:'The Mine Director is down. AutoCraft MineShaft Floor 1–10 campaign complete.',color:'gold'}
