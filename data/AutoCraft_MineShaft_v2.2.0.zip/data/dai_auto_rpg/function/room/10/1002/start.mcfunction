scoreboard players set @s arpg2_room 1002
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f10/1002
execute positioned 917 -47 -2 run function dai_auto_rpg:spawn/pillager
execute positioned 923 -47 2 run function dai_auto_rpg:spawn/wither_skeleton
execute positioned 923 -47 -2 run function dai_auto_rpg:spawn/silverfish
execute positioned 917 -47 2 run function dai_auto_rpg:spawn/magma
title @s subtitle {text:'Control Wing — clear the chamber.',color:'gray'}
