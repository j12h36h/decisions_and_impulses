title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Control Wing secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s armor.head minecraft:netherite_helmet run give @s minecraft:netherite_helmet[minecraft:custom_name={text:'Director Helm',color:'gold',italic:false}] 1
function dai_auto_rpg:map/f10/1002
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
