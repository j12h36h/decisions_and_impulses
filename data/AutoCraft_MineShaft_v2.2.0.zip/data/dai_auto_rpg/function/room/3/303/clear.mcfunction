title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Drowned Worksite secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s inventory.* minecraft:shield run give @s minecraft:shield[minecraft:custom_name={text:'Pump Shield',color:'blue',italic:false}] 1
function dai_auto_rpg:map/f3/303
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
