scoreboard players set @s arpg2_room 303
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f3/303
execute positioned 120 -47 -2 run function dai_auto_rpg:spawn/drowned
execute positioned 120 -47 2 run function dai_auto_rpg:spawn/drowned
execute positioned 118 -47 0 run function dai_auto_rpg:spawn/red
execute positioned 122 -47 0 run function dai_auto_rpg:spawn/green
title @s subtitle {text:'Drowned Worksite — clear the chamber.',color:'gray'}
