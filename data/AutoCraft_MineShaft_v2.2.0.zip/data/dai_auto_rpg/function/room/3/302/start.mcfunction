scoreboard players set @s arpg2_room 302
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
function dai_auto_rpg:map/f3/302
execute positioned 98 -47 -20 run function dai_auto_rpg:spawn/drowned
execute positioned 102 -47 -20 run function dai_auto_rpg:spawn/drowned
execute positioned 100 -47 -18 run function dai_auto_rpg:spawn/blue
execute positioned 100 -47 -22 run function dai_auto_rpg:spawn/green
title @s subtitle {text:'Pump Station — clear the chamber.',color:'gray'}
