title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Pump Station secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
execute unless items entity @s armor.feet minecraft:iron_boots run give @s minecraft:iron_boots[minecraft:custom_name={text:'Floodwalker Boots',color:'aqua',italic:false}] 1
function dai_auto_rpg:map/f3/302
tellraw @s {text:'Room clear. Use your MineShaft Key on the remaining gate.',color:'yellow'}
