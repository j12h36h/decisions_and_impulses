scoreboard players set @s arpg2_room 304
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f3/304_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f3/304_b2
execute positioned 118 -47 -22 run function dai_auto_rpg:spawn/drowned
execute positioned 122 -47 -18 run function dai_auto_rpg:spawn/drowned
execute positioned 122 -47 -22 run function dai_auto_rpg:spawn/blue
execute positioned 118 -47 -18 run function dai_auto_rpg:spawn/red
title @s subtitle {text:'Floodgate Junction — clear the chamber.',color:'gray'}
