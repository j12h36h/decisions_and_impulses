title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Floodgate Junction secured.',color:'gray'}
function dai_auto_rpg:item/give_boss_key
execute unless items entity @s armor.chest minecraft:chainmail_chestplate run give @s minecraft:chainmail_chestplate[minecraft:custom_name={text:'Survey Coat',color:'aqua',italic:false},minecraft:enchantments={"minecraft:protection":1}] 1
execute if score @s arpg2_branch matches 1 run function dai_auto_rpg:map/f3/304_b1
execute if score @s arpg2_branch matches 2 run function dai_auto_rpg:map/f3/304_b2
tellraw @s {text:'Boss Key acquired. Open the Drowned Surveyor route when ready.',color:'aqua'}
