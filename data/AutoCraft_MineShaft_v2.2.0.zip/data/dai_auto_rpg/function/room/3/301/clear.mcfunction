title @s title {"text":"ROOM CLEARED","color":"green","bold":true}
title @s subtitle {text:'Intake Gallery secured.',color:'gray'}
function dai_auto_rpg:item/give_mineshaft_key
give @s minecraft:cooked_cod 2
function dai_auto_rpg:map/f3/301
tellraw @s {text:'Route choice — North: Pump Station  |  East: Drowned Worksite',color:'yellow'}
