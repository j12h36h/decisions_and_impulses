scoreboard players set @s arpg2_room 305
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 20
function dai_auto_rpg:map/f3/305
fill 135 -48 -25 145 -48 -15 minecraft:dark_prismarine
execute positioned 140 -47 -20 run function dai_auto_rpg:spawn/f3_boss
execute positioned 137 -47 -18 run function dai_auto_rpg:spawn/drowned
execute positioned 143 -47 -22 run function dai_auto_rpg:spawn/drowned
title @s title {text:'BOSS — DROWNED SURVEYOR',color:'gold',bold:true}
title @s subtitle {text:'Manual combat. Clear the entire chamber.',color:'gray'}
