# Remove leftover/natural entities around the destination room before its encounter spawns.
# The AutoCraft MineShaft world disables natural spawning, so after this runs only entities spawned by
# the room function should be living within DAI's combat recognition radius.
kill @e[type=!minecraft:player,distance=..18]
