scoreboard objectives modify arpg2_map displayname {"text":"FLOOR 1 — SLIMEWORKS","color":"gold","bold":true}
scoreboard players reset * arpg2_map
scoreboard players set arpg2_line3 arpg2_map 3
scoreboard players display name arpg2_line3 arpg2_map {"text":"?──●──B","color":"white"}
scoreboard players set arpg2_line2 arpg2_map 2
scoreboard players display name arpg2_line2 arpg2_map {"text":"│  │","color":"white"}
scoreboard players set arpg2_line1 arpg2_map 1
scoreboard players display name arpg2_line1 arpg2_map {"text":"■──■","color":"white"}
scoreboard objectives setdisplay sidebar arpg2_map
