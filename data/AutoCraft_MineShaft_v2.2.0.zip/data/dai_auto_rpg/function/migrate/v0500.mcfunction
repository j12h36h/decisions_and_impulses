# v0.5.0 adds Floors 3–10 in isolated deep sectors; no existing geometry must be destroyed.
function dai_auto_rpg:build/home_doors
scoreboard players set @s arpg2_phase 0
tag @s add arpg2_v0500_migrated
tellraw @s {text:'MineShaft v0.5.0: Floors 3–10 are now live. The north lift always routes to your deepest unlocked floor.',color:'gold'}
