# v0.5.1 repairs Home lighting without replacing storage/furnishings.
function dai_auto_rpg:build/lighting/home
tag @s add arpg2_v0510_migrated
tellraw @s {text:'MineShaft v0.5.1: Home lighting repaired. New experience worlds now use the ACMS void preset.',color:'gold'}
