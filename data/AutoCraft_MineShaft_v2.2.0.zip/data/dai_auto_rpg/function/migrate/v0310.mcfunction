# v0.3.1 polish migration. Does not reset progression or room state.
# v0.3.0 Safety Ropes had no identity marker and could duplicate on resume; normalize all legacy leads to one marked rope.
clear @s minecraft:lead
function dai_auto_rpg:player/ensure_rope

# Repair the permanent Floor II Sigil presentation when Floor 2 is unlocked.
clear @s minecraft:echo_shard[minecraft:custom_name='{"text":"Floor II Sigil","color":"aqua","italic":false}']
clear @s minecraft:echo_shard[minecraft:custom_name='{"text":"Floor II Sigil","color":"aqua","bold":true,"italic":false}']
execute if score @s arpg2_unlock matches 2.. run clear @s minecraft:echo_shard[minecraft:custom_data~{dai_auto_rpg:{floor2_sigil:1b}}]
execute if score @s arpg2_unlock matches 2.. run give @s minecraft:echo_shard[minecraft:custom_data={dai_auto_rpg:{floor2_sigil:1b}},minecraft:custom_name={text:'Floor II Sigil',color:'aqua',bold:true,italic:false},minecraft:lore=[{text:'Permanent proof that Floor 2 is unlocked.',color:'gray',italic:false}]] 1

# Repair legacy named gear/items if the old quoted-JSON name is present. These are one-time v0.3.0 conversions.
execute if items entity @s armor.legs minecraft:leather_leggings[minecraft:custom_name='{"text":"Worn Delver Leggings","color":"gold","italic":false}'] run item replace entity @s armor.legs with minecraft:leather_leggings[minecraft:custom_name={text:'Worn Delver Leggings',color:'gold',italic:false}]
execute if items entity @s armor.feet minecraft:leather_boots[minecraft:custom_name='{"text":"Slimeproof Boots","color":"green","italic":false}'] run item replace entity @s armor.feet with minecraft:leather_boots[minecraft:custom_name={text:'Slimeproof Boots',color:'green',italic:false},minecraft:enchantments={"minecraft:protection":1}]
execute if items entity @s armor.chest minecraft:leather_chestplate[minecraft:custom_name='{"text":"Foreman’s Vest","color":"gold","italic":false}'] run item replace entity @s armor.chest with minecraft:leather_chestplate[minecraft:custom_name={text:'Foreman’s Vest',color:'gold',italic:false},minecraft:enchantments={"minecraft:protection":1}]
execute if items entity @s armor.head minecraft:chainmail_helmet[minecraft:custom_name='{"text":"Miner’s Chain Hood","color":"gray","italic":false}'] run item replace entity @s armor.head with minecraft:chainmail_helmet[minecraft:custom_name={text:'Miner’s Chain Hood',color:'gray',italic:false}]
execute if items entity @s armor.feet minecraft:chainmail_boots[minecraft:custom_name='{"text":"Overseer’s Work Boots","color":"gray","italic":false}'] run item replace entity @s armor.feet with minecraft:chainmail_boots[minecraft:custom_name={text:'Overseer’s Work Boots',color:'gray',italic:false}]
execute if items entity @s armor.head minecraft:iron_helmet[minecraft:custom_name='{"text":"Deep Mine Helm","color":"aqua","italic":false}'] run item replace entity @s armor.head with minecraft:iron_helmet[minecraft:custom_name={text:'Deep Mine Helm',color:'aqua',italic:false}]

# Inventory weapons are repaired conservatively: only the exact old custom-name component is removed/reissued.
execute store result score @s arpg2_rope run clear @s minecraft:wooden_sword[minecraft:custom_name='{"text":"Splintered Sword","color":"white","italic":false}'] 0
execute if score @s arpg2_rope matches 1.. run clear @s minecraft:wooden_sword[minecraft:custom_name='{"text":"Splintered Sword","color":"white","italic":false}']
execute if score @s arpg2_rope matches 1.. run give @s minecraft:wooden_sword[minecraft:custom_name={text:'Splintered Sword',color:'white',italic:false}] 1
execute store result score @s arpg2_rope run clear @s minecraft:stone_sword[minecraft:custom_name='{"text":"Delver Blade","color":"aqua","italic":false}'] 0
execute if score @s arpg2_rope matches 1.. run clear @s minecraft:stone_sword[minecraft:custom_name='{"text":"Delver Blade","color":"aqua","italic":false}']
execute if score @s arpg2_rope matches 1.. run give @s minecraft:stone_sword[minecraft:custom_name={text:'Delver Blade',color:'aqua',italic:false}] 1
execute store result score @s arpg2_rope run clear @s minecraft:wooden_axe[minecraft:custom_name='{"text":"Redcap Hatchet","color":"red","italic":false}'] 0
execute if score @s arpg2_rope matches 1.. run clear @s minecraft:wooden_axe[minecraft:custom_name='{"text":"Redcap Hatchet","color":"red","italic":false}']
execute if score @s arpg2_rope matches 1.. run give @s minecraft:wooden_axe[minecraft:custom_name={text:'Redcap Hatchet',color:'red',italic:false}] 1
execute store result score @s arpg2_rope run clear @s minecraft:stone_axe[minecraft:custom_name='{"text":"Shaftbreaker","color":"red","italic":false}'] 0
execute if score @s arpg2_rope matches 1.. run clear @s minecraft:stone_axe[minecraft:custom_name='{"text":"Shaftbreaker","color":"red","italic":false}']
execute if score @s arpg2_rope matches 1.. run give @s minecraft:stone_axe[minecraft:custom_name={text:'Shaftbreaker',color:'red',italic:false}] 1
execute store result score @s arpg2_rope run clear @s minecraft:iron_sword[minecraft:custom_name='{"text":"Overseer’s Blade","color":"gold","bold":true,"italic":false}'] 0
execute if score @s arpg2_rope matches 1.. run clear @s minecraft:iron_sword[minecraft:custom_name='{"text":"Overseer’s Blade","color":"gold","bold":true,"italic":false}']
execute if score @s arpg2_rope matches 1.. run give @s minecraft:iron_sword[minecraft:custom_name={text:'Overseer’s Blade',color:'gold',bold:true,italic:false},minecraft:enchantments={"minecraft:sharpness":1}] 1

function dai_auto_rpg:player/ensure_rope
tag @s add arpg2_v0310_migrated
tellraw @s {text:'MineShaft v0.3.1 applied: item labels repaired, Safety Rope normalized, and combat/boss safeguards enabled.',color:'gold'}
