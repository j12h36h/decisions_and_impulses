tag @s add arpg2_v0340_migrated
tellraw @s {text:'MineShaft v0.3.4 applied: fixed-slot hotbar rewards now preserve displaced inventory items.',color:'gold'}
