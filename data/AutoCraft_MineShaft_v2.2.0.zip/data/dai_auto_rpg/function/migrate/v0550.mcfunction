# Home-only v0.5.5 migration: add the east-side farm without touching progression or inventory.
function dai_auto_rpg:build/home_farm
tag @s add arpg2_v0550_migrated
tellraw @s {text:'A small farm has been opened off the east side of Home.',color:'gold'}
