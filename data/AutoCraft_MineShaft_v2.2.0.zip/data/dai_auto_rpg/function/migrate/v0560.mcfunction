# v0.5.6 Home-safe migration: replace legacy next-floor sigils with floor-clear mementos.
# Progression is scoreboard-owned; the collectible items are presentation only.
clear @s minecraft:echo_shard[minecraft:custom_data~{dai_auto_rpg:{floor2_sigil:1b}}]
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor3_sigil:1b}}]
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor4_sigil:1b}}]
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor5_sigil:1b}}]
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor6_sigil:1b}}]
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor7_sigil:1b}}]
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor8_sigil:1b}}]
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor9_sigil:1b}}]
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor10_sigil:1b}}]
execute if score @s arpg2_unlock matches 2.. run function dai_auto_rpg:item/memento/floor1
execute if score @s arpg2_unlock matches 3.. run function dai_auto_rpg:item/memento/floor2
execute if score @s arpg2_unlock matches 4.. run function dai_auto_rpg:item/memento/floor3
execute if score @s arpg2_unlock matches 5.. run function dai_auto_rpg:item/memento/floor4
execute if score @s arpg2_unlock matches 6.. run function dai_auto_rpg:item/memento/floor5
execute if score @s arpg2_unlock matches 7.. run function dai_auto_rpg:item/memento/floor6
execute if score @s arpg2_unlock matches 8.. run function dai_auto_rpg:item/memento/floor7
execute if score @s arpg2_unlock matches 9.. run function dai_auto_rpg:item/memento/floor8
execute if score @s arpg2_unlock matches 10.. run function dai_auto_rpg:item/memento/floor9
execute if entity @s[tag=arpg2_campaign_clear] run function dai_auto_rpg:item/memento/floor10
tag @s add arpg2_v0560_migrated
tellraw @s {text:'Legacy floor sigils were converted into MineShaft mementos for each floor you have cleared.',color:'gold'}
