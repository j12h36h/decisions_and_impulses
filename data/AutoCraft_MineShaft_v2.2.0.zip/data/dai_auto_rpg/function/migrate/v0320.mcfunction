
function dai_auto_rpg:player/ensure_rope
tag @s add arpg2_v0320_migrated
tellraw @s {text:'MineShaft utility-item migration applied.',color:'gold'}
