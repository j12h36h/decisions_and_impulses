
# Home-only v0.4.1 migration.
# Collapse the two-floor Home selector into one deepest-floor MineShaft lift.
function dai_auto_rpg:build/theme/home
function dai_auto_rpg:build/home_doors
tag @s add arpg2_v0410_migrated
tellraw @s {text:'MineShaft v0.4.1: Home now has one lift to your deepest unlocked floor. The retired east gate and its lighting were cleaned up.',color:'gold'}
