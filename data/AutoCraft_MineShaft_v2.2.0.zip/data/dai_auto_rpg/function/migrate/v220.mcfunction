function dai_auto_rpg:player/ensure_rope
tag @s add arpg2_v220_migrated
tellraw @s [{"text":"ACMS // ","color":"gold","bold":true},{"text":"v2.2 recovery/runtime migration applied.","color":"gray"}]
