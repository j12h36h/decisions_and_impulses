
# Convert old prebuilt/teleporting floors to v0.4's sealed on-demand MineShaft.
# This function runs ONLY while the player is Home.
kill @e[tag=arpg2_enemy]
fill -10 -33 -30 50 -24 10 minecraft:deepslate
fill -50 -49 -10 10 -40 30 minecraft:deepslate
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_combat 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_clear_timer 0
tag @s add arpg2_v0400_migrated
tellraw @s {text:'MineShaft v0.4.0 applied: DAI combat control removed; floors now carve physical rooms and rail tunnels only as you explore.',color:'gold'}
