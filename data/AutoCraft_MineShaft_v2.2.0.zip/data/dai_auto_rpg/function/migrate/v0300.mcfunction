
function dai_auto_rpg:build/theme/home
function dai_auto_rpg:build/home_doors
tag @s add arpg2_v0300_migrated
tellraw @s {text:'MineShaft presentation migration applied.',color:'gold'}
