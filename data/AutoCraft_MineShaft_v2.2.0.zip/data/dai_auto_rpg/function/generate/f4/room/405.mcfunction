# Floor 4 — Sporekeeper Nest — generated room at center (180,-47,20).
fill 173 -48 13 187 -41 27 minecraft:mossy_stone_bricks hollow
fill 174 -47 14 186 -42 26 minecraft:air
fill 174 -48 14 186 -48 26 minecraft:mud_bricks
fill 175 -47 15 175 -42 15 minecraft:stripped_dark_oak_log[axis=y]
fill 185 -47 15 185 -42 15 minecraft:stripped_dark_oak_log[axis=y]
fill 175 -47 25 175 -42 25 minecraft:stripped_dark_oak_log[axis=y]
fill 185 -47 25 185 -42 25 minecraft:stripped_dark_oak_log[axis=y]
fill 175 -42 15 185 -42 15 minecraft:stripped_dark_oak_log[axis=x]
fill 175 -42 25 185 -42 25 minecraft:stripped_dark_oak_log[axis=x]
fill 175 -42 15 175 -42 25 minecraft:stripped_dark_oak_log[axis=z]
fill 185 -42 15 185 -42 25 minecraft:stripped_dark_oak_log[axis=z]
fill 176 -47 20 184 -47 20 minecraft:rail[shape=east_west]
setblock 174 -45 18 minecraft:coal_ore
setblock 186 -44 22 minecraft:redstone_ore
setblock 184 -47 24 minecraft:barrel[facing=up]
setblock 180 -42 20 minecraft:lantern[hanging=true]
setblock 176 -42 16 minecraft:lantern[hanging=true]
setblock 184 -42 16 minecraft:lantern[hanging=true]
setblock 176 -42 24 minecraft:lantern[hanging=true]
setblock 184 -42 24 minecraft:lantern[hanging=true]
setblock 174 -44 20 minecraft:wall_torch[facing=east]
setblock 186 -44 20 minecraft:wall_torch[facing=west]
setblock 180 -44 14 minecraft:wall_torch[facing=south]
setblock 180 -44 26 minecraft:wall_torch[facing=north]
setblock 176 -47 16 minecraft:brown_mushroom
setblock 184 -47 24 minecraft:red_mushroom
setblock 175 -45 25 minecraft:cobweb
setblock 185 -44 15 minecraft:cobweb
fill 177 -48 17 183 -48 23 minecraft:mud_bricks
fill 177 -47 17 183 -44 23 minecraft:air
