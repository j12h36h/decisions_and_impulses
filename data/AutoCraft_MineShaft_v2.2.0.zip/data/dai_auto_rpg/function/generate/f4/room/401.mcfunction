# Floor 4 — Moss Intake — generated room at center (220,-47,0).
fill 213 -48 -7 227 -41 7 minecraft:mossy_stone_bricks hollow
fill 214 -47 -6 226 -42 6 minecraft:air
fill 214 -48 -6 226 -48 6 minecraft:mud_bricks
fill 215 -47 -5 215 -42 -5 minecraft:stripped_dark_oak_log[axis=y]
fill 225 -47 -5 225 -42 -5 minecraft:stripped_dark_oak_log[axis=y]
fill 215 -47 5 215 -42 5 minecraft:stripped_dark_oak_log[axis=y]
fill 225 -47 5 225 -42 5 minecraft:stripped_dark_oak_log[axis=y]
fill 215 -42 -5 225 -42 -5 minecraft:stripped_dark_oak_log[axis=x]
fill 215 -42 5 225 -42 5 minecraft:stripped_dark_oak_log[axis=x]
fill 215 -42 -5 215 -42 5 minecraft:stripped_dark_oak_log[axis=z]
fill 225 -42 -5 225 -42 5 minecraft:stripped_dark_oak_log[axis=z]
fill 216 -47 0 224 -47 0 minecraft:rail[shape=east_west]
setblock 214 -45 -2 minecraft:coal_ore
setblock 226 -44 2 minecraft:redstone_ore
setblock 224 -47 4 minecraft:barrel[facing=up]
setblock 220 -42 0 minecraft:lantern[hanging=true]
setblock 216 -42 -4 minecraft:lantern[hanging=true]
setblock 224 -42 -4 minecraft:lantern[hanging=true]
setblock 216 -42 4 minecraft:lantern[hanging=true]
setblock 224 -42 4 minecraft:lantern[hanging=true]
setblock 214 -44 0 minecraft:wall_torch[facing=east]
setblock 226 -44 0 minecraft:wall_torch[facing=west]
setblock 220 -44 -6 minecraft:wall_torch[facing=south]
setblock 220 -44 6 minecraft:wall_torch[facing=north]
setblock 216 -47 -4 minecraft:brown_mushroom
setblock 224 -47 4 minecraft:red_mushroom
setblock 215 -45 5 minecraft:cobweb
setblock 225 -44 -5 minecraft:cobweb
setblock 213 -47 0 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 213 -46 0 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
setblock 220 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 220 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
