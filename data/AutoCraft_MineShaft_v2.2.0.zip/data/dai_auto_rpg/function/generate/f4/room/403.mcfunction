# Floor 4 — Spore Garden — generated room at center (220,-47,20).
fill 213 -48 13 227 -41 27 minecraft:mossy_stone_bricks hollow
fill 214 -47 14 226 -42 26 minecraft:air
fill 214 -48 14 226 -48 26 minecraft:mud_bricks
fill 215 -47 15 215 -42 15 minecraft:stripped_dark_oak_log[axis=y]
fill 225 -47 15 225 -42 15 minecraft:stripped_dark_oak_log[axis=y]
fill 215 -47 25 215 -42 25 minecraft:stripped_dark_oak_log[axis=y]
fill 225 -47 25 225 -42 25 minecraft:stripped_dark_oak_log[axis=y]
fill 215 -42 15 225 -42 15 minecraft:stripped_dark_oak_log[axis=x]
fill 215 -42 25 225 -42 25 minecraft:stripped_dark_oak_log[axis=x]
fill 215 -42 15 215 -42 25 minecraft:stripped_dark_oak_log[axis=z]
fill 225 -42 15 225 -42 25 minecraft:stripped_dark_oak_log[axis=z]
fill 216 -47 20 224 -47 20 minecraft:rail[shape=east_west]
setblock 214 -45 18 minecraft:coal_ore
setblock 226 -44 22 minecraft:redstone_ore
setblock 224 -47 24 minecraft:barrel[facing=up]
setblock 220 -42 20 minecraft:lantern[hanging=true]
setblock 216 -42 16 minecraft:lantern[hanging=true]
setblock 224 -42 16 minecraft:lantern[hanging=true]
setblock 216 -42 24 minecraft:lantern[hanging=true]
setblock 224 -42 24 minecraft:lantern[hanging=true]
setblock 214 -44 20 minecraft:wall_torch[facing=east]
setblock 226 -44 20 minecraft:wall_torch[facing=west]
setblock 220 -44 14 minecraft:wall_torch[facing=south]
setblock 220 -44 26 minecraft:wall_torch[facing=north]
setblock 216 -47 16 minecraft:brown_mushroom
setblock 224 -47 24 minecraft:red_mushroom
setblock 215 -45 25 minecraft:cobweb
setblock 225 -44 15 minecraft:cobweb
fill 218 -48 18 222 -48 22 minecraft:moss_block
setblock 213 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 213 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
