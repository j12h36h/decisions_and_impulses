# Floor 4 — Root Junction — generated room at center (200,-47,20).
fill 193 -48 13 207 -41 27 minecraft:mossy_stone_bricks hollow
fill 194 -47 14 206 -42 26 minecraft:air
fill 194 -48 14 206 -48 26 minecraft:mud_bricks
fill 195 -47 15 195 -42 15 minecraft:stripped_dark_oak_log[axis=y]
fill 205 -47 15 205 -42 15 minecraft:stripped_dark_oak_log[axis=y]
fill 195 -47 25 195 -42 25 minecraft:stripped_dark_oak_log[axis=y]
fill 205 -47 25 205 -42 25 minecraft:stripped_dark_oak_log[axis=y]
fill 195 -42 15 205 -42 15 minecraft:stripped_dark_oak_log[axis=x]
fill 195 -42 25 205 -42 25 minecraft:stripped_dark_oak_log[axis=x]
fill 195 -42 15 195 -42 25 minecraft:stripped_dark_oak_log[axis=z]
fill 205 -42 15 205 -42 25 minecraft:stripped_dark_oak_log[axis=z]
fill 200 -47 16 200 -47 24 minecraft:rail[shape=north_south]
setblock 194 -45 18 minecraft:coal_ore
setblock 206 -44 22 minecraft:redstone_ore
setblock 204 -47 24 minecraft:barrel[facing=up]
setblock 200 -42 20 minecraft:lantern[hanging=true]
setblock 196 -42 16 minecraft:lantern[hanging=true]
setblock 204 -42 16 minecraft:lantern[hanging=true]
setblock 196 -42 24 minecraft:lantern[hanging=true]
setblock 204 -42 24 minecraft:lantern[hanging=true]
setblock 194 -44 20 minecraft:wall_torch[facing=east]
setblock 206 -44 20 minecraft:wall_torch[facing=west]
setblock 200 -44 14 minecraft:wall_torch[facing=south]
setblock 200 -44 26 minecraft:wall_torch[facing=north]
setblock 196 -47 16 minecraft:brown_mushroom
setblock 204 -47 24 minecraft:red_mushroom
setblock 195 -45 25 minecraft:cobweb
setblock 205 -44 15 minecraft:cobweb
fill 198 -48 18 202 -48 22 minecraft:moss_block
setblock 193 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 193 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
