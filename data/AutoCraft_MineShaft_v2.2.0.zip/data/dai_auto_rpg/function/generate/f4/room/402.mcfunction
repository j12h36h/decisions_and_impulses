# Floor 4 — Webbed Barracks — generated room at center (200,-47,0).
fill 193 -48 -7 207 -41 7 minecraft:mossy_stone_bricks hollow
fill 194 -47 -6 206 -42 6 minecraft:air
fill 194 -48 -6 206 -48 6 minecraft:mud_bricks
fill 195 -47 -5 195 -42 -5 minecraft:stripped_dark_oak_log[axis=y]
fill 205 -47 -5 205 -42 -5 minecraft:stripped_dark_oak_log[axis=y]
fill 195 -47 5 195 -42 5 minecraft:stripped_dark_oak_log[axis=y]
fill 205 -47 5 205 -42 5 minecraft:stripped_dark_oak_log[axis=y]
fill 195 -42 -5 205 -42 -5 minecraft:stripped_dark_oak_log[axis=x]
fill 195 -42 5 205 -42 5 minecraft:stripped_dark_oak_log[axis=x]
fill 195 -42 -5 195 -42 5 minecraft:stripped_dark_oak_log[axis=z]
fill 205 -42 -5 205 -42 5 minecraft:stripped_dark_oak_log[axis=z]
fill 200 -47 -4 200 -47 4 minecraft:rail[shape=north_south]
setblock 194 -45 -2 minecraft:coal_ore
setblock 206 -44 2 minecraft:redstone_ore
setblock 204 -47 4 minecraft:barrel[facing=up]
setblock 200 -42 0 minecraft:lantern[hanging=true]
setblock 196 -42 -4 minecraft:lantern[hanging=true]
setblock 204 -42 -4 minecraft:lantern[hanging=true]
setblock 196 -42 4 minecraft:lantern[hanging=true]
setblock 204 -42 4 minecraft:lantern[hanging=true]
setblock 194 -44 0 minecraft:wall_torch[facing=east]
setblock 206 -44 0 minecraft:wall_torch[facing=west]
setblock 200 -44 -6 minecraft:wall_torch[facing=south]
setblock 200 -44 6 minecraft:wall_torch[facing=north]
setblock 196 -47 -4 minecraft:brown_mushroom
setblock 204 -47 4 minecraft:red_mushroom
setblock 195 -45 5 minecraft:cobweb
setblock 205 -44 -5 minecraft:cobweb
fill 198 -48 -2 202 -48 2 minecraft:moss_block
setblock 200 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 200 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
