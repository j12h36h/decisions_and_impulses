# Reset the reserved Floor 4 sector back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add 170 -10 230 30
kill @e[type=!minecraft:player,x=170,y=-50,z=-10,dx=60,dy=11,dz=40]
fill 170 -49 -10 230 -40 30 minecraft:deepslate
function dai_auto_rpg:generate/f4/room/401
forceload remove 170 -10 230 30
