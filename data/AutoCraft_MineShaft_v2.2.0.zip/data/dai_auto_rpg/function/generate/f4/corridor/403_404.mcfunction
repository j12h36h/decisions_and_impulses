# Floor 4 connector 403 -> 404.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 206 -44 20 minecraft:air
setblock 214 -44 20 minecraft:air
fill 207 -48 18 213 -42 22 minecraft:mossy_stone_bricks hollow
fill 208 -47 19 212 -43 21 minecraft:air
fill 208 -48 19 212 -48 21 minecraft:mud_bricks
fill 207 -47 19 207 -44 21 minecraft:air
fill 213 -47 19 213 -44 21 minecraft:air
fill 208 -47 20 212 -47 20 minecraft:rail[shape=east_west]
fill 210 -47 18 210 -43 18 minecraft:stripped_dark_oak_log[axis=y]
fill 210 -47 22 210 -43 22 minecraft:stripped_dark_oak_log[axis=y]
setblock 210 -43 20 minecraft:lantern[hanging=true]
setblock 209 -45 19 minecraft:wall_torch[facing=south]
setblock 211 -45 21 minecraft:wall_torch[facing=north]
