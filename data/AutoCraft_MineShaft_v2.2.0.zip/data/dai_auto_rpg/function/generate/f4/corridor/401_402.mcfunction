# Floor 4 connector 401 -> 402.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 206 -44 0 minecraft:air
setblock 214 -44 0 minecraft:air
fill 207 -48 -2 213 -42 2 minecraft:mossy_stone_bricks hollow
fill 208 -47 -1 212 -43 1 minecraft:air
fill 208 -48 -1 212 -48 1 minecraft:mud_bricks
fill 207 -47 -1 207 -44 1 minecraft:air
fill 213 -47 -1 213 -44 1 minecraft:air
fill 208 -47 0 212 -47 0 minecraft:rail[shape=east_west]
fill 210 -47 -2 210 -43 -2 minecraft:stripped_dark_oak_log[axis=y]
fill 210 -47 2 210 -43 2 minecraft:stripped_dark_oak_log[axis=y]
setblock 210 -43 0 minecraft:lantern[hanging=true]
setblock 209 -45 -1 minecraft:wall_torch[facing=south]
setblock 211 -45 1 minecraft:wall_torch[facing=north]
