# Floor 4 connector 402 -> 404.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 200 -44 6 minecraft:air
setblock 200 -44 14 minecraft:air
fill 198 -48 7 202 -42 13 minecraft:mossy_stone_bricks hollow
fill 199 -47 8 201 -43 12 minecraft:air
fill 199 -48 8 201 -48 12 minecraft:mud_bricks
fill 199 -47 7 201 -44 7 minecraft:air
fill 199 -47 13 201 -44 13 minecraft:air
fill 200 -47 8 200 -47 12 minecraft:rail[shape=north_south]
fill 198 -47 10 198 -43 10 minecraft:stripped_dark_oak_log[axis=y]
fill 202 -47 10 202 -43 10 minecraft:stripped_dark_oak_log[axis=y]
setblock 200 -43 10 minecraft:lantern[hanging=true]
setblock 199 -45 9 minecraft:wall_torch[facing=east]
setblock 201 -45 11 minecraft:wall_torch[facing=west]
