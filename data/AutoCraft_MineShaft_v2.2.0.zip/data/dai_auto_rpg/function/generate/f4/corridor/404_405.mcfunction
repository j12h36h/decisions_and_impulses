# Floor 4 connector 404 -> 405.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 186 -44 20 minecraft:air
setblock 194 -44 20 minecraft:air
fill 187 -48 18 193 -42 22 minecraft:mossy_stone_bricks hollow
fill 188 -47 19 192 -43 21 minecraft:air
fill 188 -48 19 192 -48 21 minecraft:mud_bricks
fill 187 -47 19 187 -44 21 minecraft:air
fill 193 -47 19 193 -44 21 minecraft:air
fill 188 -47 20 192 -47 20 minecraft:rail[shape=east_west]
fill 190 -47 18 190 -43 18 minecraft:stripped_dark_oak_log[axis=y]
fill 190 -47 22 190 -43 22 minecraft:stripped_dark_oak_log[axis=y]
setblock 190 -43 20 minecraft:lantern[hanging=true]
setblock 189 -45 19 minecraft:wall_torch[facing=south]
setblock 191 -45 21 minecraft:wall_torch[facing=north]
