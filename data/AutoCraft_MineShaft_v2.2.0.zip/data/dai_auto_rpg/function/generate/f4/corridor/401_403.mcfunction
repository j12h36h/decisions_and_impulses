# Floor 4 connector 401 -> 403.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 220 -44 6 minecraft:air
setblock 220 -44 14 minecraft:air
fill 218 -48 7 222 -42 13 minecraft:mossy_stone_bricks hollow
fill 219 -47 8 221 -43 12 minecraft:air
fill 219 -48 8 221 -48 12 minecraft:mud_bricks
fill 219 -47 7 221 -44 7 minecraft:air
fill 219 -47 13 221 -44 13 minecraft:air
fill 220 -47 8 220 -47 12 minecraft:rail[shape=north_south]
fill 218 -47 10 218 -43 10 minecraft:stripped_dark_oak_log[axis=y]
fill 222 -47 10 222 -43 10 minecraft:stripped_dark_oak_log[axis=y]
setblock 220 -43 10 minecraft:lantern[hanging=true]
setblock 219 -45 9 minecraft:wall_torch[facing=east]
setblock 221 -45 11 minecraft:wall_torch[facing=west]
