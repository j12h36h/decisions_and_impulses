# Floor 10 connector 1003 -> 1004.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 926 -44 20 minecraft:air
setblock 934 -44 20 minecraft:air
fill 927 -48 18 933 -42 22 minecraft:reinforced_deepslate hollow
fill 928 -47 19 932 -43 21 minecraft:air
fill 928 -48 19 932 -48 21 minecraft:polished_blackstone
fill 927 -47 19 927 -44 21 minecraft:air
fill 933 -47 19 933 -44 21 minecraft:air
fill 928 -47 20 932 -47 20 minecraft:rail[shape=east_west]
fill 930 -47 18 930 -43 18 minecraft:polished_basalt[axis=y]
fill 930 -47 22 930 -43 22 minecraft:polished_basalt[axis=y]
setblock 930 -43 20 minecraft:soul_lantern[hanging=true]
setblock 929 -45 19 minecraft:wall_torch[facing=south]
setblock 931 -45 21 minecraft:wall_torch[facing=north]
