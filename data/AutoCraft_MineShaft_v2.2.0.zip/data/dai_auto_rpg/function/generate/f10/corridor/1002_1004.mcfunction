# Floor 10 connector 1002 -> 1004.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 920 -44 6 minecraft:air
setblock 920 -44 14 minecraft:air
fill 918 -48 7 922 -42 13 minecraft:reinforced_deepslate hollow
fill 919 -47 8 921 -43 12 minecraft:air
fill 919 -48 8 921 -48 12 minecraft:polished_blackstone
fill 919 -47 7 921 -44 7 minecraft:air
fill 919 -47 13 921 -44 13 minecraft:air
fill 920 -47 8 920 -47 12 minecraft:rail[shape=north_south]
fill 918 -47 10 918 -43 10 minecraft:polished_basalt[axis=y]
fill 922 -47 10 922 -43 10 minecraft:polished_basalt[axis=y]
setblock 920 -43 10 minecraft:soul_lantern[hanging=true]
setblock 919 -45 9 minecraft:wall_torch[facing=east]
setblock 921 -45 11 minecraft:wall_torch[facing=west]
