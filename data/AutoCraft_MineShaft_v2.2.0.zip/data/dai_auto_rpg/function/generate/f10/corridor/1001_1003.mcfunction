# Floor 10 connector 1001 -> 1003.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 940 -44 6 minecraft:air
setblock 940 -44 14 minecraft:air
fill 938 -48 7 942 -42 13 minecraft:reinforced_deepslate hollow
fill 939 -47 8 941 -43 12 minecraft:air
fill 939 -48 8 941 -48 12 minecraft:polished_blackstone
fill 939 -47 7 941 -44 7 minecraft:air
fill 939 -47 13 941 -44 13 minecraft:air
fill 940 -47 8 940 -47 12 minecraft:rail[shape=north_south]
fill 938 -47 10 938 -43 10 minecraft:polished_basalt[axis=y]
fill 942 -47 10 942 -43 10 minecraft:polished_basalt[axis=y]
setblock 940 -43 10 minecraft:soul_lantern[hanging=true]
setblock 939 -45 9 minecraft:wall_torch[facing=east]
setblock 941 -45 11 minecraft:wall_torch[facing=west]
