# Floor 10 connector 1004 -> 1005.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 906 -44 20 minecraft:air
setblock 914 -44 20 minecraft:air
fill 907 -48 18 913 -42 22 minecraft:reinforced_deepslate hollow
fill 908 -47 19 912 -43 21 minecraft:air
fill 908 -48 19 912 -48 21 minecraft:polished_blackstone
fill 907 -47 19 907 -44 21 minecraft:air
fill 913 -47 19 913 -44 21 minecraft:air
fill 908 -47 20 912 -47 20 minecraft:rail[shape=east_west]
fill 910 -47 18 910 -43 18 minecraft:polished_basalt[axis=y]
fill 910 -47 22 910 -43 22 minecraft:polished_basalt[axis=y]
setblock 910 -43 20 minecraft:soul_lantern[hanging=true]
setblock 909 -45 19 minecraft:wall_torch[facing=south]
setblock 911 -45 21 minecraft:wall_torch[facing=north]
