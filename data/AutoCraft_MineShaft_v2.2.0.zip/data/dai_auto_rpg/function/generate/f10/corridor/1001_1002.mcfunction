# Floor 10 connector 1001 -> 1002.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 926 -44 0 minecraft:air
setblock 934 -44 0 minecraft:air
fill 927 -48 -2 933 -42 2 minecraft:reinforced_deepslate hollow
fill 928 -47 -1 932 -43 1 minecraft:air
fill 928 -48 -1 932 -48 1 minecraft:polished_blackstone
fill 927 -47 -1 927 -44 1 minecraft:air
fill 933 -47 -1 933 -44 1 minecraft:air
fill 928 -47 0 932 -47 0 minecraft:rail[shape=east_west]
fill 930 -47 -2 930 -43 -2 minecraft:polished_basalt[axis=y]
fill 930 -47 2 930 -43 2 minecraft:polished_basalt[axis=y]
setblock 930 -43 0 minecraft:soul_lantern[hanging=true]
setblock 929 -45 -1 minecraft:wall_torch[facing=south]
setblock 931 -45 1 minecraft:wall_torch[facing=north]
