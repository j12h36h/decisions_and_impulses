# Floor 10 — Director Junction — generated room at center (920,-47,20).
fill 913 -48 13 927 -41 27 minecraft:reinforced_deepslate hollow
fill 914 -47 14 926 -42 26 minecraft:air
fill 914 -48 14 926 -48 26 minecraft:polished_blackstone
fill 915 -47 15 915 -42 15 minecraft:polished_basalt[axis=y]
fill 925 -47 15 925 -42 15 minecraft:polished_basalt[axis=y]
fill 915 -47 25 915 -42 25 minecraft:polished_basalt[axis=y]
fill 925 -47 25 925 -42 25 minecraft:polished_basalt[axis=y]
fill 915 -42 15 925 -42 15 minecraft:polished_basalt[axis=x]
fill 915 -42 25 925 -42 25 minecraft:polished_basalt[axis=x]
fill 915 -42 15 915 -42 25 minecraft:polished_basalt[axis=z]
fill 925 -42 15 925 -42 25 minecraft:polished_basalt[axis=z]
fill 920 -47 16 920 -47 24 minecraft:rail[shape=north_south]
setblock 914 -45 18 minecraft:crying_obsidian
setblock 926 -44 22 minecraft:diamond_block
setblock 924 -47 24 minecraft:barrel[facing=up]
setblock 920 -42 20 minecraft:soul_lantern[hanging=true]
setblock 916 -42 16 minecraft:soul_lantern[hanging=true]
setblock 924 -42 16 minecraft:soul_lantern[hanging=true]
setblock 916 -42 24 minecraft:soul_lantern[hanging=true]
setblock 924 -42 24 minecraft:soul_lantern[hanging=true]
setblock 914 -44 20 minecraft:wall_torch[facing=east]
setblock 926 -44 20 minecraft:wall_torch[facing=west]
setblock 920 -44 14 minecraft:wall_torch[facing=south]
setblock 920 -44 26 minecraft:wall_torch[facing=north]
setblock 916 -48 16 minecraft:amethyst_block
setblock 924 -48 24 minecraft:exposed_copper
setblock 916 -47 24 minecraft:crying_obsidian
setblock 924 -47 16 minecraft:chiseled_deepslate
setblock 913 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 913 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
