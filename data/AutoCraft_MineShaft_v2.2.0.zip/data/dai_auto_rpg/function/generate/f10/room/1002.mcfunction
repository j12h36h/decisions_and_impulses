# Floor 10 — Control Wing — generated room at center (920,-47,0).
fill 913 -48 -7 927 -41 7 minecraft:reinforced_deepslate hollow
fill 914 -47 -6 926 -42 6 minecraft:air
fill 914 -48 -6 926 -48 6 minecraft:polished_blackstone
fill 915 -47 -5 915 -42 -5 minecraft:polished_basalt[axis=y]
fill 925 -47 -5 925 -42 -5 minecraft:polished_basalt[axis=y]
fill 915 -47 5 915 -42 5 minecraft:polished_basalt[axis=y]
fill 925 -47 5 925 -42 5 minecraft:polished_basalt[axis=y]
fill 915 -42 -5 925 -42 -5 minecraft:polished_basalt[axis=x]
fill 915 -42 5 925 -42 5 minecraft:polished_basalt[axis=x]
fill 915 -42 -5 915 -42 5 minecraft:polished_basalt[axis=z]
fill 925 -42 -5 925 -42 5 minecraft:polished_basalt[axis=z]
fill 920 -47 -4 920 -47 4 minecraft:rail[shape=north_south]
setblock 914 -45 -2 minecraft:crying_obsidian
setblock 926 -44 2 minecraft:diamond_block
setblock 924 -47 4 minecraft:barrel[facing=up]
setblock 920 -42 0 minecraft:soul_lantern[hanging=true]
setblock 916 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 924 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 916 -42 4 minecraft:soul_lantern[hanging=true]
setblock 924 -42 4 minecraft:soul_lantern[hanging=true]
setblock 914 -44 0 minecraft:wall_torch[facing=east]
setblock 926 -44 0 minecraft:wall_torch[facing=west]
setblock 920 -44 -6 minecraft:wall_torch[facing=south]
setblock 920 -44 6 minecraft:wall_torch[facing=north]
setblock 916 -48 -4 minecraft:moss_block
setblock 924 -48 4 minecraft:magma_block
setblock 916 -47 4 minecraft:crying_obsidian
setblock 924 -47 -4 minecraft:chiseled_deepslate
setblock 920 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 920 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
