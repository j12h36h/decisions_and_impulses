# Floor 10 — Central Shaft — generated room at center (940,-47,0).
fill 933 -48 -7 947 -41 7 minecraft:reinforced_deepslate hollow
fill 934 -47 -6 946 -42 6 minecraft:air
fill 934 -48 -6 946 -48 6 minecraft:polished_blackstone
fill 935 -47 -5 935 -42 -5 minecraft:polished_basalt[axis=y]
fill 945 -47 -5 945 -42 -5 minecraft:polished_basalt[axis=y]
fill 935 -47 5 935 -42 5 minecraft:polished_basalt[axis=y]
fill 945 -47 5 945 -42 5 minecraft:polished_basalt[axis=y]
fill 935 -42 -5 945 -42 -5 minecraft:polished_basalt[axis=x]
fill 935 -42 5 945 -42 5 minecraft:polished_basalt[axis=x]
fill 935 -42 -5 935 -42 5 minecraft:polished_basalt[axis=z]
fill 945 -42 -5 945 -42 5 minecraft:polished_basalt[axis=z]
fill 936 -47 0 944 -47 0 minecraft:rail[shape=east_west]
setblock 934 -45 -2 minecraft:crying_obsidian
setblock 946 -44 2 minecraft:diamond_block
setblock 944 -47 4 minecraft:barrel[facing=up]
setblock 940 -42 0 minecraft:soul_lantern[hanging=true]
setblock 936 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 944 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 936 -42 4 minecraft:soul_lantern[hanging=true]
setblock 944 -42 4 minecraft:soul_lantern[hanging=true]
setblock 934 -44 0 minecraft:wall_torch[facing=east]
setblock 946 -44 0 minecraft:wall_torch[facing=west]
setblock 940 -44 -6 minecraft:wall_torch[facing=south]
setblock 940 -44 6 minecraft:wall_torch[facing=north]
setblock 936 -48 -4 minecraft:dark_prismarine
setblock 944 -48 4 minecraft:moss_block
setblock 936 -47 4 minecraft:crying_obsidian
setblock 944 -47 -4 minecraft:chiseled_deepslate
setblock 933 -47 0 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 933 -46 0 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
setblock 940 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 940 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
