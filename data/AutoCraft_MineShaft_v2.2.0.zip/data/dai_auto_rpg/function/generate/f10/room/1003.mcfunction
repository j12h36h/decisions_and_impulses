# Floor 10 — Core Works — generated room at center (940,-47,20).
fill 933 -48 13 947 -41 27 minecraft:reinforced_deepslate hollow
fill 934 -47 14 946 -42 26 minecraft:air
fill 934 -48 14 946 -48 26 minecraft:polished_blackstone
fill 935 -47 15 935 -42 15 minecraft:polished_basalt[axis=y]
fill 945 -47 15 945 -42 15 minecraft:polished_basalt[axis=y]
fill 935 -47 25 935 -42 25 minecraft:polished_basalt[axis=y]
fill 945 -47 25 945 -42 25 minecraft:polished_basalt[axis=y]
fill 935 -42 15 945 -42 15 minecraft:polished_basalt[axis=x]
fill 935 -42 25 945 -42 25 minecraft:polished_basalt[axis=x]
fill 935 -42 15 935 -42 25 minecraft:polished_basalt[axis=z]
fill 945 -42 15 945 -42 25 minecraft:polished_basalt[axis=z]
fill 936 -47 20 944 -47 20 minecraft:rail[shape=east_west]
setblock 934 -45 18 minecraft:crying_obsidian
setblock 946 -44 22 minecraft:diamond_block
setblock 944 -47 24 minecraft:barrel[facing=up]
setblock 940 -42 20 minecraft:soul_lantern[hanging=true]
setblock 936 -42 16 minecraft:soul_lantern[hanging=true]
setblock 944 -42 16 minecraft:soul_lantern[hanging=true]
setblock 936 -42 24 minecraft:soul_lantern[hanging=true]
setblock 944 -42 24 minecraft:soul_lantern[hanging=true]
setblock 934 -44 20 minecraft:wall_torch[facing=east]
setblock 946 -44 20 minecraft:wall_torch[facing=west]
setblock 940 -44 14 minecraft:wall_torch[facing=south]
setblock 940 -44 26 minecraft:wall_torch[facing=north]
setblock 936 -48 16 minecraft:magma_block
setblock 944 -48 24 minecraft:amethyst_block
setblock 936 -47 24 minecraft:crying_obsidian
setblock 944 -47 16 minecraft:chiseled_deepslate
setblock 933 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 933 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
