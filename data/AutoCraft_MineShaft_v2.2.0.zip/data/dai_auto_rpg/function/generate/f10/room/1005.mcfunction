# Floor 10 — Mine Heart — generated room at center (900,-47,20).
fill 893 -48 13 907 -41 27 minecraft:reinforced_deepslate hollow
fill 894 -47 14 906 -42 26 minecraft:air
fill 894 -48 14 906 -48 26 minecraft:polished_blackstone
fill 895 -47 15 895 -42 15 minecraft:polished_basalt[axis=y]
fill 905 -47 15 905 -42 15 minecraft:polished_basalt[axis=y]
fill 895 -47 25 895 -42 25 minecraft:polished_basalt[axis=y]
fill 905 -47 25 905 -42 25 minecraft:polished_basalt[axis=y]
fill 895 -42 15 905 -42 15 minecraft:polished_basalt[axis=x]
fill 895 -42 25 905 -42 25 minecraft:polished_basalt[axis=x]
fill 895 -42 15 895 -42 25 minecraft:polished_basalt[axis=z]
fill 905 -42 15 905 -42 25 minecraft:polished_basalt[axis=z]
fill 896 -47 20 904 -47 20 minecraft:rail[shape=east_west]
setblock 894 -45 18 minecraft:crying_obsidian
setblock 906 -44 22 minecraft:diamond_block
setblock 904 -47 24 minecraft:barrel[facing=up]
setblock 900 -42 20 minecraft:soul_lantern[hanging=true]
setblock 896 -42 16 minecraft:soul_lantern[hanging=true]
setblock 904 -42 16 minecraft:soul_lantern[hanging=true]
setblock 896 -42 24 minecraft:soul_lantern[hanging=true]
setblock 904 -42 24 minecraft:soul_lantern[hanging=true]
setblock 894 -44 20 minecraft:wall_torch[facing=east]
setblock 906 -44 20 minecraft:wall_torch[facing=west]
setblock 900 -44 14 minecraft:wall_torch[facing=south]
setblock 900 -44 26 minecraft:wall_torch[facing=north]
setblock 896 -48 16 minecraft:exposed_copper
setblock 904 -48 24 minecraft:sculk
setblock 896 -47 24 minecraft:crying_obsidian
setblock 904 -47 16 minecraft:chiseled_deepslate
fill 898 -48 18 902 -48 22 minecraft:crying_obsidian
setblock 900 -48 20 minecraft:lodestone
fill 897 -48 17 903 -48 23 minecraft:polished_blackstone
fill 897 -47 17 903 -44 23 minecraft:air
setblock 900 -48 20 minecraft:lodestone
