# Reset the reserved Floor 10 sector back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add 890 -10 950 30
kill @e[type=!minecraft:player,x=890,y=-50,z=-10,dx=60,dy=11,dz=40]
fill 890 -49 -10 950 -40 30 minecraft:deepslate
function dai_auto_rpg:generate/f10/room/1001
forceload remove 890 -10 950 30
