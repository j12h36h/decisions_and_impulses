# Reset the reserved Floor 6 sector back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add 410 -10 470 30
kill @e[type=!minecraft:player,x=410,y=-50,z=-10,dx=60,dy=11,dz=40]
fill 410 -49 -10 470 -40 30 minecraft:deepslate
function dai_auto_rpg:generate/f6/room/601
forceload remove 410 -10 470 30
