# Floor 6 — Shard Gallery — generated room at center (440,-47,0).
fill 433 -48 -7 447 -41 7 minecraft:polished_deepslate hollow
fill 434 -47 -6 446 -42 6 minecraft:air
fill 434 -48 -6 446 -48 6 minecraft:calcite
fill 435 -47 -5 435 -42 -5 minecraft:polished_basalt[axis=y]
fill 445 -47 -5 445 -42 -5 minecraft:polished_basalt[axis=y]
fill 435 -47 5 435 -42 5 minecraft:polished_basalt[axis=y]
fill 445 -47 5 445 -42 5 minecraft:polished_basalt[axis=y]
fill 435 -42 -5 445 -42 -5 minecraft:polished_basalt[axis=x]
fill 435 -42 5 445 -42 5 minecraft:polished_basalt[axis=x]
fill 435 -42 -5 435 -42 5 minecraft:polished_basalt[axis=z]
fill 445 -42 -5 445 -42 5 minecraft:polished_basalt[axis=z]
fill 440 -47 -4 440 -47 4 minecraft:rail[shape=north_south]
setblock 434 -45 -2 minecraft:amethyst_block
setblock 446 -44 2 minecraft:deepslate_diamond_ore
setblock 444 -47 4 minecraft:barrel[facing=up]
setblock 440 -42 0 minecraft:soul_lantern[hanging=true]
setblock 436 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 444 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 436 -42 4 minecraft:soul_lantern[hanging=true]
setblock 444 -42 4 minecraft:soul_lantern[hanging=true]
setblock 434 -44 0 minecraft:wall_torch[facing=east]
setblock 446 -44 0 minecraft:wall_torch[facing=west]
setblock 440 -44 -6 minecraft:wall_torch[facing=south]
setblock 440 -44 6 minecraft:wall_torch[facing=north]
setblock 436 -47 -4 minecraft:amethyst_block
setblock 444 -47 4 minecraft:amethyst_block
setblock 436 -46 -4 minecraft:amethyst_block
setblock 444 -46 4 minecraft:amethyst_block
setblock 438 -47 3 minecraft:pointed_dripstone[vertical_direction=up,thickness=tip]
setblock 442 -47 -3 minecraft:pointed_dripstone[vertical_direction=up,thickness=tip]
setblock 440 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 440 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
