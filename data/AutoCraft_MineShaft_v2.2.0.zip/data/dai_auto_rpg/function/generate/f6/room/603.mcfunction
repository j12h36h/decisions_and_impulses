# Floor 6 — Echo Chamber — generated room at center (460,-47,20).
fill 453 -48 13 467 -41 27 minecraft:polished_deepslate hollow
fill 454 -47 14 466 -42 26 minecraft:air
fill 454 -48 14 466 -48 26 minecraft:calcite
fill 455 -47 15 455 -42 15 minecraft:polished_basalt[axis=y]
fill 465 -47 15 465 -42 15 minecraft:polished_basalt[axis=y]
fill 455 -47 25 455 -42 25 minecraft:polished_basalt[axis=y]
fill 465 -47 25 465 -42 25 minecraft:polished_basalt[axis=y]
fill 455 -42 15 465 -42 15 minecraft:polished_basalt[axis=x]
fill 455 -42 25 465 -42 25 minecraft:polished_basalt[axis=x]
fill 455 -42 15 455 -42 25 minecraft:polished_basalt[axis=z]
fill 465 -42 15 465 -42 25 minecraft:polished_basalt[axis=z]
fill 456 -47 20 464 -47 20 minecraft:rail[shape=east_west]
setblock 454 -45 18 minecraft:amethyst_block
setblock 466 -44 22 minecraft:deepslate_diamond_ore
setblock 464 -47 24 minecraft:barrel[facing=up]
setblock 460 -42 20 minecraft:soul_lantern[hanging=true]
setblock 456 -42 16 minecraft:soul_lantern[hanging=true]
setblock 464 -42 16 minecraft:soul_lantern[hanging=true]
setblock 456 -42 24 minecraft:soul_lantern[hanging=true]
setblock 464 -42 24 minecraft:soul_lantern[hanging=true]
setblock 454 -44 20 minecraft:wall_torch[facing=east]
setblock 466 -44 20 minecraft:wall_torch[facing=west]
setblock 460 -44 14 minecraft:wall_torch[facing=south]
setblock 460 -44 26 minecraft:wall_torch[facing=north]
setblock 456 -47 16 minecraft:amethyst_block
setblock 464 -47 24 minecraft:amethyst_block
setblock 456 -46 16 minecraft:amethyst_block
setblock 464 -46 24 minecraft:amethyst_block
setblock 458 -47 23 minecraft:pointed_dripstone[vertical_direction=up,thickness=tip]
setblock 462 -47 17 minecraft:pointed_dripstone[vertical_direction=up,thickness=tip]
setblock 453 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 453 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
