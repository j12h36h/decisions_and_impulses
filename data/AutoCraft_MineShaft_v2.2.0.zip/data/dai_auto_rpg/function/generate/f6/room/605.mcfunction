# Floor 6 — Prospector Vault — generated room at center (420,-47,20).
fill 413 -48 13 427 -41 27 minecraft:polished_deepslate hollow
fill 414 -47 14 426 -42 26 minecraft:air
fill 414 -48 14 426 -48 26 minecraft:calcite
fill 415 -47 15 415 -42 15 minecraft:polished_basalt[axis=y]
fill 425 -47 15 425 -42 15 minecraft:polished_basalt[axis=y]
fill 415 -47 25 415 -42 25 minecraft:polished_basalt[axis=y]
fill 425 -47 25 425 -42 25 minecraft:polished_basalt[axis=y]
fill 415 -42 15 425 -42 15 minecraft:polished_basalt[axis=x]
fill 415 -42 25 425 -42 25 minecraft:polished_basalt[axis=x]
fill 415 -42 15 415 -42 25 minecraft:polished_basalt[axis=z]
fill 425 -42 15 425 -42 25 minecraft:polished_basalt[axis=z]
fill 416 -47 20 424 -47 20 minecraft:rail[shape=east_west]
setblock 414 -45 18 minecraft:amethyst_block
setblock 426 -44 22 minecraft:deepslate_diamond_ore
setblock 424 -47 24 minecraft:barrel[facing=up]
setblock 420 -42 20 minecraft:soul_lantern[hanging=true]
setblock 416 -42 16 minecraft:soul_lantern[hanging=true]
setblock 424 -42 16 minecraft:soul_lantern[hanging=true]
setblock 416 -42 24 minecraft:soul_lantern[hanging=true]
setblock 424 -42 24 minecraft:soul_lantern[hanging=true]
setblock 414 -44 20 minecraft:wall_torch[facing=east]
setblock 426 -44 20 minecraft:wall_torch[facing=west]
setblock 420 -44 14 minecraft:wall_torch[facing=south]
setblock 420 -44 26 minecraft:wall_torch[facing=north]
setblock 416 -47 16 minecraft:amethyst_block
setblock 424 -47 24 minecraft:amethyst_block
setblock 416 -46 16 minecraft:amethyst_block
setblock 424 -46 24 minecraft:amethyst_block
fill 417 -48 17 423 -48 23 minecraft:calcite
fill 417 -47 17 423 -44 23 minecraft:air
