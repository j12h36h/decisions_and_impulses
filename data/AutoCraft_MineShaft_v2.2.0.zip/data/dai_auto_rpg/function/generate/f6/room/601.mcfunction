# Floor 6 — Fault Mouth — generated room at center (460,-47,0).
fill 453 -48 -7 467 -41 7 minecraft:polished_deepslate hollow
fill 454 -47 -6 466 -42 6 minecraft:air
fill 454 -48 -6 466 -48 6 minecraft:calcite
fill 455 -47 -5 455 -42 -5 minecraft:polished_basalt[axis=y]
fill 465 -47 -5 465 -42 -5 minecraft:polished_basalt[axis=y]
fill 455 -47 5 455 -42 5 minecraft:polished_basalt[axis=y]
fill 465 -47 5 465 -42 5 minecraft:polished_basalt[axis=y]
fill 455 -42 -5 465 -42 -5 minecraft:polished_basalt[axis=x]
fill 455 -42 5 465 -42 5 minecraft:polished_basalt[axis=x]
fill 455 -42 -5 455 -42 5 minecraft:polished_basalt[axis=z]
fill 465 -42 -5 465 -42 5 minecraft:polished_basalt[axis=z]
fill 456 -47 0 464 -47 0 minecraft:rail[shape=east_west]
setblock 454 -45 -2 minecraft:amethyst_block
setblock 466 -44 2 minecraft:deepslate_diamond_ore
setblock 464 -47 4 minecraft:barrel[facing=up]
setblock 460 -42 0 minecraft:soul_lantern[hanging=true]
setblock 456 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 464 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 456 -42 4 minecraft:soul_lantern[hanging=true]
setblock 464 -42 4 minecraft:soul_lantern[hanging=true]
setblock 454 -44 0 minecraft:wall_torch[facing=east]
setblock 466 -44 0 minecraft:wall_torch[facing=west]
setblock 460 -44 -6 minecraft:wall_torch[facing=south]
setblock 460 -44 6 minecraft:wall_torch[facing=north]
setblock 456 -47 -4 minecraft:amethyst_block
setblock 464 -47 4 minecraft:amethyst_block
setblock 456 -46 -4 minecraft:amethyst_block
setblock 464 -46 4 minecraft:amethyst_block
setblock 453 -47 0 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 453 -46 0 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
setblock 460 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 460 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
