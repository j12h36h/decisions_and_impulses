# Floor 6 — Resonance Junction — generated room at center (440,-47,20).
fill 433 -48 13 447 -41 27 minecraft:polished_deepslate hollow
fill 434 -47 14 446 -42 26 minecraft:air
fill 434 -48 14 446 -48 26 minecraft:calcite
fill 435 -47 15 435 -42 15 minecraft:polished_basalt[axis=y]
fill 445 -47 15 445 -42 15 minecraft:polished_basalt[axis=y]
fill 435 -47 25 435 -42 25 minecraft:polished_basalt[axis=y]
fill 445 -47 25 445 -42 25 minecraft:polished_basalt[axis=y]
fill 435 -42 15 445 -42 15 minecraft:polished_basalt[axis=x]
fill 435 -42 25 445 -42 25 minecraft:polished_basalt[axis=x]
fill 435 -42 15 435 -42 25 minecraft:polished_basalt[axis=z]
fill 445 -42 15 445 -42 25 minecraft:polished_basalt[axis=z]
fill 440 -47 16 440 -47 24 minecraft:rail[shape=north_south]
setblock 434 -45 18 minecraft:amethyst_block
setblock 446 -44 22 minecraft:deepslate_diamond_ore
setblock 444 -47 24 minecraft:barrel[facing=up]
setblock 440 -42 20 minecraft:soul_lantern[hanging=true]
setblock 436 -42 16 minecraft:soul_lantern[hanging=true]
setblock 444 -42 16 minecraft:soul_lantern[hanging=true]
setblock 436 -42 24 minecraft:soul_lantern[hanging=true]
setblock 444 -42 24 minecraft:soul_lantern[hanging=true]
setblock 434 -44 20 minecraft:wall_torch[facing=east]
setblock 446 -44 20 minecraft:wall_torch[facing=west]
setblock 440 -44 14 minecraft:wall_torch[facing=south]
setblock 440 -44 26 minecraft:wall_torch[facing=north]
setblock 436 -47 16 minecraft:amethyst_block
setblock 444 -47 24 minecraft:amethyst_block
setblock 436 -46 16 minecraft:amethyst_block
setblock 444 -46 24 minecraft:amethyst_block
setblock 438 -47 23 minecraft:pointed_dripstone[vertical_direction=up,thickness=tip]
setblock 442 -47 17 minecraft:pointed_dripstone[vertical_direction=up,thickness=tip]
setblock 433 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 433 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
