# Floor 6 connector 602 -> 604.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 440 -44 6 minecraft:air
setblock 440 -44 14 minecraft:air
fill 438 -48 7 442 -42 13 minecraft:polished_deepslate hollow
fill 439 -47 8 441 -43 12 minecraft:air
fill 439 -48 8 441 -48 12 minecraft:calcite
fill 439 -47 7 441 -44 7 minecraft:air
fill 439 -47 13 441 -44 13 minecraft:air
fill 440 -47 8 440 -47 12 minecraft:rail[shape=north_south]
fill 438 -47 10 438 -43 10 minecraft:polished_basalt[axis=y]
fill 442 -47 10 442 -43 10 minecraft:polished_basalt[axis=y]
setblock 440 -43 10 minecraft:soul_lantern[hanging=true]
setblock 439 -45 9 minecraft:wall_torch[facing=east]
setblock 441 -45 11 minecraft:wall_torch[facing=west]
