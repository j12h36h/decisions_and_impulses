# Floor 6 connector 603 -> 604.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 446 -44 20 minecraft:air
setblock 454 -44 20 minecraft:air
fill 447 -48 18 453 -42 22 minecraft:polished_deepslate hollow
fill 448 -47 19 452 -43 21 minecraft:air
fill 448 -48 19 452 -48 21 minecraft:calcite
fill 447 -47 19 447 -44 21 minecraft:air
fill 453 -47 19 453 -44 21 minecraft:air
fill 448 -47 20 452 -47 20 minecraft:rail[shape=east_west]
fill 450 -47 18 450 -43 18 minecraft:polished_basalt[axis=y]
fill 450 -47 22 450 -43 22 minecraft:polished_basalt[axis=y]
setblock 450 -43 20 minecraft:soul_lantern[hanging=true]
setblock 449 -45 19 minecraft:wall_torch[facing=south]
setblock 451 -45 21 minecraft:wall_torch[facing=north]
