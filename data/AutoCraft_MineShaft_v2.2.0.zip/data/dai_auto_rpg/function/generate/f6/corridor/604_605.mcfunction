# Floor 6 connector 604 -> 605.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 426 -44 20 minecraft:air
setblock 434 -44 20 minecraft:air
fill 427 -48 18 433 -42 22 minecraft:polished_deepslate hollow
fill 428 -47 19 432 -43 21 minecraft:air
fill 428 -48 19 432 -48 21 minecraft:calcite
fill 427 -47 19 427 -44 21 minecraft:air
fill 433 -47 19 433 -44 21 minecraft:air
fill 428 -47 20 432 -47 20 minecraft:rail[shape=east_west]
fill 430 -47 18 430 -43 18 minecraft:polished_basalt[axis=y]
fill 430 -47 22 430 -43 22 minecraft:polished_basalt[axis=y]
setblock 430 -43 20 minecraft:soul_lantern[hanging=true]
setblock 429 -45 19 minecraft:wall_torch[facing=south]
setblock 431 -45 21 minecraft:wall_torch[facing=north]
