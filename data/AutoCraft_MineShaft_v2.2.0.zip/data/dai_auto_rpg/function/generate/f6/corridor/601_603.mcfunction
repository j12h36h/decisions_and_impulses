# Floor 6 connector 601 -> 603.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 460 -44 6 minecraft:air
setblock 460 -44 14 minecraft:air
fill 458 -48 7 462 -42 13 minecraft:polished_deepslate hollow
fill 459 -47 8 461 -43 12 minecraft:air
fill 459 -48 8 461 -48 12 minecraft:calcite
fill 459 -47 7 461 -44 7 minecraft:air
fill 459 -47 13 461 -44 13 minecraft:air
fill 460 -47 8 460 -47 12 minecraft:rail[shape=north_south]
fill 458 -47 10 458 -43 10 minecraft:polished_basalt[axis=y]
fill 462 -47 10 462 -43 10 minecraft:polished_basalt[axis=y]
setblock 460 -43 10 minecraft:soul_lantern[hanging=true]
setblock 459 -45 9 minecraft:wall_torch[facing=east]
setblock 461 -45 11 minecraft:wall_torch[facing=west]
