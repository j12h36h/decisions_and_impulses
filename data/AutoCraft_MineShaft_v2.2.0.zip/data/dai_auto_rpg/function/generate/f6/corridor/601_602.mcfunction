# Floor 6 connector 601 -> 602.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 446 -44 0 minecraft:air
setblock 454 -44 0 minecraft:air
fill 447 -48 -2 453 -42 2 minecraft:polished_deepslate hollow
fill 448 -47 -1 452 -43 1 minecraft:air
fill 448 -48 -1 452 -48 1 minecraft:calcite
fill 447 -47 -1 447 -44 1 minecraft:air
fill 453 -47 -1 453 -44 1 minecraft:air
fill 448 -47 0 452 -47 0 minecraft:rail[shape=east_west]
fill 450 -47 -2 450 -43 -2 minecraft:polished_basalt[axis=y]
fill 450 -47 2 450 -43 2 minecraft:polished_basalt[axis=y]
setblock 450 -43 0 minecraft:soul_lantern[hanging=true]
setblock 449 -45 -1 minecraft:wall_torch[facing=south]
setblock 451 -45 1 minecraft:wall_torch[facing=north]
