# Reset the reserved Floor 3 sector back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add 90 -30 150 10
kill @e[type=!minecraft:player,x=90,y=-50,z=-30,dx=60,dy=11,dz=40]
fill 90 -49 -30 150 -40 10 minecraft:deepslate
function dai_auto_rpg:generate/f3/room/301
forceload remove 90 -30 150 10
