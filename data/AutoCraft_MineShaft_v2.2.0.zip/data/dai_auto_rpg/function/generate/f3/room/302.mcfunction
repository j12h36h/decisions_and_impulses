# Floor 3 — Pump Station — generated room at center (100,-47,-20).
fill 93 -48 -27 107 -41 -13 minecraft:prismarine_bricks hollow
fill 94 -47 -26 106 -42 -14 minecraft:air
fill 94 -48 -26 106 -48 -14 minecraft:dark_prismarine
fill 95 -47 -25 95 -42 -25 minecraft:stripped_spruce_log[axis=y]
fill 105 -47 -25 105 -42 -25 minecraft:stripped_spruce_log[axis=y]
fill 95 -47 -15 95 -42 -15 minecraft:stripped_spruce_log[axis=y]
fill 105 -47 -15 105 -42 -15 minecraft:stripped_spruce_log[axis=y]
fill 95 -42 -25 105 -42 -25 minecraft:stripped_spruce_log[axis=x]
fill 95 -42 -15 105 -42 -15 minecraft:stripped_spruce_log[axis=x]
fill 95 -42 -25 95 -42 -15 minecraft:stripped_spruce_log[axis=z]
fill 105 -42 -25 105 -42 -15 minecraft:stripped_spruce_log[axis=z]
fill 100 -47 -24 100 -47 -16 minecraft:rail[shape=north_south]
setblock 94 -45 -22 minecraft:copper_ore
setblock 106 -44 -18 minecraft:lapis_ore
setblock 104 -47 -16 minecraft:barrel[facing=up]
setblock 100 -42 -20 minecraft:soul_lantern[hanging=true]
setblock 96 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 104 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 96 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 104 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 94 -44 -20 minecraft:wall_torch[facing=east]
setblock 106 -44 -20 minecraft:wall_torch[facing=west]
setblock 100 -44 -26 minecraft:wall_torch[facing=south]
setblock 100 -44 -14 minecraft:wall_torch[facing=north]
setblock 96 -47 -24 minecraft:water_cauldron[level=3]
setblock 104 -47 -16 minecraft:water_cauldron[level=3]
setblock 96 -47 -16 minecraft:wet_sponge
setblock 104 -47 -24 minecraft:prismarine
fill 98 -48 -21 102 -48 -19 minecraft:blue_ice
setblock 107 -47 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 107 -46 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
