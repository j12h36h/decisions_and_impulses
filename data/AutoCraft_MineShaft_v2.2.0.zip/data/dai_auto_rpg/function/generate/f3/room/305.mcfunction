# Floor 3 — Surveyor Cistern — generated room at center (140,-47,-20).
fill 133 -48 -27 147 -41 -13 minecraft:prismarine_bricks hollow
fill 134 -47 -26 146 -42 -14 minecraft:air
fill 134 -48 -26 146 -48 -14 minecraft:dark_prismarine
fill 135 -47 -25 135 -42 -25 minecraft:stripped_spruce_log[axis=y]
fill 145 -47 -25 145 -42 -25 minecraft:stripped_spruce_log[axis=y]
fill 135 -47 -15 135 -42 -15 minecraft:stripped_spruce_log[axis=y]
fill 145 -47 -15 145 -42 -15 minecraft:stripped_spruce_log[axis=y]
fill 135 -42 -25 145 -42 -25 minecraft:stripped_spruce_log[axis=x]
fill 135 -42 -15 145 -42 -15 minecraft:stripped_spruce_log[axis=x]
fill 135 -42 -25 135 -42 -15 minecraft:stripped_spruce_log[axis=z]
fill 145 -42 -25 145 -42 -15 minecraft:stripped_spruce_log[axis=z]
fill 136 -47 -20 144 -47 -20 minecraft:rail[shape=east_west]
setblock 134 -45 -22 minecraft:copper_ore
setblock 146 -44 -18 minecraft:lapis_ore
setblock 144 -47 -16 minecraft:barrel[facing=up]
setblock 140 -42 -20 minecraft:soul_lantern[hanging=true]
setblock 136 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 144 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 136 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 144 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 134 -44 -20 minecraft:wall_torch[facing=east]
setblock 146 -44 -20 minecraft:wall_torch[facing=west]
setblock 140 -44 -26 minecraft:wall_torch[facing=south]
setblock 140 -44 -14 minecraft:wall_torch[facing=north]
setblock 136 -47 -24 minecraft:water_cauldron[level=3]
setblock 144 -47 -16 minecraft:water_cauldron[level=3]
setblock 136 -47 -16 minecraft:wet_sponge
setblock 144 -47 -24 minecraft:prismarine
fill 137 -48 -23 143 -48 -17 minecraft:dark_prismarine
fill 137 -47 -23 143 -44 -17 minecraft:air
