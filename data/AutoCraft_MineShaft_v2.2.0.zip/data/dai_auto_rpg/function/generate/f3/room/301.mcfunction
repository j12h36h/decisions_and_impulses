# Floor 3 — Intake Gallery — generated room at center (100,-47,0).
fill 93 -48 -7 107 -41 7 minecraft:prismarine_bricks hollow
fill 94 -47 -6 106 -42 6 minecraft:air
fill 94 -48 -6 106 -48 6 minecraft:dark_prismarine
fill 95 -47 -5 95 -42 -5 minecraft:stripped_spruce_log[axis=y]
fill 105 -47 -5 105 -42 -5 minecraft:stripped_spruce_log[axis=y]
fill 95 -47 5 95 -42 5 minecraft:stripped_spruce_log[axis=y]
fill 105 -47 5 105 -42 5 minecraft:stripped_spruce_log[axis=y]
fill 95 -42 -5 105 -42 -5 minecraft:stripped_spruce_log[axis=x]
fill 95 -42 5 105 -42 5 minecraft:stripped_spruce_log[axis=x]
fill 95 -42 -5 95 -42 5 minecraft:stripped_spruce_log[axis=z]
fill 105 -42 -5 105 -42 5 minecraft:stripped_spruce_log[axis=z]
fill 96 -47 0 104 -47 0 minecraft:rail[shape=east_west]
setblock 94 -45 -2 minecraft:copper_ore
setblock 106 -44 2 minecraft:lapis_ore
setblock 104 -47 4 minecraft:barrel[facing=up]
setblock 100 -42 0 minecraft:soul_lantern[hanging=true]
setblock 96 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 104 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 96 -42 4 minecraft:soul_lantern[hanging=true]
setblock 104 -42 4 minecraft:soul_lantern[hanging=true]
setblock 94 -44 0 minecraft:wall_torch[facing=east]
setblock 106 -44 0 minecraft:wall_torch[facing=west]
setblock 100 -44 -6 minecraft:wall_torch[facing=south]
setblock 100 -44 6 minecraft:wall_torch[facing=north]
setblock 96 -47 -4 minecraft:water_cauldron[level=3]
setblock 104 -47 4 minecraft:water_cauldron[level=3]
setblock 96 -47 4 minecraft:wet_sponge
setblock 104 -47 -4 minecraft:prismarine
setblock 100 -47 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 100 -46 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 107 -47 0 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 107 -46 0 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
