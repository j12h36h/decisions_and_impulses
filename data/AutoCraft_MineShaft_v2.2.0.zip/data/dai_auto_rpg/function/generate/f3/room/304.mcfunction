# Floor 3 — Floodgate Junction — generated room at center (120,-47,-20).
fill 113 -48 -27 127 -41 -13 minecraft:prismarine_bricks hollow
fill 114 -47 -26 126 -42 -14 minecraft:air
fill 114 -48 -26 126 -48 -14 minecraft:dark_prismarine
fill 115 -47 -25 115 -42 -25 minecraft:stripped_spruce_log[axis=y]
fill 125 -47 -25 125 -42 -25 minecraft:stripped_spruce_log[axis=y]
fill 115 -47 -15 115 -42 -15 minecraft:stripped_spruce_log[axis=y]
fill 125 -47 -15 125 -42 -15 minecraft:stripped_spruce_log[axis=y]
fill 115 -42 -25 125 -42 -25 minecraft:stripped_spruce_log[axis=x]
fill 115 -42 -15 125 -42 -15 minecraft:stripped_spruce_log[axis=x]
fill 115 -42 -25 115 -42 -15 minecraft:stripped_spruce_log[axis=z]
fill 125 -42 -25 125 -42 -15 minecraft:stripped_spruce_log[axis=z]
fill 120 -47 -24 120 -47 -16 minecraft:rail[shape=north_south]
setblock 114 -45 -22 minecraft:copper_ore
setblock 126 -44 -18 minecraft:lapis_ore
setblock 124 -47 -16 minecraft:barrel[facing=up]
setblock 120 -42 -20 minecraft:soul_lantern[hanging=true]
setblock 116 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 124 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 116 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 124 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 114 -44 -20 minecraft:wall_torch[facing=east]
setblock 126 -44 -20 minecraft:wall_torch[facing=west]
setblock 120 -44 -26 minecraft:wall_torch[facing=south]
setblock 120 -44 -14 minecraft:wall_torch[facing=north]
setblock 116 -47 -24 minecraft:water_cauldron[level=3]
setblock 124 -47 -16 minecraft:water_cauldron[level=3]
setblock 116 -47 -16 minecraft:wet_sponge
setblock 124 -47 -24 minecraft:prismarine
fill 118 -48 -21 122 -48 -19 minecraft:blue_ice
setblock 127 -47 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 127 -46 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
