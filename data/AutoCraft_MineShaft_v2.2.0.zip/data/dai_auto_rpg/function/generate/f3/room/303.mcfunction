# Floor 3 — Drowned Worksite — generated room at center (120,-47,0).
fill 113 -48 -7 127 -41 7 minecraft:prismarine_bricks hollow
fill 114 -47 -6 126 -42 6 minecraft:air
fill 114 -48 -6 126 -48 6 minecraft:dark_prismarine
fill 115 -47 -5 115 -42 -5 minecraft:stripped_spruce_log[axis=y]
fill 125 -47 -5 125 -42 -5 minecraft:stripped_spruce_log[axis=y]
fill 115 -47 5 115 -42 5 minecraft:stripped_spruce_log[axis=y]
fill 125 -47 5 125 -42 5 minecraft:stripped_spruce_log[axis=y]
fill 115 -42 -5 125 -42 -5 minecraft:stripped_spruce_log[axis=x]
fill 115 -42 5 125 -42 5 minecraft:stripped_spruce_log[axis=x]
fill 115 -42 -5 115 -42 5 minecraft:stripped_spruce_log[axis=z]
fill 125 -42 -5 125 -42 5 minecraft:stripped_spruce_log[axis=z]
fill 116 -47 0 124 -47 0 minecraft:rail[shape=east_west]
setblock 114 -45 -2 minecraft:copper_ore
setblock 126 -44 2 minecraft:lapis_ore
setblock 124 -47 4 minecraft:barrel[facing=up]
setblock 120 -42 0 minecraft:soul_lantern[hanging=true]
setblock 116 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 124 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 116 -42 4 minecraft:soul_lantern[hanging=true]
setblock 124 -42 4 minecraft:soul_lantern[hanging=true]
setblock 114 -44 0 minecraft:wall_torch[facing=east]
setblock 126 -44 0 minecraft:wall_torch[facing=west]
setblock 120 -44 -6 minecraft:wall_torch[facing=south]
setblock 120 -44 6 minecraft:wall_torch[facing=north]
setblock 116 -47 -4 minecraft:water_cauldron[level=3]
setblock 124 -47 4 minecraft:water_cauldron[level=3]
setblock 116 -47 4 minecraft:wet_sponge
setblock 124 -47 -4 minecraft:prismarine
setblock 120 -47 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 120 -46 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
