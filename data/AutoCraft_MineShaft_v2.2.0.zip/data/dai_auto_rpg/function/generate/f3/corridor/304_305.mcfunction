# Floor 3 connector 304 -> 305.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 126 -44 -20 minecraft:air
setblock 134 -44 -20 minecraft:air
fill 127 -48 -22 133 -42 -18 minecraft:prismarine_bricks hollow
fill 128 -47 -21 132 -43 -19 minecraft:air
fill 128 -48 -21 132 -48 -19 minecraft:dark_prismarine
fill 127 -47 -21 127 -44 -19 minecraft:air
fill 133 -47 -21 133 -44 -19 minecraft:air
fill 128 -47 -20 132 -47 -20 minecraft:rail[shape=east_west]
fill 130 -47 -22 130 -43 -22 minecraft:stripped_spruce_log[axis=y]
fill 130 -47 -18 130 -43 -18 minecraft:stripped_spruce_log[axis=y]
setblock 130 -43 -20 minecraft:soul_lantern[hanging=true]
setblock 129 -45 -21 minecraft:wall_torch[facing=south]
setblock 131 -45 -19 minecraft:wall_torch[facing=north]
