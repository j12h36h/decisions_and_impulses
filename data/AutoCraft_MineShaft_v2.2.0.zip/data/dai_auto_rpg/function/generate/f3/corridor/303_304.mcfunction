# Floor 3 connector 303 -> 304.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 120 -44 -14 minecraft:air
setblock 120 -44 -6 minecraft:air
fill 118 -48 -13 122 -42 -7 minecraft:prismarine_bricks hollow
fill 119 -47 -12 121 -43 -8 minecraft:air
fill 119 -48 -12 121 -48 -8 minecraft:dark_prismarine
fill 119 -47 -13 121 -44 -13 minecraft:air
fill 119 -47 -7 121 -44 -7 minecraft:air
fill 120 -47 -12 120 -47 -8 minecraft:rail[shape=north_south]
fill 118 -47 -10 118 -43 -10 minecraft:stripped_spruce_log[axis=y]
fill 122 -47 -10 122 -43 -10 minecraft:stripped_spruce_log[axis=y]
setblock 120 -43 -10 minecraft:soul_lantern[hanging=true]
setblock 119 -45 -11 minecraft:wall_torch[facing=east]
setblock 121 -45 -9 minecraft:wall_torch[facing=west]
