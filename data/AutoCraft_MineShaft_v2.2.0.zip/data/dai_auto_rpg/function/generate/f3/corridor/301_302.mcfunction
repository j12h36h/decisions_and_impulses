# Floor 3 connector 301 -> 302.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 100 -44 -14 minecraft:air
setblock 100 -44 -6 minecraft:air
fill 98 -48 -13 102 -42 -7 minecraft:prismarine_bricks hollow
fill 99 -47 -12 101 -43 -8 minecraft:air
fill 99 -48 -12 101 -48 -8 minecraft:dark_prismarine
fill 99 -47 -13 101 -44 -13 minecraft:air
fill 99 -47 -7 101 -44 -7 minecraft:air
fill 100 -47 -12 100 -47 -8 minecraft:rail[shape=north_south]
fill 98 -47 -10 98 -43 -10 minecraft:stripped_spruce_log[axis=y]
fill 102 -47 -10 102 -43 -10 minecraft:stripped_spruce_log[axis=y]
setblock 100 -43 -10 minecraft:soul_lantern[hanging=true]
setblock 99 -45 -11 minecraft:wall_torch[facing=east]
setblock 101 -45 -9 minecraft:wall_torch[facing=west]
