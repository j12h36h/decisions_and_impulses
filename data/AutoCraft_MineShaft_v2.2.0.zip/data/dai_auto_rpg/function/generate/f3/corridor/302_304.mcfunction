# Floor 3 connector 302 -> 304.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 106 -44 -20 minecraft:air
setblock 114 -44 -20 minecraft:air
fill 107 -48 -22 113 -42 -18 minecraft:prismarine_bricks hollow
fill 108 -47 -21 112 -43 -19 minecraft:air
fill 108 -48 -21 112 -48 -19 minecraft:dark_prismarine
fill 107 -47 -21 107 -44 -19 minecraft:air
fill 113 -47 -21 113 -44 -19 minecraft:air
fill 108 -47 -20 112 -47 -20 minecraft:rail[shape=east_west]
fill 110 -47 -22 110 -43 -22 minecraft:stripped_spruce_log[axis=y]
fill 110 -47 -18 110 -43 -18 minecraft:stripped_spruce_log[axis=y]
setblock 110 -43 -20 minecraft:soul_lantern[hanging=true]
setblock 109 -45 -21 minecraft:wall_torch[facing=south]
setblock 111 -45 -19 minecraft:wall_torch[facing=north]
