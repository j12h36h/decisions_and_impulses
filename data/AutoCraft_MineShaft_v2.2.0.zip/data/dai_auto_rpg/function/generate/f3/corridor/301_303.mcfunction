# Floor 3 connector 301 -> 303.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 106 -44 0 minecraft:air
setblock 114 -44 0 minecraft:air
fill 107 -48 -2 113 -42 2 minecraft:prismarine_bricks hollow
fill 108 -47 -1 112 -43 1 minecraft:air
fill 108 -48 -1 112 -48 1 minecraft:dark_prismarine
fill 107 -47 -1 107 -44 1 minecraft:air
fill 113 -47 -1 113 -44 1 minecraft:air
fill 108 -47 0 112 -47 0 minecraft:rail[shape=east_west]
fill 110 -47 -2 110 -43 -2 minecraft:stripped_spruce_log[axis=y]
fill 110 -47 2 110 -43 2 minecraft:stripped_spruce_log[axis=y]
setblock 110 -43 0 minecraft:soul_lantern[hanging=true]
setblock 109 -45 -1 minecraft:wall_torch[facing=south]
setblock 111 -45 1 minecraft:wall_torch[facing=north]
