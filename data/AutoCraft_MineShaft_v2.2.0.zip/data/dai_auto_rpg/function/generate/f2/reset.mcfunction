
# Reset the reserved Floor 2 volume back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add -50 -10 10 30
kill @e[type=!minecraft:player,x=-50,y=-50,z=-10,dx=60,dy=11,dz=40]
fill -50 -49 -10 10 -40 30 minecraft:deepslate
function dai_auto_rpg:generate/f2/room/201
forceload remove -50 -10 10 30
