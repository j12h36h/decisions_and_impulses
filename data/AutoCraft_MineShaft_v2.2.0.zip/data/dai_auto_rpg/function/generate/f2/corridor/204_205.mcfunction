# Generated east/west connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock -34 -44 20 minecraft:air
setblock -26 -44 20 minecraft:air
fill -33 -48 18 -27 -42 22 minecraft:deepslate_tiles hollow
fill -32 -47 19 -28 -43 21 minecraft:air
fill -32 -48 19 -28 -48 21 minecraft:dark_oak_planks
fill -33 -47 19 -33 -44 21 minecraft:air
fill -27 -47 19 -27 -44 21 minecraft:air
fill -32 -47 20 -28 -47 20 minecraft:rail[shape=east_west]
fill -30 -47 18 -30 -43 18 minecraft:dark_oak_log[axis=y]
fill -30 -47 22 -30 -43 22 minecraft:dark_oak_log[axis=y]
setblock -30 -43 20 minecraft:lantern[hanging=true]
setblock -31 -45 19 minecraft:wall_torch[facing=south]
setblock -29 -45 21 minecraft:wall_torch[facing=north]
