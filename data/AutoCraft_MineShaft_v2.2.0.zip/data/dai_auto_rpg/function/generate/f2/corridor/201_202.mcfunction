# Generated east/west connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock -14 -44 0 minecraft:air
setblock -6 -44 0 minecraft:air
fill -13 -48 -2 -7 -42 2 minecraft:deepslate_tiles hollow
fill -12 -47 -1 -8 -43 1 minecraft:air
fill -12 -48 -1 -8 -48 1 minecraft:dark_oak_planks
fill -13 -47 -1 -13 -44 1 minecraft:air
fill -7 -47 -1 -7 -44 1 minecraft:air
fill -12 -47 0 -8 -47 0 minecraft:rail[shape=east_west]
fill -10 -47 -2 -10 -43 -2 minecraft:dark_oak_log[axis=y]
fill -10 -47 2 -10 -43 2 minecraft:dark_oak_log[axis=y]
setblock -10 -43 0 minecraft:lantern[hanging=true]
setblock -11 -45 -1 minecraft:wall_torch[facing=south]
setblock -9 -45 1 minecraft:wall_torch[facing=north]
