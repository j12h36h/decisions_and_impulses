# Generated north/south connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 0 -44 6 minecraft:air
setblock 0 -44 14 minecraft:air
fill -2 -48 7 2 -42 13 minecraft:deepslate_tiles hollow
fill -1 -47 8 1 -43 12 minecraft:air
fill -1 -48 8 1 -48 12 minecraft:dark_oak_planks
fill -1 -47 7 1 -44 7 minecraft:air
fill -1 -47 13 1 -44 13 minecraft:air
fill 0 -47 8 0 -47 12 minecraft:rail[shape=north_south]
fill -2 -47 10 -2 -43 10 minecraft:dark_oak_log[axis=y]
fill 2 -47 10 2 -43 10 minecraft:dark_oak_log[axis=y]
setblock 0 -43 10 minecraft:lantern[hanging=true]
setblock -1 -45 9 minecraft:wall_torch[facing=east]
setblock 1 -45 11 minecraft:wall_torch[facing=west]
