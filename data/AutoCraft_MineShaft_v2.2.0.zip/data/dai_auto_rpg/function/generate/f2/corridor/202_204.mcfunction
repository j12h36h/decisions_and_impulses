# Generated north/south connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock -20 -44 6 minecraft:air
setblock -20 -44 14 minecraft:air
fill -22 -48 7 -18 -42 13 minecraft:deepslate_tiles hollow
fill -21 -47 8 -19 -43 12 minecraft:air
fill -21 -48 8 -19 -48 12 minecraft:dark_oak_planks
fill -21 -47 7 -19 -44 7 minecraft:air
fill -21 -47 13 -19 -44 13 minecraft:air
fill -20 -47 8 -20 -47 12 minecraft:rail[shape=north_south]
fill -22 -47 10 -22 -43 10 minecraft:dark_oak_log[axis=y]
fill -18 -47 10 -18 -43 10 minecraft:dark_oak_log[axis=y]
setblock -20 -43 10 minecraft:lantern[hanging=true]
setblock -21 -45 9 minecraft:wall_torch[facing=east]
setblock -19 -45 11 minecraft:wall_torch[facing=west]
