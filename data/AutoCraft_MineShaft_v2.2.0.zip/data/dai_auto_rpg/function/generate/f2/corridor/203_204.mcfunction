# Generated east/west connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock -14 -44 20 minecraft:air
setblock -6 -44 20 minecraft:air
fill -13 -48 18 -7 -42 22 minecraft:deepslate_tiles hollow
fill -12 -47 19 -8 -43 21 minecraft:air
fill -12 -48 19 -8 -48 21 minecraft:dark_oak_planks
fill -13 -47 19 -13 -44 21 minecraft:air
fill -7 -47 19 -7 -44 21 minecraft:air
fill -12 -47 20 -8 -47 20 minecraft:rail[shape=east_west]
fill -10 -47 18 -10 -43 18 minecraft:dark_oak_log[axis=y]
fill -10 -47 22 -10 -43 22 minecraft:dark_oak_log[axis=y]
setblock -10 -43 20 minecraft:lantern[hanging=true]
setblock -11 -45 19 minecraft:wall_torch[facing=south]
setblock -9 -45 21 minecraft:wall_torch[facing=north]
