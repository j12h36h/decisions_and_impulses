# Floor 2 generated room at center (-20,-47,20).
fill -27 -48 13 -13 -41 27 minecraft:deepslate_tiles hollow
fill -26 -47 14 -14 -42 26 minecraft:air
fill -26 -48 14 -14 -48 26 minecraft:dark_oak_planks
fill -25 -47 15 -25 -42 15 minecraft:dark_oak_log[axis=y]
fill -15 -47 15 -15 -42 15 minecraft:dark_oak_log[axis=y]
fill -25 -47 25 -25 -42 25 minecraft:dark_oak_log[axis=y]
fill -15 -47 25 -15 -42 25 minecraft:dark_oak_log[axis=y]
fill -25 -42 15 -15 -42 15 minecraft:dark_oak_log[axis=x]
fill -25 -42 25 -15 -42 25 minecraft:dark_oak_log[axis=x]
fill -25 -42 15 -25 -42 25 minecraft:dark_oak_log[axis=z]
fill -15 -42 15 -15 -42 25 minecraft:dark_oak_log[axis=z]
fill -20 -47 16 -20 -47 24 minecraft:rail[shape=north_south]
setblock -26 -45 18 minecraft:deepslate_coal_ore
setblock -14 -44 22 minecraft:deepslate_iron_ore
setblock -16 -47 24 minecraft:barrel[facing=up]
setblock -20 -42 20 minecraft:lantern[hanging=true]
setblock -24 -42 16 minecraft:lantern[hanging=true]
setblock -16 -42 16 minecraft:lantern[hanging=true]
setblock -24 -42 24 minecraft:lantern[hanging=true]
setblock -16 -42 24 minecraft:lantern[hanging=true]
setblock -26 -44 20 minecraft:wall_torch[facing=east]
setblock -14 -44 20 minecraft:wall_torch[facing=west]
setblock -20 -44 14 minecraft:wall_torch[facing=south]
setblock -20 -44 26 minecraft:wall_torch[facing=north]
setblock -27 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock -27 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
