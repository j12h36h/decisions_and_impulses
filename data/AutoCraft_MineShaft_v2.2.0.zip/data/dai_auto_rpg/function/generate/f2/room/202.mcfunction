# Floor 2 generated room at center (-20,-47,0).
fill -27 -48 -7 -13 -41 7 minecraft:deepslate_tiles hollow
fill -26 -47 -6 -14 -42 6 minecraft:air
fill -26 -48 -6 -14 -48 6 minecraft:dark_oak_planks
fill -25 -47 -5 -25 -42 -5 minecraft:dark_oak_log[axis=y]
fill -15 -47 -5 -15 -42 -5 minecraft:dark_oak_log[axis=y]
fill -25 -47 5 -25 -42 5 minecraft:dark_oak_log[axis=y]
fill -15 -47 5 -15 -42 5 minecraft:dark_oak_log[axis=y]
fill -25 -42 -5 -15 -42 -5 minecraft:dark_oak_log[axis=x]
fill -25 -42 5 -15 -42 5 minecraft:dark_oak_log[axis=x]
fill -25 -42 -5 -25 -42 5 minecraft:dark_oak_log[axis=z]
fill -15 -42 -5 -15 -42 5 minecraft:dark_oak_log[axis=z]
fill -20 -47 -4 -20 -47 4 minecraft:rail[shape=north_south]
setblock -26 -45 -2 minecraft:deepslate_coal_ore
setblock -14 -44 2 minecraft:deepslate_iron_ore
setblock -16 -47 4 minecraft:barrel[facing=up]
setblock -20 -42 0 minecraft:lantern[hanging=true]
setblock -24 -42 -4 minecraft:lantern[hanging=true]
setblock -16 -42 -4 minecraft:lantern[hanging=true]
setblock -24 -42 4 minecraft:lantern[hanging=true]
setblock -16 -42 4 minecraft:lantern[hanging=true]
setblock -26 -44 0 minecraft:wall_torch[facing=east]
setblock -14 -44 0 minecraft:wall_torch[facing=west]
setblock -20 -44 -6 minecraft:wall_torch[facing=south]
setblock -20 -44 6 minecraft:wall_torch[facing=north]
setblock -20 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock -20 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
