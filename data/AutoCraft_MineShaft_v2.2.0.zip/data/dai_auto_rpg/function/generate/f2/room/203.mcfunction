# Floor 2 generated room at center (0,-47,20).
fill -7 -48 13 7 -41 27 minecraft:deepslate_tiles hollow
fill -6 -47 14 6 -42 26 minecraft:air
fill -6 -48 14 6 -48 26 minecraft:dark_oak_planks
fill -5 -47 15 -5 -42 15 minecraft:dark_oak_log[axis=y]
fill 5 -47 15 5 -42 15 minecraft:dark_oak_log[axis=y]
fill -5 -47 25 -5 -42 25 minecraft:dark_oak_log[axis=y]
fill 5 -47 25 5 -42 25 minecraft:dark_oak_log[axis=y]
fill -5 -42 15 5 -42 15 minecraft:dark_oak_log[axis=x]
fill -5 -42 25 5 -42 25 minecraft:dark_oak_log[axis=x]
fill -5 -42 15 -5 -42 25 minecraft:dark_oak_log[axis=z]
fill 5 -42 15 5 -42 25 minecraft:dark_oak_log[axis=z]
fill 0 -47 16 0 -47 24 minecraft:rail[shape=north_south]
setblock -6 -45 18 minecraft:deepslate_coal_ore
setblock 6 -44 22 minecraft:deepslate_iron_ore
setblock 4 -47 24 minecraft:barrel[facing=up]
setblock 0 -42 20 minecraft:lantern[hanging=true]
setblock -4 -42 16 minecraft:lantern[hanging=true]
setblock 4 -42 16 minecraft:lantern[hanging=true]
setblock -4 -42 24 minecraft:lantern[hanging=true]
setblock 4 -42 24 minecraft:lantern[hanging=true]
setblock -6 -44 20 minecraft:wall_torch[facing=east]
setblock 6 -44 20 minecraft:wall_torch[facing=west]
setblock 0 -44 14 minecraft:wall_torch[facing=south]
setblock 0 -44 26 minecraft:wall_torch[facing=north]
setblock -7 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock -7 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
