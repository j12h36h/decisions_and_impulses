# Floor 2 generated room at center (-40,-47,20).
fill -47 -48 13 -33 -41 27 minecraft:deepslate_tiles hollow
fill -46 -47 14 -34 -42 26 minecraft:air
fill -46 -48 14 -34 -48 26 minecraft:dark_oak_planks
fill -45 -47 15 -45 -42 15 minecraft:dark_oak_log[axis=y]
fill -35 -47 15 -35 -42 15 minecraft:dark_oak_log[axis=y]
fill -45 -47 25 -45 -42 25 minecraft:dark_oak_log[axis=y]
fill -35 -47 25 -35 -42 25 minecraft:dark_oak_log[axis=y]
fill -45 -42 15 -35 -42 15 minecraft:dark_oak_log[axis=x]
fill -45 -42 25 -35 -42 25 minecraft:dark_oak_log[axis=x]
fill -45 -42 15 -45 -42 25 minecraft:dark_oak_log[axis=z]
fill -35 -42 15 -35 -42 25 minecraft:dark_oak_log[axis=z]
fill -40 -47 16 -40 -47 24 minecraft:rail[shape=north_south]
setblock -46 -45 18 minecraft:deepslate_coal_ore
setblock -34 -44 22 minecraft:deepslate_iron_ore
setblock -36 -47 24 minecraft:barrel[facing=up]
setblock -40 -42 20 minecraft:lantern[hanging=true]
setblock -44 -42 16 minecraft:lantern[hanging=true]
setblock -36 -42 16 minecraft:lantern[hanging=true]
setblock -44 -42 24 minecraft:lantern[hanging=true]
setblock -36 -42 24 minecraft:lantern[hanging=true]
setblock -46 -44 20 minecraft:wall_torch[facing=east]
setblock -34 -44 20 minecraft:wall_torch[facing=west]
setblock -40 -44 14 minecraft:wall_torch[facing=south]
setblock -40 -44 26 minecraft:wall_torch[facing=north]
fill -45 -48 15 -35 -48 25 minecraft:dark_oak_planks
