# Floor 2 generated room at center (0,-47,0).
fill -7 -48 -7 7 -41 7 minecraft:deepslate_tiles hollow
fill -6 -47 -6 6 -42 6 minecraft:air
fill -6 -48 -6 6 -48 6 minecraft:dark_oak_planks
fill -5 -47 -5 -5 -42 -5 minecraft:dark_oak_log[axis=y]
fill 5 -47 -5 5 -42 -5 minecraft:dark_oak_log[axis=y]
fill -5 -47 5 -5 -42 5 minecraft:dark_oak_log[axis=y]
fill 5 -47 5 5 -42 5 minecraft:dark_oak_log[axis=y]
fill -5 -42 -5 5 -42 -5 minecraft:dark_oak_log[axis=x]
fill -5 -42 5 5 -42 5 minecraft:dark_oak_log[axis=x]
fill -5 -42 -5 -5 -42 5 minecraft:dark_oak_log[axis=z]
fill 5 -42 -5 5 -42 5 minecraft:dark_oak_log[axis=z]
fill 0 -47 -4 0 -47 4 minecraft:rail[shape=north_south]
setblock -6 -45 -2 minecraft:deepslate_coal_ore
setblock 6 -44 2 minecraft:deepslate_iron_ore
setblock 4 -47 4 minecraft:barrel[facing=up]
setblock 0 -42 0 minecraft:lantern[hanging=true]
setblock -4 -42 -4 minecraft:lantern[hanging=true]
setblock 4 -42 -4 minecraft:lantern[hanging=true]
setblock -4 -42 4 minecraft:lantern[hanging=true]
setblock 4 -42 4 minecraft:lantern[hanging=true]
setblock -6 -44 0 minecraft:wall_torch[facing=east]
setblock 6 -44 0 minecraft:wall_torch[facing=west]
setblock 0 -44 -6 minecraft:wall_torch[facing=south]
setblock 0 -44 6 minecraft:wall_torch[facing=north]
setblock -7 -47 0 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock -7 -46 0 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
setblock 0 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 0 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
