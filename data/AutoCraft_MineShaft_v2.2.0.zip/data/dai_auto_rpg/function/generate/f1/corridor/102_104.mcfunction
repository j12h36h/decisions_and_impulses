# Generated east/west connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 6 -28 -20 minecraft:air
setblock 14 -28 -20 minecraft:air
fill 7 -32 -22 13 -26 -18 minecraft:stone_bricks hollow
fill 8 -31 -21 12 -27 -19 minecraft:air
fill 8 -32 -21 12 -32 -19 minecraft:spruce_planks
fill 7 -31 -21 7 -28 -19 minecraft:air
fill 13 -31 -21 13 -28 -19 minecraft:air
fill 8 -31 -20 12 -31 -20 minecraft:rail[shape=east_west]
fill 10 -31 -22 10 -27 -22 minecraft:spruce_log[axis=y]
fill 10 -31 -18 10 -27 -18 minecraft:spruce_log[axis=y]
setblock 10 -27 -20 minecraft:lantern[hanging=true]
setblock 9 -29 -21 minecraft:wall_torch[facing=south]
setblock 11 -29 -19 minecraft:wall_torch[facing=north]
