# Generated east/west connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 6 -28 0 minecraft:air
setblock 14 -28 0 minecraft:air
fill 7 -32 -2 13 -26 2 minecraft:stone_bricks hollow
fill 8 -31 -1 12 -27 1 minecraft:air
fill 8 -32 -1 12 -32 1 minecraft:spruce_planks
fill 7 -31 -1 7 -28 1 minecraft:air
fill 13 -31 -1 13 -28 1 minecraft:air
fill 8 -31 0 12 -31 0 minecraft:rail[shape=east_west]
fill 10 -31 -2 10 -27 -2 minecraft:spruce_log[axis=y]
fill 10 -31 2 10 -27 2 minecraft:spruce_log[axis=y]
setblock 10 -27 0 minecraft:lantern[hanging=true]
setblock 9 -29 -1 minecraft:wall_torch[facing=south]
setblock 11 -29 1 minecraft:wall_torch[facing=north]
