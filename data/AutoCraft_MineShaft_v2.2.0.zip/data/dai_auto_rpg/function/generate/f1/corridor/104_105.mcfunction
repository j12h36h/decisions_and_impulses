# Generated east/west connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 26 -28 -20 minecraft:air
setblock 34 -28 -20 minecraft:air
fill 27 -32 -22 33 -26 -18 minecraft:stone_bricks hollow
fill 28 -31 -21 32 -27 -19 minecraft:air
fill 28 -32 -21 32 -32 -19 minecraft:spruce_planks
fill 27 -31 -21 27 -28 -19 minecraft:air
fill 33 -31 -21 33 -28 -19 minecraft:air
fill 28 -31 -20 32 -31 -20 minecraft:rail[shape=east_west]
fill 30 -31 -22 30 -27 -22 minecraft:spruce_log[axis=y]
fill 30 -31 -18 30 -27 -18 minecraft:spruce_log[axis=y]
setblock 30 -27 -20 minecraft:lantern[hanging=true]
setblock 29 -29 -21 minecraft:wall_torch[facing=south]
setblock 31 -29 -19 minecraft:wall_torch[facing=north]
