# Generated north/south connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 20 -28 -14 minecraft:air
setblock 20 -28 -6 minecraft:air
fill 18 -32 -13 22 -26 -7 minecraft:stone_bricks hollow
fill 19 -31 -12 21 -27 -8 minecraft:air
fill 19 -32 -12 21 -32 -8 minecraft:spruce_planks
fill 19 -31 -13 21 -28 -13 minecraft:air
fill 19 -31 -7 21 -28 -7 minecraft:air
fill 20 -31 -12 20 -31 -8 minecraft:rail[shape=north_south]
fill 18 -31 -10 18 -27 -10 minecraft:spruce_log[axis=y]
fill 22 -31 -10 22 -27 -10 minecraft:spruce_log[axis=y]
setblock 20 -27 -10 minecraft:lantern[hanging=true]
setblock 19 -29 -11 minecraft:wall_torch[facing=east]
setblock 21 -29 -9 minecraft:wall_torch[facing=west]
