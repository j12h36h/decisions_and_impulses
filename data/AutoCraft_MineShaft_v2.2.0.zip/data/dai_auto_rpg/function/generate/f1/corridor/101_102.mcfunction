# Generated north/south connector.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 0 -28 -14 minecraft:air
setblock 0 -28 -6 minecraft:air
fill -2 -32 -13 2 -26 -7 minecraft:stone_bricks hollow
fill -1 -31 -12 1 -27 -8 minecraft:air
fill -1 -32 -12 1 -32 -8 minecraft:spruce_planks
fill -1 -31 -13 1 -28 -13 minecraft:air
fill -1 -31 -7 1 -28 -7 minecraft:air
fill 0 -31 -12 0 -31 -8 minecraft:rail[shape=north_south]
fill -2 -31 -10 -2 -27 -10 minecraft:spruce_log[axis=y]
fill 2 -31 -10 2 -27 -10 minecraft:spruce_log[axis=y]
setblock 0 -27 -10 minecraft:lantern[hanging=true]
setblock -1 -29 -11 minecraft:wall_torch[facing=east]
setblock 1 -29 -9 minecraft:wall_torch[facing=west]
