# Floor 1 generated room at center (20,-31,-20).
fill 13 -32 -27 27 -25 -13 minecraft:stone_bricks hollow
fill 14 -31 -26 26 -26 -14 minecraft:air
fill 14 -32 -26 26 -32 -14 minecraft:spruce_planks
fill 15 -31 -25 15 -26 -25 minecraft:spruce_log[axis=y]
fill 25 -31 -25 25 -26 -25 minecraft:spruce_log[axis=y]
fill 15 -31 -15 15 -26 -15 minecraft:spruce_log[axis=y]
fill 25 -31 -15 25 -26 -15 minecraft:spruce_log[axis=y]
fill 15 -26 -25 25 -26 -25 minecraft:spruce_log[axis=x]
fill 15 -26 -15 25 -26 -15 minecraft:spruce_log[axis=x]
fill 15 -26 -25 15 -26 -15 minecraft:spruce_log[axis=z]
fill 25 -26 -25 25 -26 -15 minecraft:spruce_log[axis=z]
fill 16 -31 -20 24 -31 -20 minecraft:rail[shape=east_west]
setblock 14 -29 -22 minecraft:coal_ore
setblock 26 -28 -18 minecraft:iron_ore
setblock 24 -31 -16 minecraft:barrel[facing=up]
setblock 20 -26 -20 minecraft:lantern[hanging=true]
setblock 16 -26 -24 minecraft:lantern[hanging=true]
setblock 24 -26 -24 minecraft:lantern[hanging=true]
setblock 16 -26 -16 minecraft:lantern[hanging=true]
setblock 24 -26 -16 minecraft:lantern[hanging=true]
setblock 14 -28 -20 minecraft:wall_torch[facing=east]
setblock 26 -28 -20 minecraft:wall_torch[facing=west]
setblock 20 -28 -26 minecraft:wall_torch[facing=south]
setblock 20 -28 -14 minecraft:wall_torch[facing=north]
setblock 27 -31 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 27 -30 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
