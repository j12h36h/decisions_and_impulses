# Floor 1 generated room at center (0,-31,-20).
fill -7 -32 -27 7 -25 -13 minecraft:stone_bricks hollow
fill -6 -31 -26 6 -26 -14 minecraft:air
fill -6 -32 -26 6 -32 -14 minecraft:spruce_planks
fill -5 -31 -25 -5 -26 -25 minecraft:spruce_log[axis=y]
fill 5 -31 -25 5 -26 -25 minecraft:spruce_log[axis=y]
fill -5 -31 -15 -5 -26 -15 minecraft:spruce_log[axis=y]
fill 5 -31 -15 5 -26 -15 minecraft:spruce_log[axis=y]
fill -5 -26 -25 5 -26 -25 minecraft:spruce_log[axis=x]
fill -5 -26 -15 5 -26 -15 minecraft:spruce_log[axis=x]
fill -5 -26 -25 -5 -26 -15 minecraft:spruce_log[axis=z]
fill 5 -26 -25 5 -26 -15 minecraft:spruce_log[axis=z]
fill -4 -31 -20 4 -31 -20 minecraft:rail[shape=east_west]
setblock -6 -29 -22 minecraft:coal_ore
setblock 6 -28 -18 minecraft:iron_ore
setblock 4 -31 -16 minecraft:barrel[facing=up]
setblock 0 -26 -20 minecraft:lantern[hanging=true]
setblock -4 -26 -24 minecraft:lantern[hanging=true]
setblock 4 -26 -24 minecraft:lantern[hanging=true]
setblock -4 -26 -16 minecraft:lantern[hanging=true]
setblock 4 -26 -16 minecraft:lantern[hanging=true]
setblock -6 -28 -20 minecraft:wall_torch[facing=east]
setblock 6 -28 -20 minecraft:wall_torch[facing=west]
setblock 0 -28 -26 minecraft:wall_torch[facing=south]
setblock 0 -28 -14 minecraft:wall_torch[facing=north]
setblock 7 -31 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 7 -30 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
