# Floor 1 generated room at center (40,-31,-20).
fill 33 -32 -27 47 -25 -13 minecraft:stone_bricks hollow
fill 34 -31 -26 46 -26 -14 minecraft:air
fill 34 -32 -26 46 -32 -14 minecraft:spruce_planks
fill 35 -31 -25 35 -26 -25 minecraft:spruce_log[axis=y]
fill 45 -31 -25 45 -26 -25 minecraft:spruce_log[axis=y]
fill 35 -31 -15 35 -26 -15 minecraft:spruce_log[axis=y]
fill 45 -31 -15 45 -26 -15 minecraft:spruce_log[axis=y]
fill 35 -26 -25 45 -26 -25 minecraft:spruce_log[axis=x]
fill 35 -26 -15 45 -26 -15 minecraft:spruce_log[axis=x]
fill 35 -26 -25 35 -26 -15 minecraft:spruce_log[axis=z]
fill 45 -26 -25 45 -26 -15 minecraft:spruce_log[axis=z]
fill 36 -31 -20 44 -31 -20 minecraft:rail[shape=east_west]
setblock 34 -29 -22 minecraft:coal_ore
setblock 46 -28 -18 minecraft:iron_ore
setblock 44 -31 -16 minecraft:barrel[facing=up]
setblock 40 -26 -20 minecraft:lantern[hanging=true]
setblock 36 -26 -24 minecraft:lantern[hanging=true]
setblock 44 -26 -24 minecraft:lantern[hanging=true]
setblock 36 -26 -16 minecraft:lantern[hanging=true]
setblock 44 -26 -16 minecraft:lantern[hanging=true]
setblock 34 -28 -20 minecraft:wall_torch[facing=east]
setblock 46 -28 -20 minecraft:wall_torch[facing=west]
setblock 40 -28 -26 minecraft:wall_torch[facing=south]
setblock 40 -28 -14 minecraft:wall_torch[facing=north]
fill 35 -32 -25 45 -32 -15 minecraft:spruce_planks
