# Floor 1 generated room at center (20,-31,0).
fill 13 -32 -7 27 -25 7 minecraft:stone_bricks hollow
fill 14 -31 -6 26 -26 6 minecraft:air
fill 14 -32 -6 26 -32 6 minecraft:spruce_planks
fill 15 -31 -5 15 -26 -5 minecraft:spruce_log[axis=y]
fill 25 -31 -5 25 -26 -5 minecraft:spruce_log[axis=y]
fill 15 -31 5 15 -26 5 minecraft:spruce_log[axis=y]
fill 25 -31 5 25 -26 5 minecraft:spruce_log[axis=y]
fill 15 -26 -5 25 -26 -5 minecraft:spruce_log[axis=x]
fill 15 -26 5 25 -26 5 minecraft:spruce_log[axis=x]
fill 15 -26 -5 15 -26 5 minecraft:spruce_log[axis=z]
fill 25 -26 -5 25 -26 5 minecraft:spruce_log[axis=z]
fill 16 -31 0 24 -31 0 minecraft:rail[shape=east_west]
setblock 14 -29 -2 minecraft:coal_ore
setblock 26 -28 2 minecraft:iron_ore
setblock 24 -31 4 minecraft:barrel[facing=up]
setblock 20 -26 0 minecraft:lantern[hanging=true]
setblock 16 -26 -4 minecraft:lantern[hanging=true]
setblock 24 -26 -4 minecraft:lantern[hanging=true]
setblock 16 -26 4 minecraft:lantern[hanging=true]
setblock 24 -26 4 minecraft:lantern[hanging=true]
setblock 14 -28 0 minecraft:wall_torch[facing=east]
setblock 26 -28 0 minecraft:wall_torch[facing=west]
setblock 20 -28 -6 minecraft:wall_torch[facing=south]
setblock 20 -28 6 minecraft:wall_torch[facing=north]
setblock 20 -31 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 20 -30 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
