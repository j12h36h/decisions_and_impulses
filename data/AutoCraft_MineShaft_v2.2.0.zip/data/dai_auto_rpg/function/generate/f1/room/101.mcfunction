# Floor 1 generated room at center (0,-31,0).
fill -7 -32 -7 7 -25 7 minecraft:stone_bricks hollow
fill -6 -31 -6 6 -26 6 minecraft:air
fill -6 -32 -6 6 -32 6 minecraft:spruce_planks
fill -5 -31 -5 -5 -26 -5 minecraft:spruce_log[axis=y]
fill 5 -31 -5 5 -26 -5 minecraft:spruce_log[axis=y]
fill -5 -31 5 -5 -26 5 minecraft:spruce_log[axis=y]
fill 5 -31 5 5 -26 5 minecraft:spruce_log[axis=y]
fill -5 -26 -5 5 -26 -5 minecraft:spruce_log[axis=x]
fill -5 -26 5 5 -26 5 minecraft:spruce_log[axis=x]
fill -5 -26 -5 -5 -26 5 minecraft:spruce_log[axis=z]
fill 5 -26 -5 5 -26 5 minecraft:spruce_log[axis=z]
fill -4 -31 0 4 -31 0 minecraft:rail[shape=east_west]
setblock -6 -29 -2 minecraft:coal_ore
setblock 6 -28 2 minecraft:iron_ore
setblock 4 -31 4 minecraft:barrel[facing=up]
setblock 0 -26 0 minecraft:lantern[hanging=true]
setblock -4 -26 -4 minecraft:lantern[hanging=true]
setblock 4 -26 -4 minecraft:lantern[hanging=true]
setblock -4 -26 4 minecraft:lantern[hanging=true]
setblock 4 -26 4 minecraft:lantern[hanging=true]
setblock -6 -28 0 minecraft:wall_torch[facing=east]
setblock 6 -28 0 minecraft:wall_torch[facing=west]
setblock 0 -28 -6 minecraft:wall_torch[facing=south]
setblock 0 -28 6 minecraft:wall_torch[facing=north]
setblock 0 -31 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 0 -30 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 7 -31 0 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 7 -30 0 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
