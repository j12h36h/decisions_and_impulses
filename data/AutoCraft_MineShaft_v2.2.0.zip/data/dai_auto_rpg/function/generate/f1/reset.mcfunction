
# Reset the reserved Floor 1 volume back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add -10 -30 50 10
kill @e[type=!minecraft:player,x=-10,y=-34,z=-30,dx=60,dy=11,dz=40]
fill -10 -33 -30 50 -24 10 minecraft:deepslate
function dai_auto_rpg:generate/f1/room/101
forceload remove -10 -30 50 10
