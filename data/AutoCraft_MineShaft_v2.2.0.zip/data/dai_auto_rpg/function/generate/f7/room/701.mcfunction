# Floor 7 — Machine Intake — generated room at center (580,-47,0).
fill 573 -48 -7 587 -41 7 minecraft:deepslate_bricks hollow
fill 574 -47 -6 586 -42 6 minecraft:air
fill 574 -48 -6 586 -48 6 minecraft:exposed_copper
fill 575 -47 -5 575 -42 -5 minecraft:stripped_dark_oak_log[axis=y]
fill 585 -47 -5 585 -42 -5 minecraft:stripped_dark_oak_log[axis=y]
fill 575 -47 5 575 -42 5 minecraft:stripped_dark_oak_log[axis=y]
fill 585 -47 5 585 -42 5 minecraft:stripped_dark_oak_log[axis=y]
fill 575 -42 -5 585 -42 -5 minecraft:stripped_dark_oak_log[axis=x]
fill 575 -42 5 585 -42 5 minecraft:stripped_dark_oak_log[axis=x]
fill 575 -42 -5 575 -42 5 minecraft:stripped_dark_oak_log[axis=z]
fill 585 -42 -5 585 -42 5 minecraft:stripped_dark_oak_log[axis=z]
fill 576 -47 0 584 -47 0 minecraft:rail[shape=east_west]
setblock 574 -45 -2 minecraft:redstone_block
setblock 586 -44 2 minecraft:iron_block
setblock 584 -47 4 minecraft:barrel[facing=up]
setblock 580 -42 0 minecraft:lantern[hanging=true]
setblock 576 -42 -4 minecraft:lantern[hanging=true]
setblock 584 -42 -4 minecraft:lantern[hanging=true]
setblock 576 -42 4 minecraft:lantern[hanging=true]
setblock 584 -42 4 minecraft:lantern[hanging=true]
setblock 574 -44 0 minecraft:wall_torch[facing=east]
setblock 586 -44 0 minecraft:wall_torch[facing=west]
setblock 580 -44 -6 minecraft:wall_torch[facing=south]
setblock 580 -44 6 minecraft:wall_torch[facing=north]
setblock 576 -47 -4 minecraft:redstone_lamp
setblock 576 -48 -4 minecraft:redstone_block
setblock 584 -47 4 minecraft:observer[facing=up]
setblock 584 -47 -4 minecraft:piston[facing=up,extended=false]
setblock 580 -47 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 580 -46 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 587 -47 0 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 587 -46 0 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
