# Floor 7 — Assembly Deck — generated room at center (600,-47,0).
fill 593 -48 -7 607 -41 7 minecraft:deepslate_bricks hollow
fill 594 -47 -6 606 -42 6 minecraft:air
fill 594 -48 -6 606 -48 6 minecraft:exposed_copper
fill 595 -47 -5 595 -42 -5 minecraft:stripped_dark_oak_log[axis=y]
fill 605 -47 -5 605 -42 -5 minecraft:stripped_dark_oak_log[axis=y]
fill 595 -47 5 595 -42 5 minecraft:stripped_dark_oak_log[axis=y]
fill 605 -47 5 605 -42 5 minecraft:stripped_dark_oak_log[axis=y]
fill 595 -42 -5 605 -42 -5 minecraft:stripped_dark_oak_log[axis=x]
fill 595 -42 5 605 -42 5 minecraft:stripped_dark_oak_log[axis=x]
fill 595 -42 -5 595 -42 5 minecraft:stripped_dark_oak_log[axis=z]
fill 605 -42 -5 605 -42 5 minecraft:stripped_dark_oak_log[axis=z]
fill 596 -47 0 604 -47 0 minecraft:rail[shape=east_west]
setblock 594 -45 -2 minecraft:redstone_block
setblock 606 -44 2 minecraft:iron_block
setblock 604 -47 4 minecraft:barrel[facing=up]
setblock 600 -42 0 minecraft:lantern[hanging=true]
setblock 596 -42 -4 minecraft:lantern[hanging=true]
setblock 604 -42 -4 minecraft:lantern[hanging=true]
setblock 596 -42 4 minecraft:lantern[hanging=true]
setblock 604 -42 4 minecraft:lantern[hanging=true]
setblock 594 -44 0 minecraft:wall_torch[facing=east]
setblock 606 -44 0 minecraft:wall_torch[facing=west]
setblock 600 -44 -6 minecraft:wall_torch[facing=south]
setblock 600 -44 6 minecraft:wall_torch[facing=north]
setblock 596 -47 -4 minecraft:redstone_lamp
setblock 596 -48 -4 minecraft:redstone_block
setblock 604 -47 4 minecraft:observer[facing=up]
setblock 604 -47 -4 minecraft:piston[facing=up,extended=false]
setblock 600 -47 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 600 -46 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
