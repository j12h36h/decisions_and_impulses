# Floor 7 — Engineer Control — generated room at center (620,-47,-20).
fill 613 -48 -27 627 -41 -13 minecraft:deepslate_bricks hollow
fill 614 -47 -26 626 -42 -14 minecraft:air
fill 614 -48 -26 626 -48 -14 minecraft:exposed_copper
fill 615 -47 -25 615 -42 -25 minecraft:stripped_dark_oak_log[axis=y]
fill 625 -47 -25 625 -42 -25 minecraft:stripped_dark_oak_log[axis=y]
fill 615 -47 -15 615 -42 -15 minecraft:stripped_dark_oak_log[axis=y]
fill 625 -47 -15 625 -42 -15 minecraft:stripped_dark_oak_log[axis=y]
fill 615 -42 -25 625 -42 -25 minecraft:stripped_dark_oak_log[axis=x]
fill 615 -42 -15 625 -42 -15 minecraft:stripped_dark_oak_log[axis=x]
fill 615 -42 -25 615 -42 -15 minecraft:stripped_dark_oak_log[axis=z]
fill 625 -42 -25 625 -42 -15 minecraft:stripped_dark_oak_log[axis=z]
fill 616 -47 -20 624 -47 -20 minecraft:rail[shape=east_west]
setblock 614 -45 -22 minecraft:redstone_block
setblock 626 -44 -18 minecraft:iron_block
setblock 624 -47 -16 minecraft:barrel[facing=up]
setblock 620 -42 -20 minecraft:lantern[hanging=true]
setblock 616 -42 -24 minecraft:lantern[hanging=true]
setblock 624 -42 -24 minecraft:lantern[hanging=true]
setblock 616 -42 -16 minecraft:lantern[hanging=true]
setblock 624 -42 -16 minecraft:lantern[hanging=true]
setblock 614 -44 -20 minecraft:wall_torch[facing=east]
setblock 626 -44 -20 minecraft:wall_torch[facing=west]
setblock 620 -44 -26 minecraft:wall_torch[facing=south]
setblock 620 -44 -14 minecraft:wall_torch[facing=north]
setblock 616 -47 -24 minecraft:redstone_lamp
setblock 616 -48 -24 minecraft:redstone_block
setblock 624 -47 -16 minecraft:observer[facing=up]
setblock 624 -47 -24 minecraft:piston[facing=up,extended=false]
fill 617 -48 -23 623 -48 -17 minecraft:exposed_copper
fill 617 -47 -23 623 -44 -17 minecraft:air
