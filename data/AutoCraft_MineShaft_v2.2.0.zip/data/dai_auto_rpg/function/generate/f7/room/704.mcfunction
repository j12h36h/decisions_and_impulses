# Floor 7 — Control Junction — generated room at center (600,-47,-20).
fill 593 -48 -27 607 -41 -13 minecraft:deepslate_bricks hollow
fill 594 -47 -26 606 -42 -14 minecraft:air
fill 594 -48 -26 606 -48 -14 minecraft:exposed_copper
fill 595 -47 -25 595 -42 -25 minecraft:stripped_dark_oak_log[axis=y]
fill 605 -47 -25 605 -42 -25 minecraft:stripped_dark_oak_log[axis=y]
fill 595 -47 -15 595 -42 -15 minecraft:stripped_dark_oak_log[axis=y]
fill 605 -47 -15 605 -42 -15 minecraft:stripped_dark_oak_log[axis=y]
fill 595 -42 -25 605 -42 -25 minecraft:stripped_dark_oak_log[axis=x]
fill 595 -42 -15 605 -42 -15 minecraft:stripped_dark_oak_log[axis=x]
fill 595 -42 -25 595 -42 -15 minecraft:stripped_dark_oak_log[axis=z]
fill 605 -42 -25 605 -42 -15 minecraft:stripped_dark_oak_log[axis=z]
fill 600 -47 -24 600 -47 -16 minecraft:rail[shape=north_south]
setblock 594 -45 -22 minecraft:redstone_block
setblock 606 -44 -18 minecraft:iron_block
setblock 604 -47 -16 minecraft:barrel[facing=up]
setblock 600 -42 -20 minecraft:lantern[hanging=true]
setblock 596 -42 -24 minecraft:lantern[hanging=true]
setblock 604 -42 -24 minecraft:lantern[hanging=true]
setblock 596 -42 -16 minecraft:lantern[hanging=true]
setblock 604 -42 -16 minecraft:lantern[hanging=true]
setblock 594 -44 -20 minecraft:wall_torch[facing=east]
setblock 606 -44 -20 minecraft:wall_torch[facing=west]
setblock 600 -44 -26 minecraft:wall_torch[facing=south]
setblock 600 -44 -14 minecraft:wall_torch[facing=north]
setblock 596 -47 -24 minecraft:redstone_lamp
setblock 596 -48 -24 minecraft:redstone_block
setblock 604 -47 -16 minecraft:observer[facing=up]
setblock 604 -47 -24 minecraft:piston[facing=up,extended=false]
fill 598 -48 -20 602 -48 -20 minecraft:powered_rail[shape=east_west,powered=true]
setblock 607 -47 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 607 -46 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
