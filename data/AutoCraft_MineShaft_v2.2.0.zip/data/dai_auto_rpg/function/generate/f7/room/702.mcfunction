# Floor 7 — Relay Hall — generated room at center (580,-47,-20).
fill 573 -48 -27 587 -41 -13 minecraft:deepslate_bricks hollow
fill 574 -47 -26 586 -42 -14 minecraft:air
fill 574 -48 -26 586 -48 -14 minecraft:exposed_copper
fill 575 -47 -25 575 -42 -25 minecraft:stripped_dark_oak_log[axis=y]
fill 585 -47 -25 585 -42 -25 minecraft:stripped_dark_oak_log[axis=y]
fill 575 -47 -15 575 -42 -15 minecraft:stripped_dark_oak_log[axis=y]
fill 585 -47 -15 585 -42 -15 minecraft:stripped_dark_oak_log[axis=y]
fill 575 -42 -25 585 -42 -25 minecraft:stripped_dark_oak_log[axis=x]
fill 575 -42 -15 585 -42 -15 minecraft:stripped_dark_oak_log[axis=x]
fill 575 -42 -25 575 -42 -15 minecraft:stripped_dark_oak_log[axis=z]
fill 585 -42 -25 585 -42 -15 minecraft:stripped_dark_oak_log[axis=z]
fill 580 -47 -24 580 -47 -16 minecraft:rail[shape=north_south]
setblock 574 -45 -22 minecraft:redstone_block
setblock 586 -44 -18 minecraft:iron_block
setblock 584 -47 -16 minecraft:barrel[facing=up]
setblock 580 -42 -20 minecraft:lantern[hanging=true]
setblock 576 -42 -24 minecraft:lantern[hanging=true]
setblock 584 -42 -24 minecraft:lantern[hanging=true]
setblock 576 -42 -16 minecraft:lantern[hanging=true]
setblock 584 -42 -16 minecraft:lantern[hanging=true]
setblock 574 -44 -20 minecraft:wall_torch[facing=east]
setblock 586 -44 -20 minecraft:wall_torch[facing=west]
setblock 580 -44 -26 minecraft:wall_torch[facing=south]
setblock 580 -44 -14 minecraft:wall_torch[facing=north]
setblock 576 -47 -24 minecraft:redstone_lamp
setblock 576 -48 -24 minecraft:redstone_block
setblock 584 -47 -16 minecraft:observer[facing=up]
setblock 584 -47 -24 minecraft:piston[facing=up,extended=false]
fill 578 -48 -20 582 -48 -20 minecraft:powered_rail[shape=east_west,powered=true]
setblock 587 -47 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 587 -46 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
