# Reset the reserved Floor 7 sector back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add 570 -30 630 10
kill @e[type=!minecraft:player,x=570,y=-50,z=-30,dx=60,dy=11,dz=40]
fill 570 -49 -30 630 -40 10 minecraft:deepslate
function dai_auto_rpg:generate/f7/room/701
forceload remove 570 -30 630 10
