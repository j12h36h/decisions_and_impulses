# Floor 7 connector 704 -> 705.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 606 -44 -20 minecraft:air
setblock 614 -44 -20 minecraft:air
fill 607 -48 -22 613 -42 -18 minecraft:deepslate_bricks hollow
fill 608 -47 -21 612 -43 -19 minecraft:air
fill 608 -48 -21 612 -48 -19 minecraft:exposed_copper
fill 607 -47 -21 607 -44 -19 minecraft:air
fill 613 -47 -21 613 -44 -19 minecraft:air
fill 608 -47 -20 612 -47 -20 minecraft:rail[shape=east_west]
fill 610 -47 -22 610 -43 -22 minecraft:stripped_dark_oak_log[axis=y]
fill 610 -47 -18 610 -43 -18 minecraft:stripped_dark_oak_log[axis=y]
setblock 610 -43 -20 minecraft:lantern[hanging=true]
setblock 609 -45 -21 minecraft:wall_torch[facing=south]
setblock 611 -45 -19 minecraft:wall_torch[facing=north]
