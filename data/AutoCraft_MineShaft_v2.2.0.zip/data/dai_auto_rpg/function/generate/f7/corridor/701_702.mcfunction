# Floor 7 connector 701 -> 702.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 580 -44 -14 minecraft:air
setblock 580 -44 -6 minecraft:air
fill 578 -48 -13 582 -42 -7 minecraft:deepslate_bricks hollow
fill 579 -47 -12 581 -43 -8 minecraft:air
fill 579 -48 -12 581 -48 -8 minecraft:exposed_copper
fill 579 -47 -13 581 -44 -13 minecraft:air
fill 579 -47 -7 581 -44 -7 minecraft:air
fill 580 -47 -12 580 -47 -8 minecraft:rail[shape=north_south]
fill 578 -47 -10 578 -43 -10 minecraft:stripped_dark_oak_log[axis=y]
fill 582 -47 -10 582 -43 -10 minecraft:stripped_dark_oak_log[axis=y]
setblock 580 -43 -10 minecraft:lantern[hanging=true]
setblock 579 -45 -11 minecraft:wall_torch[facing=east]
setblock 581 -45 -9 minecraft:wall_torch[facing=west]
