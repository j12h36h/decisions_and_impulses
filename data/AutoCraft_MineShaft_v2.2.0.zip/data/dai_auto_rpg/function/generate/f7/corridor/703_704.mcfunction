# Floor 7 connector 703 -> 704.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 600 -44 -14 minecraft:air
setblock 600 -44 -6 minecraft:air
fill 598 -48 -13 602 -42 -7 minecraft:deepslate_bricks hollow
fill 599 -47 -12 601 -43 -8 minecraft:air
fill 599 -48 -12 601 -48 -8 minecraft:exposed_copper
fill 599 -47 -13 601 -44 -13 minecraft:air
fill 599 -47 -7 601 -44 -7 minecraft:air
fill 600 -47 -12 600 -47 -8 minecraft:rail[shape=north_south]
fill 598 -47 -10 598 -43 -10 minecraft:stripped_dark_oak_log[axis=y]
fill 602 -47 -10 602 -43 -10 minecraft:stripped_dark_oak_log[axis=y]
setblock 600 -43 -10 minecraft:lantern[hanging=true]
setblock 599 -45 -11 minecraft:wall_torch[facing=east]
setblock 601 -45 -9 minecraft:wall_torch[facing=west]
