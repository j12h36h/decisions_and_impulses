# Floor 7 connector 701 -> 703.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 586 -44 0 minecraft:air
setblock 594 -44 0 minecraft:air
fill 587 -48 -2 593 -42 2 minecraft:deepslate_bricks hollow
fill 588 -47 -1 592 -43 1 minecraft:air
fill 588 -48 -1 592 -48 1 minecraft:exposed_copper
fill 587 -47 -1 587 -44 1 minecraft:air
fill 593 -47 -1 593 -44 1 minecraft:air
fill 588 -47 0 592 -47 0 minecraft:rail[shape=east_west]
fill 590 -47 -2 590 -43 -2 minecraft:stripped_dark_oak_log[axis=y]
fill 590 -47 2 590 -43 2 minecraft:stripped_dark_oak_log[axis=y]
setblock 590 -43 0 minecraft:lantern[hanging=true]
setblock 589 -45 -1 minecraft:wall_torch[facing=south]
setblock 591 -45 1 minecraft:wall_torch[facing=north]
