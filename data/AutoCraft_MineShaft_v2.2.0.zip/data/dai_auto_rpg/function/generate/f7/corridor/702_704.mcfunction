# Floor 7 connector 702 -> 704.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 586 -44 -20 minecraft:air
setblock 594 -44 -20 minecraft:air
fill 587 -48 -22 593 -42 -18 minecraft:deepslate_bricks hollow
fill 588 -47 -21 592 -43 -19 minecraft:air
fill 588 -48 -21 592 -48 -19 minecraft:exposed_copper
fill 587 -47 -21 587 -44 -19 minecraft:air
fill 593 -47 -21 593 -44 -19 minecraft:air
fill 588 -47 -20 592 -47 -20 minecraft:rail[shape=east_west]
fill 590 -47 -22 590 -43 -22 minecraft:stripped_dark_oak_log[axis=y]
fill 590 -47 -18 590 -43 -18 minecraft:stripped_dark_oak_log[axis=y]
setblock 590 -43 -20 minecraft:lantern[hanging=true]
setblock 589 -45 -21 minecraft:wall_torch[facing=south]
setblock 591 -45 -19 minecraft:wall_torch[facing=north]
