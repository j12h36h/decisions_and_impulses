# Reset the reserved Floor 9 sector back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add 810 -30 870 10
kill @e[type=!minecraft:player,x=810,y=-50,z=-30,dx=60,dy=11,dz=40]
fill 810 -49 -30 870 -40 10 minecraft:deepslate
function dai_auto_rpg:generate/f9/room/901
forceload remove 810 -30 870 10
