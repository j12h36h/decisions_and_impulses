# Floor 9 connector 904 -> 905.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 846 -44 -20 minecraft:air
setblock 854 -44 -20 minecraft:air
fill 847 -48 -22 853 -42 -18 minecraft:deepslate_tiles hollow
fill 848 -47 -21 852 -43 -19 minecraft:air
fill 848 -48 -21 852 -48 -19 minecraft:polished_deepslate
fill 847 -47 -21 847 -44 -19 minecraft:air
fill 853 -47 -21 853 -44 -19 minecraft:air
fill 848 -47 -20 852 -47 -20 minecraft:rail[shape=east_west]
fill 850 -47 -22 850 -43 -22 minecraft:stripped_warped_stem[axis=y]
fill 850 -47 -18 850 -43 -18 minecraft:stripped_warped_stem[axis=y]
setblock 850 -43 -20 minecraft:soul_lantern[hanging=true]
setblock 849 -45 -21 minecraft:wall_torch[facing=south]
setblock 851 -45 -19 minecraft:wall_torch[facing=north]
