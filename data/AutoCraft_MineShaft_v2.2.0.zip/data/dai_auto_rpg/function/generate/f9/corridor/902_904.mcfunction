# Floor 9 connector 902 -> 904.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 826 -44 -20 minecraft:air
setblock 834 -44 -20 minecraft:air
fill 827 -48 -22 833 -42 -18 minecraft:deepslate_tiles hollow
fill 828 -47 -21 832 -43 -19 minecraft:air
fill 828 -48 -21 832 -48 -19 minecraft:polished_deepslate
fill 827 -47 -21 827 -44 -19 minecraft:air
fill 833 -47 -21 833 -44 -19 minecraft:air
fill 828 -47 -20 832 -47 -20 minecraft:rail[shape=east_west]
fill 830 -47 -22 830 -43 -22 minecraft:stripped_warped_stem[axis=y]
fill 830 -47 -18 830 -43 -18 minecraft:stripped_warped_stem[axis=y]
setblock 830 -43 -20 minecraft:soul_lantern[hanging=true]
setblock 829 -45 -21 minecraft:wall_torch[facing=south]
setblock 831 -45 -19 minecraft:wall_torch[facing=north]
