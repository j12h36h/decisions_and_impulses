# Floor 9 connector 901 -> 902.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 820 -44 -14 minecraft:air
setblock 820 -44 -6 minecraft:air
fill 818 -48 -13 822 -42 -7 minecraft:deepslate_tiles hollow
fill 819 -47 -12 821 -43 -8 minecraft:air
fill 819 -48 -12 821 -48 -8 minecraft:polished_deepslate
fill 819 -47 -13 821 -44 -13 minecraft:air
fill 819 -47 -7 821 -44 -7 minecraft:air
fill 820 -47 -12 820 -47 -8 minecraft:rail[shape=north_south]
fill 818 -47 -10 818 -43 -10 minecraft:stripped_warped_stem[axis=y]
fill 822 -47 -10 822 -43 -10 minecraft:stripped_warped_stem[axis=y]
setblock 820 -43 -10 minecraft:soul_lantern[hanging=true]
setblock 819 -45 -11 minecraft:wall_torch[facing=east]
setblock 821 -45 -9 minecraft:wall_torch[facing=west]
