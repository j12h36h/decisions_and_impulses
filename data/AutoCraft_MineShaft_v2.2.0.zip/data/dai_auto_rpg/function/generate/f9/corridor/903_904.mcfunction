# Floor 9 connector 903 -> 904.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 840 -44 -14 minecraft:air
setblock 840 -44 -6 minecraft:air
fill 838 -48 -13 842 -42 -7 minecraft:deepslate_tiles hollow
fill 839 -47 -12 841 -43 -8 minecraft:air
fill 839 -48 -12 841 -48 -8 minecraft:polished_deepslate
fill 839 -47 -13 841 -44 -13 minecraft:air
fill 839 -47 -7 841 -44 -7 minecraft:air
fill 840 -47 -12 840 -47 -8 minecraft:rail[shape=north_south]
fill 838 -47 -10 838 -43 -10 minecraft:stripped_warped_stem[axis=y]
fill 842 -47 -10 842 -43 -10 minecraft:stripped_warped_stem[axis=y]
setblock 840 -43 -10 minecraft:soul_lantern[hanging=true]
setblock 839 -45 -11 minecraft:wall_torch[facing=east]
setblock 841 -45 -9 minecraft:wall_torch[facing=west]
