# Floor 9 connector 901 -> 903.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 826 -44 0 minecraft:air
setblock 834 -44 0 minecraft:air
fill 827 -48 -2 833 -42 2 minecraft:deepslate_tiles hollow
fill 828 -47 -1 832 -43 1 minecraft:air
fill 828 -48 -1 832 -48 1 minecraft:polished_deepslate
fill 827 -47 -1 827 -44 1 minecraft:air
fill 833 -47 -1 833 -44 1 minecraft:air
fill 828 -47 0 832 -47 0 minecraft:rail[shape=east_west]
fill 830 -47 -2 830 -43 -2 minecraft:stripped_warped_stem[axis=y]
fill 830 -47 2 830 -43 2 minecraft:stripped_warped_stem[axis=y]
setblock 830 -43 0 minecraft:soul_lantern[hanging=true]
setblock 829 -45 -1 minecraft:wall_torch[facing=south]
setblock 831 -45 1 minecraft:wall_torch[facing=north]
