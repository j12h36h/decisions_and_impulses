# Floor 9 — Sculk Crossing — generated room at center (840,-47,0).
fill 833 -48 -7 847 -41 7 minecraft:deepslate_tiles hollow
fill 834 -47 -6 846 -42 6 minecraft:air
fill 834 -48 -6 846 -48 6 minecraft:polished_deepslate
fill 835 -47 -5 835 -42 -5 minecraft:stripped_warped_stem[axis=y]
fill 845 -47 -5 845 -42 -5 minecraft:stripped_warped_stem[axis=y]
fill 835 -47 5 835 -42 5 minecraft:stripped_warped_stem[axis=y]
fill 845 -47 5 845 -42 5 minecraft:stripped_warped_stem[axis=y]
fill 835 -42 -5 845 -42 -5 minecraft:stripped_warped_stem[axis=x]
fill 835 -42 5 845 -42 5 minecraft:stripped_warped_stem[axis=x]
fill 835 -42 -5 835 -42 5 minecraft:stripped_warped_stem[axis=z]
fill 845 -42 -5 845 -42 5 minecraft:stripped_warped_stem[axis=z]
fill 836 -47 0 844 -47 0 minecraft:rail[shape=east_west]
setblock 834 -45 -2 minecraft:sculk
setblock 846 -44 2 minecraft:sculk_catalyst
setblock 844 -47 4 minecraft:barrel[facing=up]
setblock 840 -42 0 minecraft:soul_lantern[hanging=true]
setblock 836 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 844 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 836 -42 4 minecraft:soul_lantern[hanging=true]
setblock 844 -42 4 minecraft:soul_lantern[hanging=true]
setblock 834 -44 0 minecraft:wall_torch[facing=east]
setblock 846 -44 0 minecraft:wall_torch[facing=west]
setblock 840 -44 -6 minecraft:wall_torch[facing=south]
setblock 840 -44 6 minecraft:wall_torch[facing=north]
setblock 836 -48 -4 minecraft:sculk
setblock 844 -48 4 minecraft:sculk
setblock 836 -48 4 minecraft:sculk_sensor
setblock 844 -48 -4 minecraft:sculk_catalyst
fill 838 -48 -2 842 -48 2 minecraft:sculk replace minecraft:polished_deepslate
setblock 840 -47 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 840 -46 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
