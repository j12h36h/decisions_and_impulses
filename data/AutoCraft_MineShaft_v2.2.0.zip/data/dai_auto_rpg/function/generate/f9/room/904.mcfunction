# Floor 9 — Forgotten Junction — generated room at center (840,-47,-20).
fill 833 -48 -27 847 -41 -13 minecraft:deepslate_tiles hollow
fill 834 -47 -26 846 -42 -14 minecraft:air
fill 834 -48 -26 846 -48 -14 minecraft:polished_deepslate
fill 835 -47 -25 835 -42 -25 minecraft:stripped_warped_stem[axis=y]
fill 845 -47 -25 845 -42 -25 minecraft:stripped_warped_stem[axis=y]
fill 835 -47 -15 835 -42 -15 minecraft:stripped_warped_stem[axis=y]
fill 845 -47 -15 845 -42 -15 minecraft:stripped_warped_stem[axis=y]
fill 835 -42 -25 845 -42 -25 minecraft:stripped_warped_stem[axis=x]
fill 835 -42 -15 845 -42 -15 minecraft:stripped_warped_stem[axis=x]
fill 835 -42 -25 835 -42 -15 minecraft:stripped_warped_stem[axis=z]
fill 845 -42 -25 845 -42 -15 minecraft:stripped_warped_stem[axis=z]
fill 840 -47 -24 840 -47 -16 minecraft:rail[shape=north_south]
setblock 834 -45 -22 minecraft:sculk
setblock 846 -44 -18 minecraft:sculk_catalyst
setblock 844 -47 -16 minecraft:barrel[facing=up]
setblock 840 -42 -20 minecraft:soul_lantern[hanging=true]
setblock 836 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 844 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 836 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 844 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 834 -44 -20 minecraft:wall_torch[facing=east]
setblock 846 -44 -20 minecraft:wall_torch[facing=west]
setblock 840 -44 -26 minecraft:wall_torch[facing=south]
setblock 840 -44 -14 minecraft:wall_torch[facing=north]
setblock 836 -48 -24 minecraft:sculk
setblock 844 -48 -16 minecraft:sculk
setblock 836 -48 -16 minecraft:sculk_sensor
setblock 844 -48 -24 minecraft:sculk_catalyst
fill 838 -48 -22 842 -48 -18 minecraft:sculk replace minecraft:polished_deepslate
setblock 847 -47 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 847 -46 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
