# Floor 9 — Silent Archive — generated room at center (820,-47,-20).
fill 813 -48 -27 827 -41 -13 minecraft:deepslate_tiles hollow
fill 814 -47 -26 826 -42 -14 minecraft:air
fill 814 -48 -26 826 -48 -14 minecraft:polished_deepslate
fill 815 -47 -25 815 -42 -25 minecraft:stripped_warped_stem[axis=y]
fill 825 -47 -25 825 -42 -25 minecraft:stripped_warped_stem[axis=y]
fill 815 -47 -15 815 -42 -15 minecraft:stripped_warped_stem[axis=y]
fill 825 -47 -15 825 -42 -15 minecraft:stripped_warped_stem[axis=y]
fill 815 -42 -25 825 -42 -25 minecraft:stripped_warped_stem[axis=x]
fill 815 -42 -15 825 -42 -15 minecraft:stripped_warped_stem[axis=x]
fill 815 -42 -25 815 -42 -15 minecraft:stripped_warped_stem[axis=z]
fill 825 -42 -25 825 -42 -15 minecraft:stripped_warped_stem[axis=z]
fill 820 -47 -24 820 -47 -16 minecraft:rail[shape=north_south]
setblock 814 -45 -22 minecraft:sculk
setblock 826 -44 -18 minecraft:sculk_catalyst
setblock 824 -47 -16 minecraft:barrel[facing=up]
setblock 820 -42 -20 minecraft:soul_lantern[hanging=true]
setblock 816 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 824 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 816 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 824 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 814 -44 -20 minecraft:wall_torch[facing=east]
setblock 826 -44 -20 minecraft:wall_torch[facing=west]
setblock 820 -44 -26 minecraft:wall_torch[facing=south]
setblock 820 -44 -14 minecraft:wall_torch[facing=north]
setblock 816 -48 -24 minecraft:sculk
setblock 824 -48 -16 minecraft:sculk
setblock 816 -48 -16 minecraft:sculk_sensor
setblock 824 -48 -24 minecraft:sculk_catalyst
setblock 827 -47 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 827 -46 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
