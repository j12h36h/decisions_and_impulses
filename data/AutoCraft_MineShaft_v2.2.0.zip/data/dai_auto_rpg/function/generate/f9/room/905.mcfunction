# Floor 9 — Surveyor Sanctum — generated room at center (860,-47,-20).
fill 853 -48 -27 867 -41 -13 minecraft:deepslate_tiles hollow
fill 854 -47 -26 866 -42 -14 minecraft:air
fill 854 -48 -26 866 -48 -14 minecraft:polished_deepslate
fill 855 -47 -25 855 -42 -25 minecraft:stripped_warped_stem[axis=y]
fill 865 -47 -25 865 -42 -25 minecraft:stripped_warped_stem[axis=y]
fill 855 -47 -15 855 -42 -15 minecraft:stripped_warped_stem[axis=y]
fill 865 -47 -15 865 -42 -15 minecraft:stripped_warped_stem[axis=y]
fill 855 -42 -25 865 -42 -25 minecraft:stripped_warped_stem[axis=x]
fill 855 -42 -15 865 -42 -15 minecraft:stripped_warped_stem[axis=x]
fill 855 -42 -25 855 -42 -15 minecraft:stripped_warped_stem[axis=z]
fill 865 -42 -25 865 -42 -15 minecraft:stripped_warped_stem[axis=z]
fill 856 -47 -20 864 -47 -20 minecraft:rail[shape=east_west]
setblock 854 -45 -22 minecraft:sculk
setblock 866 -44 -18 minecraft:sculk_catalyst
setblock 864 -47 -16 minecraft:barrel[facing=up]
setblock 860 -42 -20 minecraft:soul_lantern[hanging=true]
setblock 856 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 864 -42 -24 minecraft:soul_lantern[hanging=true]
setblock 856 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 864 -42 -16 minecraft:soul_lantern[hanging=true]
setblock 854 -44 -20 minecraft:wall_torch[facing=east]
setblock 866 -44 -20 minecraft:wall_torch[facing=west]
setblock 860 -44 -26 minecraft:wall_torch[facing=south]
setblock 860 -44 -14 minecraft:wall_torch[facing=north]
setblock 856 -48 -24 minecraft:sculk
setblock 864 -48 -16 minecraft:sculk
setblock 856 -48 -16 minecraft:sculk_sensor
setblock 864 -48 -24 minecraft:sculk_catalyst
fill 858 -48 -22 862 -48 -18 minecraft:sculk replace minecraft:polished_deepslate
fill 857 -48 -23 863 -48 -17 minecraft:polished_deepslate
fill 857 -47 -23 863 -44 -17 minecraft:air
