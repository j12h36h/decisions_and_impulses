# Floor 9 — Ancient Threshold — generated room at center (820,-47,0).
fill 813 -48 -7 827 -41 7 minecraft:deepslate_tiles hollow
fill 814 -47 -6 826 -42 6 minecraft:air
fill 814 -48 -6 826 -48 6 minecraft:polished_deepslate
fill 815 -47 -5 815 -42 -5 minecraft:stripped_warped_stem[axis=y]
fill 825 -47 -5 825 -42 -5 minecraft:stripped_warped_stem[axis=y]
fill 815 -47 5 815 -42 5 minecraft:stripped_warped_stem[axis=y]
fill 825 -47 5 825 -42 5 minecraft:stripped_warped_stem[axis=y]
fill 815 -42 -5 825 -42 -5 minecraft:stripped_warped_stem[axis=x]
fill 815 -42 5 825 -42 5 minecraft:stripped_warped_stem[axis=x]
fill 815 -42 -5 815 -42 5 minecraft:stripped_warped_stem[axis=z]
fill 825 -42 -5 825 -42 5 minecraft:stripped_warped_stem[axis=z]
fill 816 -47 0 824 -47 0 minecraft:rail[shape=east_west]
setblock 814 -45 -2 minecraft:sculk
setblock 826 -44 2 minecraft:sculk_catalyst
setblock 824 -47 4 minecraft:barrel[facing=up]
setblock 820 -42 0 minecraft:soul_lantern[hanging=true]
setblock 816 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 824 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 816 -42 4 minecraft:soul_lantern[hanging=true]
setblock 824 -42 4 minecraft:soul_lantern[hanging=true]
setblock 814 -44 0 minecraft:wall_torch[facing=east]
setblock 826 -44 0 minecraft:wall_torch[facing=west]
setblock 820 -44 -6 minecraft:wall_torch[facing=south]
setblock 820 -44 6 minecraft:wall_torch[facing=north]
setblock 816 -48 -4 minecraft:sculk
setblock 824 -48 4 minecraft:sculk
setblock 816 -48 4 minecraft:sculk_sensor
setblock 824 -48 -4 minecraft:sculk_catalyst
setblock 820 -47 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 820 -46 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 827 -47 0 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 827 -46 0 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
