# Floor 8 — Breach Mouth — generated room at center (700,-47,0).
fill 693 -48 -7 707 -41 7 minecraft:blackstone hollow
fill 694 -47 -6 706 -42 6 minecraft:air
fill 694 -48 -6 706 -48 6 minecraft:basalt
fill 695 -47 -5 695 -42 -5 minecraft:stripped_crimson_stem[axis=y]
fill 705 -47 -5 705 -42 -5 minecraft:stripped_crimson_stem[axis=y]
fill 695 -47 5 695 -42 5 minecraft:stripped_crimson_stem[axis=y]
fill 705 -47 5 705 -42 5 minecraft:stripped_crimson_stem[axis=y]
fill 695 -42 -5 705 -42 -5 minecraft:stripped_crimson_stem[axis=x]
fill 695 -42 5 705 -42 5 minecraft:stripped_crimson_stem[axis=x]
fill 695 -42 -5 695 -42 5 minecraft:stripped_crimson_stem[axis=z]
fill 705 -42 -5 705 -42 5 minecraft:stripped_crimson_stem[axis=z]
fill 696 -47 0 704 -47 0 minecraft:rail[shape=east_west]
setblock 694 -45 -2 minecraft:nether_gold_ore
setblock 706 -44 2 minecraft:ancient_debris
setblock 704 -47 4 minecraft:barrel[facing=up]
setblock 700 -42 0 minecraft:soul_lantern[hanging=true]
setblock 696 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 704 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 696 -42 4 minecraft:soul_lantern[hanging=true]
setblock 704 -42 4 minecraft:soul_lantern[hanging=true]
setblock 694 -44 0 minecraft:wall_torch[facing=east]
setblock 706 -44 0 minecraft:wall_torch[facing=west]
setblock 700 -44 -6 minecraft:wall_torch[facing=south]
setblock 700 -44 6 minecraft:wall_torch[facing=north]
setblock 696 -48 -4 minecraft:magma_block
setblock 704 -48 4 minecraft:soul_sand
setblock 696 -47 4 minecraft:crying_obsidian
setblock 704 -47 -4 minecraft:nether_bricks
setblock 693 -47 0 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 693 -46 0 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
setblock 700 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 700 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
