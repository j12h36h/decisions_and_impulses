# Floor 8 — Blackstone Junction — generated room at center (680,-47,20).
fill 673 -48 13 687 -41 27 minecraft:blackstone hollow
fill 674 -47 14 686 -42 26 minecraft:air
fill 674 -48 14 686 -48 26 minecraft:basalt
fill 675 -47 15 675 -42 15 minecraft:stripped_crimson_stem[axis=y]
fill 685 -47 15 685 -42 15 minecraft:stripped_crimson_stem[axis=y]
fill 675 -47 25 675 -42 25 minecraft:stripped_crimson_stem[axis=y]
fill 685 -47 25 685 -42 25 minecraft:stripped_crimson_stem[axis=y]
fill 675 -42 15 685 -42 15 minecraft:stripped_crimson_stem[axis=x]
fill 675 -42 25 685 -42 25 minecraft:stripped_crimson_stem[axis=x]
fill 675 -42 15 675 -42 25 minecraft:stripped_crimson_stem[axis=z]
fill 685 -42 15 685 -42 25 minecraft:stripped_crimson_stem[axis=z]
fill 680 -47 16 680 -47 24 minecraft:rail[shape=north_south]
setblock 674 -45 18 minecraft:nether_gold_ore
setblock 686 -44 22 minecraft:ancient_debris
setblock 684 -47 24 minecraft:barrel[facing=up]
setblock 680 -42 20 minecraft:soul_lantern[hanging=true]
setblock 676 -42 16 minecraft:soul_lantern[hanging=true]
setblock 684 -42 16 minecraft:soul_lantern[hanging=true]
setblock 676 -42 24 minecraft:soul_lantern[hanging=true]
setblock 684 -42 24 minecraft:soul_lantern[hanging=true]
setblock 674 -44 20 minecraft:wall_torch[facing=east]
setblock 686 -44 20 minecraft:wall_torch[facing=west]
setblock 680 -44 14 minecraft:wall_torch[facing=south]
setblock 680 -44 26 minecraft:wall_torch[facing=north]
setblock 676 -48 16 minecraft:magma_block
setblock 684 -48 24 minecraft:soul_sand
setblock 676 -47 24 minecraft:crying_obsidian
setblock 684 -47 16 minecraft:nether_bricks
fill 679 -48 17 681 -48 18 minecraft:magma_block
setblock 673 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 673 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
