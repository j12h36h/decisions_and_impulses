# Floor 8 — Basalt Sluice — generated room at center (680,-47,0).
fill 673 -48 -7 687 -41 7 minecraft:blackstone hollow
fill 674 -47 -6 686 -42 6 minecraft:air
fill 674 -48 -6 686 -48 6 minecraft:basalt
fill 675 -47 -5 675 -42 -5 minecraft:stripped_crimson_stem[axis=y]
fill 685 -47 -5 685 -42 -5 minecraft:stripped_crimson_stem[axis=y]
fill 675 -47 5 675 -42 5 minecraft:stripped_crimson_stem[axis=y]
fill 685 -47 5 685 -42 5 minecraft:stripped_crimson_stem[axis=y]
fill 675 -42 -5 685 -42 -5 minecraft:stripped_crimson_stem[axis=x]
fill 675 -42 5 685 -42 5 minecraft:stripped_crimson_stem[axis=x]
fill 675 -42 -5 675 -42 5 minecraft:stripped_crimson_stem[axis=z]
fill 685 -42 -5 685 -42 5 minecraft:stripped_crimson_stem[axis=z]
fill 680 -47 -4 680 -47 4 minecraft:rail[shape=north_south]
setblock 674 -45 -2 minecraft:nether_gold_ore
setblock 686 -44 2 minecraft:ancient_debris
setblock 684 -47 4 minecraft:barrel[facing=up]
setblock 680 -42 0 minecraft:soul_lantern[hanging=true]
setblock 676 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 684 -42 -4 minecraft:soul_lantern[hanging=true]
setblock 676 -42 4 minecraft:soul_lantern[hanging=true]
setblock 684 -42 4 minecraft:soul_lantern[hanging=true]
setblock 674 -44 0 minecraft:wall_torch[facing=east]
setblock 686 -44 0 minecraft:wall_torch[facing=west]
setblock 680 -44 -6 minecraft:wall_torch[facing=south]
setblock 680 -44 6 minecraft:wall_torch[facing=north]
setblock 676 -48 -4 minecraft:magma_block
setblock 684 -48 4 minecraft:soul_sand
setblock 676 -47 4 minecraft:crying_obsidian
setblock 684 -47 -4 minecraft:nether_bricks
fill 679 -48 -3 681 -48 -2 minecraft:magma_block
setblock 680 -47 7 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock 680 -46 7 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
