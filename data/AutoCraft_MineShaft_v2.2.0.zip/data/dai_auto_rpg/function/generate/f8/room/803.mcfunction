# Floor 8 — Rift Walk — generated room at center (700,-47,20).
fill 693 -48 13 707 -41 27 minecraft:blackstone hollow
fill 694 -47 14 706 -42 26 minecraft:air
fill 694 -48 14 706 -48 26 minecraft:basalt
fill 695 -47 15 695 -42 15 minecraft:stripped_crimson_stem[axis=y]
fill 705 -47 15 705 -42 15 minecraft:stripped_crimson_stem[axis=y]
fill 695 -47 25 695 -42 25 minecraft:stripped_crimson_stem[axis=y]
fill 705 -47 25 705 -42 25 minecraft:stripped_crimson_stem[axis=y]
fill 695 -42 15 705 -42 15 minecraft:stripped_crimson_stem[axis=x]
fill 695 -42 25 705 -42 25 minecraft:stripped_crimson_stem[axis=x]
fill 695 -42 15 695 -42 25 minecraft:stripped_crimson_stem[axis=z]
fill 705 -42 15 705 -42 25 minecraft:stripped_crimson_stem[axis=z]
fill 696 -47 20 704 -47 20 minecraft:rail[shape=east_west]
setblock 694 -45 18 minecraft:nether_gold_ore
setblock 706 -44 22 minecraft:ancient_debris
setblock 704 -47 24 minecraft:barrel[facing=up]
setblock 700 -42 20 minecraft:soul_lantern[hanging=true]
setblock 696 -42 16 minecraft:soul_lantern[hanging=true]
setblock 704 -42 16 minecraft:soul_lantern[hanging=true]
setblock 696 -42 24 minecraft:soul_lantern[hanging=true]
setblock 704 -42 24 minecraft:soul_lantern[hanging=true]
setblock 694 -44 20 minecraft:wall_torch[facing=east]
setblock 706 -44 20 minecraft:wall_torch[facing=west]
setblock 700 -44 14 minecraft:wall_torch[facing=south]
setblock 700 -44 26 minecraft:wall_torch[facing=north]
setblock 696 -48 16 minecraft:magma_block
setblock 704 -48 24 minecraft:soul_sand
setblock 696 -47 24 minecraft:crying_obsidian
setblock 704 -47 16 minecraft:nether_bricks
fill 699 -48 17 701 -48 18 minecraft:magma_block
setblock 693 -47 20 minecraft:iron_door[facing=west,half=lower,hinge=left,open=false,powered=false]
setblock 693 -46 20 minecraft:iron_door[facing=west,half=upper,hinge=left,open=false,powered=false]
