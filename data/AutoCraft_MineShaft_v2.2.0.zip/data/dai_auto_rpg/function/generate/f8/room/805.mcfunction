# Floor 8 — Rift Office — generated room at center (660,-47,20).
fill 653 -48 13 667 -41 27 minecraft:blackstone hollow
fill 654 -47 14 666 -42 26 minecraft:air
fill 654 -48 14 666 -48 26 minecraft:basalt
fill 655 -47 15 655 -42 15 minecraft:stripped_crimson_stem[axis=y]
fill 665 -47 15 665 -42 15 minecraft:stripped_crimson_stem[axis=y]
fill 655 -47 25 655 -42 25 minecraft:stripped_crimson_stem[axis=y]
fill 665 -47 25 665 -42 25 minecraft:stripped_crimson_stem[axis=y]
fill 655 -42 15 665 -42 15 minecraft:stripped_crimson_stem[axis=x]
fill 655 -42 25 665 -42 25 minecraft:stripped_crimson_stem[axis=x]
fill 655 -42 15 655 -42 25 minecraft:stripped_crimson_stem[axis=z]
fill 665 -42 15 665 -42 25 minecraft:stripped_crimson_stem[axis=z]
fill 656 -47 20 664 -47 20 minecraft:rail[shape=east_west]
setblock 654 -45 18 minecraft:nether_gold_ore
setblock 666 -44 22 minecraft:ancient_debris
setblock 664 -47 24 minecraft:barrel[facing=up]
setblock 660 -42 20 minecraft:soul_lantern[hanging=true]
setblock 656 -42 16 minecraft:soul_lantern[hanging=true]
setblock 664 -42 16 minecraft:soul_lantern[hanging=true]
setblock 656 -42 24 minecraft:soul_lantern[hanging=true]
setblock 664 -42 24 minecraft:soul_lantern[hanging=true]
setblock 654 -44 20 minecraft:wall_torch[facing=east]
setblock 666 -44 20 minecraft:wall_torch[facing=west]
setblock 660 -44 14 minecraft:wall_torch[facing=south]
setblock 660 -44 26 minecraft:wall_torch[facing=north]
setblock 656 -48 16 minecraft:magma_block
setblock 664 -48 24 minecraft:soul_sand
setblock 656 -47 24 minecraft:crying_obsidian
setblock 664 -47 16 minecraft:nether_bricks
fill 657 -48 17 663 -48 23 minecraft:basalt
fill 657 -47 17 663 -44 23 minecraft:air
