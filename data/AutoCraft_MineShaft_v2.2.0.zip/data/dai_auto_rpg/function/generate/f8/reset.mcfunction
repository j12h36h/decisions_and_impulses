# Reset the reserved Floor 8 sector back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add 650 -10 710 30
kill @e[type=!minecraft:player,x=650,y=-50,z=-10,dx=60,dy=11,dz=40]
fill 650 -49 -10 710 -40 30 minecraft:deepslate
function dai_auto_rpg:generate/f8/room/801
forceload remove 650 -10 710 30
