# Floor 8 connector 802 -> 804.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 680 -44 6 minecraft:air
setblock 680 -44 14 minecraft:air
fill 678 -48 7 682 -42 13 minecraft:blackstone hollow
fill 679 -47 8 681 -43 12 minecraft:air
fill 679 -48 8 681 -48 12 minecraft:basalt
fill 679 -47 7 681 -44 7 minecraft:air
fill 679 -47 13 681 -44 13 minecraft:air
fill 680 -47 8 680 -47 12 minecraft:rail[shape=north_south]
fill 678 -47 10 678 -43 10 minecraft:stripped_crimson_stem[axis=y]
fill 682 -47 10 682 -43 10 minecraft:stripped_crimson_stem[axis=y]
setblock 680 -43 10 minecraft:soul_lantern[hanging=true]
setblock 679 -45 9 minecraft:wall_torch[facing=east]
setblock 681 -45 11 minecraft:wall_torch[facing=west]
