# Floor 8 connector 801 -> 803.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 700 -44 6 minecraft:air
setblock 700 -44 14 minecraft:air
fill 698 -48 7 702 -42 13 minecraft:blackstone hollow
fill 699 -47 8 701 -43 12 minecraft:air
fill 699 -48 8 701 -48 12 minecraft:basalt
fill 699 -47 7 701 -44 7 minecraft:air
fill 699 -47 13 701 -44 13 minecraft:air
fill 700 -47 8 700 -47 12 minecraft:rail[shape=north_south]
fill 698 -47 10 698 -43 10 minecraft:stripped_crimson_stem[axis=y]
fill 702 -47 10 702 -43 10 minecraft:stripped_crimson_stem[axis=y]
setblock 700 -43 10 minecraft:soul_lantern[hanging=true]
setblock 699 -45 9 minecraft:wall_torch[facing=east]
setblock 701 -45 11 minecraft:wall_torch[facing=west]
