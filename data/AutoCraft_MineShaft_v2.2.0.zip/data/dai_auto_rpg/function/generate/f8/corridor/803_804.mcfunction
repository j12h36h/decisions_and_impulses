# Floor 8 connector 803 -> 804.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 686 -44 20 minecraft:air
setblock 694 -44 20 minecraft:air
fill 687 -48 18 693 -42 22 minecraft:blackstone hollow
fill 688 -47 19 692 -43 21 minecraft:air
fill 688 -48 19 692 -48 21 minecraft:basalt
fill 687 -47 19 687 -44 21 minecraft:air
fill 693 -47 19 693 -44 21 minecraft:air
fill 688 -47 20 692 -47 20 minecraft:rail[shape=east_west]
fill 690 -47 18 690 -43 18 minecraft:stripped_crimson_stem[axis=y]
fill 690 -47 22 690 -43 22 minecraft:stripped_crimson_stem[axis=y]
setblock 690 -43 20 minecraft:soul_lantern[hanging=true]
setblock 689 -45 19 minecraft:wall_torch[facing=south]
setblock 691 -45 21 minecraft:wall_torch[facing=north]
