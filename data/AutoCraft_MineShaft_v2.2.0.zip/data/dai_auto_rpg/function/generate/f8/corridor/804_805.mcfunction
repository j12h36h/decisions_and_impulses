# Floor 8 connector 804 -> 805.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 666 -44 20 minecraft:air
setblock 674 -44 20 minecraft:air
fill 667 -48 18 673 -42 22 minecraft:blackstone hollow
fill 668 -47 19 672 -43 21 minecraft:air
fill 668 -48 19 672 -48 21 minecraft:basalt
fill 667 -47 19 667 -44 21 minecraft:air
fill 673 -47 19 673 -44 21 minecraft:air
fill 668 -47 20 672 -47 20 minecraft:rail[shape=east_west]
fill 670 -47 18 670 -43 18 minecraft:stripped_crimson_stem[axis=y]
fill 670 -47 22 670 -43 22 minecraft:stripped_crimson_stem[axis=y]
setblock 670 -43 20 minecraft:soul_lantern[hanging=true]
setblock 669 -45 19 minecraft:wall_torch[facing=south]
setblock 671 -45 21 minecraft:wall_torch[facing=north]
