# Floor 8 connector 801 -> 802.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 686 -44 0 minecraft:air
setblock 694 -44 0 minecraft:air
fill 687 -48 -2 693 -42 2 minecraft:blackstone hollow
fill 688 -47 -1 692 -43 1 minecraft:air
fill 688 -48 -1 692 -48 1 minecraft:basalt
fill 687 -47 -1 687 -44 1 minecraft:air
fill 693 -47 -1 693 -44 1 minecraft:air
fill 688 -47 0 692 -47 0 minecraft:rail[shape=east_west]
fill 690 -47 -2 690 -43 -2 minecraft:stripped_crimson_stem[axis=y]
fill 690 -47 2 690 -43 2 minecraft:stripped_crimson_stem[axis=y]
setblock 690 -43 0 minecraft:soul_lantern[hanging=true]
setblock 689 -45 -1 minecraft:wall_torch[facing=south]
setblock 691 -45 1 minecraft:wall_torch[facing=north]
