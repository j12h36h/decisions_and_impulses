# Floor 5 — Furnace Core — generated room at center (380,-47,-20).
fill 373 -48 -27 387 -41 -13 minecraft:polished_blackstone_bricks hollow
fill 374 -47 -26 386 -42 -14 minecraft:air
fill 374 -48 -26 386 -48 -14 minecraft:smooth_basalt
fill 375 -47 -25 375 -42 -25 minecraft:stripped_crimson_stem[axis=y]
fill 385 -47 -25 385 -42 -25 minecraft:stripped_crimson_stem[axis=y]
fill 375 -47 -15 375 -42 -15 minecraft:stripped_crimson_stem[axis=y]
fill 385 -47 -15 385 -42 -15 minecraft:stripped_crimson_stem[axis=y]
fill 375 -42 -25 385 -42 -25 minecraft:stripped_crimson_stem[axis=x]
fill 375 -42 -15 385 -42 -15 minecraft:stripped_crimson_stem[axis=x]
fill 375 -42 -25 375 -42 -15 minecraft:stripped_crimson_stem[axis=z]
fill 385 -42 -25 385 -42 -15 minecraft:stripped_crimson_stem[axis=z]
fill 376 -47 -20 384 -47 -20 minecraft:rail[shape=east_west]
setblock 374 -45 -22 minecraft:deepslate_iron_ore
setblock 386 -44 -18 minecraft:deepslate_redstone_ore
setblock 384 -47 -16 minecraft:barrel[facing=up]
setblock 380 -42 -20 minecraft:lantern[hanging=true]
setblock 376 -42 -24 minecraft:lantern[hanging=true]
setblock 384 -42 -24 minecraft:lantern[hanging=true]
setblock 376 -42 -16 minecraft:lantern[hanging=true]
setblock 384 -42 -16 minecraft:lantern[hanging=true]
setblock 374 -44 -20 minecraft:wall_torch[facing=east]
setblock 386 -44 -20 minecraft:wall_torch[facing=west]
setblock 380 -44 -26 minecraft:wall_torch[facing=south]
setblock 380 -44 -14 minecraft:wall_torch[facing=north]
setblock 376 -47 -24 minecraft:blast_furnace[facing=east]
setblock 384 -47 -16 minecraft:lava_cauldron
setblock 376 -48 -16 minecraft:magma_block
setblock 384 -48 -24 minecraft:magma_block
fill 379 -48 -23 381 -48 -22 minecraft:magma_block
fill 377 -48 -23 383 -48 -17 minecraft:smooth_basalt
fill 377 -47 -23 383 -44 -17 minecraft:air
