# Floor 5 — Smelter Deck — generated room at center (360,-47,0).
fill 353 -48 -7 367 -41 7 minecraft:polished_blackstone_bricks hollow
fill 354 -47 -6 366 -42 6 minecraft:air
fill 354 -48 -6 366 -48 6 minecraft:smooth_basalt
fill 355 -47 -5 355 -42 -5 minecraft:stripped_crimson_stem[axis=y]
fill 365 -47 -5 365 -42 -5 minecraft:stripped_crimson_stem[axis=y]
fill 355 -47 5 355 -42 5 minecraft:stripped_crimson_stem[axis=y]
fill 365 -47 5 365 -42 5 minecraft:stripped_crimson_stem[axis=y]
fill 355 -42 -5 365 -42 -5 minecraft:stripped_crimson_stem[axis=x]
fill 355 -42 5 365 -42 5 minecraft:stripped_crimson_stem[axis=x]
fill 355 -42 -5 355 -42 5 minecraft:stripped_crimson_stem[axis=z]
fill 365 -42 -5 365 -42 5 minecraft:stripped_crimson_stem[axis=z]
fill 356 -47 0 364 -47 0 minecraft:rail[shape=east_west]
setblock 354 -45 -2 minecraft:deepslate_iron_ore
setblock 366 -44 2 minecraft:deepslate_redstone_ore
setblock 364 -47 4 minecraft:barrel[facing=up]
setblock 360 -42 0 minecraft:lantern[hanging=true]
setblock 356 -42 -4 minecraft:lantern[hanging=true]
setblock 364 -42 -4 minecraft:lantern[hanging=true]
setblock 356 -42 4 minecraft:lantern[hanging=true]
setblock 364 -42 4 minecraft:lantern[hanging=true]
setblock 354 -44 0 minecraft:wall_torch[facing=east]
setblock 366 -44 0 minecraft:wall_torch[facing=west]
setblock 360 -44 -6 minecraft:wall_torch[facing=south]
setblock 360 -44 6 minecraft:wall_torch[facing=north]
setblock 356 -47 -4 minecraft:blast_furnace[facing=east]
setblock 364 -47 4 minecraft:lava_cauldron
setblock 356 -48 4 minecraft:magma_block
setblock 364 -48 -4 minecraft:magma_block
fill 359 -48 -3 361 -48 -2 minecraft:magma_block
setblock 360 -47 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 360 -46 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
