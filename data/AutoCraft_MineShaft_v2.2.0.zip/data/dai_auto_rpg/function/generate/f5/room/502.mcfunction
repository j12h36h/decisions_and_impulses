# Floor 5 — Cooling Line — generated room at center (340,-47,-20).
fill 333 -48 -27 347 -41 -13 minecraft:polished_blackstone_bricks hollow
fill 334 -47 -26 346 -42 -14 minecraft:air
fill 334 -48 -26 346 -48 -14 minecraft:smooth_basalt
fill 335 -47 -25 335 -42 -25 minecraft:stripped_crimson_stem[axis=y]
fill 345 -47 -25 345 -42 -25 minecraft:stripped_crimson_stem[axis=y]
fill 335 -47 -15 335 -42 -15 minecraft:stripped_crimson_stem[axis=y]
fill 345 -47 -15 345 -42 -15 minecraft:stripped_crimson_stem[axis=y]
fill 335 -42 -25 345 -42 -25 minecraft:stripped_crimson_stem[axis=x]
fill 335 -42 -15 345 -42 -15 minecraft:stripped_crimson_stem[axis=x]
fill 335 -42 -25 335 -42 -15 minecraft:stripped_crimson_stem[axis=z]
fill 345 -42 -25 345 -42 -15 minecraft:stripped_crimson_stem[axis=z]
fill 340 -47 -24 340 -47 -16 minecraft:rail[shape=north_south]
setblock 334 -45 -22 minecraft:deepslate_iron_ore
setblock 346 -44 -18 minecraft:deepslate_redstone_ore
setblock 344 -47 -16 minecraft:barrel[facing=up]
setblock 340 -42 -20 minecraft:lantern[hanging=true]
setblock 336 -42 -24 minecraft:lantern[hanging=true]
setblock 344 -42 -24 minecraft:lantern[hanging=true]
setblock 336 -42 -16 minecraft:lantern[hanging=true]
setblock 344 -42 -16 minecraft:lantern[hanging=true]
setblock 334 -44 -20 minecraft:wall_torch[facing=east]
setblock 346 -44 -20 minecraft:wall_torch[facing=west]
setblock 340 -44 -26 minecraft:wall_torch[facing=south]
setblock 340 -44 -14 minecraft:wall_torch[facing=north]
setblock 336 -47 -24 minecraft:blast_furnace[facing=east]
setblock 344 -47 -16 minecraft:lava_cauldron
setblock 336 -48 -16 minecraft:magma_block
setblock 344 -48 -24 minecraft:magma_block
setblock 347 -47 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 347 -46 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
