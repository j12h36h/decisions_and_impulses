# Floor 5 — Heat Exchange — generated room at center (360,-47,-20).
fill 353 -48 -27 367 -41 -13 minecraft:polished_blackstone_bricks hollow
fill 354 -47 -26 366 -42 -14 minecraft:air
fill 354 -48 -26 366 -48 -14 minecraft:smooth_basalt
fill 355 -47 -25 355 -42 -25 minecraft:stripped_crimson_stem[axis=y]
fill 365 -47 -25 365 -42 -25 minecraft:stripped_crimson_stem[axis=y]
fill 355 -47 -15 355 -42 -15 minecraft:stripped_crimson_stem[axis=y]
fill 365 -47 -15 365 -42 -15 minecraft:stripped_crimson_stem[axis=y]
fill 355 -42 -25 365 -42 -25 minecraft:stripped_crimson_stem[axis=x]
fill 355 -42 -15 365 -42 -15 minecraft:stripped_crimson_stem[axis=x]
fill 355 -42 -25 355 -42 -15 minecraft:stripped_crimson_stem[axis=z]
fill 365 -42 -25 365 -42 -15 minecraft:stripped_crimson_stem[axis=z]
fill 360 -47 -24 360 -47 -16 minecraft:rail[shape=north_south]
setblock 354 -45 -22 minecraft:deepslate_iron_ore
setblock 366 -44 -18 minecraft:deepslate_redstone_ore
setblock 364 -47 -16 minecraft:barrel[facing=up]
setblock 360 -42 -20 minecraft:lantern[hanging=true]
setblock 356 -42 -24 minecraft:lantern[hanging=true]
setblock 364 -42 -24 minecraft:lantern[hanging=true]
setblock 356 -42 -16 minecraft:lantern[hanging=true]
setblock 364 -42 -16 minecraft:lantern[hanging=true]
setblock 354 -44 -20 minecraft:wall_torch[facing=east]
setblock 366 -44 -20 minecraft:wall_torch[facing=west]
setblock 360 -44 -26 minecraft:wall_torch[facing=south]
setblock 360 -44 -14 minecraft:wall_torch[facing=north]
setblock 356 -47 -24 minecraft:blast_furnace[facing=east]
setblock 364 -47 -16 minecraft:lava_cauldron
setblock 356 -48 -16 minecraft:magma_block
setblock 364 -48 -24 minecraft:magma_block
fill 359 -48 -23 361 -48 -22 minecraft:magma_block
setblock 367 -47 -20 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 367 -46 -20 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
