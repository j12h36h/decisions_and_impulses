# Floor 5 — Foundry Intake — generated room at center (340,-47,0).
fill 333 -48 -7 347 -41 7 minecraft:polished_blackstone_bricks hollow
fill 334 -47 -6 346 -42 6 minecraft:air
fill 334 -48 -6 346 -48 6 minecraft:smooth_basalt
fill 335 -47 -5 335 -42 -5 minecraft:stripped_crimson_stem[axis=y]
fill 345 -47 -5 345 -42 -5 minecraft:stripped_crimson_stem[axis=y]
fill 335 -47 5 335 -42 5 minecraft:stripped_crimson_stem[axis=y]
fill 345 -47 5 345 -42 5 minecraft:stripped_crimson_stem[axis=y]
fill 335 -42 -5 345 -42 -5 minecraft:stripped_crimson_stem[axis=x]
fill 335 -42 5 345 -42 5 minecraft:stripped_crimson_stem[axis=x]
fill 335 -42 -5 335 -42 5 minecraft:stripped_crimson_stem[axis=z]
fill 345 -42 -5 345 -42 5 minecraft:stripped_crimson_stem[axis=z]
fill 336 -47 0 344 -47 0 minecraft:rail[shape=east_west]
setblock 334 -45 -2 minecraft:deepslate_iron_ore
setblock 346 -44 2 minecraft:deepslate_redstone_ore
setblock 344 -47 4 minecraft:barrel[facing=up]
setblock 340 -42 0 minecraft:lantern[hanging=true]
setblock 336 -42 -4 minecraft:lantern[hanging=true]
setblock 344 -42 -4 minecraft:lantern[hanging=true]
setblock 336 -42 4 minecraft:lantern[hanging=true]
setblock 344 -42 4 minecraft:lantern[hanging=true]
setblock 334 -44 0 minecraft:wall_torch[facing=east]
setblock 346 -44 0 minecraft:wall_torch[facing=west]
setblock 340 -44 -6 minecraft:wall_torch[facing=south]
setblock 340 -44 6 minecraft:wall_torch[facing=north]
setblock 336 -47 -4 minecraft:blast_furnace[facing=east]
setblock 344 -47 4 minecraft:lava_cauldron
setblock 336 -48 4 minecraft:magma_block
setblock 344 -48 -4 minecraft:magma_block
setblock 340 -47 -7 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock 340 -46 -7 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock 347 -47 0 minecraft:iron_door[facing=east,half=lower,hinge=left,open=false,powered=false]
setblock 347 -46 0 minecraft:iron_door[facing=east,half=upper,hinge=left,open=false,powered=false]
