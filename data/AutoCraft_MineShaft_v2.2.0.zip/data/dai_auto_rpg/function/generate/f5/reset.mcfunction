# Reset the reserved Floor 5 sector back to solid rock.
# v0.5.1 chunk-safe generation: load this isolated sector before remote block commands run.
forceload add 330 -30 390 10
kill @e[type=!minecraft:player,x=330,y=-50,z=-30,dx=60,dy=11,dz=40]
fill 330 -49 -30 390 -40 10 minecraft:deepslate
function dai_auto_rpg:generate/f5/room/501
forceload remove 330 -30 390 10
