# Floor 5 connector 502 -> 504.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 346 -44 -20 minecraft:air
setblock 354 -44 -20 minecraft:air
fill 347 -48 -22 353 -42 -18 minecraft:polished_blackstone_bricks hollow
fill 348 -47 -21 352 -43 -19 minecraft:air
fill 348 -48 -21 352 -48 -19 minecraft:smooth_basalt
fill 347 -47 -21 347 -44 -19 minecraft:air
fill 353 -47 -21 353 -44 -19 minecraft:air
fill 348 -47 -20 352 -47 -20 minecraft:rail[shape=east_west]
fill 350 -47 -22 350 -43 -22 minecraft:stripped_crimson_stem[axis=y]
fill 350 -47 -18 350 -43 -18 minecraft:stripped_crimson_stem[axis=y]
setblock 350 -43 -20 minecraft:lantern[hanging=true]
setblock 349 -45 -21 minecraft:wall_torch[facing=south]
setblock 351 -45 -19 minecraft:wall_torch[facing=north]
