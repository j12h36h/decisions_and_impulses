# Floor 5 connector 503 -> 504.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 360 -44 -14 minecraft:air
setblock 360 -44 -6 minecraft:air
fill 358 -48 -13 362 -42 -7 minecraft:polished_blackstone_bricks hollow
fill 359 -47 -12 361 -43 -8 minecraft:air
fill 359 -48 -12 361 -48 -8 minecraft:smooth_basalt
fill 359 -47 -13 361 -44 -13 minecraft:air
fill 359 -47 -7 361 -44 -7 minecraft:air
fill 360 -47 -12 360 -47 -8 minecraft:rail[shape=north_south]
fill 358 -47 -10 358 -43 -10 minecraft:stripped_crimson_stem[axis=y]
fill 362 -47 -10 362 -43 -10 minecraft:stripped_crimson_stem[axis=y]
setblock 360 -43 -10 minecraft:lantern[hanging=true]
setblock 359 -45 -11 minecraft:wall_torch[facing=east]
setblock 361 -45 -9 minecraft:wall_torch[facing=west]
