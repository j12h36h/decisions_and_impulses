# Floor 5 connector 504 -> 505.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 366 -44 -20 minecraft:air
setblock 374 -44 -20 minecraft:air
fill 367 -48 -22 373 -42 -18 minecraft:polished_blackstone_bricks hollow
fill 368 -47 -21 372 -43 -19 minecraft:air
fill 368 -48 -21 372 -48 -19 minecraft:smooth_basalt
fill 367 -47 -21 367 -44 -19 minecraft:air
fill 373 -47 -21 373 -44 -19 minecraft:air
fill 368 -47 -20 372 -47 -20 minecraft:rail[shape=east_west]
fill 370 -47 -22 370 -43 -22 minecraft:stripped_crimson_stem[axis=y]
fill 370 -47 -18 370 -43 -18 minecraft:stripped_crimson_stem[axis=y]
setblock 370 -43 -20 minecraft:lantern[hanging=true]
setblock 369 -45 -21 minecraft:wall_torch[facing=south]
setblock 371 -45 -19 minecraft:wall_torch[facing=north]
