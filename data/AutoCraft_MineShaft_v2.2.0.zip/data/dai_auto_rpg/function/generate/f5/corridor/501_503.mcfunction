# Floor 5 connector 501 -> 503.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 346 -44 0 minecraft:air
setblock 354 -44 0 minecraft:air
fill 347 -48 -2 353 -42 2 minecraft:polished_blackstone_bricks hollow
fill 348 -47 -1 352 -43 1 minecraft:air
fill 348 -48 -1 352 -48 1 minecraft:smooth_basalt
fill 347 -47 -1 347 -44 1 minecraft:air
fill 353 -47 -1 353 -44 1 minecraft:air
fill 348 -47 0 352 -47 0 minecraft:rail[shape=east_west]
fill 350 -47 -2 350 -43 -2 minecraft:stripped_crimson_stem[axis=y]
fill 350 -47 2 350 -43 2 minecraft:stripped_crimson_stem[axis=y]
setblock 350 -43 0 minecraft:lantern[hanging=true]
setblock 349 -45 -1 minecraft:wall_torch[facing=south]
setblock 351 -45 1 minecraft:wall_torch[facing=north]
