# Floor 5 connector 501 -> 502.
# v0.5.1 doorway-torch cleanup: remove endpoint torches before their support wall is carved away.
setblock 340 -44 -14 minecraft:air
setblock 340 -44 -6 minecraft:air
fill 338 -48 -13 342 -42 -7 minecraft:polished_blackstone_bricks hollow
fill 339 -47 -12 341 -43 -8 minecraft:air
fill 339 -48 -12 341 -48 -8 minecraft:smooth_basalt
fill 339 -47 -13 341 -44 -13 minecraft:air
fill 339 -47 -7 341 -44 -7 minecraft:air
fill 340 -47 -12 340 -47 -8 minecraft:rail[shape=north_south]
fill 338 -47 -10 338 -43 -10 minecraft:stripped_crimson_stem[axis=y]
fill 342 -47 -10 342 -43 -10 minecraft:stripped_crimson_stem[axis=y]
setblock 340 -43 -10 minecraft:lantern[hanging=true]
setblock 339 -45 -11 minecraft:wall_torch[facing=east]
setblock 341 -45 -9 minecraft:wall_torch[facing=west]
