summon minecraft:stray ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Crystal Stray',color:'aqua',italic:false},CustomNameVisible:1b}
