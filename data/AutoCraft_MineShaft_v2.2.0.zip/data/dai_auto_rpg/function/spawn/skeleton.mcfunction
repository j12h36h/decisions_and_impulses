summon minecraft:skeleton ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Lost Archer',color:'gray',italic:false},CustomNameVisible:1b}
