summon minecraft:wither_skeleton ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Breach Warden',color:'dark_red',italic:false},CustomNameVisible:1b}
