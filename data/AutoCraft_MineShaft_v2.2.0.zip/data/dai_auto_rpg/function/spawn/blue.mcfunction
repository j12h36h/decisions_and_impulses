summon minecraft:slime ~ ~ ~ {Size:0,PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_blue"],CustomName:{text:'Blue Slime',color:'blue',italic:false},CustomNameVisible:1b}
team join arpg2_blue @e[tag=arpg2_blue,sort=nearest,limit=1,distance=..2]
execute as @e[tag=arpg2_blue,sort=nearest,limit=1,distance=..2] run attribute @s minecraft:max_health base set 4
execute as @e[tag=arpg2_blue,sort=nearest,limit=1,distance=..2] run data modify entity @s Health set value 4.0f
effect give @e[tag=arpg2_blue,sort=nearest,limit=1,distance=..2] minecraft:slowness infinite 0 true
