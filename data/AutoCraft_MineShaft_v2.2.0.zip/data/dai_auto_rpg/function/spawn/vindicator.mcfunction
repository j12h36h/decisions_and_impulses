summon minecraft:vindicator ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Deepworks Breaker',color:'gold',italic:false},CustomNameVisible:1b}
