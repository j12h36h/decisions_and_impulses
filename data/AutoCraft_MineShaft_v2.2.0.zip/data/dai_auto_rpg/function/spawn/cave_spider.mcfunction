summon minecraft:cave_spider ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Spore Spider',color:'green',italic:false},CustomNameVisible:1b}
