scoreboard players set @s arpg2_phase 3
summon minecraft:wither_skeleton ~ ~ ~ {PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_boss"],CustomName:{text:'Heartbound Director',color:'dark_red',bold:true,italic:false},CustomNameVisible:1b}
team join arpg2_boss @e[tag=arpg2_boss,type=minecraft:wither_skeleton,sort=nearest,limit=1,distance=..3]
execute as @e[tag=arpg2_boss,type=minecraft:wither_skeleton,sort=nearest,limit=1,distance=..3] run attribute @s minecraft:max_health base set 88
execute as @e[tag=arpg2_boss,type=minecraft:wither_skeleton,sort=nearest,limit=1,distance=..3] run data modify entity @s Health set value 88.0f
item replace entity @e[tag=arpg2_boss,type=minecraft:wither_skeleton,sort=nearest,limit=1,distance=..3] weapon.mainhand with minecraft:netherite_sword
effect give @e[tag=arpg2_boss,type=minecraft:wither_skeleton,sort=nearest,limit=1,distance=..3] minecraft:speed infinite 0 true
execute positioned ~-3 ~ ~-2 run function dai_auto_rpg:spawn/silverfish
execute positioned ~3 ~ ~2 run function dai_auto_rpg:spawn/magma
title @s title {text:'FINAL PHASE — HEARTBOUND',color:'dark_red',bold:true}
playsound minecraft:block.respawn_anchor.deplete master @s ~ ~ ~ 1.0 0.6
