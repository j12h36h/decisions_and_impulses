summon minecraft:slime ~ ~ ~ {Size:3,PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_boss"],CustomName:{text:'Slime Foreman',color:'gold',bold:true,italic:false},CustomNameVisible:1b}
team join arpg2_boss @e[tag=arpg2_boss,sort=nearest,limit=1,distance=..2]
