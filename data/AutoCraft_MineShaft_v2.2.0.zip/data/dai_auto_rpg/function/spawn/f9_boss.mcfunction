summon minecraft:witch ~ ~ ~ {PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_boss"],CustomName:{text:'Deep Surveyor',color:'gold',bold:true,italic:false},CustomNameVisible:1b}
team join arpg2_boss @e[tag=arpg2_boss,type=minecraft:witch,sort=nearest,limit=1,distance=..2]
execute as @e[tag=arpg2_boss,type=minecraft:witch,sort=nearest,limit=1,distance=..2] run attribute @s minecraft:max_health base set 72
execute as @e[tag=arpg2_boss,type=minecraft:witch,sort=nearest,limit=1,distance=..2] run data modify entity @s Health set value 72.0f
effect give @e[tag=arpg2_boss,type=minecraft:witch,sort=nearest,limit=1,distance=..2] minecraft:speed infinite 0 true
