summon minecraft:zombie ~ ~ ~ {PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_boss"],CustomName:{text:'Lost Overseer',color:'gold',bold:true,italic:false},CustomNameVisible:1b}
team join arpg2_boss @e[tag=arpg2_boss,sort=nearest,limit=1,distance=..2]
execute as @e[tag=arpg2_boss,type=minecraft:zombie,sort=nearest,limit=1,distance=..2] run attribute @s minecraft:max_health base set 30
execute as @e[tag=arpg2_boss,type=minecraft:zombie,sort=nearest,limit=1,distance=..2] run data modify entity @s Health set value 30.0f
item replace entity @e[tag=arpg2_boss,type=minecraft:zombie,sort=nearest,limit=1,distance=..2] weapon.mainhand with minecraft:iron_axe
item replace entity @e[tag=arpg2_boss,type=minecraft:zombie,sort=nearest,limit=1,distance=..2] armor.head with minecraft:iron_helmet
item replace entity @e[tag=arpg2_boss,type=minecraft:zombie,sort=nearest,limit=1,distance=..2] armor.chest with minecraft:chainmail_chestplate
