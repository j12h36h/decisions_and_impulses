summon minecraft:pillager ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Deepworks Guard',color:'yellow',italic:false},CustomNameVisible:1b}
