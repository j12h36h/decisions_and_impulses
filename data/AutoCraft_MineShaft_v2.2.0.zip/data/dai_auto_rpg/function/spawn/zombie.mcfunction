summon minecraft:zombie ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Lost Miner',color:'gray',italic:false},CustomNameVisible:1b}
