summon minecraft:ravager ~ ~ ~ {PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_boss"],CustomName:{text:'Excavation Engine',color:'gold',bold:true,italic:false},CustomNameVisible:1b}
team join arpg2_boss @e[tag=arpg2_boss,type=minecraft:ravager,sort=nearest,limit=1,distance=..3]
execute as @e[tag=arpg2_boss,type=minecraft:ravager,sort=nearest,limit=1,distance=..3] run attribute @s minecraft:max_health base set 72
execute as @e[tag=arpg2_boss,type=minecraft:ravager,sort=nearest,limit=1,distance=..3] run data modify entity @s Health set value 72.0f
