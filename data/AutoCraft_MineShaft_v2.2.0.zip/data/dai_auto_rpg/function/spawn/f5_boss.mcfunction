summon minecraft:magma_cube ~ ~ ~ {Size:3,PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_boss"],CustomName:{text:'Furnace Foreman',color:'gold',bold:true,italic:false},CustomNameVisible:1b}
team join arpg2_boss @e[tag=arpg2_boss,type=minecraft:magma_cube,sort=nearest,limit=1,distance=..2]
execute as @e[tag=arpg2_boss,type=minecraft:magma_cube,sort=nearest,limit=1,distance=..2] run attribute @s minecraft:max_health base set 48
execute as @e[tag=arpg2_boss,type=minecraft:magma_cube,sort=nearest,limit=1,distance=..2] run data modify entity @s Health set value 48.0f
