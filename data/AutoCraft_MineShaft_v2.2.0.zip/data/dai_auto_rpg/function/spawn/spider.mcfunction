summon minecraft:spider ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Hollow Spider',color:'dark_green',italic:false},CustomNameVisible:1b}
