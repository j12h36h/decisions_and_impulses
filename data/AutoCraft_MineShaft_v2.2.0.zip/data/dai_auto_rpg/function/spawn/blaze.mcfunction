summon minecraft:blaze ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Breach Flame',color:'red',italic:false},CustomNameVisible:1b}
