summon minecraft:witch ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Depth Walker',color:'dark_aqua',italic:false},CustomNameVisible:1b}
