summon minecraft:magma_cube ~ ~ ~ {Size:1,PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Molten Slag',color:'red',italic:false},CustomNameVisible:1b}
