summon minecraft:husk ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Foundry Worker',color:'gold',italic:false},CustomNameVisible:1b}
item replace entity @e[tag=arpg2_enemy,type=minecraft:husk,sort=nearest,limit=1,distance=..2] weapon.mainhand with minecraft:stone_axe
