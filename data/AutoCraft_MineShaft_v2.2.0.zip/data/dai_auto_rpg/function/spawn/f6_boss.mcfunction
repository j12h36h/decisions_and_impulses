summon minecraft:stray ~ ~ ~ {PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_boss"],CustomName:{text:'Resonant Prospector',color:'gold',bold:true,italic:false},CustomNameVisible:1b}
team join arpg2_boss @e[tag=arpg2_boss,type=minecraft:stray,sort=nearest,limit=1,distance=..2]
execute as @e[tag=arpg2_boss,type=minecraft:stray,sort=nearest,limit=1,distance=..2] run attribute @s minecraft:max_health base set 50
execute as @e[tag=arpg2_boss,type=minecraft:stray,sort=nearest,limit=1,distance=..2] run data modify entity @s Health set value 50.0f
item replace entity @e[tag=arpg2_boss,type=minecraft:stray,sort=nearest,limit=1,distance=..2] weapon.mainhand with minecraft:bow
item replace entity @e[tag=arpg2_boss,type=minecraft:stray,sort=nearest,limit=1,distance=..2] armor.head with minecraft:diamond_helmet
