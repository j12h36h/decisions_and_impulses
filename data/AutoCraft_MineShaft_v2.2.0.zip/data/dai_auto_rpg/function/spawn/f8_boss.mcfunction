summon minecraft:piglin_brute ~ ~ ~ {PersistenceRequired:1b,IsImmuneToZombification:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_boss"],CustomName:{text:'Rift Superintendent',color:'gold',bold:true,italic:false},CustomNameVisible:1b}
team join arpg2_boss @e[tag=arpg2_boss,type=minecraft:piglin_brute,sort=nearest,limit=1,distance=..2]
execute as @e[tag=arpg2_boss,type=minecraft:piglin_brute,sort=nearest,limit=1,distance=..2] run attribute @s minecraft:max_health base set 64
execute as @e[tag=arpg2_boss,type=minecraft:piglin_brute,sort=nearest,limit=1,distance=..2] run data modify entity @s Health set value 64.0f
item replace entity @e[tag=arpg2_boss,type=minecraft:piglin_brute,sort=nearest,limit=1,distance=..2] weapon.mainhand with minecraft:diamond_axe
