scoreboard players set @s arpg2_phase 2
summon minecraft:vindicator ~ ~ ~ {PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_boss"],CustomName:{text:'Mine Director',color:'gold',bold:true,italic:false},CustomNameVisible:1b}
team join arpg2_boss @e[tag=arpg2_boss,type=minecraft:vindicator,sort=nearest,limit=1,distance=..3]
execute as @e[tag=arpg2_boss,type=minecraft:vindicator,sort=nearest,limit=1,distance=..3] run attribute @s minecraft:max_health base set 64
execute as @e[tag=arpg2_boss,type=minecraft:vindicator,sort=nearest,limit=1,distance=..3] run data modify entity @s Health set value 64.0f
item replace entity @e[tag=arpg2_boss,type=minecraft:vindicator,sort=nearest,limit=1,distance=..3] weapon.mainhand with minecraft:netherite_axe
execute positioned ~-3 ~ ~ run function dai_auto_rpg:spawn/pillager
execute positioned ~3 ~ ~ run function dai_auto_rpg:spawn/pillager
title @s title {text:'PHASE II — MINE DIRECTOR',color:'gold',bold:true}
playsound minecraft:entity.ravager.roar master @s ~ ~ ~ 0.9 0.8
