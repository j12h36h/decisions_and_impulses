summon minecraft:endermite ~ ~ ~ {PersistenceRequired:1b,Tags:["arpg2_enemy"],CustomName:{text:'Sculk Mite',color:'dark_aqua',italic:false},CustomNameVisible:1b}
