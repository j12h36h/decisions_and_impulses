summon minecraft:slime ~ ~ ~ {Size:0,PersistenceRequired:1b,Glowing:1b,Tags:["arpg2_enemy","arpg2_red"],CustomName:{text:'Red Slime',color:'red',italic:false},CustomNameVisible:1b}
team join arpg2_red @e[tag=arpg2_red,sort=nearest,limit=1,distance=..2]
effect give @e[tag=arpg2_red,sort=nearest,limit=1,distance=..2] minecraft:speed infinite 1 true
