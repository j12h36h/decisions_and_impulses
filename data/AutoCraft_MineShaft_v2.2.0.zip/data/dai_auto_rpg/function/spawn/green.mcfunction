summon minecraft:slime ~ ~ ~ {Size:0,PersistenceRequired:1b,Tags:["arpg2_enemy","arpg2_green"],CustomName:{text:'Green Slime',color:'green',italic:false},CustomNameVisible:1b}
