# v2.2 authoritative mode split + physical recovery.
execute as @a[tag=arpg2_player,y=-64,dy=3] run function dai_auto_rpg:player/void_recover

# Home is Survival; every active MineShaft room is Adventure.
execute as @a[tag=arpg2_player,scores={arpg2_room=0}] unless entity @s[gamemode=survival] run gamemode survival @s
execute as @a[tag=arpg2_player,scores={arpg2_room=1..}] unless entity @s[gamemode=adventure] run gamemode adventure @s

# v0.5.5 Home farm migration is Home-safe and non-destructive.
execute as @a[tag=arpg2_player,tag=!arpg2_v0550_migrated,scores={arpg2_room=0}] run function dai_auto_rpg:migrate/v0550

# v0.5.1 lighting migration is Home-safe and non-destructive.
execute as @a[tag=arpg2_player,tag=!arpg2_v0510_migrated,scores={arpg2_room=0}] run function dai_auto_rpg:migrate/v0510

# v0.5.0 campaign migration is Home-safe and non-destructive.
execute as @a[tag=arpg2_player,tag=!arpg2_v0500_migrated,scores={arpg2_room=0}] run function dai_auto_rpg:migrate/v0500

# v0.4.x migrations retained for save compatibility.
execute as @a[tag=arpg2_player,tag=!arpg2_v0400_migrated,scores={arpg2_room=0}] run function dai_auto_rpg:migrate/v0400
execute as @a[tag=arpg2_player,tag=!arpg2_v0410_migrated,scores={arpg2_room=0}] run function dai_auto_rpg:migrate/v0410

# Older migrations retained for save compatibility.
execute as @a[tag=arpg2_player,tag=!arpg2_v0340_migrated] run function dai_auto_rpg:migrate/v0340
execute as @a[tag=arpg2_player,tag=!arpg2_v0201_migrated] run function dai_auto_rpg:migrate/v0201
execute as @a[tag=arpg2_player,tag=!arpg2_v0300_migrated,scores={arpg2_room=0}] run function dai_auto_rpg:migrate/v0300
execute as @a[tag=arpg2_player,tag=!arpg2_v0310_migrated] run function dai_auto_rpg:migrate/v0310
execute as @a[tag=arpg2_player,tag=!arpg2_v0320_migrated] run function dai_auto_rpg:migrate/v0320

# v0.5.6 converts legacy floor sigils into floor-specific mementos.
execute as @a[tag=arpg2_player,tag=!arpg2_v0560_migrated,scores={arpg2_room=0}] run function dai_auto_rpg:migrate/v0560

team join arpg2_red @e[tag=arpg2_red]
team join arpg2_blue @e[tag=arpg2_blue]
team join arpg2_boss @e[tag=arpg2_boss]

# Persistent death recovery.
execute as @a[tag=arpg2_player] unless score @s arpg2_seen_deaths = @s arpg2_deaths run function dai_auto_rpg:player/death

# Generated rooms only begin when the player physically walks into them.
execute as @a[tag=arpg2_player,scores={arpg2_next_room=102}] if entity @s[x=-6,y=-32,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/1/102/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=103}] if entity @s[x=14,y=-32,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/1/103/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=104}] if entity @s[x=14,y=-32,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/1/104/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=105}] if entity @s[x=34,y=-32,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/1/105/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=202}] if entity @s[x=-26,y=-48,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/2/202/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=203}] if entity @s[x=-6,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/2/203/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=204}] if entity @s[x=-26,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/2/204/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=205}] if entity @s[x=-46,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/2/205/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=302}] if entity @s[x=94,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/3/302/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=303}] if entity @s[x=114,y=-48,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/3/303/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=304}] if entity @s[x=114,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/3/304/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=305}] if entity @s[x=134,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/3/305/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=402}] if entity @s[x=194,y=-48,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/4/402/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=403}] if entity @s[x=214,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/4/403/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=404}] if entity @s[x=194,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/4/404/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=405}] if entity @s[x=174,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/4/405/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=502}] if entity @s[x=334,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/5/502/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=503}] if entity @s[x=354,y=-48,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/5/503/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=504}] if entity @s[x=354,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/5/504/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=505}] if entity @s[x=374,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/5/505/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=602}] if entity @s[x=434,y=-48,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/6/602/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=603}] if entity @s[x=454,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/6/603/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=604}] if entity @s[x=434,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/6/604/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=605}] if entity @s[x=414,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/6/605/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=702}] if entity @s[x=574,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/7/702/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=703}] if entity @s[x=594,y=-48,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/7/703/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=704}] if entity @s[x=594,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/7/704/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=705}] if entity @s[x=614,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/7/705/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=802}] if entity @s[x=674,y=-48,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/8/802/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=803}] if entity @s[x=694,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/8/803/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=804}] if entity @s[x=674,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/8/804/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=805}] if entity @s[x=654,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/8/805/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=902}] if entity @s[x=814,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/9/902/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=903}] if entity @s[x=834,y=-48,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/9/903/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=904}] if entity @s[x=834,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/9/904/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=905}] if entity @s[x=854,y=-48,z=-26,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/9/905/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=1002}] if entity @s[x=914,y=-48,z=-6,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/10/1002/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=1003}] if entity @s[x=934,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/10/1003/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=1004}] if entity @s[x=914,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/10/1004/start
execute as @a[tag=arpg2_player,scores={arpg2_next_room=1005}] if entity @s[x=894,y=-48,z=14,dx=12,dy=8,dz=12] run function dai_auto_rpg:room/10/1005/start

# Server-authoritative room completion; combat remains manual.
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=101}] run function dai_auto_rpg:encounter/check/101
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=102}] run function dai_auto_rpg:encounter/check/102
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=103}] run function dai_auto_rpg:encounter/check/103
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=104}] run function dai_auto_rpg:encounter/check/104
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=105}] run function dai_auto_rpg:encounter/check/105
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=201}] run function dai_auto_rpg:encounter/check/201
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=202}] run function dai_auto_rpg:encounter/check/202
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=203}] run function dai_auto_rpg:encounter/check/203
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=204}] run function dai_auto_rpg:encounter/check/204
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=205}] run function dai_auto_rpg:encounter/check/205
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=301}] run function dai_auto_rpg:encounter/check/301
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=302}] run function dai_auto_rpg:encounter/check/302
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=303}] run function dai_auto_rpg:encounter/check/303
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=304}] run function dai_auto_rpg:encounter/check/304
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=305}] run function dai_auto_rpg:encounter/check/305
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=401}] run function dai_auto_rpg:encounter/check/401
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=402}] run function dai_auto_rpg:encounter/check/402
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=403}] run function dai_auto_rpg:encounter/check/403
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=404}] run function dai_auto_rpg:encounter/check/404
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=405}] run function dai_auto_rpg:encounter/check/405
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=501}] run function dai_auto_rpg:encounter/check/501
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=502}] run function dai_auto_rpg:encounter/check/502
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=503}] run function dai_auto_rpg:encounter/check/503
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=504}] run function dai_auto_rpg:encounter/check/504
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=505}] run function dai_auto_rpg:encounter/check/505
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=601}] run function dai_auto_rpg:encounter/check/601
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=602}] run function dai_auto_rpg:encounter/check/602
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=603}] run function dai_auto_rpg:encounter/check/603
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=604}] run function dai_auto_rpg:encounter/check/604
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=605}] run function dai_auto_rpg:encounter/check/605
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=701}] run function dai_auto_rpg:encounter/check/701
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=702}] run function dai_auto_rpg:encounter/check/702
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=703}] run function dai_auto_rpg:encounter/check/703
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=704}] run function dai_auto_rpg:encounter/check/704
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=705}] run function dai_auto_rpg:encounter/check/705
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=801}] run function dai_auto_rpg:encounter/check/801
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=802}] run function dai_auto_rpg:encounter/check/802
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=803}] run function dai_auto_rpg:encounter/check/803
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=804}] run function dai_auto_rpg:encounter/check/804
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=805}] run function dai_auto_rpg:encounter/check/805
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=901}] run function dai_auto_rpg:encounter/check/901
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=902}] run function dai_auto_rpg:encounter/check/902
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=903}] run function dai_auto_rpg:encounter/check/903
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=904}] run function dai_auto_rpg:encounter/check/904
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=905}] run function dai_auto_rpg:encounter/check/905
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=1001}] run function dai_auto_rpg:encounter/check/1001
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=1002}] run function dai_auto_rpg:encounter/check/1002
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=1003}] run function dai_auto_rpg:encounter/check/1003
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=1004}] run function dai_auto_rpg:encounter/check/1004
execute as @a[tag=arpg2_player,scores={arpg2_combat=1,arpg2_room=1005}] run function dai_auto_rpg:encounter/check/1005

# HUD refresh is visual-only; 4 Hz is enough and removes dozens of title/item-count commands from every server tick.
scoreboard players add #ui arpg2_ui_clock 1
execute if score #ui arpg2_ui_clock matches 5.. run function dai_auto_rpg:ui/tick
execute if score #ui arpg2_ui_clock matches 5.. run scoreboard players set #ui arpg2_ui_clock 0
