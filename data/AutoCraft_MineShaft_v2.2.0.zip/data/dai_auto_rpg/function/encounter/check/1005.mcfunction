tag @e[type=minecraft:magma_cube,x=893,y=-48,z=13,dx=14,dy=8,dz=14] add arpg2_enemy
execute if entity @e[tag=arpg2_enemy,x=893,y=-48,z=13,dx=14,dy=8,dz=14] run scoreboard players set @s arpg2_clear_timer 20
execute unless entity @e[tag=arpg2_enemy,x=893,y=-48,z=13,dx=14,dy=8,dz=14] if score @s arpg2_phase matches 1 positioned 900 -47 20 run function dai_auto_rpg:spawn/f10_phase2
execute unless entity @e[tag=arpg2_enemy,x=893,y=-48,z=13,dx=14,dy=8,dz=14] if score @s arpg2_phase matches 2 positioned 900 -47 20 run function dai_auto_rpg:spawn/f10_phase3
execute unless entity @e[tag=arpg2_enemy,x=893,y=-48,z=13,dx=14,dy=8,dz=14] if score @s arpg2_phase matches 3 if score @s arpg2_clear_timer matches 1.. run scoreboard players remove @s arpg2_clear_timer 1
execute unless entity @e[tag=arpg2_enemy,x=893,y=-48,z=13,dx=14,dy=8,dz=14] if score @s arpg2_phase matches 3 if score @s arpg2_clear_timer matches ..0 run function dai_auto_rpg:room/cleared
