tag @e[type=minecraft:slime,x=33,y=-32,z=-27,dx=14,dy=8,dz=14] add arpg2_enemy
team join arpg2_boss @e[type=minecraft:slime,x=33,y=-32,z=-27,dx=14,dy=8,dz=14]
execute if entity @e[tag=arpg2_enemy,x=33,y=-32,z=-27,dx=14,dy=8,dz=14] run scoreboard players set @s arpg2_clear_timer 30
execute unless entity @e[tag=arpg2_enemy,x=33,y=-32,z=-27,dx=14,dy=8,dz=14] if score @s arpg2_clear_timer matches 1.. run scoreboard players remove @s arpg2_clear_timer 1
execute unless entity @e[tag=arpg2_enemy,x=33,y=-32,z=-27,dx=14,dy=8,dz=14] if score @s arpg2_clear_timer matches ..0 run function dai_auto_rpg:room/cleared
