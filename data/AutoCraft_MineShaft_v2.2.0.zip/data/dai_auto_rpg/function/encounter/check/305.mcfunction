execute if entity @e[tag=arpg2_enemy,x=133,y=-48,z=-27,dx=14,dy=8,dz=14] run scoreboard players set @s arpg2_clear_timer 20
execute unless entity @e[tag=arpg2_enemy,x=133,y=-48,z=-27,dx=14,dy=8,dz=14] if score @s arpg2_clear_timer matches 1.. run scoreboard players remove @s arpg2_clear_timer 1
execute unless entity @e[tag=arpg2_enemy,x=133,y=-48,z=-27,dx=14,dy=8,dz=14] if score @s arpg2_clear_timer matches ..0 run function dai_auto_rpg:room/cleared
