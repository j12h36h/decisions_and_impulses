function dai_auto_rpg:build/all
gamerule minecraft:keep_inventory true
gamerule minecraft:immediate_respawn true
gamerule minecraft:spawn_mobs false
gamerule minecraft:mob_griefing false
tag @s add arpg2_player
tag @s add arpg2_v0201_migrated
tag @s add arpg2_v0300_migrated
tag @s add arpg2_v0310_migrated
tag @s add arpg2_v0340_migrated
tag @s add arpg2_v0400_migrated
tag @s add arpg2_v0410_migrated
tag @s add arpg2_v0500_migrated
tag @s add arpg2_v0510_migrated
tag @s add arpg2_v0550_migrated
tag @s add arpg2_v0560_migrated
scoreboard players set @s arpg2_room 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_timer 0
scoreboard players set @s arpg2_combat 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_rope 1
scoreboard players set @s arpg2_unlock 1
scoreboard players set @s arpg2_first_weapon 0
scoreboard players set @s arpg2_loot 0
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_phase 0
scoreboard players add @s arpg2_deaths 0
scoreboard players operation @s arpg2_seen_deaths = @s arpg2_deaths
clear @s
item replace entity @s armor.legs with minecraft:leather_leggings[minecraft:custom_name={text:'Worn Delver Leggings',color:'gold',italic:false}]
item replace entity @s hotbar.7 with minecraft:written_book[minecraft:written_book_content={title:"AutoCraft MineShaft Guide",author:"DAI",pages:[{text:'AUTOCRAFT MINESHAFT\n\nTen floors. You choose the route and fight the battles. Rooms and tunnels are physically carved only as you unlock them.',color:'black'},{text:'HOME LIFT\n\nThe north iron door is the MineShaft lift. It always sends you directly to the deepest floor you have unlocked.',color:'black'},{text:'HOME FARM\n\nThe east arch leads to a compact underground farm with wheat, carrots, berries, composting and storage. It is a safe supply corner between expeditions.',color:'black'},{text:'COMBAT\n\nCombat is completely manual. DAI does not move, aim, attack, eat, or change your selected weapon. Clear every enemy to progress.',color:'black'},{text:'ROUTES & KEYS\n\nA cleared room awards a MineShaft Key. Use it on one available iron gate. Your chosen tunnel and next room are generated, then you physically walk there.',color:'black'},{text:'BOSS KEYS\n\nThe final normal room awards a Boss Key. Use it in that room to expose the boss route, then walk into the chamber.',color:'black'},{text:'FLOORS 1–5\n\n1 Slimeworks\n2 Abandoned Shafts\n3 Flooded Excavation\n4 Fungal Hollows\n5 Deep Foundry',color:'black'},{text:'FLOORS 6–10\n\n6 Crystal Fault\n7 Industrial Deepworks\n8 Nether Breach\n9 Ancient Depths\n10 Heart of the Mine',color:'black'},{text:'HOME / DUNGEON MODE\n\nHome is Survival mode so you can farm, craft and manage supplies. The authored Home walls, floors, ceilings and lift shell are protected. MineShaft floors switch to Adventure mode.',color:'black'},{text:'FLOOR MEMENTOS\n\nEvery boss clear awards a unique trophy from the floor you conquered. These mementos replace the old next-floor sigil crystals; progression itself remains permanent and scoreboard-based.',color:'black'},{text:'SAFETY ROPE\n\nRight-click the Safety Rope to abandon the current floor and return Home. Gear and unlocked floors are kept; temporary keys are lost.',color:'black'},{text:'GEAR & DEATH\n\nYou begin with leather leggings and no weapon. Fight with whatever gear you find. Death returns you Home and preserves equipment and unlocked floors.',color:'black'}]}]
item replace entity @s hotbar.8 with minecraft:lead[minecraft:custom_data={dai_auto_rpg:{safety_rope:1b}},minecraft:custom_name={text:'Safety Rope',color:'gold',bold:true,italic:false},minecraft:lore=[{text:'Right-click anywhere to retreat safely to Home.',color:'gray',italic:false},{text:'This rope is never consumed.',color:'dark_gray',italic:false}]]
spawnpoint @s 0 -15 0
teleport @s 0.5 -15 0.5 180 0
gamemode survival @s
scoreboard objectives setdisplay sidebar
title @s times 5 30 5
title @s title {"text":"AUTOCRAFT MINESHAFT","color":"gold","bold":true}
title @s subtitle {"text":"Ten floors. Choose the route. Fight the MineShaft.","color":"gray"}
tellraw @s {"text":"Read the AutoCraft MineShaft Guide, then use the north iron door to begin Floor 1.","color":"yellow"}
