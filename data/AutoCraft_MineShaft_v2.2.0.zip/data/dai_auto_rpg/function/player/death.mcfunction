
scoreboard players operation @s arpg2_seen_deaths = @s arpg2_deaths
scoreboard players set @s arpg2_combat 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_timer 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
kill @e[tag=arpg2_enemy]
function dai_auto_rpg:player/home
title @s title {text:'EXPEDITION FAILED',color:'red',bold:true}
title @s subtitle {text:'Your gear is safe. The MineShaft will shift on your next descent.',color:'gray'}
