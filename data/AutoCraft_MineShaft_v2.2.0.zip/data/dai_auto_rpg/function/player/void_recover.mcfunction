effect give @s minecraft:resistance 4 4 true
execute if score @s arpg2_room matches 1.. run function dai_auto_rpg:room/recenter
execute if score @s arpg2_room matches 0 run function dai_auto_rpg:player/home
title @s actionbar {"text":"SAFETY ROPE // emergency room recovery","color":"gold"}
