function dai_auto_rpg:build/home_doors
function dai_auto_rpg:player/ensure_rope
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_room 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_combat 0
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_clear_timer 0
scoreboard players set @s arpg2_phase 0
kill @e[tag=arpg2_enemy]
teleport @s 0.5 -15 0.5 180 0
# Home is a protected Survival hub. Set the mode after teleport so Safety Rope/death returns cannot remain in Adventure.
gamemode survival @s
scoreboard objectives setdisplay sidebar
title @s times 5 25 5
title @s title {text:'HOME ROOM',color:'gold'}
title @s subtitle {text:'The north mine lift returns you to your deepest unlocked floor.',color:'gray'}
