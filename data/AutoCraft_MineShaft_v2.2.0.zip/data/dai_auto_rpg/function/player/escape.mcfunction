
execute unless items entity @s weapon.mainhand minecraft:lead[minecraft:custom_data~{dai_auto_rpg:{safety_rope:1b}}] unless items entity @s weapon.offhand minecraft:lead[minecraft:custom_data~{dai_auto_rpg:{safety_rope:1b}}] run return 0
scoreboard players set @s arpg2_combat 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_clear_timer 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
kill @e[tag=arpg2_enemy]
function dai_auto_rpg:player/home
title @s title {text:'SAFE RETREAT',color:'gold',bold:true}
title @s subtitle {text:'The route will be carved fresh on your next descent.',color:'gray'}
tellraw @s {text:'Safety Rope returned you Home. Gear is safe; temporary keys were left behind.',color:'yellow'}
