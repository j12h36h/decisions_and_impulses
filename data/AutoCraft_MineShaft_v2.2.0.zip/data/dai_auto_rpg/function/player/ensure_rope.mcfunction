# Keep exactly one marked Safety Rope while preserving any unrelated item occupying slot 9.
execute store result score @s arpg2_rope run clear @s minecraft:lead[minecraft:custom_data~{dai_auto_rpg:{safety_rope:1b}}] 0
scoreboard players set @s arpg2_stash 0
execute if items entity @s hotbar.8 minecraft:lead[minecraft:custom_data~{dai_auto_rpg:{safety_rope:1b}}] run scoreboard players set @s arpg2_stash 1
execute unless items entity @s hotbar.8 minecraft:lead[minecraft:custom_data~{dai_auto_rpg:{safety_rope:1b}}] run function dai_auto_rpg:inventory/stash/hotbar_8
execute if score @s arpg2_stash matches 1.. run clear @s minecraft:lead[minecraft:custom_data~{dai_auto_rpg:{safety_rope:1b}}]
execute if score @s arpg2_stash matches 1.. run item replace entity @s hotbar.8 with minecraft:lead[minecraft:custom_data={dai_auto_rpg:{safety_rope:1b}},minecraft:custom_name={text:'Safety Rope',color:'gold',bold:true,italic:false},minecraft:lore=[{text:'Right-click anywhere to retreat safely to Home.',color:'gray',italic:false},{text:'This rope is never consumed.',color:'dark_gray',italic:false}]]
execute if score @s arpg2_stash matches 0 if score @s arpg2_rope matches 0 run give @s minecraft:lead[minecraft:custom_data={dai_auto_rpg:{safety_rope:1b}},minecraft:custom_name={text:'Safety Rope',color:'gold',bold:true,italic:false},minecraft:lore=[{text:'Right-click anywhere to retreat safely to Home.',color:'gray',italic:false},{text:'This rope is never consumed.',color:'dark_gray',italic:false}]] 1
