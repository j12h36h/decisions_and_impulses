execute unless entity @s[tag=arpg2_player] run function dai_auto_rpg:player/first_join
tag @s add arpg2_player
execute unless score @s arpg2_unlock matches 1.. run scoreboard players set @s arpg2_unlock 1
scoreboard players add @s arpg2_deaths 0
scoreboard players operation @s arpg2_seen_deaths = @s arpg2_deaths
scoreboard players set @s arpg2_phase 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_room 0
scoreboard players set @s arpg2_combat 0
spawnpoint @s 0 -15 0
teleport @s 0.5 -15 0.5 180 0
gamemode survival @s
function dai_auto_rpg:player/ensure_rope
scoreboard objectives setdisplay sidebar
kill @e[tag=arpg2_enemy]
tellraw @s {text:'Returned to the Home Room. The north MineShaft lift always targets your deepest unlocked floor.',color:'gray'}
