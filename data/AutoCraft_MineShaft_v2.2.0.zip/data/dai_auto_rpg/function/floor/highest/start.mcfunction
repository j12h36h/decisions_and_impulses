# Home's single MineShaft lift always launches the deepest unlocked floor.
# Exact unlock checks prevent multiple floor starts from cascading in one interaction.
execute if score @s arpg2_unlock matches 10 run function dai_auto_rpg:floor/10/start
execute if score @s arpg2_unlock matches 9 run function dai_auto_rpg:floor/9/start
execute if score @s arpg2_unlock matches 8 run function dai_auto_rpg:floor/8/start
execute if score @s arpg2_unlock matches 7 run function dai_auto_rpg:floor/7/start
execute if score @s arpg2_unlock matches 6 run function dai_auto_rpg:floor/6/start
execute if score @s arpg2_unlock matches 5 run function dai_auto_rpg:floor/5/start
execute if score @s arpg2_unlock matches 4 run function dai_auto_rpg:floor/4/start
execute if score @s arpg2_unlock matches 3 run function dai_auto_rpg:floor/3/start
execute if score @s arpg2_unlock matches 2 run function dai_auto_rpg:floor/2/start
execute if score @s arpg2_unlock matches 1 run function dai_auto_rpg:floor/1/start
