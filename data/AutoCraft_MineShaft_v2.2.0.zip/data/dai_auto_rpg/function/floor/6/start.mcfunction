execute unless score @s arpg2_unlock matches 6.. run tellraw @s {"text":"Floor 6 is still locked.","color":"red"}
execute unless score @s arpg2_unlock matches 6.. run return 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_room 601
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
scoreboard players set @s arpg2_phase 0
function dai_auto_rpg:generate/f6/reset
teleport @s 460.5 -47 0.5 180 0
# Dungeon floors use Adventure mode so authored geometry and encounters remain controlled.
gamemode adventure @s
function dai_auto_rpg:map/f6/601
title @s times 5 25 5
execute positioned 457 -47 0 run function dai_auto_rpg:spawn/skeleton
execute positioned 463 -47 0 run function dai_auto_rpg:spawn/stray
execute positioned 460 -47 2 run function dai_auto_rpg:spawn/silverfish
title @s title {"text":"FLOOR 6","color":"light_purple","bold":true}
title @s subtitle {"text": "Crystal Fault — ranged crews, dripstone, and resonant chambers.", "color": "gray"}
