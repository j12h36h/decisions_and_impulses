execute unless score @s arpg2_unlock matches 7.. run tellraw @s {"text":"Floor 7 is still locked.","color":"red"}
execute unless score @s arpg2_unlock matches 7.. run return 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_room 701
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
scoreboard players set @s arpg2_phase 0
function dai_auto_rpg:generate/f7/reset
teleport @s 580.5 -47 0.5 180 0
# Dungeon floors use Adventure mode so authored geometry and encounters remain controlled.
gamemode adventure @s
function dai_auto_rpg:map/f7/701
title @s times 5 25 5
execute positioned 577 -47 0 run function dai_auto_rpg:spawn/pillager
execute positioned 583 -47 0 run function dai_auto_rpg:spawn/vindicator
execute positioned 580 -47 3 run function dai_auto_rpg:spawn/pillager
title @s title {"text":"FLOOR 7","color":"yellow","bold":true}
title @s subtitle {"text": "Industrial Deepworks — armed crews and derelict machinery.", "color": "gray"}
