execute unless score @s arpg2_unlock matches 5.. run tellraw @s {"text":"Floor 5 is still locked.","color":"red"}
execute unless score @s arpg2_unlock matches 5.. run return 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_room 501
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
scoreboard players set @s arpg2_phase 0
function dai_auto_rpg:generate/f5/reset
teleport @s 340.5 -47 0.5 180 0
# Dungeon floors use Adventure mode so authored geometry and encounters remain controlled.
gamemode adventure @s
function dai_auto_rpg:map/f5/501
title @s times 5 25 5
execute positioned 338 -47 0 run function dai_auto_rpg:spawn/magma
execute positioned 342 -47 0 run function dai_auto_rpg:spawn/magma
execute positioned 340 -47 2 run function dai_auto_rpg:spawn/husk
title @s title {"text":"FLOOR 5","color":"gold","bold":true}
title @s subtitle {"text": "Deep Foundry — heat, magma, and abandoned smelting lines.", "color": "gray"}
