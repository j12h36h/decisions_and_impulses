# Key HUD while inside any MineShaft floor.
execute as @a[tag=arpg2_player,scores={arpg2_room=101..1005}] store result score @s arpg2_keys run clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}] 0
execute as @a[tag=arpg2_player,scores={arpg2_room=101..1005}] unless items entity @s inventory.* minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] run title @s actionbar {"text":"MineShaft Keys: ","color":"gold","extra":[{"score":{"name":"@s","objective":"arpg2_keys"}},{"text":"   |   Boss Key: No","color":"gray"}]}
execute as @a[tag=arpg2_player,scores={arpg2_room=101..1005}] if items entity @s inventory.* minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] run title @s actionbar {"text":"MineShaft Keys: ","color":"gold","extra":[{"score":{"name":"@s","objective":"arpg2_keys"}},{"text":"   |   Boss Key: YES","color":"aqua","bold":true}]}

# Home lift HUD: deepest unlocked floor.
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=1}] run title @s actionbar {"text":"North Mine Lift: Floor 1 — Deepest Unlocked   |   Safety Rope: Home","color":"gold"}
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=2}] run title @s actionbar {"text":"North Mine Lift: Floor 2 — Deepest Unlocked   |   Safety Rope: Home","color":"gold"}
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=3}] run title @s actionbar {"text":"North Mine Lift: Floor 3 — Deepest Unlocked   |   Safety Rope: Home","color":"gold"}
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=4}] run title @s actionbar {"text":"North Mine Lift: Floor 4 — Deepest Unlocked   |   Safety Rope: Home","color":"gold"}
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=5}] run title @s actionbar {"text":"North Mine Lift: Floor 5 — Deepest Unlocked   |   Safety Rope: Home","color":"gold"}
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=6}] run title @s actionbar {"text":"North Mine Lift: Floor 6 — Deepest Unlocked   |   Safety Rope: Home","color":"gold"}
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=7}] run title @s actionbar {"text":"North Mine Lift: Floor 7 — Deepest Unlocked   |   Safety Rope: Home","color":"gold"}
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=8}] run title @s actionbar {"text":"North Mine Lift: Floor 8 — Deepest Unlocked   |   Safety Rope: Home","color":"gold"}
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=9}] run title @s actionbar {"text":"North Mine Lift: Floor 9 — Deepest Unlocked   |   Safety Rope: Home","color":"gold"}
execute as @a[tag=arpg2_player,scores={arpg2_room=0,arpg2_unlock=10..}] run title @s actionbar {"text":"North Mine Lift: Floor 10 — Campaign Summit   |   Safety Rope: Home","color":"gold"}
