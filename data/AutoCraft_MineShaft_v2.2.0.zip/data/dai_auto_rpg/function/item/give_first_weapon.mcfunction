# The first slime drops can occupy slot 1 before the first sword is awarded; preserve them first.
function dai_auto_rpg:inventory/stash/hotbar_0
execute if score @s arpg2_stash matches 1.. run item replace entity @s hotbar.0 with minecraft:wooden_sword[minecraft:custom_name={text:'Splintered Sword',color:'white',italic:false}]
execute if score @s arpg2_stash matches 0 run give @s minecraft:wooden_sword[minecraft:custom_name={text:'Splintered Sword',color:'white',italic:false}] 1
