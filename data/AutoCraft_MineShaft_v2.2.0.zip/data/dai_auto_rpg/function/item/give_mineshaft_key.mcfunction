# Reserve slot 5 without destroying loot that may have auto-collected there during combat.
function dai_auto_rpg:inventory/stash/hotbar_4
execute if score @s arpg2_stash matches 1.. run item replace entity @s hotbar.4 with minecraft:tripwire_hook[minecraft:custom_data={dai_auto_rpg:{mineshaft_key:1b}},minecraft:custom_name={text:'MineShaft Key',color:'gold',italic:false},minecraft:lore=[{text:'Opens one normal MineShaft door.',color:'gray',italic:false}]]
execute if score @s arpg2_stash matches 0 run give @s minecraft:tripwire_hook[minecraft:custom_data={dai_auto_rpg:{mineshaft_key:1b}},minecraft:custom_name={text:'MineShaft Key',color:'gold',italic:false},minecraft:lore=[{text:'Opens one normal MineShaft door.',color:'gray',italic:false}]] 1
