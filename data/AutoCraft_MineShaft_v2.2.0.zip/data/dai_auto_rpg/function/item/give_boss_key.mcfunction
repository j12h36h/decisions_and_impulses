# Reserve slot 5 without destroying the stack currently occupying it.
function dai_auto_rpg:inventory/stash/hotbar_4
execute if score @s arpg2_stash matches 1.. run item replace entity @s hotbar.4 with minecraft:trial_key[minecraft:custom_data={dai_auto_rpg:{boss_key:1b}},minecraft:custom_name={text:'Boss Key',color:'aqua',bold:true,italic:false},minecraft:lore=[{text:'Unlocks the boss room on this floor.',color:'gray',italic:false}]]
execute if score @s arpg2_stash matches 0 run give @s minecraft:trial_key[minecraft:custom_data={dai_auto_rpg:{boss_key:1b}},minecraft:custom_name={text:'Boss Key',color:'aqua',bold:true,italic:false},minecraft:lore=[{text:'Unlocks the boss room on this floor.',color:'gray',italic:false}]] 1
