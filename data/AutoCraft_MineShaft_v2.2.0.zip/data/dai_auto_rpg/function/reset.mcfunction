scoreboard players set @s arpg2_combat 0
kill @e[tag=arpg2_enemy]
tag @s remove arpg2_player
scoreboard players reset @s arpg2_room
scoreboard players reset @s arpg2_unlock
scoreboard players reset @s arpg2_seen_deaths
scoreboard players reset @s arpg2_first_weapon
scoreboard players reset @s arpg2_loot
scoreboard players reset @s arpg2_branch
scoreboard players reset @s arpg2_phase
function dai_auto_rpg:player/first_join
