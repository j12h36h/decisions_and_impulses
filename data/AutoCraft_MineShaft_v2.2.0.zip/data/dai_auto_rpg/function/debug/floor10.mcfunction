scoreboard players set @s arpg2_unlock 10
function dai_auto_rpg:floor/10/start
