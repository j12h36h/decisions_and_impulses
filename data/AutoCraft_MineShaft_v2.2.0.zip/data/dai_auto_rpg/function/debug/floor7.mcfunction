scoreboard players set @s arpg2_unlock 7
function dai_auto_rpg:floor/7/start
