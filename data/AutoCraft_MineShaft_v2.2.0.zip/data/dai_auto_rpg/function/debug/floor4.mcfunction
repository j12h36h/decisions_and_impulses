scoreboard players set @s arpg2_unlock 4
function dai_auto_rpg:floor/4/start
