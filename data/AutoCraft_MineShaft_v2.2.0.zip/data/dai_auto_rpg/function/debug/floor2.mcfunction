scoreboard players set @s arpg2_unlock 2
give @s minecraft:echo_shard 1
function dai_auto_rpg:floor/2/start
