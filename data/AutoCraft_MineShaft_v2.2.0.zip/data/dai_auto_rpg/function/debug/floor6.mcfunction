scoreboard players set @s arpg2_unlock 6
function dai_auto_rpg:floor/6/start
