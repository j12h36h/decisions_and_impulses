function dai_auto_rpg:player/home
