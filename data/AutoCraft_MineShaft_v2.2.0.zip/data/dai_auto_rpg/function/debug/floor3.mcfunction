scoreboard players set @s arpg2_unlock 3
function dai_auto_rpg:floor/3/start
