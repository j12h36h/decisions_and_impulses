scoreboard players set @s arpg2_unlock 8
function dai_auto_rpg:floor/8/start
