scoreboard players set @s arpg2_unlock 5
function dai_auto_rpg:floor/5/start
