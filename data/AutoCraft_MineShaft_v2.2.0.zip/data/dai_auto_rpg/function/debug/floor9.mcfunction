scoreboard players set @s arpg2_unlock 9
function dai_auto_rpg:floor/9/start
