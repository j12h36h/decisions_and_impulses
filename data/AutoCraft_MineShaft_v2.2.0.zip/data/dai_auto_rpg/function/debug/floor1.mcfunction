function dai_auto_rpg:floor/1/start
