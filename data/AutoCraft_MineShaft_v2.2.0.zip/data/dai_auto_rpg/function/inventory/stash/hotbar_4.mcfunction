# Preserve whatever currently occupies hotbar slot 5 before AutoCraft MineShaft reserves that slot.
scoreboard players set @s arpg2_stash 0
execute unless items entity @s hotbar.4 * run scoreboard players set @s arpg2_stash 1
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.0 * run scoreboard players set @s arpg2_stash 100
execute if score @s arpg2_stash matches 100 run item replace entity @s inventory.0 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.1 * run scoreboard players set @s arpg2_stash 101
execute if score @s arpg2_stash matches 101 run item replace entity @s inventory.1 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.2 * run scoreboard players set @s arpg2_stash 102
execute if score @s arpg2_stash matches 102 run item replace entity @s inventory.2 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.3 * run scoreboard players set @s arpg2_stash 103
execute if score @s arpg2_stash matches 103 run item replace entity @s inventory.3 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.4 * run scoreboard players set @s arpg2_stash 104
execute if score @s arpg2_stash matches 104 run item replace entity @s inventory.4 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.5 * run scoreboard players set @s arpg2_stash 105
execute if score @s arpg2_stash matches 105 run item replace entity @s inventory.5 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.6 * run scoreboard players set @s arpg2_stash 106
execute if score @s arpg2_stash matches 106 run item replace entity @s inventory.6 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.7 * run scoreboard players set @s arpg2_stash 107
execute if score @s arpg2_stash matches 107 run item replace entity @s inventory.7 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.8 * run scoreboard players set @s arpg2_stash 108
execute if score @s arpg2_stash matches 108 run item replace entity @s inventory.8 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.9 * run scoreboard players set @s arpg2_stash 109
execute if score @s arpg2_stash matches 109 run item replace entity @s inventory.9 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.10 * run scoreboard players set @s arpg2_stash 110
execute if score @s arpg2_stash matches 110 run item replace entity @s inventory.10 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.11 * run scoreboard players set @s arpg2_stash 111
execute if score @s arpg2_stash matches 111 run item replace entity @s inventory.11 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.12 * run scoreboard players set @s arpg2_stash 112
execute if score @s arpg2_stash matches 112 run item replace entity @s inventory.12 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.13 * run scoreboard players set @s arpg2_stash 113
execute if score @s arpg2_stash matches 113 run item replace entity @s inventory.13 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.14 * run scoreboard players set @s arpg2_stash 114
execute if score @s arpg2_stash matches 114 run item replace entity @s inventory.14 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.15 * run scoreboard players set @s arpg2_stash 115
execute if score @s arpg2_stash matches 115 run item replace entity @s inventory.15 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.16 * run scoreboard players set @s arpg2_stash 116
execute if score @s arpg2_stash matches 116 run item replace entity @s inventory.16 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.17 * run scoreboard players set @s arpg2_stash 117
execute if score @s arpg2_stash matches 117 run item replace entity @s inventory.17 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.18 * run scoreboard players set @s arpg2_stash 118
execute if score @s arpg2_stash matches 118 run item replace entity @s inventory.18 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.19 * run scoreboard players set @s arpg2_stash 119
execute if score @s arpg2_stash matches 119 run item replace entity @s inventory.19 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.20 * run scoreboard players set @s arpg2_stash 120
execute if score @s arpg2_stash matches 120 run item replace entity @s inventory.20 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.21 * run scoreboard players set @s arpg2_stash 121
execute if score @s arpg2_stash matches 121 run item replace entity @s inventory.21 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.22 * run scoreboard players set @s arpg2_stash 122
execute if score @s arpg2_stash matches 122 run item replace entity @s inventory.22 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.23 * run scoreboard players set @s arpg2_stash 123
execute if score @s arpg2_stash matches 123 run item replace entity @s inventory.23 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.24 * run scoreboard players set @s arpg2_stash 124
execute if score @s arpg2_stash matches 124 run item replace entity @s inventory.24 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.25 * run scoreboard players set @s arpg2_stash 125
execute if score @s arpg2_stash matches 125 run item replace entity @s inventory.25 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * unless items entity @s inventory.26 * run scoreboard players set @s arpg2_stash 126
execute if score @s arpg2_stash matches 126 run item replace entity @s inventory.26 from entity @s hotbar.4
execute if score @s arpg2_stash matches 0 if items entity @s hotbar.4 * run tellraw @s {text:'AutoCraft MineShaft could not reserve hotbar slot 5 because the main inventory is full. No existing item was deleted.',color:'yellow'}
