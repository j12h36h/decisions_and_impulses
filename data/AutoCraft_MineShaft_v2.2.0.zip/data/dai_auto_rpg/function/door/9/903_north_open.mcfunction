clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}] 1
function dai_auto_rpg:generate/f9/room/904
function dai_auto_rpg:generate/f9/corridor/903_904
scoreboard players set @s arpg2_branch 2
scoreboard players set @s arpg2_next_room 904
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.85
tellraw @s {text:'The north route has been excavated. Walk through.',color:'gold'}
