clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] 1
function dai_auto_rpg:generate/f9/room/905
function dai_auto_rpg:generate/f9/corridor/904_905
scoreboard players set @s arpg2_next_room 905
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.72
tellraw @s {text:'The Deep Surveyor route is open. Walk into the boss chamber when ready.',color:'aqua'}
