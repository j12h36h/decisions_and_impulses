clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] 1
function dai_auto_rpg:generate/f2/room/205
function dai_auto_rpg:generate/f2/corridor/204_205
scoreboard players set @s arpg2_next_room 205
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.72
tellraw @s {text:'The Overseer gate is open. Walk into the boss chamber when ready.',color:'aqua'}
