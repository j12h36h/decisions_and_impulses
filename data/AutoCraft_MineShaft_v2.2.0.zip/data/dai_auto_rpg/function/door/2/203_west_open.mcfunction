clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}] 1
function dai_auto_rpg:generate/f2/room/204
function dai_auto_rpg:generate/f2/corridor/203_204
scoreboard players set @s arpg2_branch 2
scoreboard players set @s arpg2_next_room 204
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.85
tellraw @s {text:'The lower junction is now physically connected.',color:'gold'}
