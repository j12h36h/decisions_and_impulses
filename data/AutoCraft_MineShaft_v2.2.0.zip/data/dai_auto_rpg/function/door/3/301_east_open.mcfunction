clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}] 1
function dai_auto_rpg:generate/f3/room/303
function dai_auto_rpg:generate/f3/corridor/301_303
scoreboard players set @s arpg2_branch 2
scoreboard players set @s arpg2_next_room 303
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.85
tellraw @s {text:'The east route has been excavated. Walk through.',color:'gold'}
