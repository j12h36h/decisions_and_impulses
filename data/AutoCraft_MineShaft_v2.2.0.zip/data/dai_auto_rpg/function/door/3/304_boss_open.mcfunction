clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] 1
function dai_auto_rpg:generate/f3/room/305
function dai_auto_rpg:generate/f3/corridor/304_305
scoreboard players set @s arpg2_next_room 305
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.72
tellraw @s {text:'The Drowned Surveyor route is open. Walk into the boss chamber when ready.',color:'aqua'}
