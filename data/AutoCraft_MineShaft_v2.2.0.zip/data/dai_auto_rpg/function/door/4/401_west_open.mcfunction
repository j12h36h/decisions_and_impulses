clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}] 1
function dai_auto_rpg:generate/f4/room/402
function dai_auto_rpg:generate/f4/corridor/401_402
scoreboard players set @s arpg2_branch 1
scoreboard players set @s arpg2_next_room 402
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.85
tellraw @s {text:'The west route has been excavated. Walk through.',color:'gold'}
