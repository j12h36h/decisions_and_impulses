clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] 1
function dai_auto_rpg:generate/f4/room/405
function dai_auto_rpg:generate/f4/corridor/404_405
scoreboard players set @s arpg2_next_room 405
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.72
tellraw @s {text:'The Sporekeeper route is open. Walk into the boss chamber when ready.',color:'aqua'}
