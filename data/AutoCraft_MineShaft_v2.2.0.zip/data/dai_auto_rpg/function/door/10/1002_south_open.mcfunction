clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}] 1
function dai_auto_rpg:generate/f10/room/1004
function dai_auto_rpg:generate/f10/corridor/1002_1004
scoreboard players set @s arpg2_branch 1
scoreboard players set @s arpg2_next_room 1004
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.85
tellraw @s {text:'The south route has been excavated. Walk through.',color:'gold'}
