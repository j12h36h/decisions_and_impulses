clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] 1
function dai_auto_rpg:generate/f10/room/1005
function dai_auto_rpg:generate/f10/corridor/1004_1005
scoreboard players set @s arpg2_next_room 1005
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.72
tellraw @s {text:'The The Mine Director route is open. Walk into the boss chamber when ready.',color:'aqua'}
