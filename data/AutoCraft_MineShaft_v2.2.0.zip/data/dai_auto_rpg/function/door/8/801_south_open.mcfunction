clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}] 1
function dai_auto_rpg:generate/f8/room/803
function dai_auto_rpg:generate/f8/corridor/801_803
scoreboard players set @s arpg2_branch 2
scoreboard players set @s arpg2_next_room 803
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.85
tellraw @s {text:'The south route has been excavated. Walk through.',color:'gold'}
