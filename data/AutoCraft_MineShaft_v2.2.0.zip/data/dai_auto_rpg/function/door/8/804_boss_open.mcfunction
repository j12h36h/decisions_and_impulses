clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] 1
function dai_auto_rpg:generate/f8/room/805
function dai_auto_rpg:generate/f8/corridor/804_805
scoreboard players set @s arpg2_next_room 805
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.72
tellraw @s {text:'The Rift Superintendent route is open. Walk into the boss chamber when ready.',color:'aqua'}
