clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] 1
function dai_auto_rpg:generate/f5/room/505
function dai_auto_rpg:generate/f5/corridor/504_505
scoreboard players set @s arpg2_next_room 505
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.72
tellraw @s {text:'The Furnace Foreman route is open. Walk into the boss chamber when ready.',color:'aqua'}
