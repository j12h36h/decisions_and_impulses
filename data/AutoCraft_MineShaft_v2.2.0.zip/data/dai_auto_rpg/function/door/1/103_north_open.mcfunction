clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}] 1
function dai_auto_rpg:generate/f1/room/104
function dai_auto_rpg:generate/f1/corridor/103_104
scoreboard players set @s arpg2_branch 2
scoreboard players set @s arpg2_next_room 104
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.9
tellraw @s {text:'A deeper gallery has opened. Walk the rail tunnel.',color:'gold'}
