clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}] 1
function dai_auto_rpg:generate/f1/room/102
function dai_auto_rpg:generate/f1/corridor/101_102
scoreboard players set @s arpg2_branch 1
scoreboard players set @s arpg2_next_room 102
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.9
tellraw @s {text:'The north tunnel has been carved. Walk into the new room.',color:'gold'}
