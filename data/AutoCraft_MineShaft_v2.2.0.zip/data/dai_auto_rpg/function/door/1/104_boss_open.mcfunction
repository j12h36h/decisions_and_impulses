clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}] 1
function dai_auto_rpg:generate/f1/room/105
function dai_auto_rpg:generate/f1/corridor/104_105
scoreboard players set @s arpg2_next_room 105
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.75
tellraw @s {text:'The Foreman gate is open. Walk into the boss chamber when ready.',color:'aqua'}
