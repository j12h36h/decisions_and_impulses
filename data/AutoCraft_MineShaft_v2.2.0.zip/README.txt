AutoCraft MineShaft v2.1 — DAI 1.9.9

FLOORS 1–10 CAMPAIGN

CORE LOOP
- Combat remains completely manual. DAI does not aim, attack, move, eat, or select weapons for the player.
- DAI 1.9.9 experience controls now explicitly disable autonomous movement, combat and world editing for this experience.
- Rooms and connector tunnels are carved physically only after a route is unlocked.
- Every normal clear awards progression toward the next room.
- The last normal room awards a Boss Key.
- Boss completion unlocks the next floor and awards a unique memento representing the floor just conquered.
- The single north Home lift always launches the deepest floor currently unlocked.
- Safety Rope returns Home without deleting permanent progression or equipment, and explicitly switches the player back to Survival after the Home teleport.
- Home now includes a compact east-side farm for food, crops, composting and storage between expeditions.
- Home runs in Survival mode while every active MineShaft floor runs in Adventure mode.
- The authored Home/farm foundations, outer walls, ceilings and north-lift frame are protected from breaking through DAI 1.9.9 reaction cancellation; crops and interior utility blocks remain usable.

FLOORS
1 — Slimeworks
    Existing slime introduction and Slime Foreman.

2 — Abandoned Shafts
    Existing mixed slime/miner floor and Lost Overseer.

3 — Flooded Excavation
    Prismarine pumping works, drowned crews, flooded-industrial dressing.
    Boss: Drowned Surveyor.

4 — Fungal Hollows
    Moss, webs, spiders, venom and overgrown mine chambers.
    Boss: Sporekeeper.

5 — Deep Foundry
    Blackstone foundry rooms, magma hazards and smelting crews.
    Boss: Furnace Foreman. Magma split children are completion-tracked.

6 — Crystal Fault
    Calcite/amethyst chambers, dripstone obstacles and ranged combat.
    Boss: Resonant Prospector.

7 — Industrial Deepworks
    Copper/redstone machinery rooms with pillager/vindicator combat.
    Boss: Chief Engineer.

8 — Nether Breach
    Basalt, blackstone, soul-sand/magma hazards and Nether enemies.
    Boss: Rift Superintendent.

9 — Ancient Depths
    Sculk-infested chambers, darkness pressure and potion-based enemies.
    Boss: Deep Surveyor.

10 — Heart of the Mine
    A mixed-mechanics finale using visual motifs and enemy families from prior floors.
    Final encounter is three phases:
      I   Excavation Engine
      II  Mine Director + guards
      III Heartbound Director
    Completion awards the Floor X memento: Heart of the Mine.

ROUTE IDENTITY
- Floors 3–10 have named route choices and separate room themes.
- Each floor contains five generated rooms:
    Start -> branch choice -> branch room -> convergence -> boss.
- The sidebar map continues to reveal the path as the player physically explores it.
- Route generation remains on-demand instead of teleporting between prebuilt rooms.

WORLD / GENERATION ARCHITECTURE
- New AutoCraft MineShaft experience worlds use DAI 1.9.9 native void world_type generation.
- The generated experience world contains the authored void Overworld only; Nether and End are disabled by the world_type definition.
- Home and every MineShaft room/corridor are authored entirely by the datapack.
- Floors 3–10 remain isolated deep sectors at a safe Y level rather than stacking below Y -64.
- Every floor reset temporarily force-loads its complete reserved sector before remote fill/carve commands run, then releases it immediately after the starting chamber is generated.
- This prevents the Floor 5+ unloaded-chunk failure seen in v0.5.0 and keeps failed generation from exposing natural terrain.
- The Home lift and progression still present all sectors as descending floors.
- World generator changes apply only to newly created experience worlds; an existing save keeps its original generator.

HOME FARM
- The retired east-side Floor-2 gate location is now a timber-framed arch into a dedicated farm room.
- The room contains irrigated mature wheat and carrot beds, a small sweet-berry harvest row, a composter, barrel and hay storage.
- The farm is built once rather than reconstructed every Home return, so its crop state persists naturally.
- Existing saves receive the farm through a Home-safe v0.5.5 migration without resetting inventory, gear, progression or dungeon geometry.

MODE / HOME PROTECTION
- Home is explicitly Survival mode on first join, resume, ordinary Home return, death recovery and Safety Rope retreat.
- The Safety Rope applies Survival after the Home teleport, so Adventure mode cannot leak back into the hub.
- Floors 1–10 explicitly apply Adventure mode after their floor teleport.
- Tick-level enforcement repairs the mode if another command/mod changes it unexpectedly.
- DAI 1.9.9 player_start_break_block cancel reactions protect only the authored Home/farm shell planes and lift frame instead of blanket-protecting the whole room.
- Farm crops, barrels, crafting stations and other interior interactables are therefore not blocked by the foundation protection.

FLOOR MEMENTOS
- Legacy next-floor sigil crystals are retired. Unlock progression remains scoreboard-owned and does not require carrying a trophy.
- Floor 1: Foreman’s Core — Slimeworks.
- Floor 2: Overseer’s Compass — Abandoned Shafts.
- Floor 3: Surveyor’s Lens — Flooded Excavation.
- Floor 4: Sporekeeper’s Bloom — Fungal Hollows.
- Floor 5: Foundry Heart — Deep Foundry.
- Floor 6: Resonant Lens — Crystal Fault.
- Floor 7: Engineer’s Pocketwatch — Industrial Deepworks.
- Floor 8: Rift Cinder — Nether Breach.
- Floor 9: Deep Survey Fragment — Ancient Depths.
- Floor 10: Heart of the Mine — campaign completion.
- Existing saves convert their old sigils into the mementos for floors already cleared. Floor 10 is granted only when arpg2_campaign_clear is present.

LIGHTING / CORRIDOR FIXES
- Home lighting uses ordinary vanilla wall torches mounted only on permanent deepslate walls.
- Legacy Home lantern/chain positions are cleared by the retained non-destructive v0.5.3 migration.
- Every generated corridor clears the two doorway wall torches before removing their support wall, preventing torch item drops when a route opens.

PRESENTATION / IDENTITY
- The pack and experience are now named AutoCraft MineShaft.
- New experience saves are named AutoCraft MineShaft.
- The title screen and first-join presentation use the AutoCraft MineShaft identity.
- The internal experience id remains dai_auto_rpg:auto_rpg so existing Auto RPG / MineShaft saves remain discoverable after the rename.
- Floor/room title timing remains shortened to reduce screen obstruction.
- The Home actionbar identifies the deepest unlocked floor through Floor 10.
- The AutoCraft MineShaft Guide documents all ten floors.

SAVE COMPATIBILITY
- v0.4.x progression migrations are retained.
- Existing players with Floor 3 already unlocked can immediately enter Floor 3.
- v0.5.0 campaign migration is retained.
- v0.5.3 Home-lighting migration is retained and does not rebuild storage or reset progression.
- v2.1 memento migration is Home-safe, removes legacy sigil collectibles and reconstructs trophies from permanent unlock/campaign state.
- Existing Floor 1 / Floor 2 geometry, combat logic, keys and Safety Rope are preserved.
- The Home room is expanded only through the retired east-side gate wall; the bed, workshop and north lift remain in their established positions.
- Existing worlds created under the former DAI Auto RPG naming remain matched through the unchanged internal experience id.

DAI 1.9.9 COMPATIBILITY
- pack_format remains 48, matching the current DAI/Minecraft target.
- pack.mcmeta declares dai.version = 2.1 for DAI-managed global/world datapack version synchronization.
- Existing dai_experiences, dai_title_screens, dai_worldgen and reactions layouts remain valid in DAI 1.9.9.
- Reaction conditions continue to use the centralized 1.9.9 condition evaluator and registered reaction condition providers.
- Server-owned function actions remain compatible with DAI 1.9.9 authoritative action dispatch.
- Experience controls explicitly enforce this pack's manual-play policy.

DEBUG
- debug/floor3 through debug/floor10 remain available for direct floor testing.
- Each debug function sets the required unlock and starts that floor.

RUNTIME NOTE
- Static validation is included in VALIDATION.txt.
- Minecraft runtime testing remains authoritative for balance, mob AI, block-state behavior and DAI reaction timing.
