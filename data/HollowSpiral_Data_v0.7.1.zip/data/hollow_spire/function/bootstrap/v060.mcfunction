# v0.7.1: clear temporary active-room dispatcher tags after upgrade/reload.
tag @e[type=minecraft:marker,tag=hs_pulse_active] remove hs_pulse_active
tag @e[type=minecraft:marker,tag=hs_farm_active] remove hs_farm_active
data modify storage hollow_spire:runtime v060 set value 1b
