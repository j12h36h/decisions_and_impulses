function hollow_spire:bootstrap/ensure
execute unless data storage hollow_spire:runtime {v020:1b} run function hollow_spire:bootstrap/v020
execute unless data storage hollow_spire:runtime {v021:1b} run function hollow_spire:bootstrap/v021
execute unless data storage hollow_spire:runtime {v023:1b} run function hollow_spire:bootstrap/v023
execute unless data storage hollow_spire:runtime {v024:1b} run function hollow_spire:bootstrap/v024
execute unless data storage hollow_spire:runtime {v025:1b} run function hollow_spire:bootstrap/v025
execute unless data storage hollow_spire:runtime {v026:1b} run function hollow_spire:bootstrap/v026
execute unless data storage hollow_spire:runtime {v050:1b} run function hollow_spire:bootstrap/v050
execute unless data storage hollow_spire:runtime {v060:1b} run function hollow_spire:bootstrap/v060
scoreboard players set #tick hs_world 0
scoreboard players set #eco hs_world 0
