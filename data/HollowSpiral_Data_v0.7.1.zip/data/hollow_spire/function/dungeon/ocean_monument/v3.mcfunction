# GOLD CORE // Gold shrine behind a guardian gallery.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:prismarine_bricks replace minecraft:deepslate_tiles
execute positioned ~0 ~0 ~9 run function hollow_spire:dungeon/structures/monument/gold_shrine
execute positioned ~-12 ~0 ~-10 run function hollow_spire:dungeon/structures/monument/pillar
execute positioned ~10 ~0 ~-10 run function hollow_spire:dungeon/structures/monument/pillar
execute positioned ~-12 ~0 ~8 run function hollow_spire:dungeon/structures/monument/pillar
execute positioned ~10 ~0 ~8 run function hollow_spire:dungeon/structures/monument/pillar
execute positioned ~-13 ~0 ~-5 run function hollow_spire:dungeon/structures/monument/arch_x
summon minecraft:elder_guardian ~0 ~2 ~10 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"OCEAN MONUMENT // GOLD CORE","color":"gold","bold":true}]
