# INNER SANCTUM // Prismarine arches and a contained guardian pool.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:prismarine_bricks replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-9 run function hollow_spire:dungeon/structures/monument/arch_x
execute positioned ~7 ~0 ~9 run function hollow_spire:dungeon/structures/monument/arch_x
execute positioned ~-10 ~0 ~9 run function hollow_spire:dungeon/structures/monument/pillar
execute positioned ~9 ~0 ~-10 run function hollow_spire:dungeon/structures/monument/pillar
execute positioned ~9 ~0 ~9 run function hollow_spire:dungeon/structures/monument/pool
summon minecraft:guardian ~9 ~3 ~9 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"OCEAN MONUMENT // INNER SANCTUM","color":"aqua","bold":true}]
