# GUARDIAN GALLERY // Two contained pools with an elevated prismarine promenade.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:dark_prismarine replace minecraft:deepslate_tiles
execute positioned ~-9 ~0 ~8 run function hollow_spire:dungeon/structures/monument/pool
execute positioned ~9 ~0 ~-8 run function hollow_spire:dungeon/structures/monument/pool
execute positioned ~-13 ~0 ~-11 run function hollow_spire:dungeon/structures/monument/arch_x
execute positioned ~7 ~0 ~11 run function hollow_spire:dungeon/structures/monument/arch_x
fill ~-9 ~1 ~-2 ~-4 ~2 ~2 minecraft:prismarine_bricks
fill ~4 ~1 ~-2 ~9 ~2 ~2 minecraft:prismarine_bricks
summon minecraft:guardian ~-9 ~3 ~8 {Tags:["hs_hostile"]}
summon minecraft:guardian ~9 ~3 ~-8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"OCEAN MONUMENT // GUARDIAN GALLERY","color":"aqua","bold":true}]
