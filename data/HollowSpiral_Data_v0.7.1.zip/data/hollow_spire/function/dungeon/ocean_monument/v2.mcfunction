# SPONGE CHAMBER // Dry sponge vault with repeated monument arches.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:prismarine replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-10 run function hollow_spire:dungeon/structures/monument/arch_x
execute positioned ~7 ~0 ~-10 run function hollow_spire:dungeon/structures/monument/arch_x
fill ~-11 ~1 ~7 ~-7 ~4 ~11 minecraft:wet_sponge
fill ~7 ~1 ~7 ~11 ~4 ~11 minecraft:sponge
execute positioned ~-11 ~0 ~-4 run function hollow_spire:dungeon/structures/monument/pillar
execute positioned ~10 ~0 ~4 run function hollow_spire:dungeon/structures/monument/pillar
summon minecraft:guardian ~8 ~1 ~-8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"OCEAN MONUMENT // SPONGE CHAMBER","color":"aqua","bold":true}]
