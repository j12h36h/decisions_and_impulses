function hollow_spire:dungeon/room/base
execute store result score @s hs_room_roll run random value 1..100
execute if score @s hs_room_roll matches 1..5 run function hollow_spire:dungeon/room_types/ruins
execute if score @s hs_room_roll matches 6..9 run function hollow_spire:dungeon/room_types/carrot_farm
execute if score @s hs_room_roll matches 10..13 run function hollow_spire:dungeon/room_types/wheat_farm
execute if score @s hs_room_roll matches 14..18 run function hollow_spire:dungeon/room_types/tree_grove
execute if score @s hs_room_roll matches 19..28 run function hollow_spire:dungeon/room_types/depth_mine
execute if score @s hs_room_roll matches 29..32 run function hollow_spire:dungeon/room_types/lush_cave
execute if score @s hs_room_roll matches 33..34 run function hollow_spire:dungeon/room_types/animal_pen
execute if score @s hs_room_roll matches 35..39 run function hollow_spire:dungeon/room_types/crypt
execute if score @s hs_room_roll matches 40..42 run function hollow_spire:dungeon/room_types/library
execute if score @s hs_room_roll matches 43..45 run function hollow_spire:dungeon/room_types/smithery
execute if score @s hs_room_roll matches 46..49 run function hollow_spire:dungeon/room_types/village
execute if score @s hs_room_roll matches 50..53 run function hollow_spire:dungeon/room_types/ocean
execute if score @s hs_room_roll matches 54..57 run function hollow_spire:dungeon/room_types/castle
execute if score @s hs_room_roll matches 58..61 run function hollow_spire:dungeon/room_types/caverns
execute if score @s hs_room_roll matches 62..64 run function hollow_spire:dungeon/room_types/volcano
execute if score @s hs_room_roll matches 65..67 run function hollow_spire:dungeon/room_types/nether_wastes
execute if score @s hs_room_roll matches 68..69 run function hollow_spire:dungeon/room_types/nether_fortress
execute if score @s hs_room_roll matches 70..71 run function hollow_spire:dungeon/room_types/deep_dark
execute if score @s hs_room_roll matches 72 run function hollow_spire:dungeon/room_types/end_relic
execute if score @s hs_room_roll matches 73..77 run function hollow_spire:dungeon/room_types/trial_chamber
execute if score @s hs_room_roll matches 78..81 run function hollow_spire:dungeon/room_types/stronghold
execute if score @s hs_room_roll matches 82..84 run function hollow_spire:dungeon/room_types/woodland_mansion
execute if score @s hs_room_roll matches 85..87 run function hollow_spire:dungeon/room_types/bastion_remnant
execute if score @s hs_room_roll matches 88..90 run function hollow_spire:dungeon/room_types/ocean_monument
execute if score @s hs_room_roll matches 91..94 run function hollow_spire:dungeon/room_types/abandoned_mineshaft
execute if score @s hs_room_roll matches 95..97 run function hollow_spire:dungeon/room_types/temple
execute if score @s hs_room_roll matches 98..100 run function hollow_spire:dungeon/room_types/end_city
# Room-specific construction may touch floor controls; make the six discovery controls authoritative after generation.
function hollow_spire:dungeon/room/restore_controls
scoreboard players add #rooms hs_world 1
tag @s remove hs_new
