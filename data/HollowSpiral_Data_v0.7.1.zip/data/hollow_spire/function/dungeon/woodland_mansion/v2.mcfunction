# LIBRARY // Two substantial bookshelf rooms joined by timber framing.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:dark_oak_planks replace minecraft:deepslate_tiles
execute positioned ~-12 ~0 ~-11 run function hollow_spire:dungeon/structures/mansion/bookshelf_room
execute positioned ~7 ~0 ~5 run function hollow_spire:dungeon/structures/mansion/bookshelf_room
execute positioned ~-13 ~0 ~11 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
execute positioned ~7 ~0 ~-12 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
setblock ~10 ~1 ~-9 minecraft:chest
loot insert ~10 ~1 ~-9 loot minecraft:chests/woodland_mansion
summon minecraft:evoker ~9 ~1 ~8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"WOODLAND MANSION // LIBRARY","color":"dark_green","bold":true}]
