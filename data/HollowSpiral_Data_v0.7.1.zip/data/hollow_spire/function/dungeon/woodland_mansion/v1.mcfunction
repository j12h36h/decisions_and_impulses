# GREAT HALL // Timber bays, staircase, fireplace and illager patrol.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:dark_oak_planks replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-12 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
execute positioned ~7 ~0 ~-12 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
execute positioned ~-13 ~0 ~11 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
execute positioned ~7 ~0 ~11 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
execute positioned ~-10 ~0 ~7 run function hollow_spire:dungeon/structures/mansion/stair_landing
execute positioned ~10 ~0 ~8 run function hollow_spire:dungeon/structures/mansion/fireplace
fill ~-2 ~1 ~8 ~2 ~1 ~12 minecraft:red_carpet
summon minecraft:vindicator ~9 ~1 ~-8 {Tags:["hs_hostile"]}
summon minecraft:vindicator ~-9 ~1 ~8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"WOODLAND MANSION // GREAT HALL","color":"dark_green","bold":true}]
