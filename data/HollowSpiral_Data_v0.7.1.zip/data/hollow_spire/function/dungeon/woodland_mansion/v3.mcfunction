# JAIL WING // Timber corridor with two barred cells and a landing.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:dark_oak_planks replace minecraft:deepslate_tiles
fill ~-12 ~1 ~-11 ~-7 ~5 ~-6 minecraft:dark_oak_planks hollow
fill ~7 ~1 ~6 ~12 ~5 ~11 minecraft:dark_oak_planks hollow
fill ~-10 ~1 ~-6 ~-8 ~3 ~-6 minecraft:iron_bars
fill ~8 ~1 ~6 ~10 ~3 ~6 minecraft:iron_bars
execute positioned ~-13 ~0 ~11 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
execute positioned ~7 ~0 ~-12 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
execute positioned ~-10 ~0 ~5 run function hollow_spire:dungeon/structures/mansion/stair_landing
summon minecraft:vindicator ~9 ~1 ~-8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"WOODLAND MANSION // JAIL WING","color":"dark_green","bold":true}]
