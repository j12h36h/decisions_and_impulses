# DUEL HALL // Symmetrical galleries, fireplaces and central carpet arena.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:dark_oak_planks replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-12 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
execute positioned ~7 ~0 ~11 run function hollow_spire:dungeon/structures/mansion/timber_bay_x
execute positioned ~-10 ~0 ~-9 run function hollow_spire:dungeon/structures/mansion/fireplace
execute positioned ~10 ~0 ~9 run function hollow_spire:dungeon/structures/mansion/fireplace
fill ~-3 ~1 ~-11 ~3 ~1 ~-5 minecraft:red_carpet
fill ~-3 ~1 ~5 ~3 ~1 ~11 minecraft:blue_carpet
summon minecraft:evoker ~8 ~1 ~-8 {Tags:["hs_hostile"]}
summon minecraft:vindicator ~-8 ~1 ~8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"WOODLAND MANSION // DUEL HALL","color":"dark_green","bold":true}]
