# BRIDGE // Two offset bridge spans between ruined support piers.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:blackstone replace minecraft:deepslate_tiles
execute positioned ~-12 ~0 ~-7 run function hollow_spire:dungeon/structures/bastion/pier
execute positioned ~10 ~0 ~7 run function hollow_spire:dungeon/structures/bastion/pier
execute positioned ~-11 ~0 ~-8 run function hollow_spire:dungeon/structures/bastion/bridge_x
execute positioned ~2 ~0 ~7 run function hollow_spire:dungeon/structures/bastion/bridge_x
fill ~-12 ~1 ~8 ~-8 ~3 ~12 minecraft:cracked_polished_blackstone_bricks outline
summon minecraft:piglin ~-8 ~1 ~9 {Tags:["hs_hostile"]}
summon minecraft:piglin ~8 ~1 ~-9 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"BASTION // BRIDGE","color":"gold","bold":true}]
