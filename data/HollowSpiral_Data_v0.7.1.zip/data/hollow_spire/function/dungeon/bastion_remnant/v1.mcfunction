# TREASURE HOLD // Four broken piers surround a compact gold shrine.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:blackstone replace minecraft:deepslate_tiles
execute positioned ~-11 ~0 ~-11 run function hollow_spire:dungeon/structures/bastion/pier
execute positioned ~9 ~0 ~-11 run function hollow_spire:dungeon/structures/bastion/pier
execute positioned ~-11 ~0 ~9 run function hollow_spire:dungeon/structures/bastion/pier
execute positioned ~9 ~0 ~9 run function hollow_spire:dungeon/structures/bastion/pier
execute positioned ~0 ~0 ~9 run function hollow_spire:dungeon/structures/bastion/treasure_dais
setblock ~0 ~3 ~11 minecraft:chest
loot insert ~0 ~3 ~11 loot minecraft:chests/bastion_treasure
summon minecraft:piglin_brute ~-8 ~1 ~8 {Tags:["hs_hostile"]}
summon minecraft:piglin ~8 ~1 ~-8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"BASTION // TREASURE HOLD","color":"gold","bold":true}]
