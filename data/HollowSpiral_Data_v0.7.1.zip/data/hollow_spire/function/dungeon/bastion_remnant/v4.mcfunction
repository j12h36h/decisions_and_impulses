# HOUSING // Broken blackstone homes linked by crimson walkways.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:polished_blackstone_bricks replace minecraft:deepslate_tiles
fill ~-12 ~1 ~-11 ~-7 ~5 ~-6 minecraft:blackstone hollow
fill ~7 ~1 ~6 ~12 ~5 ~11 minecraft:blackstone hollow
fill ~-11 ~1 ~7 ~-6 ~4 ~11 minecraft:crimson_planks hollow
fill ~6 ~1 ~-11 ~11 ~4 ~-7 minecraft:crimson_planks hollow
execute positioned ~-12 ~0 ~7 run function hollow_spire:dungeon/structures/bastion/pier
execute positioned ~10 ~0 ~-9 run function hollow_spire:dungeon/structures/bastion/pier
summon minecraft:piglin ~-9 ~1 ~-8 {Tags:["hs_hostile"]}
summon minecraft:piglin_brute ~9 ~1 ~8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"BASTION // HOUSING","color":"gold","bold":true}]
