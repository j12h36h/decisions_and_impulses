# HOGLIN STABLE // Two real crimson pens between blackstone piers.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:blackstone replace minecraft:deepslate_tiles
execute positioned ~-12 ~0 ~-12 run function hollow_spire:dungeon/structures/bastion/hoglin_pen
execute positioned ~6 ~0 ~6 run function hollow_spire:dungeon/structures/bastion/hoglin_pen
execute positioned ~-11 ~0 ~8 run function hollow_spire:dungeon/structures/bastion/pier
execute positioned ~9 ~0 ~-10 run function hollow_spire:dungeon/structures/bastion/pier
summon minecraft:hoglin ~-9 ~2 ~-9 {Tags:["hs_hostile"]}
summon minecraft:hoglin ~9 ~2 ~9 {Tags:["hs_hostile"]}
summon minecraft:piglin ~9 ~1 ~-8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"BASTION // HOGLIN STABLE","color":"gold","bold":true}]
