# JUNGLE SHRINE // Mossy stepped temple, tripwire gallery and hidden chest.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:moss_block replace minecraft:deepslate_tiles
execute positioned ~8 ~0 ~8 run function hollow_spire:dungeon/structures/temple/jungle_shrine
fill ~-12 ~1 ~7 ~-8 ~3 ~11 minecraft:mossy_cobblestone outline
setblock ~-10 ~1 ~9 minecraft:chest
fill ~7 ~1 ~-12 ~12 ~1 ~-8 minecraft:mud
setblock ~9 ~2 ~-10 minecraft:vine
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TEMPLE // JUNGLE SHRINE","color":"green","bold":true}]
