# DESERT PYRAMID // Recognizable stepped pyramid placed off-center to preserve Spiral controls.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:sandstone replace minecraft:deepslate_tiles
execute positioned ~8 ~0 ~8 run function hollow_spire:dungeon/structures/temple/desert_pyramid
fill ~-12 ~1 ~7 ~-7 ~3 ~12 minecraft:sandstone outline
setblock ~-10 ~2 ~10 minecraft:suspicious_sand
setblock ~-8 ~2 ~9 minecraft:decorated_pot
summon minecraft:husk ~-9 ~1 ~9 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TEMPLE // DESERT PYRAMID","color":"yellow","bold":true}]
