# SPIDER DEN // Supported timber nest with webbed side galleries.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:stone replace minecraft:deepslate_tiles
execute positioned ~-9 ~0 ~8 run function hollow_spire:dungeon/structures/mineshaft/spider_nest
execute positioned ~7 ~0 ~-10 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~-12 ~0 ~-10 run function hollow_spire:dungeon/structures/mineshaft/support_x
fill ~7 ~1 ~7 ~12 ~4 ~12 minecraft:cobweb replace minecraft:air
summon minecraft:cave_spider ~-9 ~2 ~8 {Tags:["hs_hostile"]}
summon minecraft:cave_spider ~8 ~1 ~-8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"ABANDONED MINESHAFT // SPIDER DEN","color":"dark_red","bold":true}]
