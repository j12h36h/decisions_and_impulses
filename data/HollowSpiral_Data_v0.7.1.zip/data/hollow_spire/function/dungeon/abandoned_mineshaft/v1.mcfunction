# CROSSROAD // Four support frames and crossing rail lines.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:stone replace minecraft:deepslate_tiles
execute positioned ~-12 ~0 ~-10 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~6 ~0 ~-10 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~-12 ~0 ~10 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~6 ~0 ~10 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~-12 ~0 ~-7 run function hollow_spire:dungeon/structures/mineshaft/rail_x
execute positioned ~4 ~0 ~7 run function hollow_spire:dungeon/structures/mineshaft/rail_x
execute positioned ~10 ~0 ~-8 run function hollow_spire:dungeon/structures/mineshaft/cache
summon minecraft:cave_spider ~-9 ~1 ~8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"ABANDONED MINESHAFT // CROSSROAD","color":"gold","bold":true}]
