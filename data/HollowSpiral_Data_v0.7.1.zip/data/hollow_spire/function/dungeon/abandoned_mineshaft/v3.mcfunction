# COLLAPSED TUNNEL // Broken supports, gravel fall and interrupted rails.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:stone replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-9 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~7 ~0 ~9 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~-12 ~0 ~-6 run function hollow_spire:dungeon/structures/mineshaft/rail_x
fill ~7 ~1 ~-11 ~12 ~3 ~-7 minecraft:gravel
fill ~-12 ~1 ~7 ~-8 ~2 ~11 minecraft:cobbled_deepslate
setblock ~10 ~4 ~-9 minecraft:pointed_dripstone[vertical_direction=down]
setblock ~-10 ~2 ~9 minecraft:cobweb
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"ABANDONED MINESHAFT // COLLAPSE","color":"gold","bold":true}]
