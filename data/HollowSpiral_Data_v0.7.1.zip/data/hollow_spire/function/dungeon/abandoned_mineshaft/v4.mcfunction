# RAIL DEPOT // Multiple rail spurs, caches and repeated supports.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:stone replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-10 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~-13 ~0 ~10 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~7 ~0 ~-10 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~7 ~0 ~10 run function hollow_spire:dungeon/structures/mineshaft/support_x
execute positioned ~-12 ~0 ~-7 run function hollow_spire:dungeon/structures/mineshaft/rail_x
execute positioned ~4 ~0 ~7 run function hollow_spire:dungeon/structures/mineshaft/rail_x
execute positioned ~-10 ~0 ~8 run function hollow_spire:dungeon/structures/mineshaft/cache
execute positioned ~10 ~0 ~-8 run function hollow_spire:dungeon/structures/mineshaft/cache
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"ABANDONED MINESHAFT // RAIL DEPOT","color":"gold","bold":true}]
