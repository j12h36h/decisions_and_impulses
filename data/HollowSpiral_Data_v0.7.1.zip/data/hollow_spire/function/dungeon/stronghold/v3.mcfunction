# CELLS // Four offset prison cells with a central guarded passage.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:stone_bricks replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-12 run function hollow_spire:dungeon/structures/stronghold/cell
execute positioned ~8 ~0 ~-12 run function hollow_spire:dungeon/structures/stronghold/cell
execute positioned ~-13 ~0 ~7 run function hollow_spire:dungeon/structures/stronghold/cell
execute positioned ~8 ~0 ~7 run function hollow_spire:dungeon/structures/stronghold/cell
execute positioned ~-3 ~0 ~9 run function hollow_spire:dungeon/structures/stronghold/arch_x
summon minecraft:zombie ~-10 ~1 ~-10 {Tags:["hs_hostile"]}
summon minecraft:skeleton ~10 ~1 ~10 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"STRONGHOLD // PRISON WING","color":"gray","bold":true}]
