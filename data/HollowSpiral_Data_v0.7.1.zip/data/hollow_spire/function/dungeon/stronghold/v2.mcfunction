# ARCHIVE // Multiple library bays around a navigable center.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:stone_bricks replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-12 run function hollow_spire:dungeon/structures/stronghold/book_bay
execute positioned ~11 ~0 ~5 run function hollow_spire:dungeon/structures/stronghold/book_bay
execute positioned ~-13 ~0 ~5 run function hollow_spire:dungeon/structures/stronghold/book_bay
execute positioned ~7 ~0 ~-9 run function hollow_spire:dungeon/structures/stronghold/arch_x
setblock ~10 ~1 ~10 minecraft:chest
loot insert ~10 ~1 ~10 loot minecraft:chests/stronghold_library
summon minecraft:silverfish ~9 ~1 ~-8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"STRONGHOLD // ARCHIVE","color":"gray","bold":true}]
