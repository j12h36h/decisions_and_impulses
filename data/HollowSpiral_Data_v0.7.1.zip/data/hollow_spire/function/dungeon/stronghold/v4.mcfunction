# PORTAL SANCTUM // Incomplete portal dais with arches and silverfish guard.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:stone_bricks replace minecraft:deepslate_tiles
execute positioned ~0 ~0 ~8 run function hollow_spire:dungeon/structures/stronghold/portal_dais
execute positioned ~-13 ~0 ~-9 run function hollow_spire:dungeon/structures/stronghold/arch_x
execute positioned ~7 ~0 ~-9 run function hollow_spire:dungeon/structures/stronghold/arch_x
fill ~-10 ~1 ~7 ~-7 ~4 ~10 minecraft:iron_bars
summon minecraft:silverfish ~-8 ~1 ~-8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"STRONGHOLD // PORTAL SANCTUM","color":"dark_purple","bold":true}]
