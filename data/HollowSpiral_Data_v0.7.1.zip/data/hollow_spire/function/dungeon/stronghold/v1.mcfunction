# CROSSING // Four real archways, side cells and cracked masonry.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:stone_bricks replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-8 run function hollow_spire:dungeon/structures/stronghold/arch_x
execute positioned ~7 ~0 ~8 run function hollow_spire:dungeon/structures/stronghold/arch_x
execute positioned ~-12 ~0 ~7 run function hollow_spire:dungeon/structures/stronghold/cell
execute positioned ~8 ~0 ~-11 run function hollow_spire:dungeon/structures/stronghold/cell
fill ~-12 ~1 ~-3 ~-8 ~1 ~3 minecraft:cracked_stone_bricks
fill ~8 ~1 ~-3 ~12 ~1 ~3 minecraft:mossy_stone_bricks
summon minecraft:silverfish ~10 ~1 ~8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"STRONGHOLD // CROSSING","color":"gray","bold":true}]
