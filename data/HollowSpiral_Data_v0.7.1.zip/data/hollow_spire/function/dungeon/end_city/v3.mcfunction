# TREASURE HOUSE // Loot room, tower and balcony composition.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:end_stone_bricks replace minecraft:deepslate_tiles
execute positioned ~9 ~0 ~8 run function hollow_spire:dungeon/structures/end_city/loot_room
execute positioned ~-10 ~0 ~-9 run function hollow_spire:dungeon/structures/end_city/tower
execute positioned ~-10 ~0 ~8 run function hollow_spire:dungeon/structures/end_city/balcony
setblock ~9 ~2 ~10 minecraft:chest
loot insert ~9 ~2 ~10 loot minecraft:chests/end_city_treasure
summon minecraft:shulker ~9 ~2 ~8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"END CITY // TREASURE HOUSE","color":"light_purple","bold":true}]
