# TOWER CROSSING // Two purpur towers connected by a real elevated bridge.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:end_stone_bricks replace minecraft:deepslate_tiles
execute positioned ~-10 ~0 ~-9 run function hollow_spire:dungeon/structures/end_city/tower
execute positioned ~10 ~0 ~7 run function hollow_spire:dungeon/structures/end_city/tower
execute positioned ~-7 ~0 ~-8 run function hollow_spire:dungeon/structures/end_city/bridge_x
execute positioned ~-10 ~0 ~8 run function hollow_spire:dungeon/structures/end_city/balcony
summon minecraft:shulker ~-10 ~2 ~-9 {Tags:["hs_hostile"]}
summon minecraft:shulker ~10 ~2 ~7 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"END CITY // TOWER CROSSING","color":"light_purple","bold":true}]
