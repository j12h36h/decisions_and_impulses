# CHORUS TERRACE // Open end-stone gardens below two purpur structures.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:end_stone replace minecraft:deepslate_tiles
execute positioned ~-10 ~0 ~-9 run function hollow_spire:dungeon/structures/end_city/tower
execute positioned ~10 ~0 ~8 run function hollow_spire:dungeon/structures/end_city/balcony
fill ~-12 ~1 ~7 ~-7 ~1 ~12 minecraft:end_stone
fill ~7 ~1 ~-12 ~12 ~1 ~-7 minecraft:end_stone
setblock ~-9 ~2 ~9 minecraft:chorus_flower
setblock ~9 ~2 ~-9 minecraft:chorus_flower
setblock ~-11 ~2 ~8 minecraft:chorus_plant
setblock ~11 ~2 ~-8 minecraft:chorus_plant
summon minecraft:shulker ~10 ~3 ~8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"END CITY // CHORUS TERRACE","color":"light_purple","bold":true}]
