# BRIDGE COURT // Elevated bridge and opposing shulker balconies.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:end_stone_bricks replace minecraft:deepslate_tiles
execute positioned ~-12 ~0 ~-9 run function hollow_spire:dungeon/structures/end_city/bridge_x
execute positioned ~3 ~0 ~9 run function hollow_spire:dungeon/structures/end_city/bridge_x
execute positioned ~-10 ~0 ~8 run function hollow_spire:dungeon/structures/end_city/balcony
execute positioned ~10 ~0 ~-8 run function hollow_spire:dungeon/structures/end_city/balcony
summon minecraft:shulker ~-10 ~3 ~8 {Tags:["hs_hostile"]}
summon minecraft:shulker ~10 ~3 ~-8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"END CITY // BRIDGE COURT","color":"light_purple","bold":true}]
