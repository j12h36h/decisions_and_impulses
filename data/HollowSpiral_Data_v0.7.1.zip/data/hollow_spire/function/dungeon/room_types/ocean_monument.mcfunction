# OCEAN MONUMENT // v0.7.1 authored modular structure family.
scoreboard players set @s hs_type 26
execute store result score @s hs_tmp run random value 1..4
execute if score @s hs_tmp matches 1 run function hollow_spire:dungeon/ocean_monument/v1
execute if score @s hs_tmp matches 2 run function hollow_spire:dungeon/ocean_monument/v2
execute if score @s hs_tmp matches 3 run function hollow_spire:dungeon/ocean_monument/v3
execute if score @s hs_tmp matches 4 run function hollow_spire:dungeon/ocean_monument/v4
