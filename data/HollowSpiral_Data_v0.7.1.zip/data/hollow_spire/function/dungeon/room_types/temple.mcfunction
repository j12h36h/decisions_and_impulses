# TEMPLE // v0.7.1 authored modular structure family.
scoreboard players set @s hs_type 28
execute store result score @s hs_tmp run random value 1..2
execute if score @s hs_tmp matches 1 run function hollow_spire:dungeon/temple/v1
execute if score @s hs_tmp matches 2 run function hollow_spire:dungeon/temple/v2
