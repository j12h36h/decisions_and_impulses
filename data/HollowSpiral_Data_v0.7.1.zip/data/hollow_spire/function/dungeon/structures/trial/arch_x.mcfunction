# Seven-block tuff arch along local X.
fill ~0 ~1 ~0 ~0 ~4 ~0 minecraft:tuff_bricks
fill ~6 ~1 ~0 ~6 ~4 ~0 minecraft:tuff_bricks
fill ~1 ~5 ~0 ~5 ~5 ~0 minecraft:polished_tuff
setblock ~1 ~4 ~0 minecraft:polished_tuff_stairs[facing=east,half=top]
setblock ~5 ~4 ~0 minecraft:polished_tuff_stairs[facing=west,half=top]
setblock ~3 ~5 ~0 minecraft:copper_bulb[lit=true]
