# Raised trial-spawner dais with copper-grate corners.
fill ~-2 ~1 ~-2 ~2 ~1 ~2 minecraft:polished_tuff
fill ~-1 ~2 ~-1 ~1 ~2 ~1 minecraft:tuff_bricks
setblock ~0 ~3 ~0 minecraft:trial_spawner
setblock ~-2 ~2 ~-2 minecraft:weathered_copper_grate
setblock ~2 ~2 ~-2 minecraft:weathered_copper_grate
setblock ~-2 ~2 ~2 minecraft:weathered_copper_grate
setblock ~2 ~2 ~2 minecraft:weathered_copper_grate
