# 2x2 tuff/copper illuminated structural pillar.
fill ~0 ~1 ~0 ~1 ~5 ~1 minecraft:tuff_bricks
setblock ~0 ~3 ~-1 minecraft:oxidized_copper_grate
setblock ~1 ~3 ~-1 minecraft:oxidized_copper_grate
setblock ~0 ~4 ~0 minecraft:copper_bulb[lit=true]
setblock ~1 ~4 ~1 minecraft:copper_bulb[lit=true]
setblock ~0 ~6 ~0 minecraft:polished_tuff_slab[type=bottom]
setblock ~1 ~6 ~1 minecraft:polished_tuff_slab[type=bottom]
