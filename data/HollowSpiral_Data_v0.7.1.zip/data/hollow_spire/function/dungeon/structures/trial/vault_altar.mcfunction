# Small vault altar, not a room-sized cuboid.
fill ~-2 ~1 ~-1 ~2 ~1 ~1 minecraft:chiseled_tuff
setblock ~-2 ~2 ~0 minecraft:polished_tuff_stairs[facing=east]
setblock ~2 ~2 ~0 minecraft:polished_tuff_stairs[facing=west]
setblock ~0 ~2 ~0 minecraft:vault
setblock ~0 ~3 ~1 minecraft:copper_bulb[lit=true]
