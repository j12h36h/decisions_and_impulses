# Prismarine monument arch.
fill ~0 ~1 ~0 ~0 ~5 ~0 minecraft:prismarine_bricks
fill ~6 ~1 ~0 ~6 ~5 ~0 minecraft:prismarine_bricks
fill ~1 ~6 ~0 ~5 ~6 ~0 minecraft:dark_prismarine
setblock ~1 ~5 ~0 minecraft:prismarine_stairs[facing=east,half=top]
setblock ~5 ~5 ~0 minecraft:prismarine_stairs[facing=west,half=top]
setblock ~3 ~6 ~0 minecraft:sea_lantern
