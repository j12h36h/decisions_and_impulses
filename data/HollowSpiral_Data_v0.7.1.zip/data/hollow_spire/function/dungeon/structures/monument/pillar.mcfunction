# Sea-lantern monument column.
fill ~0 ~1 ~0 ~1 ~5 ~1 minecraft:prismarine_bricks
setblock ~0 ~3 ~0 minecraft:sea_lantern
setblock ~1 ~5 ~1 minecraft:dark_prismarine
setblock ~0 ~6 ~0 minecraft:prismarine_brick_slab[type=bottom]
