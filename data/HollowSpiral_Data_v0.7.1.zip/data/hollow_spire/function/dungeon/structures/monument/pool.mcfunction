# Contained 7x7 guardian pool with rim.
fill ~-3 ~1 ~-3 ~3 ~1 ~3 minecraft:prismarine_bricks
fill ~-3 ~2 ~-3 ~3 ~2 ~3 minecraft:dark_prismarine outline
fill ~-2 ~2 ~-2 ~2 ~3 ~2 minecraft:water
setblock ~-3 ~2 ~0 minecraft:sea_lantern
setblock ~3 ~2 ~0 minecraft:sea_lantern
