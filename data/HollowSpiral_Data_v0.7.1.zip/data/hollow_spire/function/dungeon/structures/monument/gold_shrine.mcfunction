# Monument gold core shrine.
fill ~-3 ~1 ~-3 ~3 ~1 ~3 minecraft:prismarine_bricks
fill ~-2 ~2 ~-2 ~2 ~4 ~2 minecraft:dark_prismarine hollow
setblock ~0 ~2 ~0 minecraft:gold_block
setblock ~0 ~3 ~0 minecraft:gold_block
setblock ~0 ~4 ~0 minecraft:sea_lantern
