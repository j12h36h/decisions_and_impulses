# End-city bridge span with railings and lamps.
fill ~0 ~3 ~-1 ~9 ~3 ~1 minecraft:purpur_block
fill ~0 ~4 ~-2 ~9 ~4 ~-2 minecraft:purpur_slab[type=bottom]
fill ~0 ~4 ~2 ~9 ~4 ~2 minecraft:purpur_slab[type=bottom]
setblock ~2 ~5 ~-2 minecraft:end_rod[facing=up]
setblock ~7 ~5 ~2 minecraft:end_rod[facing=up]
