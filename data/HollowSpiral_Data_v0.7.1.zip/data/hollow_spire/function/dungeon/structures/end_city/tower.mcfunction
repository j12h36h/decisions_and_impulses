# Slender purpur tower with two real floors and end-rod lighting.
fill ~-2 ~1 ~-2 ~2 ~8 ~2 minecraft:purpur_block hollow
fill ~-1 ~4 ~-1 ~1 ~4 ~1 minecraft:purpur_block
setblock ~-2 ~3 ~-2 minecraft:end_rod[facing=up]
setblock ~2 ~6 ~2 minecraft:end_rod[facing=down]
setblock ~0 ~9 ~0 minecraft:purpur_pillar
