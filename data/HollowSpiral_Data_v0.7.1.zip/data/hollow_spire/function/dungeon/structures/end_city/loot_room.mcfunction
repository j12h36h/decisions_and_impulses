# End-city treasure room shell and chest.
fill ~-4 ~1 ~-4 ~4 ~5 ~4 minecraft:purpur_block hollow
fill ~-3 ~1 ~-3 ~3 ~1 ~3 minecraft:end_stone_bricks
setblock ~0 ~2 ~2 minecraft:chest
setblock ~-2 ~2 ~0 minecraft:end_rod[facing=up]
setblock ~2 ~2 ~0 minecraft:end_rod[facing=up]
