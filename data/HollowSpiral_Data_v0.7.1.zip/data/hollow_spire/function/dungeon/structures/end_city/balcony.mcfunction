# Shulker balcony with purpur stairs and end rods.
fill ~-3 ~2 ~-2 ~3 ~2 ~2 minecraft:purpur_block
fill ~-3 ~3 ~-2 ~3 ~3 ~-2 minecraft:purpur_slab[type=bottom]
fill ~-3 ~3 ~2 ~3 ~3 ~2 minecraft:purpur_slab[type=bottom]
setblock ~-3 ~4 ~0 minecraft:end_rod[facing=up]
setblock ~3 ~4 ~0 minecraft:end_rod[facing=up]
