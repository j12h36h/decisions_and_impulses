# L-shaped two-story library furniture cluster.
fill ~0 ~1 ~0 ~0 ~4 ~6 minecraft:bookshelf
fill ~0 ~1 ~6 ~5 ~4 ~6 minecraft:bookshelf
fill ~2 ~1 ~2 ~4 ~1 ~4 minecraft:dark_oak_planks
setblock ~3 ~2 ~3 minecraft:lectern[facing=south]
setblock ~1 ~5 ~5 minecraft:lantern[hanging=true]
