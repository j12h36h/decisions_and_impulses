# Short interior staircase and railing.
setblock ~0 ~1 ~0 minecraft:dark_oak_stairs[facing=east]
setblock ~1 ~2 ~0 minecraft:dark_oak_stairs[facing=east]
setblock ~2 ~3 ~0 minecraft:dark_oak_stairs[facing=east]
fill ~3 ~3 ~-1 ~6 ~3 ~1 minecraft:dark_oak_planks
fill ~0 ~2 ~-1 ~2 ~2 ~-1 minecraft:dark_oak_fence
