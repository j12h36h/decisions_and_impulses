# Stone fireplace with chimney and safe soul fire.
fill ~-2 ~1 ~0 ~2 ~1 ~1 minecraft:cobblestone
fill ~-2 ~2 ~0 ~-2 ~4 ~1 minecraft:stone_bricks
fill ~2 ~2 ~0 ~2 ~4 ~1 minecraft:stone_bricks
fill ~-1 ~4 ~0 ~1 ~5 ~1 minecraft:stone_bricks
setblock ~0 ~2 ~1 minecraft:soul_campfire[lit=true]
setblock ~0 ~3 ~0 minecraft:iron_bars
