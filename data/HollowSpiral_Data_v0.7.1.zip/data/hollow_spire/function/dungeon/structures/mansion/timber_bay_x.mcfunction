# Mansion timber wall bay with glass window.
fill ~0 ~1 ~0 ~0 ~5 ~0 minecraft:dark_oak_log
fill ~6 ~1 ~0 ~6 ~5 ~0 minecraft:dark_oak_log
fill ~1 ~1 ~0 ~5 ~1 ~0 minecraft:dark_oak_planks
fill ~1 ~5 ~0 ~5 ~5 ~0 minecraft:dark_oak_planks
fill ~1 ~2 ~0 ~2 ~4 ~0 minecraft:dark_oak_planks
fill ~4 ~2 ~0 ~5 ~4 ~0 minecraft:dark_oak_planks
fill ~3 ~2 ~0 ~3 ~4 ~0 minecraft:glass_pane
