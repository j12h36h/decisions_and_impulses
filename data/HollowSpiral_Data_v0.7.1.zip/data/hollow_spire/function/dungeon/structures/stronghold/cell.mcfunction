# 5x5 prison cell with stone shell and barred front.
fill ~0 ~1 ~0 ~4 ~4 ~4 minecraft:stone_bricks hollow
fill ~1 ~1 ~0 ~3 ~3 ~0 minecraft:iron_bars
setblock ~2 ~1 ~4 minecraft:mossy_stone_bricks
setblock ~1 ~4 ~1 minecraft:cracked_stone_bricks
