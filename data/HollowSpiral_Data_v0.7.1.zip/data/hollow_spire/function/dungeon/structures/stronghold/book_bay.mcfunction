# Stronghold archive alcove.
fill ~0 ~1 ~0 ~0 ~4 ~5 minecraft:stone_bricks
fill ~1 ~1 ~1 ~1 ~3 ~4 minecraft:bookshelf
setblock ~2 ~1 ~2 minecraft:lectern[facing=east]
setblock ~0 ~4 ~2 minecraft:lantern[hanging=true]
