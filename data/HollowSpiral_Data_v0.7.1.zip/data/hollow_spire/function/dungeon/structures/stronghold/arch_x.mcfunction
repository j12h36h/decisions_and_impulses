# Cracked/mossy stronghold arch.
fill ~0 ~1 ~0 ~0 ~4 ~0 minecraft:stone_bricks
fill ~6 ~1 ~0 ~6 ~4 ~0 minecraft:mossy_stone_bricks
fill ~1 ~5 ~0 ~5 ~5 ~0 minecraft:cracked_stone_bricks
setblock ~1 ~4 ~0 minecraft:stone_brick_stairs[facing=east,half=top]
setblock ~5 ~4 ~0 minecraft:stone_brick_stairs[facing=west,half=top]
