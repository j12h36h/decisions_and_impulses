# Incomplete End portal on a stepped stone-brick dais.
fill ~-4 ~1 ~-4 ~4 ~1 ~4 minecraft:stone_bricks
fill ~-3 ~2 ~-3 ~3 ~2 ~3 minecraft:cracked_stone_bricks
setblock ~-2 ~3 ~-2 minecraft:end_portal_frame[facing=south]
setblock ~-1 ~3 ~-2 minecraft:end_portal_frame[facing=south]
setblock ~0 ~3 ~-2 minecraft:end_portal_frame[facing=south]
setblock ~-2 ~3 ~2 minecraft:end_portal_frame[facing=north]
setblock ~-1 ~3 ~2 minecraft:end_portal_frame[facing=north]
setblock ~0 ~3 ~2 minecraft:end_portal_frame[facing=north]
setblock ~-3 ~3 ~-1 minecraft:end_portal_frame[facing=east]
setblock ~-3 ~3 ~0 minecraft:end_portal_frame[facing=east]
setblock ~-3 ~3 ~1 minecraft:end_portal_frame[facing=east]
setblock ~1 ~3 ~-1 minecraft:end_portal_frame[facing=west]
setblock ~1 ~3 ~0 minecraft:end_portal_frame[facing=west]
setblock ~1 ~3 ~1 minecraft:end_portal_frame[facing=west]
