# Stepped hollow sandstone pyramid with central shaft/trap chamber.
fill ~-8 ~1 ~-8 ~8 ~1 ~8 minecraft:sandstone
fill ~-7 ~2 ~-7 ~7 ~2 ~7 minecraft:sandstone outline
fill ~-6 ~3 ~-6 ~6 ~3 ~6 minecraft:cut_sandstone outline
fill ~-5 ~4 ~-5 ~5 ~4 ~5 minecraft:sandstone outline
fill ~-4 ~5 ~-4 ~4 ~5 ~4 minecraft:chiseled_sandstone outline
fill ~-2 ~1 ~-2 ~2 ~5 ~2 minecraft:air
setblock ~0 ~1 ~0 minecraft:blue_terracotta
setblock ~1 ~1 ~0 minecraft:orange_terracotta
setblock ~-1 ~1 ~0 minecraft:orange_terracotta
setblock ~0 ~1 ~1 minecraft:orange_terracotta
setblock ~0 ~1 ~-1 minecraft:orange_terracotta
fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 minecraft:sandstone
setblock ~0 ~-1 ~0 minecraft:stone_pressure_plate
setblock ~0 ~-2 ~0 minecraft:tnt
