# Mossy jungle shrine with stepped roof, tripwire gallery and hidden chest.
fill ~-7 ~1 ~-6 ~7 ~1 ~6 minecraft:mossy_cobblestone
fill ~-6 ~2 ~-5 ~6 ~5 ~5 minecraft:cobblestone hollow
fill ~-5 ~6 ~-4 ~5 ~6 ~4 minecraft:mossy_cobblestone outline
fill ~-4 ~7 ~-3 ~4 ~7 ~3 minecraft:cobblestone outline
fill ~-1 ~2 ~-5 ~1 ~4 ~-5 minecraft:air
setblock ~-4 ~2 ~0 minecraft:tripwire_hook[facing=east]
setblock ~4 ~2 ~0 minecraft:tripwire_hook[facing=west]
fill ~-3 ~2 ~0 ~3 ~2 ~0 minecraft:tripwire
setblock ~-5 ~2 ~2 minecraft:dispenser[facing=east]
setblock ~5 ~2 ~-2 minecraft:dispenser[facing=west]
setblock ~0 ~2 ~4 minecraft:chest
setblock ~-2 ~2 ~4 minecraft:lever[face=wall,facing=south]
setblock ~2 ~2 ~4 minecraft:lever[face=wall,facing=south]
