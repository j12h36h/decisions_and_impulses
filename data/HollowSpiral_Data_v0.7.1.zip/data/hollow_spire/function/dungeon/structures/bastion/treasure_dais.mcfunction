# Compact treasure altar with gold, not a solid treasure cube.
fill ~-3 ~1 ~-3 ~3 ~1 ~3 minecraft:polished_blackstone_bricks
fill ~-2 ~2 ~-2 ~2 ~2 ~2 minecraft:chiseled_polished_blackstone
setblock ~0 ~3 ~0 minecraft:gold_block
setblock ~-2 ~3 ~0 minecraft:gilded_blackstone
setblock ~2 ~3 ~0 minecraft:gilded_blackstone
setblock ~0 ~3 ~2 minecraft:chest
