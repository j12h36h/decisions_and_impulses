# Broken blackstone support pier with gilded accent.
fill ~0 ~1 ~0 ~2 ~5 ~2 minecraft:polished_blackstone_bricks
setblock ~0 ~2 ~-1 minecraft:cracked_polished_blackstone_bricks
setblock ~2 ~4 ~1 minecraft:gilded_blackstone
setblock ~1 ~6 ~1 minecraft:polished_blackstone_brick_slab[type=bottom]
