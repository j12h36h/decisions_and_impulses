# Narrow bastion bridge span with broken parapets.
fill ~0 ~2 ~-1 ~8 ~2 ~1 minecraft:polished_blackstone_bricks
fill ~0 ~3 ~-2 ~2 ~3 ~-2 minecraft:blackstone_wall
fill ~6 ~3 ~2 ~8 ~3 ~2 minecraft:blackstone_wall
setblock ~3 ~2 ~-1 minecraft:cracked_polished_blackstone_bricks
setblock ~5 ~2 ~1 minecraft:cracked_polished_blackstone_bricks
