# Crimson stable pen with broken fencing.
fill ~0 ~1 ~0 ~6 ~1 ~6 minecraft:crimson_planks
fill ~0 ~2 ~0 ~6 ~2 ~0 minecraft:crimson_fence
fill ~0 ~2 ~6 ~4 ~2 ~6 minecraft:crimson_fence
fill ~0 ~2 ~1 ~0 ~2 ~5 minecraft:crimson_fence
setblock ~5 ~2 ~6 minecraft:crimson_fence_gate[facing=north,open=true]
fill ~2 ~2 ~2 ~4 ~2 ~4 minecraft:crimson_nylium
