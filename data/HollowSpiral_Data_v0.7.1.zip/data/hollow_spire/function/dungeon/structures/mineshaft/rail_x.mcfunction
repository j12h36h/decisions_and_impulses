# Supported rail segment.
fill ~0 ~1 ~0 ~8 ~1 ~0 minecraft:oak_planks
fill ~0 ~2 ~0 ~8 ~2 ~0 minecraft:rail[shape=east_west]
setblock ~2 ~1 ~1 minecraft:gravel
setblock ~6 ~1 ~-1 minecraft:gravel
