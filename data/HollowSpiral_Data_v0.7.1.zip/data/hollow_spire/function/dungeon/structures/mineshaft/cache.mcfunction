# Rail cache with chest minecart and props.
fill ~-2 ~1 ~-1 ~2 ~1 ~1 minecraft:oak_planks
fill ~-2 ~2 ~0 ~2 ~2 ~0 minecraft:rail[shape=east_west]
summon minecraft:chest_minecart ~0 ~2 ~0 {LootTable:"minecraft:chests/abandoned_mineshaft"}
setblock ~-2 ~2 ~1 minecraft:barrel
setblock ~2 ~2 ~-1 minecraft:cobweb
