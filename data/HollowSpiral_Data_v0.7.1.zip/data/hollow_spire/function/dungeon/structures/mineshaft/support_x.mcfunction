# Oak mineshaft support frame along local X.
fill ~0 ~1 ~0 ~0 ~4 ~0 minecraft:oak_log
fill ~6 ~1 ~0 ~6 ~4 ~0 minecraft:oak_log
fill ~0 ~5 ~0 ~6 ~5 ~0 minecraft:oak_log
setblock ~1 ~4 ~0 minecraft:oak_fence
setblock ~5 ~4 ~0 minecraft:oak_fence
setblock ~3 ~5 ~0 minecraft:lantern[hanging=true]
