# Cobwebbed cave-spider nest between supports.
fill ~-3 ~1 ~-3 ~3 ~4 ~3 minecraft:cobweb replace minecraft:air
fill ~-3 ~1 ~-3 ~3 ~1 ~3 minecraft:oak_planks
setblock ~0 ~2 ~0 minecraft:spawner{SpawnData:{entity:{id:"minecraft:cave_spider"}},SpawnCount:2s,SpawnRange:3s,RequiredPlayerRange:12s}
setblock ~-3 ~2 ~0 minecraft:oak_fence
setblock ~3 ~2 ~0 minecraft:oak_fence
