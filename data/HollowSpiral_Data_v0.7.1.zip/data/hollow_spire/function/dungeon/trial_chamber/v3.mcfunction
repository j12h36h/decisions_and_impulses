# VAULT GALLERY // Paired side galleries and a raised reward axis.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:polished_tuff replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-12 run function hollow_spire:dungeon/structures/trial/arch_x
execute positioned ~-13 ~0 ~-6 run function hollow_spire:dungeon/structures/trial/arch_x
execute positioned ~7 ~0 ~6 run function hollow_spire:dungeon/structures/trial/arch_x
execute positioned ~7 ~0 ~12 run function hollow_spire:dungeon/structures/trial/arch_x
execute positioned ~-10 ~0 ~8 run function hollow_spire:dungeon/structures/trial/vault_altar
execute positioned ~10 ~0 ~-8 run function hollow_spire:dungeon/structures/trial/vault_altar
execute positioned ~-10 ~0 ~-8 run function hollow_spire:dungeon/structures/trial/spawner_pod
execute positioned ~10 ~0 ~8 run function hollow_spire:dungeon/structures/trial/spawner_pod
summon minecraft:breeze ~10 ~2 ~8 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TRIAL CHAMBER // VAULT GALLERY","color":"aqua","bold":true}]
