# BOGGED COURT // Moss-grown broken court around four structural corners.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:tuff_bricks replace minecraft:deepslate_tiles
fill ~-13 ~1 ~-13 ~-7 ~1 ~-8 minecraft:moss_block
fill ~7 ~1 ~8 ~13 ~1 ~13 minecraft:moss_block
execute positioned ~-12 ~0 ~-12 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~10 ~0 ~-12 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~-12 ~0 ~10 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~10 ~0 ~10 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~-10 ~0 ~5 run function hollow_spire:dungeon/structures/trial/spawner_pod
execute positioned ~10 ~0 ~-5 run function hollow_spire:dungeon/structures/trial/spawner_pod
setblock ~-8 ~2 ~-10 minecraft:spore_blossom
setblock ~8 ~2 ~10 minecraft:flowering_azalea
summon minecraft:bogged ~-10 ~2 ~5 {Tags:["hs_hostile"]}
summon minecraft:bogged ~10 ~2 ~-5 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TRIAL CHAMBER // BOGGED COURT","color":"green","bold":true}]
