# COPPER GAUNTLET // Staggered arches create a real combat route around the central controls.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:tuff_bricks replace minecraft:deepslate_tiles
execute positioned ~-13 ~0 ~-9 run function hollow_spire:dungeon/structures/trial/arch_x
execute positioned ~2 ~0 ~-9 run function hollow_spire:dungeon/structures/trial/arch_x
execute positioned ~-6 ~0 ~9 run function hollow_spire:dungeon/structures/trial/arch_x
execute positioned ~-12 ~0 ~7 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~10 ~0 ~-7 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~-9 ~0 ~-5 run function hollow_spire:dungeon/structures/trial/spawner_pod
execute positioned ~9 ~0 ~5 run function hollow_spire:dungeon/structures/trial/spawner_pod
execute positioned ~0 ~0 ~11 run function hollow_spire:dungeon/structures/trial/vault_altar
fill ~-12 ~1 ~12 ~-6 ~1 ~12 minecraft:oxidized_copper_grate
fill ~6 ~1 ~-12 ~12 ~1 ~-12 minecraft:weathered_copper_grate
summon minecraft:bogged ~-9 ~2 ~-5 {Tags:["hs_hostile"]}
summon minecraft:breeze ~9 ~2 ~5 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TRIAL CHAMBER // COPPER GAUNTLET","color":"aqua","bold":true}]
