# TUFF ARENA // Four pillars, two arches, twin spawner pods and vault altar.
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:polished_tuff replace minecraft:deepslate_tiles
execute positioned ~-11 ~0 ~-11 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~9 ~0 ~-11 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~-11 ~0 ~9 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~9 ~0 ~9 run function hollow_spire:dungeon/structures/trial/pillar
execute positioned ~-10 ~0 ~-7 run function hollow_spire:dungeon/structures/trial/arch_x
execute positioned ~4 ~0 ~7 run function hollow_spire:dungeon/structures/trial/arch_x
execute positioned ~-9 ~0 ~6 run function hollow_spire:dungeon/structures/trial/spawner_pod
execute positioned ~9 ~0 ~-6 run function hollow_spire:dungeon/structures/trial/spawner_pod
execute positioned ~0 ~0 ~10 run function hollow_spire:dungeon/structures/trial/vault_altar
summon minecraft:breeze ~-9 ~2 ~6 {Tags:["hs_hostile"]}
summon minecraft:breeze ~9 ~2 ~-6 {Tags:["hs_hostile"]}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TRIAL CHAMBER // TUFF ARENA","color":"aqua","bold":true}]
