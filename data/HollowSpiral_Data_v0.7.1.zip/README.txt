HOLLOW SPIRAL v0.7.1

Endless survival room-grid MAIN experience for DAI 3.3 / Minecraft 26.2.

DAI 3.3 INTEGRATION
- MAIN experience id: hollow_spire
- Managed version: 0.6.0
- New expeditions use the DAI high-level void world-generation profile.
- Companion resource pack uses the stable legacy compatibility key hollow_spire.
- Save identity remains The Hollow Spiral.

v0.7.1 EFFICIENCY PASS
- Room maintenance now uses one active-room selection stage instead of repeating the same room-marker search for every repair/control subsystem.
- Each nearby room is processed once per 5 TPS pulse, including in multiplayer overlap.
- Farm stabilization retains its 32-block temporary settling radius.
- Existing worlds upgrade in place with no progression or generated-room reset.

GAMEPLAY
Six-direction persistent survival dungeon generation remains unchanged. Hollow Spiral intentionally remains in VANILLA MOB MODE; ordinary minecraft:* encounter entities are retained.

Use with Hollow Spiral Resource v0.7.1.
