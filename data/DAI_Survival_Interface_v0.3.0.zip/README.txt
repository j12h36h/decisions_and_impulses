DAI Survival Interface v0.2
For Minecraft 26.2 + DAI 1.9.9
Role: ADDON
DAI ID: dai_survival_interface

Purpose
- True screen-space survival/target interface.
- No floating text_display entities.
- No damage-number logic.
- Designed to stack with Damage Indicators and other DAI addons.

Target UI
- Appears before combat when you aim at a living entity.
- Shows target name.
- Native health progress bar.
- Shows current / maximum HP.
- Shows approximate range.
- 2.5 second target-lock grace window prevents flicker on brief ray misses.
- Eight isolated HUD lanes are included for local/LAN multiplayer use.

Commands
/function survival_interface:toggle
/function survival_interface:enable
/function survival_interface:disable

v0.2 / DAI 1.9.9 update
- Added stable DAI addon identity and managed version metadata.
- Updated compatibility metadata and release text for DAI 1.9.9.
- Fixed the Enabled / Disabled preference being overwritten by /reload.
- Existing v0.1 players keep their current si_enable score when present.
- New players still default to Enabled.

Important
Remove the old DAI_Damage_Indicators_HUD v0.x addon when installing this pack.
That older addon is a separate pack and will continue spawning its world-space
text displays if it remains enabled.

HUD implementation
Survival Interface uses Minecraft's native bossbar HUD for dynamic target text,
health values, and progress. It does not create world-space HUD entities.
