# DAI Survival Interface v0.3.0
# Screen-space target information. No text_display / world-space HUD entities.
scoreboard objectives add si_slot dummy
scoreboard objectives add si_enable dummy
scoreboard objectives add si_lock dummy
scoreboard objectives add si_ray dummy
scoreboard objectives add si_const dummy
scoreboard objectives add si_hcur dummy
scoreboard objectives add si_hmax dummy
scoreboard objectives add si_hcur_w dummy
scoreboard objectives add si_hcur_d dummy
scoreboard objectives add si_hmax_w dummy
scoreboard objectives add si_hmax_d dummy
scoreboard objectives add si_range100 dummy
scoreboard objectives add si_range10 dummy
scoreboard objectives add si_range_w dummy
scoreboard objectives add si_range_d dummy

scoreboard players set #ten si_const 10
scoreboard players set #twentyfive si_const 25
scoreboard players set #next_slot si_const 0
scoreboard players set #found si_const 0

tag @a remove si_init
tag @e[tag=si_target_temp] remove si_target_temp

# Sixteen isolated HUD lanes for multiplayer/local-LAN safety.
bossbar add survival_interface:target_1 {"text":"Target"}
bossbar add survival_interface:target_2 {"text":"Target"}
bossbar add survival_interface:target_3 {"text":"Target"}
bossbar add survival_interface:target_4 {"text":"Target"}
bossbar add survival_interface:target_5 {"text":"Target"}
bossbar add survival_interface:target_6 {"text":"Target"}
bossbar add survival_interface:target_7 {"text":"Target"}
bossbar add survival_interface:target_8 {"text":"Target"}
bossbar add survival_interface:target_9 {"text":"Target"}
bossbar add survival_interface:target_10 {"text":"Target"}
bossbar add survival_interface:target_11 {"text":"Target"}
bossbar add survival_interface:target_12 {"text":"Target"}
bossbar add survival_interface:target_13 {"text":"Target"}
bossbar add survival_interface:target_14 {"text":"Target"}
bossbar add survival_interface:target_15 {"text":"Target"}
bossbar add survival_interface:target_16 {"text":"Target"}
function survival_interface:ui/configure

tellraw @a [{"text":"[DAI Survival Interface] ","color":"gold","bold":true},{"text":"v0.3.0 loaded — DAI 1.9.9 HUD UI.","color":"gray"}]
