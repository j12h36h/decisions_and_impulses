scoreboard players set @s si_enable 0
scoreboard players set @s si_lock 0
function survival_interface:ui/hide
tellraw @s [{"text":"[Survival Interface] ","color":"gold"},{"text":"Disabled","color":"red"}]
