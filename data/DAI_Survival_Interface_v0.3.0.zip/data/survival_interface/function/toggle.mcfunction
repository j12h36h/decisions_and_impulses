execute if score @s si_enable matches 1.. run function survival_interface:disable
execute unless score @s si_enable matches 1.. run function survival_interface:enable
