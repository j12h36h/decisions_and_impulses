scoreboard players set @s si_enable 1
tellraw @s [{"text":"[Survival Interface] ","color":"gold"},{"text":"Enabled","color":"green"}]
