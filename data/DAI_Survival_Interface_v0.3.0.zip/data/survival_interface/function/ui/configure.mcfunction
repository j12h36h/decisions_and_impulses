bossbar set survival_interface:target_1 color red
bossbar set survival_interface:target_1 style progress
bossbar set survival_interface:target_1 visible false
bossbar set survival_interface:target_2 color red
bossbar set survival_interface:target_2 style progress
bossbar set survival_interface:target_2 visible false
bossbar set survival_interface:target_3 color red
bossbar set survival_interface:target_3 style progress
bossbar set survival_interface:target_3 visible false
bossbar set survival_interface:target_4 color red
bossbar set survival_interface:target_4 style progress
bossbar set survival_interface:target_4 visible false
bossbar set survival_interface:target_5 color red
bossbar set survival_interface:target_5 style progress
bossbar set survival_interface:target_5 visible false
bossbar set survival_interface:target_6 color red
bossbar set survival_interface:target_6 style progress
bossbar set survival_interface:target_6 visible false
bossbar set survival_interface:target_7 color red
bossbar set survival_interface:target_7 style progress
bossbar set survival_interface:target_7 visible false
bossbar set survival_interface:target_8 color red
bossbar set survival_interface:target_8 style progress
bossbar set survival_interface:target_8 visible false

bossbar set survival_interface:target_9 color red
bossbar set survival_interface:target_9 style progress
bossbar set survival_interface:target_9 visible false

bossbar set survival_interface:target_10 color red
bossbar set survival_interface:target_10 style progress
bossbar set survival_interface:target_10 visible false

bossbar set survival_interface:target_11 color red
bossbar set survival_interface:target_11 style progress
bossbar set survival_interface:target_11 visible false

bossbar set survival_interface:target_12 color red
bossbar set survival_interface:target_12 style progress
bossbar set survival_interface:target_12 visible false

bossbar set survival_interface:target_13 color red
bossbar set survival_interface:target_13 style progress
bossbar set survival_interface:target_13 visible false

bossbar set survival_interface:target_14 color red
bossbar set survival_interface:target_14 style progress
bossbar set survival_interface:target_14 visible false

bossbar set survival_interface:target_15 color red
bossbar set survival_interface:target_15 style progress
bossbar set survival_interface:target_15 visible false

bossbar set survival_interface:target_16 color red
bossbar set survival_interface:target_16 style progress
bossbar set survival_interface:target_16 visible false
