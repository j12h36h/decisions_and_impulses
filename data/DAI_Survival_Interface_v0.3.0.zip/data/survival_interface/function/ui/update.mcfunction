execute if score @s si_slot matches 1 run function survival_interface:ui/update_1
execute if score @s si_slot matches 2 run function survival_interface:ui/update_2
execute if score @s si_slot matches 3 run function survival_interface:ui/update_3
execute if score @s si_slot matches 4 run function survival_interface:ui/update_4
execute if score @s si_slot matches 5 run function survival_interface:ui/update_5
execute if score @s si_slot matches 6 run function survival_interface:ui/update_6
execute if score @s si_slot matches 7 run function survival_interface:ui/update_7
execute if score @s si_slot matches 8 run function survival_interface:ui/update_8

execute if score @s si_slot matches 9 run function survival_interface:ui/update_9
execute if score @s si_slot matches 10 run function survival_interface:ui/update_10
execute if score @s si_slot matches 11 run function survival_interface:ui/update_11
execute if score @s si_slot matches 12 run function survival_interface:ui/update_12
execute if score @s si_slot matches 13 run function survival_interface:ui/update_13
execute if score @s si_slot matches 14 run function survival_interface:ui/update_14
execute if score @s si_slot matches 15 run function survival_interface:ui/update_15
execute if score @s si_slot matches 16 run function survival_interface:ui/update_16
