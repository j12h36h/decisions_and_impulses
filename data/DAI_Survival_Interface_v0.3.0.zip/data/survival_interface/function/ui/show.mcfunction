execute if score @s si_slot matches 1 run bossbar set survival_interface:target_1 visible true
execute if score @s si_slot matches 2 run bossbar set survival_interface:target_2 visible true
execute if score @s si_slot matches 3 run bossbar set survival_interface:target_3 visible true
execute if score @s si_slot matches 4 run bossbar set survival_interface:target_4 visible true
execute if score @s si_slot matches 5 run bossbar set survival_interface:target_5 visible true
execute if score @s si_slot matches 6 run bossbar set survival_interface:target_6 visible true
execute if score @s si_slot matches 7 run bossbar set survival_interface:target_7 visible true
execute if score @s si_slot matches 8 run bossbar set survival_interface:target_8 visible true

execute if score @s si_slot matches 9 run bossbar set survival_interface:target_9 visible true
execute if score @s si_slot matches 10 run bossbar set survival_interface:target_10 visible true
execute if score @s si_slot matches 11 run bossbar set survival_interface:target_11 visible true
execute if score @s si_slot matches 12 run bossbar set survival_interface:target_12 visible true
execute if score @s si_slot matches 13 run bossbar set survival_interface:target_13 visible true
execute if score @s si_slot matches 14 run bossbar set survival_interface:target_14 visible true
execute if score @s si_slot matches 15 run bossbar set survival_interface:target_15 visible true
execute if score @s si_slot matches 16 run bossbar set survival_interface:target_16 visible true
