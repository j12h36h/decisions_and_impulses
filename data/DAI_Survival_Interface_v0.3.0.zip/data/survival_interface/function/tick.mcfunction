execute as @a[tag=!si_init] run function survival_interface:player/init
execute as @a[tag=si_init,scores={si_enable=1..}] at @s run function survival_interface:target/start
execute as @a[tag=si_init,scores={si_enable=..0}] run function survival_interface:ui/hide
