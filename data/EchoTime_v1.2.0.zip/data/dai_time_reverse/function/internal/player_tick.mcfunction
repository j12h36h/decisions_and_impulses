# EchoTime v1.2.0 — consolidated local player runtime.
# Called once per player from the global tick dispatcher.

# Stable identity and one-time migrations.
execute unless score @s tr_id matches 1.. run function dai_time_reverse:internal/assign_player_id
execute if entity @s[tag=!tr_init_v020] run function dai_time_reverse:internal/init_player_v020
execute if entity @s[tag=!tr_init_perfhotfix] run function dai_time_reverse:internal/init_player_perfhotfix
execute if entity @s[tag=!tr_init_v021] run function dai_time_reverse:internal/init_player_v021
execute if entity @s[tag=!tr_items_v022] run function dai_time_reverse:internal/init_player_v022
execute if entity @s[tag=!tr_items_v024] run function dai_time_reverse:internal/init_player_v024
execute if entity @s[tag=!tr_init_v120] run function dai_time_reverse:internal/init_player_v120

# Temporal Stream hold-state watchdog.
scoreboard players remove @s[scores={tr_hold=1..}] tr_hold 1
execute if score @s tr_mode matches 3 if score @s tr_hold matches 0 at @s run function dai_time_reverse:player/stop
execute if score @s tr_dry matches 1.. if score @s tr_hold matches 0 run scoreboard players set @s tr_dry 0

# Real-tick cooldowns.
scoreboard players remove @s[scores={tr_cdemg=1..}] tr_cdemg 1
scoreboard players remove @s[scores={tr_cdfull=1..}] tr_cdfull 1
scoreboard players remove @s[scores={tr_cdarea=1..}] tr_cdarea 1

# Manual/test trigger controls remain available as compatibility/debug paths.
scoreboard players enable @s tr_emergency
scoreboard players enable @s tr_full
scoreboard players enable @s tr_area
execute if score @s tr_emergency matches 1.. at @s run function dai_time_reverse:internal/trigger_emergency
execute if score @s tr_full matches 1.. at @s run function dai_time_reverse:internal/trigger_full
execute if score @s tr_area matches 1.. at @s run function dai_time_reverse:internal/trigger_area
