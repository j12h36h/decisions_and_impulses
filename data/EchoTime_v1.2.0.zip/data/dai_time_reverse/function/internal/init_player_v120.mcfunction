# v1.2.0 runtime migration marker.
# Clear only stale transient helper tags from this player. Stable IDs,
# cooldowns, item state, and temporal history configuration are preserved.
tag @s remove tr_current_player
tag @s add tr_init_v120
