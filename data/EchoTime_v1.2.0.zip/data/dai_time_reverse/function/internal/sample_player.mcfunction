# EchoTime v1.2.0 — one 10 Hz local history pass per player.
# Existing epoch guards keep overlapping-player marker/entity work deduplicated.

# Age/expire nearby historical markers exactly once this sample.
execute as @e[type=minecraft:marker,tag=tr_snapshot,distance=..64] run function dai_time_reverse:internal/age_snapshot_guard

# Play personal rewind at the same cadence used to record history.
execute if score @s tr_mode matches 1.. at @s run function dai_time_reverse:player/rewind_step

# Play localized entity rewinds only near this active player and once per epoch.
execute as @e[tag=tr_area_rewinding,distance=..64] at @s run function dai_time_reverse:entity/rewind_step_guard

# Record this player's timeline while not actively rewinding.
execute if score @s tr_mode matches 0 at @s run function dai_time_reverse:record/player
execute unless score @s tr_mode matches 0.. at @s run function dai_time_reverse:record/player

# Record only the 16 nearest rewindable non-player entities in the real field radius.
execute as @e[type=!minecraft:player,type=!minecraft:marker,distance=..10,tag=!tr_area_rewinding,limit=16,sort=nearest] at @s run function dai_time_reverse:record/entity_guard
