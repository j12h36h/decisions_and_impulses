# EchoTime v1.2.0 — one local frozen-entity dispatcher.
execute if score @s tr_freeze matches ..0 run function dai_time_reverse:freeze/stop
execute if entity @s[tag=tr_chrono_frozen] if score @s tr_freeze matches 1.. at @s run function dai_time_reverse:freeze/tick
