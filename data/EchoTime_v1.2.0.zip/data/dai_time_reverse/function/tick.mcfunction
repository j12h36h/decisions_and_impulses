# EchoTime v1.2.0 — DAI 3.3 capability + efficiency runtime.
# One global player pass, one frozen-entity pass, and a bounded 10 Hz history pass.

# Consolidated per-player control / cooldown / migration runtime.
execute as @a at @s run function dai_time_reverse:internal/player_tick

# Chrono Anchor remains maintained at 20 TPS, but through one shared selection.
execute as @e[tag=tr_chrono_frozen] at @s run function dai_time_reverse:freeze/runtime_tick

# Bounded history / playback pass: once every 2 ticks (10 Hz).
scoreboard players add #sample tr_tmp 1
execute if score #sample tr_tmp matches 2.. run scoreboard players add #epoch tr_tmp 1
execute if score #sample tr_tmp matches 2.. run function dai_time_reverse:internal/sample_tick
execute if score #sample tr_tmp matches 2.. run scoreboard players set #sample tr_tmp 0
