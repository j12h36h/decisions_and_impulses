# EchoTime v1.2.0 release
# Minecraft Java 26.2 / Data Pack 107.1 / DAI 3.3
#
# This hotfix deliberately bounds temporal history work. The previous v0.2.0
# implementation performed multiple dimension-wide entity/marker sweeps every
# server tick. On integrated clients that could create severe command/entity
# pressure before any ability was even activated.

scoreboard objectives add tr_id dummy
scoreboard objectives add tr_eid dummy
scoreboard objectives add tr_owner dummy
scoreboard objectives add tr_age dummy
scoreboard objectives add tr_mode dummy
scoreboard objectives add tr_ticks dummy
scoreboard objectives add tr_rticks dummy
scoreboard objectives add tr_hp dummy
scoreboard objectives add tr_resumehp dummy
scoreboard objectives add tr_invul dummy
scoreboard objectives add tr_nograv dummy
scoreboard objectives add tr_noai dummy
scoreboard objectives add tr_tmp dummy
scoreboard objectives add tr_loop dummy
scoreboard objectives add tr_cdemg dummy
scoreboard objectives add tr_cdfull dummy
scoreboard objectives add tr_cdarea dummy
scoreboard objectives add tr_recstamp dummy
scoreboard objectives add tr_agestamp dummy
scoreboard objectives add tr_playstamp dummy
scoreboard objectives add tr_hold dummy
scoreboard objectives add tr_dry dummy
scoreboard objectives add tr_freeze dummy
scoreboard objectives add tr_freeze_noai dummy
scoreboard objectives add tr_freeze_nograv dummy
scoreboard objectives add tr_freeze_hasnoai dummy
scoreboard objectives add tr_emergency trigger
scoreboard objectives add tr_full trigger
scoreboard objectives add tr_area trigger

scoreboard players add #next_player tr_tmp 0
scoreboard players add #next_entity tr_tmp 0
scoreboard players set #sample tr_tmp 0
scoreboard players set #epoch tr_tmp 0

# A reload must never strand an entity in temporary rewind/freeze state.
execute as @e[tag=tr_chrono_frozen] at @s run function dai_time_reverse:freeze/stop
execute as @a[scores={tr_mode=1..}] at @s run function dai_time_reverse:player/stop
execute as @a at @s as @e[tag=tr_area_rewinding,distance=..96] at @s run function dai_time_reverse:entity/stop

# Purge old runtime history from the unsafe recorder. This is intentionally a
# one-time load operation rather than a per-tick dimension sweep.
execute as @a at @s run kill @e[type=minecraft:marker,tag=tr_snapshot,distance=..128]
execute as @a at @s run kill @e[type=minecraft:marker,tag=tr_resume_frame,distance=..128]
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=tr_snapshot]
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=tr_resume_frame]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=tr_snapshot]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=tr_resume_frame]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=tr_snapshot]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=tr_resume_frame]

# Clean obsolete and transient helper tags once on load. Runtime rewind steps
# no longer need dimension-wide/current-player helper-tag sweeps.
tag @e[tag=tr_area_rewinding] remove tr_processed_tick
tag @e[tag=tr_recorded_tick] remove tr_recorded_tick
tag @e[tag=tr_current_entity] remove tr_current_entity
tag @e[type=minecraft:marker,tag=tr_selected] remove tr_selected
tag @a[tag=tr_current_player] remove tr_current_player

# v1.2.0 uses one new migration marker. Historical migration markers are no
# longer forcibly cleared on every /reload; missing ones are handled locally
# by the consolidated player runtime.
tag @a remove tr_init_v120

tellraw @a [{"text":"[EchoTime] ","color":"aqua","bold":true},{"text":"v1.2.0 loaded. ","color":"green","bold":false},{"text":"DAI 3.3 consolidated temporal runtime active.","color":"gray"}]
