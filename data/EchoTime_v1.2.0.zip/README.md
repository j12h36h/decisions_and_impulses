# EchoTime

EchoTime v1.2.0 is a standalone DAI 3.3 temporal-ability addon for Minecraft Java 26.2.

## Ability Items

- **Temporal Recall** — rewinds your recent movement and facing for up to 3 seconds. It renders as an enchanted Ender Eye.
- **Chrono Anchor** — stops nearby non-player entities in time for 2 seconds within a 10-block radius.
- **Reversal Field** — rewinds recorded nearby non-player entities within 10 blocks for up to 3 seconds.
- **Temporal Stream** — hold use to continuously rewind yourself for up to 5 seconds, then resume from the historical point reached.

Each player receives one copy of all four items automatically. If an item is lost, run:

`/function dai_time_reverse:starter/give`

The internal `dai_time_reverse` namespace and native item IDs are retained for world and addon compatibility.

## DAI 3.3 Runtime

v1.2.0 keeps the bounded 10 Hz temporal-history engine introduced in v1.1.0 while consolidating the surrounding hot path:

- one global player runtime selection per tick
- one global frozen-entity selection per tick
- one global player history selection per 10 Hz sample
- maximum 16 nearby non-player timelines recorded per player/sample
- epoch guards deduplicate overlapping-player marker/entity work
- transient rewind helper tags are cleaned locally instead of using repeated global sweeps

## World of Addons

EchoTime remains independently usable, but its stable native content IDs are recognized by compatible World of Addons releases as the **Echo Anomaly** champion integration.

World of Addons is optional and is not a dependency.

## Compatibility

- Minecraft Java 26.2
- DAI 3.3
- Data Pack format 107.1
- Datapack only; no Resource Pack required
