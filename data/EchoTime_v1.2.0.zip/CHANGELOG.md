# EchoTime v1.2.0

## DAI 3.3 Capability + Efficiency Pass

- Updated EchoTime for DAI 3.3 and bumped the managed addon version to `1.2.0`.
- Consolidated the 20 TPS player runtime behind one global player selection instead of repeated player-wide scans for initialization, cooldowns, held-use state, trigger controls, and ability routing.
- Consolidated Chrono Anchor maintenance behind one frozen-entity dispatcher instead of separate global active/expired frozen-entity scans.
- Consolidated the 10 Hz temporal-history pass behind one global player selection while preserving existing epoch-based overlap deduplication.
- Kept the v1.1.0 bounded history rules: at most 16 nearby non-player timelines per player/sample within the actual 10-block Reversal Field radius.
- Removed repeated global current-player/current-entity helper-tag clearing from active rewind steps; transient helper state is now released locally and cleaned once on load.
- Historical migration markers are no longer forcibly cleared on every `/reload`; missing migrations are handled locally by the consolidated player runtime.
- Added a v1.2.0 migration marker without resetting stable player IDs, cooldowns, or item state.
- Preserved all four native DAI ability items and their stable `dai_time_reverse:*` IDs.
- Preserved World of Addons recognition compatibility for Echo Anomaly.
- No Resource Pack is required.

## Preserved Ability Behavior

- Temporal Recall: up to 3 seconds.
- Chrono Anchor: 2-second freeze within 10 blocks.
- Reversal Field: up to 3 seconds within 10 blocks.
- Temporal Stream: hold-to-rewind for up to 5 seconds.
- Existing cooldowns, health restoration behavior, historical motion restoration, item appearance, and native-item input remain unchanged.
