scoreboard players set @s arpg2_unlock 6
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor6_sigil:1b}}]
give @s minecraft:amethyst_shard[minecraft:custom_data={dai_auto_rpg:{floor6_sigil:1b}},minecraft:custom_name={text:'Floor 6 Sigil',color:'aqua',bold:true,italic:false},minecraft:lore=[{text:'Permanent proof that Floor 6 is unlocked.',color:'gray',italic:false}]] 1
execute unless items entity @s armor.chest minecraft:diamond_chestplate run give @s minecraft:diamond_chestplate[minecraft:custom_name={text:'Furnace Plate',color:'gold',bold:true,italic:false}] 1
function dai_auto_rpg:map/f5/505
title @s title {"text":"FLOOR 5 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 6 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 6 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
