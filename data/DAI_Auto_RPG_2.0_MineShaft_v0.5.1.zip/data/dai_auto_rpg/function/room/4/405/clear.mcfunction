scoreboard players set @s arpg2_unlock 5
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor5_sigil:1b}}]
give @s minecraft:amethyst_shard[minecraft:custom_data={dai_auto_rpg:{floor5_sigil:1b}},minecraft:custom_name={text:'Floor 5 Sigil',color:'aqua',bold:true,italic:false},minecraft:lore=[{text:'Permanent proof that Floor 5 is unlocked.',color:'gray',italic:false}]] 1
execute unless items entity @s inventory.* minecraft:diamond_axe run give @s minecraft:diamond_axe[minecraft:custom_name={text:'Sporecleaver',color:'green',bold:true,italic:false}] 1
function dai_auto_rpg:map/f4/405
title @s title {"text":"FLOOR 4 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 5 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 5 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
