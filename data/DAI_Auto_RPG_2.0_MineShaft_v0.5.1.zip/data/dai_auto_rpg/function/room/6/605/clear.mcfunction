scoreboard players set @s arpg2_unlock 7
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor7_sigil:1b}}]
give @s minecraft:amethyst_shard[minecraft:custom_data={dai_auto_rpg:{floor7_sigil:1b}},minecraft:custom_name={text:'Floor 7 Sigil',color:'aqua',bold:true,italic:false},minecraft:lore=[{text:'Permanent proof that Floor 7 is unlocked.',color:'gray',italic:false}]] 1
execute unless items entity @s inventory.* minecraft:diamond_pickaxe run give @s minecraft:diamond_pickaxe[minecraft:custom_name={text:'Resonant Pick',color:'light_purple',bold:true,italic:false}] 1
function dai_auto_rpg:map/f6/605
title @s title {"text":"FLOOR 6 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 7 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 7 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
