scoreboard players set @s arpg2_unlock 10
tag @s add arpg2_campaign_clear
clear @s minecraft:nether_star[minecraft:custom_data~{dai_auto_rpg:{mineshaft_heart:1b}}]
give @s minecraft:nether_star[minecraft:custom_data={dai_auto_rpg:{mineshaft_heart:1b}},minecraft:custom_name={text:'Heart of the Mine',color:'gold',bold:true,italic:false},minecraft:lore=[{text:'Proof that all ten MineShaft floors were conquered.',color:'gray',italic:false}]] 1
function dai_auto_rpg:map/f10/1005
title @s title {"text":"MINESHAFT CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"All 10 floors conquered.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 0.8
playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.8 1.2
tellraw @s {text:'The Mine Director is down. AutoCraft MineShaft Floor 1–10 campaign complete.',color:'gold'}
