scoreboard players set @s arpg2_unlock 4
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor4_sigil:1b}}]
give @s minecraft:amethyst_shard[minecraft:custom_data={dai_auto_rpg:{floor4_sigil:1b}},minecraft:custom_name={text:'Floor 4 Sigil',color:'aqua',bold:true,italic:false},minecraft:lore=[{text:'Permanent proof that Floor 4 is unlocked.',color:'gray',italic:false}]] 1
execute unless items entity @s inventory.* minecraft:trident run give @s minecraft:trident[minecraft:custom_name={text:'Surveyor Trident',color:'aqua',bold:true,italic:false}] 1
function dai_auto_rpg:map/f3/305
title @s title {"text":"FLOOR 3 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 4 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 4 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
