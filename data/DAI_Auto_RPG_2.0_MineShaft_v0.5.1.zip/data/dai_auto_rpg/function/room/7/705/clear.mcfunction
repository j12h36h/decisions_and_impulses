scoreboard players set @s arpg2_unlock 8
clear @s minecraft:amethyst_shard[minecraft:custom_data~{dai_auto_rpg:{floor8_sigil:1b}}]
give @s minecraft:amethyst_shard[minecraft:custom_data={dai_auto_rpg:{floor8_sigil:1b}},minecraft:custom_name={text:'Floor 8 Sigil',color:'aqua',bold:true,italic:false},minecraft:lore=[{text:'Permanent proof that Floor 8 is unlocked.',color:'gray',italic:false}]] 1
execute unless items entity @s inventory.* minecraft:diamond_sword run give @s minecraft:diamond_sword[minecraft:custom_name={text:'Engineer Saber',color:'yellow',bold:true,italic:false},minecraft:enchantments={"minecraft:sharpness":1}] 1
function dai_auto_rpg:map/f7/705
title @s title {"text":"FLOOR 7 CLEARED","color":"gold","bold":true}
title @s subtitle {"text":"Floor 8 unlocked.","color":"aqua"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.0
tellraw @s {text:'Floor 8 is unlocked. Safety Rope home, then the north lift will descend directly there.',color:'yellow'}
