# Auto RPG v2 core scoreboard/team setup.
scoreboard objectives add arpg2_room dummy
scoreboard objectives add arpg2_unlock dummy
scoreboard objectives add arpg2_deaths deathCount
scoreboard objectives add arpg2_seen_deaths dummy
scoreboard objectives add arpg2_first_weapon dummy
scoreboard objectives add arpg2_loot dummy
scoreboard objectives add arpg2_branch dummy
scoreboard objectives add arpg2_keys dummy
scoreboard objectives add arpg2_combat dummy
scoreboard objectives add arpg2_clear_guard dummy
scoreboard objectives add arpg2_rope dummy
scoreboard objectives add arpg2_stash dummy
scoreboard objectives add arpg2_map dummy
scoreboard objectives modify arpg2_map numberformat blank
team add arpg2_red
team modify arpg2_red color red
team add arpg2_blue
team modify arpg2_blue color blue
team add arpg2_boss
team modify arpg2_boss color gold
scoreboard objectives add arpg2_next_room dummy
scoreboard objectives add arpg2_clear_timer dummy
scoreboard objectives add arpg2_phase dummy
