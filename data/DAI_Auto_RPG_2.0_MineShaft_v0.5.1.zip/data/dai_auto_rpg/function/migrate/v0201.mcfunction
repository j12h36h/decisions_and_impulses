# One-time migration for saves created before the physical Home interface existed.
function dai_auto_rpg:build/home_doors
function dai_auto_rpg:player/ensure_rope
# Preserve existing progression; only repair the new interface and permanent escape item.
tag @s add arpg2_v0201_migrated
tellraw @s {"text":"Auto RPG updated: Home doors and your permanent Safety Rope are now available.","color":"gold"}
