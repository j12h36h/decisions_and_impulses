
execute unless score @s arpg2_unlock matches 2.. run tellraw @s {"text":"Floor 2 is still locked.","color":"red"}
execute unless score @s arpg2_unlock matches 2.. run return 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_room 201
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
scoreboard players set @s arpg2_phase 0
function dai_auto_rpg:generate/f2/reset
teleport @s 0.5 -47 0.5 180 0
function dai_auto_rpg:map/f2/201
execute positioned -2 -47 -1 run function dai_auto_rpg:spawn/red
execute positioned 2 -47 1 run function dai_auto_rpg:spawn/blue
execute positioned 0 -47 3 run function dai_auto_rpg:spawn/green
execute positioned 0 -47 -3 run function dai_auto_rpg:spawn/zombie
title @s times 5 25 5
title @s title {"text":"FLOOR 2","color":"aqua","bold":true}
title @s subtitle {"text":"Abandoned Shafts — manual combat, deeper danger.","color":"gray"}
