execute unless score @s arpg2_unlock matches 8.. run tellraw @s {"text":"Floor 8 is still locked.","color":"red"}
execute unless score @s arpg2_unlock matches 8.. run return 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_room 801
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
scoreboard players set @s arpg2_phase 0
function dai_auto_rpg:generate/f8/reset
teleport @s 700.5 -47 0.5 180 0
function dai_auto_rpg:map/f8/801
title @s times 5 25 5
execute positioned 697 -47 0 run function dai_auto_rpg:spawn/blaze
execute positioned 703 -47 0 run function dai_auto_rpg:spawn/wither_skeleton
execute positioned 700 -47 3 run function dai_auto_rpg:spawn/magma
title @s title {"text":"FLOOR 8","color":"red","bold":true}
title @s subtitle {"text": "Nether Breach — fire, soul sand, and hostile breach crews.", "color": "gray"}
