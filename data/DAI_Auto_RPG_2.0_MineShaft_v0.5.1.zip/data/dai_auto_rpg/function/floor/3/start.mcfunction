execute unless score @s arpg2_unlock matches 3.. run tellraw @s {"text":"Floor 3 is still locked.","color":"red"}
execute unless score @s arpg2_unlock matches 3.. run return 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_room 301
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
scoreboard players set @s arpg2_phase 0
function dai_auto_rpg:generate/f3/reset
teleport @s 100.5 -47 0.5 180 0
function dai_auto_rpg:map/f3/301
title @s times 5 25 5
execute positioned 98 -47 -1 run function dai_auto_rpg:spawn/drowned
execute positioned 102 -47 1 run function dai_auto_rpg:spawn/drowned
execute positioned 100 -47 3 run function dai_auto_rpg:spawn/green
title @s title {"text":"FLOOR 3","color":"aqua","bold":true}
title @s subtitle {"text": "Flooded Excavation — drowned crews and waterlogged worksites.", "color": "gray"}
