execute unless score @s arpg2_unlock matches 10.. run tellraw @s {"text":"Floor 10 is still locked.","color":"red"}
execute unless score @s arpg2_unlock matches 10.. run return 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_room 1001
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
scoreboard players set @s arpg2_phase 0
function dai_auto_rpg:generate/f10/reset
teleport @s 940.5 -47 0.5 180 0
function dai_auto_rpg:map/f10/1001
title @s times 5 25 5
execute positioned 937 -47 0 run function dai_auto_rpg:spawn/drowned
execute positioned 943 -47 0 run function dai_auto_rpg:spawn/cave_spider
execute positioned 940 -47 3 run function dai_auto_rpg:spawn/magma
execute positioned 940 -47 -3 run function dai_auto_rpg:spawn/skeleton
title @s title {"text":"FLOOR 10","color":"dark_red","bold":true}
title @s subtitle {"text": "Heart of the Mine — every system converges here.", "color": "gray"}
