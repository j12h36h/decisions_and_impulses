execute unless score @s arpg2_unlock matches 9.. run tellraw @s {"text":"Floor 9 is still locked.","color":"red"}
execute unless score @s arpg2_unlock matches 9.. run return 0
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_room 901
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
scoreboard players set @s arpg2_phase 0
function dai_auto_rpg:generate/f9/reset
teleport @s 820.5 -47 0.5 180 0
function dai_auto_rpg:map/f9/901
title @s times 5 25 5
execute positioned 817 -47 0 run function dai_auto_rpg:spawn/silverfish
execute positioned 823 -47 0 run function dai_auto_rpg:spawn/skeleton
execute positioned 820 -47 3 run function dai_auto_rpg:spawn/enderman
effect give @s minecraft:darkness 6 0 true
playsound minecraft:block.sculk_sensor.clicking master @s ~ ~ ~ 0.7 0.6
title @s title {"text":"FLOOR 9","color":"dark_aqua","bold":true}
title @s subtitle {"text": "Ancient Depths — sculk, darkness, and things left below.", "color": "gray"}
