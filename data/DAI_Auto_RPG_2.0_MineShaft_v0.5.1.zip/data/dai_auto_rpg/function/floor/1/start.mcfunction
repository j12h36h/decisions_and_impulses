
clear @s minecraft:tripwire_hook[minecraft:custom_data~{dai_auto_rpg:{mineshaft_key:1b}}]
clear @s minecraft:trial_key[minecraft:custom_data~{dai_auto_rpg:{boss_key:1b}}]
scoreboard players set @s arpg2_branch 0
scoreboard players set @s arpg2_next_room 0
scoreboard players set @s arpg2_room 101
scoreboard players set @s arpg2_clear_guard 0
scoreboard players set @s arpg2_combat 1
scoreboard players set @s arpg2_clear_timer 10
scoreboard players set @s arpg2_phase 0
function dai_auto_rpg:generate/f1/reset
teleport @s 0.5 -31 0.5 180 0
function dai_auto_rpg:map/f1/101
execute positioned -2 -31 0 run function dai_auto_rpg:spawn/green
execute positioned 0 -31 2 run function dai_auto_rpg:spawn/green
execute positioned 2 -31 0 run function dai_auto_rpg:spawn/green
title @s times 5 25 5
title @s title {"text":"FLOOR 1","color":"green","bold":true}
title @s subtitle {"text":"Slimeworks — you fight. Clear the room to earn a key.","color":"gray"}
