DAI Auto RPG 2.0 — MineShaft v0.5.1

FLOORS 1–10 CAMPAIGN EXPANSION

CORE LOOP
- Manual combat remains unchanged. DAI does not aim, attack, move, eat, or select weapons for the player.
- Rooms and connector tunnels are still carved physically only after a route is unlocked.
- Every normal clear awards progression toward the next room.
- The last normal room awards a Boss Key.
- Boss completion unlocks the next floor.
- The single north Home lift always launches the deepest floor currently unlocked.
- Safety Rope returns Home without deleting permanent progression or equipment.

FLOORS
1 — Slimeworks
    Existing slime introduction and Slime Foreman.

2 — Abandoned Shafts
    Existing mixed slime/miner floor and Lost Overseer.

3 — Flooded Excavation
    Prismarine pumping works, drowned crews, flooded-industrial dressing.
    Boss: Drowned Surveyor.

4 — Fungal Hollows
    Moss, webs, spiders, venom and overgrown mine chambers.
    Boss: Sporekeeper.

5 — Deep Foundry
    Blackstone foundry rooms, magma hazards and smelting crews.
    Boss: Furnace Foreman. Magma split children are completion-tracked.

6 — Crystal Fault
    Calcite/amethyst chambers, dripstone obstacles and ranged combat.
    Boss: Resonant Prospector.

7 — Industrial Deepworks
    Copper/redstone machinery rooms with pillager/vindicator combat.
    Boss: Chief Engineer.

8 — Nether Breach
    Basalt, blackstone, soul-sand/magma hazards and Nether enemies.
    Boss: Rift Superintendent.

9 — Ancient Depths
    Sculk-infested chambers, darkness pressure and potion-based enemies.
    Boss: Deep Surveyor.

10 — Heart of the Mine
    A mixed-mechanics finale using visual motifs and enemy families from prior floors.
    Final encounter is three phases:
      I   Excavation Engine
      II  Mine Director + guards
      III Heartbound Director
    Completion awards the Heart of the Mine trophy.

ROUTE IDENTITY
- Floors 3–10 have named route choices and separate room themes.
- Each floor contains five generated rooms:
    Start -> branch choice -> branch room -> convergence -> boss.
- The sidebar map continues to reveal the path as the player physically explores it.
- Route generation remains on-demand instead of teleporting between prebuilt rooms.

WORLD / GENERATION ARCHITECTURE
- New ACMS experience worlds use dai_auto_rpg:mineshaft_void, a true flat void preset.
- Home and every MineShaft room/corridor are therefore authored entirely by the datapack.
- Floors 3–10 remain isolated deep sectors at a safe Y level rather than stacking below Y -64.
- Every floor reset temporarily force-loads its complete reserved sector before remote fill/carve commands run, then releases it immediately after the starting chamber is generated.
- This prevents the Floor 5+ unloaded-chunk failure seen in v0.5.0 and keeps failed generation from exposing natural terrain.
- The Home lift and progression still present all sectors as descending floors.
- World preset changes apply to newly created experience worlds; an existing normal-terrain save keeps its original generator.

LIGHTING / CORRIDOR FIXES
- Home lighting now uses ordinary vanilla wall torches mounted only on permanent deepslate walls.
- Legacy Home lantern/chain positions are cleared by a non-destructive v0.5.1 migration.
- Every generated corridor clears the two doorway wall torches before removing their support wall, preventing torch item drops when a route opens.

PRESENTATION
- Floor/room title timing is shorter to reduce screen obstruction.
- The Home actionbar identifies the deepest unlocked floor through Floor 10.
- The MineShaft Guide now documents all ten floors.
- The title screen now advertises the ten-floor campaign.

SAVE COMPATIBILITY
- v0.4.x progression is retained.
- Existing players with Floor 3 already unlocked can immediately enter the new Floor 3.
- v0.5.0 migration is Home-safe and non-destructive.
- v0.5.1 migration only repairs Home lighting; it does not rebuild storage or reset progression.
- Existing Floor 1 / Floor 2 geometry, combat logic, keys, Safety Rope and Home layout are preserved.

DEBUG
- debug/floor3 through debug/floor10 were added for direct floor testing.
- Each debug function sets the required unlock and starts that floor.

RUNTIME NOTE
- Static validation is included in VALIDATION.txt.
- Minecraft runtime testing remains authoritative for balance, mob AI, block-state behavior and DAI reaction timing.
