# Changelog

## v0.8.0 — DAI 4.1 Authority-Safe Reaction Compatibility
- Updated metadata and current documentation for **DAI Engine 4.1**.
- Added stable `dai.pack_id: blink_daggers` metadata while retaining the existing addon ID.
- Added nine exact server-loaded `client_callable` function capabilities for Kitty's intentional player-input actions.
- Marked the matching reaction action nodes with the same capability intent for Creator/audit visibility.
- Internal projectile, recall, ownership, cleanup and migration functions remain unexposed to normal clients.
- Preserved all Q/W/R timings, edge-triggered input behavior, recall behavior, projectile behavior, cooldown state and stable content IDs.
- No persistent-state migration or reset is required.

## v0.7.0 — DAI 4.0 Compatibility + Capability / Efficiency Pass
- Updated addon metadata and documentation for **DAI Engine 4.0** while preserving the stable `blink_daggers` addon ID.
- Verified the existing registry-backed DAI item definitions and structured projectile definitions against the DAI 4.0 content schema.
- Added a non-destructive v0.7.0 runtime migration; existing Q/W/R cooldowns, owner IDs, input state, and active dagger displays are preserved.
- Added `#blink_daggers:runtime_items` to centralize the five Kitty/legacy item identities used by runtime ownership checks.
- Added an idle-player fast path: players with no active cooldown/input work and no Kitty item selected return before the heavier per-player runtime/UI pass.
- Reworked projectile owner-context resolution to cache the current projectile owner score in `#owner bd_tmp`, removing the temporary `bd_current_dagger` tag and repeated global current-projectile lookup from the 20 TPS projectile hot path.
- Kept owner cleanup deterministic and preserved the existing 10-second disconnected-owner maintenance cadence.
- Consolidated the five identical ultimate target-selection steps into `blink_daggers:ultimate/target/next`; the old numbered helper functions remain as compatibility wrappers.
- Updated directional and ultimate projectile metadata descriptions to DAI 4.0 terminology without changing live command-driven movement, collision, recall, sticking, or damage behavior.
- Preserved the edge-triggered LMB/RMB reaction routing and 20-tick dual-input ultimate chord.
- Preserved Q/W/R timings, five-knife ultimate behavior, 35-block recall, 0.75-block aim tolerance, projectile speed, visual cooldown channels, and stable content IDs.
- No reset of player progression/state or active normal daggers is required.

## v0.6.0 — DAI 3.3 Capability + Efficiency Pass
- Updated addon metadata and documentation for **DAI 3.3**.
- Consolidated the player hot path into one local per-player runtime function, replacing repeated global player selectors for cooldowns, input cleanup, migration checks, and selected-item UI.
- Consolidated first-time initialization, v0.5.x migrations, and owner-ID assignment behind one v0.6.0 runtime gate.
- Replaced separate normal-dagger and ultimate-knife world scans with one shared `bd_projectile` dispatcher at the same full 20 TPS simulation rate.
- Consolidated the 10-second disconnected-owner cleanup into the same shared projectile selection.
- Existing active v0.5.x dagger displays are adopted into the shared dispatcher during `/reload` instead of being deleted.
- Added structured DAI 3.3 projectile profiles for the directional dagger and ultimate knives, documenting speed, lifetime, hit radius, damage, and collision behavior for the modern runtime; command-driven pitch drift remains authoritative.
- Kept the proven command-driven projectile implementation for exact recall, sticking, tumbling, and five-knife ultimate behavior.
- Preserved edge-triggered LMB/RMB input routing and the server-side 20-tick dual-input ultimate chord.
- Preserved Q/W/R cooldown durations, Q durability display, W safe visual fallback, R glint readiness, 35-block recall, and all standalone skill items.
- Preserved stable Kitty content IDs used by recognized World of Addons champion integration.
- No player progression, cooldown, or active normal-dagger reset is required.

## v0.5.2 — Right-Click Texture Hotfix
- Fixed the combined dagger switching to the missing `blink_daggers:kitty_dagger_red` item model when RMB starts the W/drop cooldown.
- W cooldown rendering now safely falls back to the generated/base `blink_daggers:kitty_dagger` model in the datapack-only release.
- Preserved Q durability cooldown display and R readiness glint exactly as before.
- No ability timing, input routing, recall behavior, projectile behavior, cooldown values, or saved player state changed.

## v0.5.1 — Input + Recall Hotfix
- Replaced the combined dagger's always-running `player_input_tick` idle/held router with edge-triggered input handling.
- LMB directional throw now fires on the physical attack press instead of waiting for a 3-tick tap window.
- RMB basic action now fires once on the use press instead of waiting for held-input ticks.
- Moved the 20-tick dual-click ultimate timer into the datapack server tick so holding inputs no longer queues one DAI action every tick.
- Fixed DAI action-queue saturation caused by `input/neither` dispatching continuously while the weapon was idle.
- Fixed stale `bd_ray=999` state preventing a later RMB dagger placement after a successful recall.
- Recall ray now passes through leaves, grass, ferns, flowers, vines, moss carpets, roots and similar lightweight foliage while solid blocks remain obstructive.
- Added non-destructive v0.5.1 input-state migration; cooldowns and active dagger anchors remain preserved.

## v0.5.0 — DAI 3.1 Addon Modernization
- Updated pack metadata and item definitions to the current **DAI 3.1 addon** standard.
- Added explicit empty item `events` objects for current DAI item-definition consistency.
- Reworked cooldown UI calculation from hundreds of per-tick range/replace branches into scoreboard arithmetic + function macros.
- Preserved the same 20-step durability cooldown bars, W red-flash channel, and R readiness glint.
- Limited the W flash clock to periods where the W cooldown is active.
- Removed unused throw-context tagging and a redundant recall ray reset.
- Narrowed transient tag cleanup selectors to tagged entities/players rather than unconditional global clears.
- Preserved 20 TPS projectile movement/collision while keeping orphan cleanup at a low 10-second cadence.
- Added non-destructive v0.5.0 player migration without resetting Q/W/R cooldowns or active normal dagger anchors.
- Updated README/compatibility documentation from legacy DAI 2.1/3.0 wording to **DAI 3.1**.

## v0.4.0 — Multiplayer Cleanup + Vanilla Fallback
- Kept the addon datapack-only and retained vanilla Iron Sword fallback presentation.
- Added 10-second orphan-projectile maintenance for disconnected owners.
- Preserved native `blink_daggers:*` item IDs for future unified League of Addons resource overrides.
- Preserved Q/W/R cooldowns, dual-input ultimate, directional throws, recall, and reclaim behavior.

## v0.3.1 — DAI 2.1 Input API
- Updated the combined **Kitty's Dagger** controls to the finalized DAI 2.1 input API.
- Replaced `input_attack_held` with `keybind_held` + `parameter: "attack"`.
- Replaced `input_use_held` with `keybind_held` + `parameter: "use"`.
- Continues to use `player_attack_input` to suppress vanilla LMB behavior.
- Continues to use `player_input_tick` for held-input timing and the 20-tick LMB+RMB ultimate chord.
- No longer depends on the temporary raw-input compatibility conditions from the pre-2.1 patch.
- Preserved all v0.3.0 gameplay: three cooldowns, standalone skill items, five-knife ultimate, 35-block recall, 0.75-block recall tolerance, and 1.3x directional throw velocity.

## v0.3.0
- Renamed the combined item to **Kitty's Dagger**.
- Added three independent cooldowns: directional throw, up/drop, and ultimate.
- Added main-item UI channels: durability (Q), red flash (W cooldown), enchant glint (R ready).
- Added **Kitty's Directional Throw**, **Kitty's Up Throw**, and **Kitty's Ultimate** standalone skill items.
- Standalone items cast their skill on right-click and use a normal durability cooldown bar.
- Added raw held-input routing for the combined item.
- Added 20-tick LMB+RMB ultimate chord with a short basic-skill tap grace.
- Added five-projectile ultimate targeting entities within 15 blocks.
- Added randomized horizontal circular-fan fallback when no target is available.
- Preserved 35-block recall, 0.75-block recall tolerance, and 1.3x throw velocity.
