scoreboard players operation #owner bd_tmp = @s bd_owner
execute as @a if score @s bd_pid = #owner bd_tmp run tag @s add bd_owner_context
execute unless entity @a[tag=bd_owner_context] run kill @s
tag @a[tag=bd_owner_context] remove bd_owner_context
