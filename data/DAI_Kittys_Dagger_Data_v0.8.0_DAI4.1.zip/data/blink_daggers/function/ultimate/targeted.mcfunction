# Five passes prefer unique nearby targets, then reuse the nearest target if fewer than five exist.
function blink_daggers:ultimate/target/next
function blink_daggers:ultimate/target/next
function blink_daggers:ultimate/target/next
function blink_daggers:ultimate/target/next
function blink_daggers:ultimate/target/next
