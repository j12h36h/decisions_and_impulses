# v0.8.0 / DAI 4.1: one local player pass with an idle fast-path.
execute unless entity @s[tag=bd_runtime_v070] run function blink_daggers:internal/player_runtime_v070

# Players with no Kitty cooldown/input work and no Kitty item selected leave immediately.
# This keeps multiplayer cost low without stopping cooldowns or held-input cleanup for active users.
execute if score @s bd_cd_q matches 0 if score @s bd_cd_w matches 0 if score @s bd_cd_r matches 0 if score @s bd_flash matches 0 if score @s bd_attack_ticks matches 0 if score @s bd_use_ticks matches 0 if score @s bd_combo_ticks matches 0 if score @s bd_combo_lock matches 0 unless items entity @s weapon.mainhand #blink_daggers:runtime_items run return 0

# Independent cooldowns.
execute if score @s bd_cd_q matches 1.. run scoreboard players remove @s bd_cd_q 1
execute if score @s bd_cd_w matches 1.. run scoreboard players remove @s bd_cd_w 1
execute if score @s bd_cd_r matches 1.. run scoreboard players remove @s bd_cd_r 1

# W flash clock only runs while W is cooling down.
execute if score @s bd_cd_w matches 1.. run scoreboard players add @s bd_flash 1
execute if score @s bd_cd_w matches 1.. if score @s bd_flash matches 8.. run scoreboard players set @s bd_flash 0
execute if score @s bd_cd_w matches 0 run scoreboard players set @s bd_flash 0

# Combined-item held-state cleanup + 1-second dual-click ultimate chord.
scoreboard players set @s bd_tmp 0
execute if items entity @s weapon.mainhand blink_daggers:kitty_dagger run scoreboard players set @s bd_tmp 1
execute if score @s bd_tmp matches 0 run scoreboard players set @s bd_attack_ticks 0
execute if score @s bd_tmp matches 0 run scoreboard players set @s bd_use_ticks 0
execute if score @s bd_tmp matches 0 run scoreboard players set @s bd_combo_ticks 0
execute if score @s bd_tmp matches 0 run scoreboard players set @s bd_combo_lock 0
execute if score @s bd_attack_ticks matches 1 if score @s bd_use_ticks matches 1 if items entity @s weapon.mainhand blink_daggers:kitty_dagger run function blink_daggers:input/combo_tick
execute if score @s bd_attack_ticks matches 0 run scoreboard players set @s bd_combo_ticks 0
execute if score @s bd_use_ticks matches 0 run scoreboard players set @s bd_combo_ticks 0

# Seamlessly migrate a selected legacy v0.2.x dagger.
execute if items entity @s weapon.mainhand blink_daggers:blink_dagger run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=1] 1

# Update only the currently selected Kitty item. Cooldowns still advance through this local pass.
execute if items entity @s weapon.mainhand blink_daggers:kitty_dagger run function blink_daggers:ui/main
execute if items entity @s weapon.mainhand blink_daggers:kitty_directional_throw run function blink_daggers:ui/q_item
execute if items entity @s weapon.mainhand blink_daggers:kitty_up_throw run function blink_daggers:ui/w_item
execute if items entity @s weapon.mainhand blink_daggers:kitty_ultimate run function blink_daggers:ui/r_item
