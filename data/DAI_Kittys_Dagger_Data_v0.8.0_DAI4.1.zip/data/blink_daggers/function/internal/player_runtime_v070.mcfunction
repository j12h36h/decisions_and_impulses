# v0.7.0 / DAI 4.0 runtime migration gate.
# Preserve all v0.6.x cooldowns/projectiles and reuse the consolidated v0.6.0 bootstrap.
execute unless entity @s[tag=bd_runtime_v060] run function blink_daggers:internal/player_runtime_v060
execute unless score @s bd_pid matches 1.. run function blink_daggers:internal/assign_player_id
scoreboard players add @s bd_cd_q 0
scoreboard players add @s bd_cd_w 0
scoreboard players add @s bd_cd_r 0
scoreboard players add @s bd_flash 0
scoreboard players add @s bd_attack_ticks 0
scoreboard players add @s bd_use_ticks 0
scoreboard players add @s bd_combo_ticks 0
scoreboard players add @s bd_combo_lock 0
tag @s add bd_runtime_v070
