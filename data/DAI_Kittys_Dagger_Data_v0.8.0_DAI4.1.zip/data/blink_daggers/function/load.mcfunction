# [DAI] Kitty's Dagger v0.8.0 / DAI 4.1 addon runtime
scoreboard objectives add bd_pid dummy
scoreboard objectives add bd_owner dummy
scoreboard objectives add bd_age dummy
scoreboard objectives add bd_spin dummy
scoreboard objectives add bd_pitch dummy
scoreboard objectives add bd_ray dummy
scoreboard objectives add bd_cd_q dummy
scoreboard objectives add bd_cd_w dummy
scoreboard objectives add bd_cd_r dummy
scoreboard objectives add bd_flash dummy
scoreboard objectives add bd_attack_ticks dummy
scoreboard objectives add bd_use_ticks dummy
scoreboard objectives add bd_combo_ticks dummy
scoreboard objectives add bd_combo_lock dummy
scoreboard objectives add bd_rand dummy
scoreboard objectives add bd_tmp dummy
scoreboard objectives add bd_ui dummy

# Persistent fake-player state and UI constants. `add 0` preserves existing world values across /reload.
scoreboard players add #next_player bd_tmp 0
scoreboard players set #owner bd_tmp 0
scoreboard players set #maintenance bd_tmp 0
scoreboard players set #five bd_ui 5
scoreboard players set #fifteen bd_ui 15

# Clear transient execution-context tags only. Active normal daggers survive /reload.
tag @a[tag=bd_owner_context] remove bd_owner_context
tag @a[tag=bd_ray_user] remove bd_ray_user
tag @a[tag=bd_action_user] remove bd_action_user
tag @a[tag=bd_ult_user] remove bd_ult_user
tag @e[tag=bd_current_dagger] remove bd_current_dagger
tag @e[tag=bd_ray_hit] remove bd_ray_hit
tag @e[tag=bd_ult_target] remove bd_ult_target
tag @e[tag=bd_ult_selected] remove bd_ult_selected

# v0.7.0 / DAI 4.0 runtime migration:
# - force online players through the DAI 4.0 bootstrap gate once after /reload
# - preserve all cooldowns and active dagger displays
# - adopt pre-v0.6.0 display projectiles into the shared dispatcher
tag @a remove bd_runtime_v070
tag @e[type=minecraft:item_display,tag=bd_dagger] add bd_projectile
tag @e[type=minecraft:item_display,tag=bd_ult_knife] add bd_projectile
