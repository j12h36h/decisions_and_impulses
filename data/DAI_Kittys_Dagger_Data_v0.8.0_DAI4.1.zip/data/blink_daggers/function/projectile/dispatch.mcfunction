# v0.8.0 / DAI 4.1 shared projectile dispatcher: one item_display selection for all Kitty projectile families.
execute if entity @s[tag=bd_dagger] run function blink_daggers:projectile/tick
execute if entity @s[tag=bd_ult_knife] run function blink_daggers:ultimate/projectile_tick
