# [DAI] Kitty's Dagger v0.8.0

A **DAI Engine 4.1 addon** implementing Kitty's combined three-skill dagger kit plus three standalone right-click skill items.

## Combined item: Kitty's Dagger
- **LMB:** directional dagger throw fires immediately on the physical attack press.
- **RMB:** immediately aim at an owned dagger to blink/reclaim; otherwise place a dagger at your feet and gain Speed III.
- **Hold LMB + RMB together for 20 ticks (~1 second):** cast the five-knife ultimate.
- Simultaneous dual-input is edge-routed; holding both does not dispatch a DAI action every tick.
- Directional cooldown is shown by durability.
- Up/drop cooldown safely uses the base dagger visual in this datapack-only build.
- Ultimate readiness is shown by enchantment glint.

## Recall
- Recall range: 35 blocks with a 0.75-block aim tolerance.
- The recall ray passes through lightweight foliage such as leaves, short/tall grass, ferns, flowers, vines, moss carpets, roots and similar plants.
- Solid terrain still blocks the ray.

## Ultimate
- Throws exactly five knife projectiles.
- If entities exist within 15 blocks, unique nearby targets are preferred and remaining knives reuse the nearest target when fewer than five exist.
- If no valid targets exist, five knives fire horizontally in a randomized circular fan around the player's facing direction.
- Each ultimate knife deals 6 projectile damage.

## Standalone skill items
- **Kitty's Directional Throw:** right-click Q; durability bar = Q cooldown.
- **Kitty's Up Throw:** right-click W; durability bar = W cooldown.
- **Kitty's Ultimate:** right-click R; durability bar = R cooldown.
- Cooldowns are shared with the combined item.

## Defaults
- Q cooldown: 100 ticks / 5 seconds.
- W cooldown: 100 ticks / 5 seconds.
- R cooldown: 300 ticks / 15 seconds.
- Normal dagger anchors live about 100 ticks / 5 seconds.
- Directional projectile speed: 0.715 blocks/tick.
- Disconnected-owner projectile cleanup: every 200 ticks / 10 seconds.

## DAI Engine 4.1
- Declares the stable DAI addon identity **`blink_daggers`** and remains an addon rather than an Experience Pack.
- Keeps the existing registry-backed DAI item identities and structured DAI projectile profiles compatible with the 4.1 content runtime.
- Preserves DAI reaction-driven input routing for LMB/RMB and the server-side dual-input ultimate chord.
- Uses a v0.7.0 non-destructive runtime migration; existing cooldowns, player IDs and active dagger displays are preserved.
- Adds an idle-player fast path so players with no active cooldown/input state and no Kitty item selected skip almost all per-tick addon work.
- Adds one `#blink_daggers:runtime_items` item tag for low-cost runtime ownership checks and future addon integration.
- Replaces per-projectile temporary entity lookup tags with a scoreboard owner-context cache, reducing hot-path entity selector work.
- Consolidates the five identical ultimate target-selection helpers into one shared implementation while retaining the old helper IDs as compatibility wrappers.
- Existing v0.5.x/v0.6.x worlds and players remain non-destructive.
- Stable `blink_daggers:*` content IDs remain unchanged for recognized World of Addons integrations.

This pack is intentionally **datapack-only**. It does not claim Experience saves, world generation, title-screen ownership, or an Experience resource-pack lifecycle.

Requires **Decisions & Impulses (D.A.I.) Engine 4.1** and Minecraft **26.2**.


## v0.8.0 — DAI 4.1 Authority Compatibility

DAI 4.1 no longer trusts a client merely because it knows a datapack function ID. Kitty's reaction-driven inputs therefore now declare exact server-loaded capabilities for the nine functions that are intentionally callable from player input.

- LMB/RMB reaction behavior is unchanged.
- Only the exact Q/W/R and input-edge functions used by Kitty are exposed.
- Internal projectile, recall, cleanup, migration and maintenance functions remain server-only.
- Stable `blink_daggers:*` item/function IDs are unchanged.
- No cooldown, player ID, projectile or saved-state reset is required.
