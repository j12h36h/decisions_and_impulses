# EchoTime v1.0

- Promoted EchoTime to the 1.0 release line.
- Restored Temporal Recall's intended Ender-themed appearance as an **enchanted Ender Eye**.
- Kept Temporal Recall on a passive Clock carrier internally so the old Ender Pearl delayed-teleport bug cannot return.
- Fixed and expanded English localization entries for all four native EchoTime items and their descriptions.
- Preserved the existing `dai_time_reverse` namespace and native item IDs for world compatibility.
- No changes to Temporal Recall timing, Chrono Anchor's 2-second 10-block freeze, Reversal Field's 10-block rewind, or Temporal Stream's 5-second channel behavior.
- Compatible with DAI 1.9.9 / Minecraft Java 26.2.
