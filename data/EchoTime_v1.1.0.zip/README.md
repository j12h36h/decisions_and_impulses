# EchoTime

EchoTime v1.0 is a standalone DAI temporal-ability addon for Minecraft Java 26.2 and DAI 1.9.9.

## Ability Items

- **Temporal Recall** — rewinds your recent movement and facing for up to 3 seconds. It uses a safe passive carrier internally, but renders as an **enchanted Ender Eye**.
- **Chrono Anchor** — stops nearby non-player entities in time for 2 seconds within a 10-block radius.
- **Reversal Field** — rewinds recorded nearby non-player entities within 10 blocks for up to 3 seconds.
- **Temporal Stream** — hold use to continuously rewind yourself for up to 5 seconds, then resume from the historical point reached.

Each player receives one copy of all four items automatically. If an item is lost, run:

`/function dai_time_reverse:starter/give`

The internal `dai_time_reverse` namespace is intentionally retained for compatibility with existing worlds and items.

## Compatibility

- Minecraft Java 26.2
- DAI 1.9.9
- Data Pack format 107.1
