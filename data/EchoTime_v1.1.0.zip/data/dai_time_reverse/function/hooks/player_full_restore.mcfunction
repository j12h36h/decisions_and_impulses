# Extension hook for experience-specific personal state.
# v0.2.0's Chrono Anchor contract restores transform + historical health.
# Inventory/effect/hunger rewrites are intentionally not guessed by the base addon.
