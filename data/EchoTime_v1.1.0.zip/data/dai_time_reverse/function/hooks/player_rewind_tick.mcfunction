# Rewind playback owns player position, but vanilla does not allow datapacks to
# directly rewrite a player's Motion/FallDistance NBT like it does for mobs.
# Refresh a short protection window so fall state from the erased future cannot
# resolve as damage between historical teleport frames.
effect give @s minecraft:resistance 1 4 true
effect give @s minecraft:slow_falling 1 0 true
execute if score @s tr_mode matches 3 run title @s actionbar [{"text":"Temporal Stream • charge ","color":"aqua"},{"score":{"name":"@s","objective":"tr_ticks"},"color":"white"},{"text":"/50","color":"dark_aqua"}]
