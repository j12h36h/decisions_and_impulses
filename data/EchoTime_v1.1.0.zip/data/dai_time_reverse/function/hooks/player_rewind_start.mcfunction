# Default start feedback. Main experiences may append their own presentation here.
#
# Player entities cannot have Motion/FallDistance written back with vanilla /data
# the way non-player entities can. Protect the player while the discarded fall
# timeline is being replaced by historical positions.
effect give @s minecraft:resistance 4 4 true
effect give @s minecraft:slow_falling 4 0 true
playsound minecraft:block.respawn_anchor.set_spawn player @s ~ ~ ~ 0.6 1.8
title @s actionbar {"text":"Timeline reversing...","color":"aqua"}
