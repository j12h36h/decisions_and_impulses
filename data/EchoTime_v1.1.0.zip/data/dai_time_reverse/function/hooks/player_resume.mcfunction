# Give normal player physics a short safe handoff after positional playback.
# This prevents stale downward velocity/fall distance from the discarded future
# from immediately resolving as fall damage after Temporal Recall/Chrono Anchor.
effect give @s minecraft:resistance 1 4 true
effect give @s minecraft:slow_falling 1 0 true
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.45 1.35
title @s actionbar {"text":"Timeline resumed.","color":"green"}
