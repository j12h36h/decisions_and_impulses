# Runs every tick while Temporal Stream is actively being used.
# Revoke immediately so minecraft:using_item can reward this function again next tick.
advancement revoke @s only dai_time_reverse:temporal_stream_using
scoreboard players set @s tr_hold 3

# Exhaustion locks this channel until the player actually releases the item.
execute if score @s tr_dry matches 1.. run return 0

# First held-use pulse starts the continuous rewind. Later pulses only keep it alive.
execute if score @s tr_mode matches 0 run function dai_time_reverse:activate/stream
