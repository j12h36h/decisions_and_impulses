# Manual recovery command for the four EchoTime ability items.
execute unless items entity @s inventory.* dai_time_reverse:temporal_recall run give @s dai_time_reverse:temporal_recall 1
execute unless items entity @s inventory.* dai_time_reverse:chrono_anchor run give @s dai_time_reverse:chrono_anchor 1
execute unless items entity @s inventory.* dai_time_reverse:reversal_field run give @s dai_time_reverse:reversal_field 1
execute unless items entity @s inventory.* dai_time_reverse:temporal_stream run give @s dai_time_reverse:temporal_stream 1
tag @s add tr_items_v022
tag @s add tr_items_v024
tellraw @s [{"text":"[EchoTime] ","color":"aqua","bold":true},{"text":"Ability items restored: ","color":"green","bold":false},{"text":"Temporal Recall, Chrono Anchor, Reversal Field, Temporal Stream","color":"white"}]
