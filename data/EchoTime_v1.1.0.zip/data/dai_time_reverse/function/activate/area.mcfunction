# Reversal Field: entities currently within 10 blocks rewind for up to 3 seconds.
execute if score @s tr_cdarea matches 1.. run title @s actionbar {"text":"Reversal Field is recharging.","color":"gray"}
execute if score @s tr_cdarea matches 1.. run return 0
execute unless entity @e[type=!minecraft:player,type=!minecraft:marker,distance=..10,scores={tr_eid=1..},tag=!tr_area_rewinding] run title @s actionbar {"text":"No recorded entity timeline is in range.","color":"yellow"}
execute unless entity @e[type=!minecraft:player,type=!minecraft:marker,distance=..10,scores={tr_eid=1..},tag=!tr_area_rewinding] run return 0

scoreboard players set @s tr_cdarea 80
playsound minecraft:block.respawn_anchor.set_spawn player @s ~ ~ ~ 0.55 1.65
execute as @e[type=!minecraft:player,type=!minecraft:marker,distance=..10,scores={tr_eid=1..},tag=!tr_area_rewinding,limit=8,sort=nearest] at @s run function dai_time_reverse:entity/start
