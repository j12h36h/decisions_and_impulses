# Temporal Stream: rewind continuously while use is held, up to 5 seconds.
execute unless score @s tr_mode matches 0 run return 0

scoreboard players set @s tr_mode 3
scoreboard players set @s tr_ticks 50
scoreboard players set @s tr_hold 3
scoreboard players set @s tr_dry 0
function dai_time_reverse:hooks/player_rewind_start
playsound minecraft:item.spyglass.use player @s ~ ~ ~ 0.45 1.6
title @s actionbar {"text":"Temporal Stream engaged — hold to rewind.","color":"aqua"}
