# EchoTime Chrono Anchor: locally freezes nearby entities for 2 seconds.
# This is a time-stop effect, not a rewind. The caster remains free to move.
execute if score @s tr_cdfull matches 1.. run title @s actionbar {"text":"Chrono Anchor is recharging.","color":"gray"}
execute if score @s tr_cdfull matches 1.. run return 0

scoreboard players set @s tr_cdfull 120

# Freeze non-player entities in a 10-block radius. Exclude runtime markers so
# EchoTime's own history infrastructure is never frozen or tagged.
execute as @e[type=!minecraft:player,type=!minecraft:marker,distance=..10] at @s run function dai_time_reverse:freeze/start

title @s actionbar {"text":"Chrono Anchor — time stopped for 2 seconds","color":"aqua"}
