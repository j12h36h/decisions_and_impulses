# Temporal Recall: 3 seconds, movement/facing only.
execute unless score @s tr_mode matches 0 run title @s actionbar {"text":"A personal rewind is already active.","color":"yellow"}
execute unless score @s tr_mode matches 0 run return 0
execute if score @s tr_cdemg matches 1.. run title @s actionbar {"text":"Temporal Recall is recharging.","color":"gray"}
execute if score @s tr_cdemg matches 1.. run return 0

scoreboard players set @s tr_mode 1
scoreboard players set @s tr_ticks 30
scoreboard players set @s tr_cdemg 80
function dai_time_reverse:hooks/player_rewind_start
