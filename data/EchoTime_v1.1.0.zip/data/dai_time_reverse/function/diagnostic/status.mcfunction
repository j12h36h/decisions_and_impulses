# EchoTime v0.2.6 diagnostic
tellraw @s [{"text":"[EchoTime] ","color":"aqua","bold":true},{"text":"v0.2.6 is loaded.","color":"green","bold":false}]
tellraw @s [{"text":"Chrono Anchor: ","color":"aqua"},{"text":"2-second time stop / 10-block radius","color":"white"}]
tellraw @s [{"text":"Internal namespace: ","color":"gray"},{"text":"dai_time_reverse (retained for compatibility)","color":"white"}]
