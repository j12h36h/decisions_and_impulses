scoreboard players operation #owner tr_tmp = @s tr_id

# Full rewind restores personal health at the historical release frame.
execute if score @s tr_mode matches 2 run function dai_time_reverse:player/restore_health
execute if score @s tr_mode matches 2 run function dai_time_reverse:hooks/player_full_restore

# DAI can use this hook to re-apply recorded forward player velocity / input ownership.
function dai_time_reverse:hooks/player_resume

# The old future no longer exists. Clear unused frames from that branch.
execute as @e[type=minecraft:marker,tag=tr_player_snapshot] if score @s tr_owner = #owner tr_tmp run kill @s
execute as @e[type=minecraft:marker,tag=tr_resume_frame,tag=tr_player_resume] if score @s tr_owner = #owner tr_tmp run kill @s

scoreboard players set @s tr_mode 0
scoreboard players set @s tr_ticks 0
tag @s remove tr_current_player
