# Vanilla-safe best effort: restore historical health to half-health-point precision.
# Heal first, then trim down with armor-bypassing out_of_world damage.
# The loop is hard-capped so unusual immunity behavior can never recurse forever.
scoreboard players operation #target_hp tr_tmp = @s tr_resumehp
execute if score #target_hp tr_tmp matches ..0 run scoreboard players set #target_hp tr_tmp 1
scoreboard players set @s tr_loop 0
effect give @s minecraft:instant_health 1 10 true
function dai_time_reverse:player/restore_health_loop
