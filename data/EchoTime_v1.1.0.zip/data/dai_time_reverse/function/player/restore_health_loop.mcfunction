scoreboard players add @s tr_loop 1
execute store result score #current_hp tr_tmp run data get entity @s Health 2
execute if score #current_hp tr_tmp > #target_hp tr_tmp run damage @s 0.5 minecraft:out_of_world
execute store result score #current_hp tr_tmp run data get entity @s Health 2
execute if score #current_hp tr_tmp > #target_hp tr_tmp if score @s tr_loop matches ..63 run function dai_time_reverse:player/restore_health_loop
