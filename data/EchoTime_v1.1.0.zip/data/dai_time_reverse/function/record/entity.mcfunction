# Allocate an entity timeline ID the first time this entity enters the tracked radius.
execute unless score @s tr_eid matches 1.. run function dai_time_reverse:internal/assign_entity_id

summon minecraft:marker ~ ~ ~ {Tags:["tr_snapshot","tr_entity_snapshot","tr_new_entity"],data:{}}
scoreboard players operation @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] tr_owner = @s tr_eid
scoreboard players set @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] tr_age 0
data modify entity @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] Rotation set from entity @s Rotation
data modify entity @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] data.motion set from entity @s Motion
execute if data entity @s Health run data modify entity @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] data.health set from entity @s Health
execute if data entity @s Fire run data modify entity @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] data.fire set from entity @s Fire
execute if data entity @s Air run data modify entity @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] data.air set from entity @s Air
execute if data entity @s inGround run data modify entity @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] data.in_ground set from entity @s inGround
execute if data entity @s FallDistance run data modify entity @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] data.fall_distance set from entity @s FallDistance

tag @e[type=minecraft:marker,tag=tr_new_entity,limit=1,sort=nearest] remove tr_new_entity
