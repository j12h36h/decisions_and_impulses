# One invisible marker = one historical player frame.
summon minecraft:marker ~ ~ ~ {Tags:["tr_snapshot","tr_player_snapshot","tr_new_player"]}
scoreboard players operation @e[type=minecraft:marker,tag=tr_new_player,limit=1,sort=nearest] tr_owner = @s tr_id
scoreboard players set @e[type=minecraft:marker,tag=tr_new_player,limit=1,sort=nearest] tr_age 0
execute store result score @e[type=minecraft:marker,tag=tr_new_player,limit=1,sort=nearest] tr_hp run data get entity @s Health 2
data modify entity @e[type=minecraft:marker,tag=tr_new_player,limit=1,sort=nearest] Rotation set from entity @s Rotation
data modify entity @e[type=minecraft:marker,tag=tr_new_player,limit=1,sort=nearest] data.motion set from entity @s Motion
execute if data entity @s FallDistance run data modify entity @e[type=minecraft:marker,tag=tr_new_player,limit=1,sort=nearest] data.fall_distance set from entity @s FallDistance

tag @e[type=minecraft:marker,tag=tr_new_player,limit=1,sort=nearest] remove tr_new_player
