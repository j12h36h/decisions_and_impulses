# Deduplicate an entity that is inside multiple players' 10-block sample radii.
execute if score @s tr_recstamp = #epoch tr_tmp run return 0
scoreboard players operation @s tr_recstamp = #epoch tr_tmp
function dai_time_reverse:record/entity
