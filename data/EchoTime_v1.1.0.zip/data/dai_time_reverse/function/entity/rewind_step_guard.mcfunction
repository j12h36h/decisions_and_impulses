# Deduplicate area playback for overlapping players without global tag sweeps.
execute if score @s tr_playstamp = #epoch tr_tmp run return 0
scoreboard players operation @s tr_playstamp = #epoch tr_tmp
function dai_time_reverse:entity/rewind_step
