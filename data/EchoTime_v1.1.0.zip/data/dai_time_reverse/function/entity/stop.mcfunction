scoreboard players operation #owner tr_tmp = @s tr_eid

tag @e[type=minecraft:marker,tag=tr_selected] remove tr_selected
execute as @e[type=minecraft:marker,tag=tr_resume_frame,tag=tr_entity_resume] if score @s tr_owner = #owner tr_tmp run tag @s add tr_selected

# CRITICAL RULE: resume with the historical frame's ORIGINAL FORWARD velocity.
execute if data entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.motion run data modify entity @s Motion set from entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.motion
execute if data entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.in_ground run data modify entity @s inGround set from entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.in_ground
execute if data entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.fall_distance run data modify entity @s FallDistance set from entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.fall_distance

# Restore simulation flags exactly as they were before localized rewind began.
execute if score @s tr_invul matches 0 run data merge entity @s {Invulnerable:0b}
execute if score @s tr_invul matches 1.. run data merge entity @s {Invulnerable:1b}
execute if score @s tr_nograv matches 0 run data merge entity @s {NoGravity:0b}
execute if score @s tr_nograv matches 1.. run data merge entity @s {NoGravity:1b}
execute if data entity @s NoAI if score @s tr_noai matches 0 run data merge entity @s {NoAI:0b}
execute if data entity @s NoAI if score @s tr_noai matches 1.. run data merge entity @s {NoAI:1b}

# Discard the old future so subsequent rewinds start from the new branch.
execute as @e[type=minecraft:marker,tag=tr_entity_snapshot] if score @s tr_owner = #owner tr_tmp run kill @s
execute as @e[type=minecraft:marker,tag=tr_resume_frame,tag=tr_entity_resume] if score @s tr_owner = #owner tr_tmp run kill @s

scoreboard players set @s tr_rticks 0
tag @s remove tr_area_rewinding
tag @s remove tr_current_entity
