# A newly spawned entity may not have history yet, but assigning an ID is harmless.
execute unless score @s tr_eid matches 1.. run function dai_time_reverse:internal/assign_entity_id

scoreboard players set @s tr_rticks 30
scoreboard players set @s tr_invul 0
scoreboard players set @s tr_nograv 0
scoreboard players set @s tr_noai 0
execute store result score @s tr_invul run data get entity @s Invulnerable 1
execute store result score @s tr_nograv run data get entity @s NoGravity 1
execute if data entity @s NoAI store result score @s tr_noai run data get entity @s NoAI 1

# Seed the resume slot with the entity's CURRENT forward state. The first consumed historical
# frame replaces this marker; if no history exists, stop() can still restore the original motion.
summon minecraft:marker ~ ~ ~ {Tags:["tr_resume_frame","tr_entity_resume","tr_new_origin"],data:{}}
scoreboard players operation @e[type=minecraft:marker,tag=tr_new_origin,limit=1,sort=nearest] tr_owner = @s tr_eid
data modify entity @e[type=minecraft:marker,tag=tr_new_origin,limit=1,sort=nearest] data.motion set from entity @s Motion
execute if data entity @s inGround run data modify entity @e[type=minecraft:marker,tag=tr_new_origin,limit=1,sort=nearest] data.in_ground set from entity @s inGround
execute if data entity @s FallDistance run data modify entity @e[type=minecraft:marker,tag=tr_new_origin,limit=1,sort=nearest] data.fall_distance set from entity @s FallDistance
tag @e[type=minecraft:marker,tag=tr_new_origin,limit=1,sort=nearest] remove tr_new_origin

data merge entity @s {Invulnerable:1b,NoGravity:1b,Motion:[0.0d,0.0d,0.0d]}
execute if data entity @s NoAI run data merge entity @s {NoAI:1b}
tag @s add tr_area_rewinding
