# Maintain the frozen pose for the full duration even if another system tries
# to impart velocity while Chrono Anchor is active.
data merge entity @s {NoGravity:1b,Motion:[0.0d,0.0d,0.0d]}
execute if score @s tr_freeze_hasnoai matches 1 run data merge entity @s {NoAI:1b}
scoreboard players remove @s tr_freeze 1
execute if score @s tr_freeze matches ..0 run function dai_time_reverse:freeze/stop
