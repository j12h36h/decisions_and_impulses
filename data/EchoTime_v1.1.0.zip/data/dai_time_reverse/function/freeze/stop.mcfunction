# Resume normal simulation. Chrono Anchor intentionally resumes entities from
# rest rather than replaying prior motion; it is a pause in time, not a rewind.
execute if score @s tr_freeze_nograv matches 0 run data merge entity @s {NoGravity:0b}
execute if score @s tr_freeze_nograv matches 1.. run data merge entity @s {NoGravity:1b}
execute if score @s tr_freeze_hasnoai matches 1 if score @s tr_freeze_noai matches 0 run data merge entity @s {NoAI:0b}
execute if score @s tr_freeze_hasnoai matches 1 if score @s tr_freeze_noai matches 1.. run data merge entity @s {NoAI:1b}
scoreboard players set @s tr_freeze 0
tag @s remove tr_chrono_frozen
