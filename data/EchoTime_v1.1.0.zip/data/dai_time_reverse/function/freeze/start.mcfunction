# Do not overwrite the original state if an entity is already frozen.
execute if entity @s[tag=tr_chrono_frozen] run scoreboard players set @s tr_freeze 40
execute if entity @s[tag=tr_chrono_frozen] run return 0

scoreboard players set @s tr_freeze 40
scoreboard players set @s tr_freeze_noai 0
scoreboard players set @s tr_freeze_nograv 0
scoreboard players set @s tr_freeze_hasnoai 0

# Remember simulation flags so the entity returns to its prior state cleanly.
execute store success score @s tr_freeze_hasnoai run data get entity @s NoAI
execute if score @s tr_freeze_hasnoai matches 1 store result score @s tr_freeze_noai run data get entity @s NoAI 1
execute store result score @s tr_freeze_nograv run data get entity @s NoGravity 1

# Visually lock the entity in place. NoAI halts living-entity decisions where
# supported; NoGravity + zero Motion handles projectiles and other entities.
execute if score @s tr_freeze_hasnoai matches 1 run data merge entity @s {NoAI:1b}
data merge entity @s {NoGravity:1b,Motion:[0.0d,0.0d,0.0d]}
tag @s add tr_chrono_frozen
