scoreboard players add #next_entity tr_tmp 1
scoreboard players operation @s tr_eid = #next_entity tr_tmp
