scoreboard players add #next_player tr_tmp 1
scoreboard players operation @s tr_id = #next_player tr_tmp
scoreboard players set @s tr_mode 0
scoreboard players set @s tr_ticks 0
scoreboard players set @s tr_cdemg 0
scoreboard players set @s tr_cdfull 0
scoreboard players set @s tr_cdarea 0
execute store result score @s tr_resumehp run data get entity @s Health 2
