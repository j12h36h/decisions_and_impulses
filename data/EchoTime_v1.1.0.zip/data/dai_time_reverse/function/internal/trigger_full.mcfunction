scoreboard players set @s tr_full 0
function dai_time_reverse:activate/full
