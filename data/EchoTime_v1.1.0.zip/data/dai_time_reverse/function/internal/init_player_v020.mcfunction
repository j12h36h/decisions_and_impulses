# Per-version migration/init. Existing v0.1.x player IDs remain valid.
execute unless score @s tr_mode matches 0.. run scoreboard players set @s tr_mode 0
execute unless score @s tr_ticks matches 0.. run scoreboard players set @s tr_ticks 0
execute unless score @s tr_resumehp matches 0.. run execute store result score @s tr_resumehp run data get entity @s Health 2
execute unless score @s tr_cdemg matches 0.. run scoreboard players set @s tr_cdemg 0
execute unless score @s tr_cdfull matches 0.. run scoreboard players set @s tr_cdfull 0
execute unless score @s tr_cdarea matches 0.. run scoreboard players set @s tr_cdarea 0
tag @s add tr_init_v020
