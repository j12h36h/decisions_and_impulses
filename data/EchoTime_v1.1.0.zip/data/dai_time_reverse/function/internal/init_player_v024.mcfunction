# v0.2.4 continuous-rewind item migration.
execute unless items entity @s inventory.* dai_time_reverse:temporal_stream run give @s dai_time_reverse:temporal_stream 1
scoreboard players set @s tr_hold 0
scoreboard players set @s tr_dry 0
tag @s add tr_items_v024
