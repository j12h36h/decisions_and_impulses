# v0.2.2 item migration.
# EchoTime abilities are normal DAI gameplay items now. Grant one copy of
# each ability item once per player; existing copies are preserved.
execute unless items entity @s inventory.* dai_time_reverse:temporal_recall run give @s dai_time_reverse:temporal_recall 1
execute unless items entity @s inventory.* dai_time_reverse:chrono_anchor run give @s dai_time_reverse:chrono_anchor 1
execute unless items entity @s inventory.* dai_time_reverse:reversal_field run give @s dai_time_reverse:reversal_field 1
tag @s add tr_items_v022
