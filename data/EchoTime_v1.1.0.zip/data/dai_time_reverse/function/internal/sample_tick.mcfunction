# 10 Hz bounded temporal-history pass.
#
# Safety invariants:
# - no dimension-wide per-tick tag clearing
# - history aging only near active players
# - at most 16 non-player timelines sampled per player
# - entity sampling radius equals Reversal Field's 10-block activation radius
# - per-entity/per-marker epoch scores deduplicate overlapping players

# Age/expire nearby historical markers exactly once this sample.
execute as @a at @s as @e[type=minecraft:marker,tag=tr_snapshot,distance=..64] run function dai_time_reverse:internal/age_snapshot_guard

# Play personal rewinds at the same 10 Hz cadence used to record history.
execute as @a[scores={tr_mode=1..}] at @s run function dai_time_reverse:player/rewind_step

# Play localized entity rewinds only near an active player and once per sample.
execute as @a at @s as @e[tag=tr_area_rewinding,distance=..64] at @s run function dai_time_reverse:entity/rewind_step_guard

# Record player history after rewind processing.
execute as @a[scores={tr_mode=0}] at @s run function dai_time_reverse:record/player
execute as @a unless score @s tr_mode matches 0.. at @s run function dai_time_reverse:record/player

# Record only the 16 nearest rewindable non-player entities inside the actual
# field radius. This hard cap prevents mob farms/entity piles from multiplying
# history markers without bound.
execute as @a at @s as @e[type=!minecraft:player,type=!minecraft:marker,distance=..10,tag=!tr_area_rewinding,limit=16,sort=nearest] at @s run function dai_time_reverse:record/entity_guard
