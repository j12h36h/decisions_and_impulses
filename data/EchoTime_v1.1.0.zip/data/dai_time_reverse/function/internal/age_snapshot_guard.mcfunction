# A marker can be reached from overlapping players, but may age only once for
# the current 10 Hz sample epoch.
execute if score @s tr_agestamp = #epoch tr_tmp run return 0
scoreboard players operation @s tr_agestamp = #epoch tr_tmp
scoreboard players add @s tr_age 1
execute if score @s tr_age matches 61.. run kill @s
