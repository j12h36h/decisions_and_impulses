# Migration for the bounded 10 Hz history engine.
# Existing stable player IDs and cooldowns remain valid.
scoreboard players set @s tr_mode 0
scoreboard players set @s tr_ticks 0
scoreboard players set @s tr_recstamp 0
scoreboard players set @s tr_agestamp 0
scoreboard players set @s tr_playstamp 0
execute store result score @s tr_resumehp run data get entity @s Health 2
tag @s add tr_init_perfhotfix
