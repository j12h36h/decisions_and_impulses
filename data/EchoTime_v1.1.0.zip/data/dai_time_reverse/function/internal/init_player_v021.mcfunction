# v0.2.1 migration marker.
# Preserve IDs, cooldowns and existing stable state; this exists so future
# migrations can distinguish players that have loaded the 0.2.1 runtime.
tag @s add tr_init_v021
