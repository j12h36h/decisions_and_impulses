scoreboard players set @s tr_area 0
function dai_time_reverse:activate/area
