# Lightweight 20 TPS control loop. Heavy history work is moved to a bounded
# 10 Hz sample pass so simply having the addon installed cannot create an
# unbounded per-tick entity/marker workload.

execute as @a unless score @s tr_id matches 1.. run function dai_time_reverse:internal/assign_player_id
execute as @a[tag=!tr_init_v020] run function dai_time_reverse:internal/init_player_v020
execute as @a[tag=!tr_init_perfhotfix] run function dai_time_reverse:internal/init_player_perfhotfix
execute as @a[tag=!tr_init_v021] run function dai_time_reverse:internal/init_player_v021
execute as @a[tag=!tr_items_v022] run function dai_time_reverse:internal/init_player_v022
execute as @a[tag=!tr_items_v024] run function dai_time_reverse:internal/init_player_v024

# The three temporal abilities are native DAI items. Trigger objectives remain
# enabled below only as a debug/compatibility fallback.


# Temporal Stream hold-state watchdog. minecraft:using_item refreshes tr_hold to 3
# every tick while use is held. Releasing (or switching away) lets it decay to 0,
# which resumes immediately from the historical position already reached.
scoreboard players remove @a[scores={tr_hold=1..}] tr_hold 1
execute as @a[scores={tr_mode=3,tr_hold=0}] at @s run function dai_time_reverse:player/stop
execute as @a[scores={tr_dry=1..,tr_hold=0}] run scoreboard players set @s tr_dry 0


# Chrono Anchor time-stop maintenance. The freeze is intentionally handled at
# 20 TPS so affected entities remain visually locked between history samples.
execute as @e[tag=tr_chrono_frozen,scores={tr_freeze=1..}] at @s run function dai_time_reverse:freeze/tick
execute as @e[tag=tr_chrono_frozen,scores={tr_freeze=..0}] at @s run function dai_time_reverse:freeze/stop

# Cooldowns remain real server ticks.
scoreboard players remove @a[scores={tr_cdemg=1..}] tr_cdemg 1
scoreboard players remove @a[scores={tr_cdfull=1..}] tr_cdfull 1
scoreboard players remove @a[scores={tr_cdarea=1..}] tr_cdarea 1

# Keep manual/test trigger controls available.
scoreboard players enable @a tr_emergency
scoreboard players enable @a tr_full
scoreboard players enable @a tr_area
execute as @a[scores={tr_emergency=1..}] at @s run function dai_time_reverse:internal/trigger_emergency
execute as @a[scores={tr_full=1..}] at @s run function dai_time_reverse:internal/trigger_full
execute as @a[scores={tr_area=1..}] at @s run function dai_time_reverse:internal/trigger_area

# Bounded history / playback pass: once every 2 ticks (10 Hz).
scoreboard players add #sample tr_tmp 1
execute if score #sample tr_tmp matches 2.. run scoreboard players add #epoch tr_tmp 1
execute if score #sample tr_tmp matches 2.. run function dai_time_reverse:internal/sample_tick
execute if score #sample tr_tmp matches 2.. run scoreboard players set #sample tr_tmp 0
