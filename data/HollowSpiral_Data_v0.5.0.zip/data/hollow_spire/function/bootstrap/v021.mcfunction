# v0.2.1 safety migration.
# Retrofit every currently loaded v0.2.0 room now; unloaded rooms are patched lazily
# by dungeon/pulse the first time a player approaches them.
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v021_safe] at @s run function hollow_spire:dungeon/room/retrofit_v021
# Adopt any hostiles created by v0.2.0 so the visibility safeguard applies immediately.
tag @e[type=minecraft:skeleton] add hs_hostile
tag @e[type=minecraft:zombie] add hs_hostile
tag @e[type=minecraft:spider] add hs_hostile
tag @e[type=minecraft:magma_cube] add hs_hostile
tag @e[type=minecraft:zombified_piglin] add hs_hostile
tag @e[type=minecraft:blaze] add hs_hostile
tag @e[type=minecraft:enderman] add hs_hostile
effect clear @e[tag=hs_hostile] minecraft:invisibility
data modify storage hollow_spire:runtime v021 set value 1b
