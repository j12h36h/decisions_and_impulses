# v0.3.4 retrofit: open Volcano containment and repair every already-generated vertical connection.
# First remove legacy Volcano walls/doors and install low retaining borders/landing dams.
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=21}] at @s run function hollow_spire:dungeon/volcano/safety
# Every room marker with another room exactly one vertical pitch above represents an existing stair connection. Rebuild from the lower endpoint.
execute as @e[type=minecraft:marker,tag=hs_room] at @s positioned ~ ~20 ~ if entity @e[type=minecraft:marker,tag=hs_room,distance=..1] positioned ~ ~-20 ~ run function hollow_spire:dungeon/vertical/build_up
data modify storage hollow_spire:runtime v034 set value 1b
