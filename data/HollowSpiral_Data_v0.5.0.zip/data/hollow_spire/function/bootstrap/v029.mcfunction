# v0.2.9 room-family expansion.
scoreboard objectives add hs_ritual dummy
scoreboard objectives add hs_village dummy
scoreboard objectives add hs_ocean dummy
# Existing v0.2.x Village Workshop markers (type 13) are accepted as legacy Overworld Smithery rooms.
# No destructive room rebuilds are performed during this migration.
data modify storage hollow_spire:runtime v029 set value 1b
