# v0.2.7 room-library migration.
scoreboard objectives add hs_depth dummy
scoreboard objectives add hs_secondary dummy
# Slightly brighten the existing Home Room without changing its layout.
execute as @e[type=minecraft:marker,tag=hs_start_room,tag=!hs_v027_homelight] at @s run function hollow_spire:dungeon/room/home_lighting
# Existing Lush Caves receive their one-time slime population when currently loaded.
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v027_lushslimes,scores={hs_type=7}] at @s run function hollow_spire:dungeon/room/lush_slimes
data modify storage hollow_spire:runtime v027 set value 1b
