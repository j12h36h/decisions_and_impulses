# v0.3.2: wall controls + clean ritual mobs. Geometry-heavy room redesigns apply to new rooms only.
execute as @e[type=minecraft:marker,tag=hs_room] at @s run function hollow_spire:dungeon/room/restore_controls
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=9},tag=!hs_v032_ritual_clean] at @s run function hollow_spire:dungeon/crypt/refresh_v032
data modify storage hollow_spire:runtime v032 set value 1b
