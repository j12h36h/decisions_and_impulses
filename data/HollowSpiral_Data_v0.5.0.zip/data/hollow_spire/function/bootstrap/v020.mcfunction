# Migration only installs v0.2.0 objectives. Existing v0.1.x authored worlds are intentionally not rebuilt in place.
scoreboard objectives add hs_type dummy
scoreboard objectives add hs_roll dummy
scoreboard objectives add hs_gx dummy
scoreboard objectives add hs_gy dummy
scoreboard objectives add hs_gz dummy
scoreboard objectives add hs_seen_room dummy
scoreboard players add #rooms hs_world 0
scoreboard players add #built hs_world 0
data modify storage hollow_spire:runtime v020 set value 1b
