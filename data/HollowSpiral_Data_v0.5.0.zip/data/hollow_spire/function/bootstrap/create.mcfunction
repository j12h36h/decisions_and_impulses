# Hollow Spiral v0.2.0 persistent runtime state.
scoreboard objectives add hs_world dummy
scoreboard objectives add hs_type dummy
scoreboard objectives add hs_roll dummy
scoreboard objectives add hs_room_roll dummy
scoreboard objectives add hs_gx dummy
scoreboard objectives add hs_gy dummy
scoreboard objectives add hs_gz dummy
scoreboard objectives add hs_tmp dummy
scoreboard objectives add hs_seen_room dummy
scoreboard objectives add hs_depth dummy
scoreboard objectives add hs_secondary dummy
scoreboard objectives add hs_grove dummy
scoreboard objectives add hs_farmfix dummy
scoreboard objectives add hs_ritual dummy
scoreboard objectives add hs_village dummy
scoreboard objectives add hs_ocean dummy
scoreboard objectives add hs_ruin dummy
scoreboard objectives add hs_infest dummy
scoreboard objectives add hs_castle dummy
scoreboard objectives add hs_palette dummy
scoreboard objectives add hs_cavern dummy
scoreboard objectives add hs_volcano dummy
scoreboard players set #tick hs_world 0
scoreboard players set #eco hs_world 0
scoreboard players set #rooms hs_world 0
scoreboard players set #built hs_world 0
data modify storage hollow_spire:runtime bootstrap set value 1b
data modify storage hollow_spire:runtime v020 set value 1b
data modify storage hollow_spire:runtime v021 set value 1b
data modify storage hollow_spire:runtime v023 set value 1b
data modify storage hollow_spire:runtime v024 set value 1b
data modify storage hollow_spire:runtime v027 set value 1b
data modify storage hollow_spire:runtime v028 set value 1b
data modify storage hollow_spire:runtime v029 set value 1b
data modify storage hollow_spire:runtime v030 set value 1b
data modify storage hollow_spire:runtime v031 set value 1b

data modify storage hollow_spire:runtime v032 set value 1b

data modify storage hollow_spire:runtime v033 set value 1b
data modify storage hollow_spire:runtime v034 set value 1b
data modify storage hollow_spire:runtime v035 set value 1b

data modify storage hollow_spire:runtime v036 set value 1b
