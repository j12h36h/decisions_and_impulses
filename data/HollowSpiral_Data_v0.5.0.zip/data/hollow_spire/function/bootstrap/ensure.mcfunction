execute unless data storage hollow_spire:runtime {bootstrap:1b} run function hollow_spire:bootstrap/create

execute unless data storage hollow_spire:runtime {v027:1b} run function hollow_spire:bootstrap/v027
execute unless data storage hollow_spire:runtime {v028:1b} run function hollow_spire:bootstrap/v028
execute unless data storage hollow_spire:runtime {v029:1b} run function hollow_spire:bootstrap/v029
execute unless data storage hollow_spire:runtime {v030:1b} run function hollow_spire:bootstrap/v030
execute unless data storage hollow_spire:runtime {v031:1b} run function hollow_spire:bootstrap/v031

execute unless data storage hollow_spire:runtime {v032:1b} run function hollow_spire:bootstrap/v032

execute unless data storage hollow_spire:runtime {v033:1b} run function hollow_spire:bootstrap/v033

execute unless data storage hollow_spire:runtime {v034:1b} run function hollow_spire:bootstrap/v034

execute unless data storage hollow_spire:runtime {v035:1b} run function hollow_spire:bootstrap/v035

execute unless data storage hollow_spire:runtime {v036:1b} run function hollow_spire:bootstrap/v036
