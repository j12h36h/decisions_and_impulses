# v0.5.0: invalidate only the new integrity marker; existing generated rooms remain untouched.
tag @e[type=minecraft:marker,tag=hs_room] remove hs_v050_integrity
data modify storage hollow_spire:runtime v050 set value 1b
