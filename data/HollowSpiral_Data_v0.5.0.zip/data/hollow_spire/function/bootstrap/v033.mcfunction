data modify storage hollow_spire:runtime v033 set value 1b
