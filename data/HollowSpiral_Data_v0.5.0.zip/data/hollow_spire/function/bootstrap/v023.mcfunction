# v0.2.3 staircase lantern cleanup.
# Remove misplaced stairwell lanterns from any currently loaded rooms;
# unloaded rooms are corrected lazily by dungeon/pulse when revisited.
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v023_stairfix] at @s run function hollow_spire:dungeon/room/retrofit_v023
data modify storage hollow_spire:runtime v023 set value 1b
