# v0.3.6 vertical-access / Coral Grotto / Castle defense migration.
# Rebuild loaded legacy Coral Grottos as structural reef ruins and restore their pressure shell.
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=18,hs_ocean=4},tag=!hs_v036_grotto] at @s run function hollow_spire:dungeon/ocean/retrofit_v036_grotto
# Rebuild each loaded existing vertical link from its lower endpoint with expanded DOWN exposure and pressure-wall-safe carving.
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v036_stairfix] at @s run function hollow_spire:dungeon/room/retrofit_v036_stairs
# Relocate/restore controls after stair carving. Existing opened exits stay buttonless because restore_controls checks their actual neighbor/door state.
execute as @e[type=minecraft:marker,tag=hs_room] at @s run function hollow_spire:dungeon/room/restore_controls
# Existing Castles gain exactly one defensive roll.
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=19},tag=!hs_v036_castleguard] at @s run function hollow_spire:dungeon/castle/populate_defenders
data modify storage hollow_spire:runtime v036 set value 1b
