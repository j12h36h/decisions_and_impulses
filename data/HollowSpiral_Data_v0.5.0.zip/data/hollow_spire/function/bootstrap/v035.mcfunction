# v0.3.5 room repair pass.
# Stabilize already-generated Fungal Bog water without respawning the hut/witch.
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=20,hs_cavern=2}] at @s run function hollow_spire:dungeon/caverns/fungal_bog_water_fix
# Clip the legacy Smithery roof overhang back behind the room shell.
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=13}] at @s run function hollow_spire:dungeon/room/retrofit_v035_smithery
# Replace old block-chunk Flooded Ruins with the new submerged masonry settlement, then restore ocean containment/control geometry.
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=18,hs_ocean=1}] at @s run kill @e[tag=hs_ocean_mob,distance=..28]
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=18,hs_ocean=1}] at @s run function hollow_spire:dungeon/ocean/flooded_ruins
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=18,hs_ocean=1}] at @s run function hollow_spire:dungeon/ocean/safety
data modify storage hollow_spire:runtime v035 set value 1b
