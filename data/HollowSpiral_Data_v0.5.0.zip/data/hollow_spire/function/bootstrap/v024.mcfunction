# v0.2.4 two-wide staircase migration.
# Rebuild any loaded vertical links using the wider geometry. Unloaded rooms are
# corrected lazily by dungeon/pulse when a player revisits them.
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v024_stairwide] at @s run function hollow_spire:dungeon/room/retrofit_v024
data modify storage hollow_spire:runtime v024 set value 1b
