# v0.3.1: isolate room-family selection from nested per-room random rolls.
scoreboard objectives add hs_room_roll dummy
data modify storage hollow_spire:runtime v031 set value 1b
