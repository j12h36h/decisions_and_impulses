# v0.3.0 room-family expansion.
scoreboard objectives add hs_ruin dummy
scoreboard objectives add hs_infest dummy
scoreboard objectives add hs_castle dummy
scoreboard objectives add hs_palette dummy
scoreboard objectives add hs_cavern dummy
scoreboard objectives add hs_volcano dummy
# Existing type-1 Ruined Chambers are not destructively rebuilt; they receive the new silverfish infestation lazily when revisited.
data modify storage hollow_spire:runtime v030 set value 1b
