# v0.2.6 farm-light migration.
# Repair any currently loaded rooms immediately; unloaded rooms are repaired lazily by dungeon/pulse.
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v026_farmlight] at @s run function hollow_spire:dungeon/room/retrofit_v026
data modify storage hollow_spire:runtime v026 set value 1b
