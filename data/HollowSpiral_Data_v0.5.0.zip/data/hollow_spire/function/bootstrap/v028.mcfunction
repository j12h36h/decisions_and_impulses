
# v0.2.8 room-library + staircase migration.
scoreboard objectives add hs_grove dummy
scoreboard objectives add hs_farmfix dummy

# Retire existing Monster Crypt runtime behavior without destructively rebuilding player-modified rooms.
execute as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=9}] at @s run kill @e[tag=hs_hostile,distance=..18]
scoreboard players set @e[type=minecraft:marker,tag=hs_room,scores={hs_type=9}] hs_type 1
# Treasure Vault is removed from the active room library; legacy physical rooms remain inert/persistent.
scoreboard players set @e[type=minecraft:marker,tag=hs_room,scores={hs_type=14}] hs_type 1

# Loaded conventional farms receive support repair + requested passive mobs.
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v028_farmanimals,scores={hs_type=2..3}] at @s run function hollow_spire:dungeon/room/retrofit_v028_farm
# Existing legacy Oak Groves keep their blocks but gain the requested fauna and are declared Forest groves.
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v028_groveanimals,scores={hs_type=4}] at @s run scoreboard players set @s hs_grove 1
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v028_groveanimals,scores={hs_type=4}] at @s run function hollow_spire:dungeon/grove/populate
# Rebuild loaded existing vertical links.
execute as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v028_stair3] at @s run function hollow_spire:dungeon/room/retrofit_v028

data modify storage hollow_spire:runtime v028 set value 1b
