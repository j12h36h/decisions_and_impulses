function hollow_spire:bootstrap/ensure
tag @s add hs_player
clear @s
gamemode survival @s
spawnpoint @s 0 81 0
teleport @s 0.5 81 0.5 0 0
give @s minecraft:bread 4
give @s minecraft:torch 12
effect give @s minecraft:resistance 5 4 true
title @s times 10 70 20
title @s title {"text":"THE HOLLOW SPIRAL","color":"aqua","bold":true}
title @s subtitle {"text":"Six directions. Random rooms. Survival is the progression.","color":"gray"}
tellraw @s [{"text":"SPIRAL // ","color":"dark_aqua","bold":true},{"text":"Press the floor button beside any sealed iron door to generate that direction.","color":"white"}]
tellraw @s [{"text":"VERTICAL // ","color":"dark_aqua","bold":true},{"text":"The warped button near the center opens UP. The crimson button opens DOWN.","color":"white"}]
tellraw @s [{"text":"SURVIVAL // ","color":"gold","bold":true},{"text":"Rooms are permanent once discovered. Farms, ores, structures and hostile rooms are real survival resources.","color":"white"}]
