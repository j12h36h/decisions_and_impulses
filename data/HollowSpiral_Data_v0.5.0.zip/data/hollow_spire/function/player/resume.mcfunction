tag @s add hs_player
gamemode survival @s
tellraw @s [{"text":"HOLLOW SPIRAL // ","color":"aqua","bold":true},{"text":"Persistent dungeon state restored.","color":"gray"}]
