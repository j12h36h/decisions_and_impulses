teleport @s 0.5 81 0.5 0 0
effect give @s minecraft:blindness 2 0 true
effect give @s minecraft:resistance 3 4 true
tellraw @s [{"text":"THE HOLLOW REJECTED YOUR FALL.","color":"dark_aqua","italic":true}]
