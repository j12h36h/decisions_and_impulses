function hollow_spire:bootstrap/ensure
execute if entity @e[type=minecraft:marker,tag=hs_start_room,limit=1] run return 0
forceload add -64 -64 64 64
kill @e[type=minecraft:marker,tag=hs_room]
summon minecraft:marker 0 80 0 {Tags:["hs_room","hs_start_room"]}
scoreboard players set @e[type=minecraft:marker,tag=hs_start_room,limit=1] hs_gx 0
scoreboard players set @e[type=minecraft:marker,tag=hs_start_room,limit=1] hs_gy 0
scoreboard players set @e[type=minecraft:marker,tag=hs_start_room,limit=1] hs_gz 0
execute as @e[type=minecraft:marker,tag=hs_start_room,limit=1] at @s run function hollow_spire:dungeon/room/start
scoreboard players set #rooms hs_world 1
scoreboard players set #built hs_world 1
forceload remove -64 -64 64 64
