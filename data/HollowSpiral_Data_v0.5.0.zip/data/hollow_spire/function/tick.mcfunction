scoreboard players add #tick hs_world 1
scoreboard players add #eco hs_world 1
execute if score #tick hs_world matches 4.. run function hollow_spire:dungeon/pulse
execute if score #tick hs_world matches 4.. run scoreboard players set #tick hs_world 0
execute if score #eco hs_world matches 100.. run function hollow_spire:dungeon/ecology
execute if score #eco hs_world matches 100.. run scoreboard players set #eco hs_world 0
execute as @a[tag=hs_player,y=-64,dy=13] run function hollow_spire:player/void_recall
