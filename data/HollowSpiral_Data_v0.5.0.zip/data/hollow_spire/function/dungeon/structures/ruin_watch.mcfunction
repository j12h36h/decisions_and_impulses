# Masonry village watch-house/tower.
fill ~0 ~0 ~0 ~6 ~0 ~6 minecraft:cobblestone
fill ~0 ~1 ~0 ~6 ~8 ~6 minecraft:stone_bricks hollow
fill ~1 ~1 ~1 ~5 ~7 ~5 minecraft:air
setblock ~3 ~1 ~6 minecraft:oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~3 ~2 ~6 minecraft:oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
setblock ~0 ~4 ~3 minecraft:iron_bars
setblock ~6 ~4 ~3 minecraft:iron_bars
fill ~0 ~9 ~0 ~6 ~9 ~6 minecraft:stone_brick_slab[type=bottom]
setblock ~0 ~10 ~0 minecraft:stone_brick_wall
setblock ~6 ~10 ~0 minecraft:stone_brick_wall
setblock ~0 ~10 ~6 minecraft:stone_brick_wall
setblock ~6 ~10 ~6 minecraft:stone_brick_wall
setblock ~3 ~10 ~0 minecraft:stone_brick_wall
setblock ~3 ~10 ~6 minecraft:stone_brick_wall
