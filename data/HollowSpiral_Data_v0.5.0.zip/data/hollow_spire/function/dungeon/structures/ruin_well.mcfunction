# Masonry village well; recognizable village utility translated into stone.
fill ~0 ~0 ~0 ~4 ~0 ~4 minecraft:cobblestone
fill ~0 ~1 ~0 ~4 ~1 ~4 minecraft:stone_bricks hollow
fill ~1 ~1 ~1 ~3 ~1 ~3 minecraft:water
fill ~0 ~2 ~0 ~0 ~3 ~0 minecraft:stone_brick_wall
fill ~4 ~2 ~0 ~4 ~3 ~0 minecraft:stone_brick_wall
fill ~0 ~2 ~4 ~0 ~3 ~4 minecraft:stone_brick_wall
fill ~4 ~2 ~4 ~4 ~3 ~4 minecraft:stone_brick_wall
fill ~-1 ~4 ~-1 ~5 ~4 ~5 minecraft:stone_brick_slab[type=bottom]
