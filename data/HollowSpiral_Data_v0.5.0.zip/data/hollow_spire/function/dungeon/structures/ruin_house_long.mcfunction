# 9x7 masonry translation of a longer village home/workshop.
fill ~0 ~0 ~0 ~8 ~0 ~6 minecraft:cobblestone
fill ~0 ~1 ~0 ~8 ~4 ~6 minecraft:stone_bricks hollow
fill ~1 ~1 ~1 ~7 ~3 ~5 minecraft:air
fill ~0 ~1 ~0 ~0 ~4 ~0 minecraft:polished_andesite
fill ~8 ~1 ~0 ~8 ~4 ~0 minecraft:polished_andesite
fill ~0 ~1 ~6 ~0 ~4 ~6 minecraft:polished_andesite
fill ~8 ~1 ~6 ~8 ~4 ~6 minecraft:polished_andesite
setblock ~4 ~1 ~6 minecraft:oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~4 ~2 ~6 minecraft:oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
fill ~0 ~2 ~2 ~0 ~3 ~4 minecraft:glass_pane
fill ~8 ~2 ~2 ~8 ~3 ~4 minecraft:glass_pane
setblock ~2 ~1 ~2 minecraft:composter
setblock ~6 ~1 ~2 minecraft:barrel
# Finished roof + stone gables.
fill ~-1 ~5 ~-1 ~9 ~5 ~-1 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~-1 ~5 ~7 ~9 ~5 ~7 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~0 ~6 ~0 ~8 ~6 ~0 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~0 ~6 ~6 ~8 ~6 ~6 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~1 ~7 ~1 ~7 ~7 ~1 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~1 ~7 ~5 ~7 ~7 ~5 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~2 ~8 ~2 ~6 ~8 ~4 minecraft:smooth_stone_slab[type=bottom]
fill ~0 ~5 ~0 ~0 ~5 ~6 minecraft:stone_bricks
fill ~8 ~5 ~0 ~8 ~5 ~6 minecraft:stone_bricks
fill ~0 ~6 ~1 ~0 ~6 ~5 minecraft:stone_bricks
fill ~8 ~6 ~1 ~8 ~6 ~5 minecraft:stone_bricks
fill ~0 ~7 ~2 ~0 ~7 ~4 minecraft:stone_bricks
fill ~8 ~7 ~2 ~8 ~7 ~4 minecraft:stone_bricks
