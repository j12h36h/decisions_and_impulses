# Complete 5x4 masonry market stall before siege damage.
fill ~0 ~0 ~0 ~4 ~0 ~3 minecraft:cobblestone
fill ~0 ~1 ~0 ~0 ~3 ~0 minecraft:stone_brick_wall
fill ~4 ~1 ~0 ~4 ~3 ~0 minecraft:stone_brick_wall
fill ~0 ~1 ~3 ~0 ~3 ~3 minecraft:stone_brick_wall
fill ~4 ~1 ~3 ~4 ~3 ~3 minecraft:stone_brick_wall
fill ~-1 ~4 ~-1 ~5 ~4 ~4 minecraft:brick_slab[type=bottom]
fill ~1 ~1 ~1 ~3 ~1 ~2 minecraft:smooth_stone_slab[type=top]
setblock ~2 ~2 ~1 minecraft:barrel
