# Compact masonry village chapel/meeting hall with a small bell tower.
fill ~0 ~0 ~0 ~7 ~0 ~9 minecraft:cobblestone
fill ~0 ~1 ~0 ~7 ~5 ~9 minecraft:stone_bricks hollow
fill ~1 ~1 ~1 ~6 ~4 ~8 minecraft:air
fill ~0 ~1 ~0 ~0 ~5 ~0 minecraft:polished_andesite
fill ~7 ~1 ~0 ~7 ~5 ~0 minecraft:polished_andesite
fill ~0 ~1 ~9 ~0 ~5 ~9 minecraft:polished_andesite
fill ~7 ~1 ~9 ~7 ~5 ~9 minecraft:polished_andesite
setblock ~3 ~1 ~9 minecraft:oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~3 ~2 ~9 minecraft:oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
fill ~0 ~2 ~3 ~0 ~4 ~5 minecraft:glass_pane
fill ~7 ~2 ~3 ~7 ~4 ~5 minecraft:glass_pane
# Finished chapel roof.
fill ~-1 ~6 ~-1 ~8 ~6 ~-1 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~-1 ~6 ~10 ~8 ~6 ~10 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~0 ~7 ~0 ~7 ~7 ~0 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~0 ~7 ~9 ~7 ~7 ~9 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~1 ~8 ~1 ~6 ~8 ~1 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~1 ~8 ~8 ~6 ~8 ~8 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~2 ~9 ~2 ~5 ~9 ~7 minecraft:smooth_stone_slab[type=bottom]
fill ~0 ~6 ~0 ~0 ~6 ~9 minecraft:stone_bricks
fill ~7 ~6 ~0 ~7 ~6 ~9 minecraft:stone_bricks
fill ~0 ~7 ~1 ~0 ~7 ~8 minecraft:stone_bricks
fill ~7 ~7 ~1 ~7 ~7 ~8 minecraft:stone_bricks
fill ~0 ~8 ~2 ~0 ~8 ~7 minecraft:stone_bricks
fill ~7 ~8 ~2 ~7 ~8 ~7 minecraft:stone_bricks
# Bell tower tucked into rear corner.
fill ~1 ~6 ~1 ~3 ~10 ~3 minecraft:stone_bricks hollow
fill ~2 ~7 ~2 ~2 ~9 ~2 minecraft:air
setblock ~2 ~8 ~2 minecraft:bell[attachment=floor,facing=north,powered=false]
fill ~0 ~11 ~0 ~4 ~11 ~4 minecraft:stone_brick_slab[type=bottom]
