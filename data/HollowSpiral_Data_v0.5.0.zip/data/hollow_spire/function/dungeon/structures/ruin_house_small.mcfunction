# 7x7 masonry translation of a small vanilla-style village house.
fill ~0 ~0 ~0 ~6 ~0 ~6 minecraft:cobblestone
# Walls (planks -> stone bricks), corner timber (logs -> polished andesite).
fill ~0 ~1 ~0 ~6 ~4 ~6 minecraft:stone_bricks hollow
fill ~1 ~1 ~1 ~5 ~3 ~5 minecraft:air
fill ~0 ~1 ~0 ~0 ~4 ~0 minecraft:polished_andesite
fill ~6 ~1 ~0 ~6 ~4 ~0 minecraft:polished_andesite
fill ~0 ~1 ~6 ~0 ~4 ~6 minecraft:polished_andesite
fill ~6 ~1 ~6 ~6 ~4 ~6 minecraft:polished_andesite
# Village interior and doorway.
setblock ~3 ~1 ~6 minecraft:oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~3 ~2 ~6 minecraft:oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
fill ~0 ~2 ~2 ~0 ~3 ~3 minecraft:glass_pane
fill ~6 ~2 ~2 ~6 ~3 ~3 minecraft:glass_pane
setblock ~1 ~1 ~2 minecraft:barrel
setblock ~4 ~1 ~2 minecraft:stonecutter
# Complete peaked masonry roof with filled gable ends.
fill ~-1 ~5 ~-1 ~7 ~5 ~-1 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~-1 ~5 ~7 ~7 ~5 ~7 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~0 ~6 ~0 ~6 ~6 ~0 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~0 ~6 ~6 ~6 ~6 ~6 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~1 ~7 ~1 ~5 ~7 ~1 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~1 ~7 ~5 ~5 ~7 ~5 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~2 ~8 ~2 ~4 ~8 ~4 minecraft:smooth_stone_slab[type=bottom]
fill ~0 ~5 ~0 ~0 ~5 ~6 minecraft:stone_bricks
fill ~6 ~5 ~0 ~6 ~5 ~6 minecraft:stone_bricks
fill ~0 ~6 ~1 ~0 ~6 ~5 minecraft:stone_bricks
fill ~6 ~6 ~1 ~6 ~6 ~5 minecraft:stone_bricks
fill ~0 ~7 ~2 ~0 ~7 ~4 minecraft:stone_bricks
fill ~6 ~7 ~2 ~6 ~7 ~4 minecraft:stone_bricks
