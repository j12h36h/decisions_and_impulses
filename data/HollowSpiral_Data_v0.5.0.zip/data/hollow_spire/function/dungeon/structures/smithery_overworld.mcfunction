# Reusable compact Overworld village smithery, 10x9 footprint.
fill ~0 ~0 ~0 ~9 ~0 ~8 minecraft:cobblestone
# House walls and timber corners.
fill ~0 ~1 ~0 ~9 ~4 ~8 minecraft:cobblestone hollow
fill ~1 ~1 ~1 ~8 ~3 ~7 minecraft:air
fill ~0 ~1 ~0 ~0 ~4 ~0 minecraft:oak_log[axis=y]
fill ~9 ~1 ~0 ~9 ~4 ~0 minecraft:oak_log[axis=y]
fill ~0 ~1 ~8 ~0 ~4 ~8 minecraft:oak_log[axis=y]
fill ~9 ~1 ~8 ~9 ~4 ~8 minecraft:oak_log[axis=y]
# Front door and windows.
setblock ~4 ~1 ~8 minecraft:oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~4 ~2 ~8 minecraft:oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
fill ~0 ~2 ~3 ~0 ~3 ~4 minecraft:glass_pane
fill ~9 ~2 ~3 ~9 ~3 ~4 minecraft:glass_pane
# Proper peaked stone roof.
fill ~-1 ~5 ~-1 ~10 ~5 ~-1 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~-1 ~5 ~9 ~10 ~5 ~9 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~0 ~6 ~0 ~9 ~6 ~0 minecraft:stone_brick_stairs[facing=south,half=bottom]
fill ~0 ~6 ~8 ~9 ~6 ~8 minecraft:stone_brick_stairs[facing=north,half=bottom]
fill ~1 ~7 ~1 ~8 ~7 ~7 minecraft:smooth_stone_slab[type=bottom]
# Forge bay: fully contained lava hearth and chimney.
fill ~6 ~1 ~1 ~8 ~1 ~3 minecraft:stone_bricks
setblock ~7 ~1 ~2 minecraft:lava
setblock ~6 ~2 ~2 minecraft:iron_bars
setblock ~8 ~2 ~2 minecraft:iron_bars
fill ~8 ~2 ~1 ~8 ~7 ~2 minecraft:bricks
setblock ~7 ~2 ~1 minecraft:blast_furnace[facing=south]
# Working interior.
setblock ~2 ~1 ~2 minecraft:anvil[facing=north]
setblock ~3 ~1 ~2 minecraft:smithing_table
setblock ~2 ~1 ~5 minecraft:grindstone[face=floor,facing=south]
setblock ~3 ~1 ~5 minecraft:furnace[facing=south]
setblock ~6 ~1 ~6 minecraft:barrel
setblock ~7 ~1 ~6 minecraft:cauldron
setblock ~8 ~1 ~6 minecraft:stonecutter

# v0.3.3 roof completion: fill both gable ends beneath the existing stone roof.
fill ~0 ~5 ~0 ~0 ~5 ~8 minecraft:cobblestone
fill ~9 ~5 ~0 ~9 ~5 ~8 minecraft:cobblestone
fill ~0 ~6 ~1 ~0 ~6 ~7 minecraft:stone_bricks
fill ~9 ~6 ~1 ~9 ~6 ~7 minecraft:stone_bricks
fill ~0 ~7 ~2 ~0 ~7 ~6 minecraft:stone_bricks
fill ~9 ~7 ~2 ~9 ~7 ~6 minecraft:stone_bricks
