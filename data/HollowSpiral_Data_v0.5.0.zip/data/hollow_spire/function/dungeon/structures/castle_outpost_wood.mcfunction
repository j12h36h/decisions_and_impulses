# Reusable compact pillager-style timber outpost.
fill ~0 ~0 ~0 ~6 ~0 ~6 minecraft:cobblestone
fill ~0 ~1 ~0 ~6 ~7 ~6 minecraft:dark_oak_planks hollow
fill ~1 ~1 ~1 ~5 ~6 ~5 minecraft:air
fill ~0 ~1 ~0 ~0 ~7 ~0 minecraft:dark_oak_log[axis=y]
fill ~6 ~1 ~0 ~6 ~7 ~0 minecraft:dark_oak_log[axis=y]
fill ~0 ~1 ~6 ~0 ~7 ~6 minecraft:dark_oak_log[axis=y]
fill ~6 ~1 ~6 ~6 ~7 ~6 minecraft:dark_oak_log[axis=y]
setblock ~3 ~1 ~6 minecraft:dark_oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~3 ~2 ~6 minecraft:dark_oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
fill ~-1 ~8 ~-1 ~7 ~8 ~7 minecraft:dark_oak_slab[type=bottom]
fill ~0 ~9 ~0 ~6 ~9 ~6 minecraft:cobblestone_wall
setblock ~2 ~1 ~2 minecraft:barrel
