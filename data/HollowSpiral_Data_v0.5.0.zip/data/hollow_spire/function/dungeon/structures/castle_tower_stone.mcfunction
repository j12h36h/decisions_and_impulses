# Reusable 5x5 stone tower.
fill ~0 ~0 ~0 ~4 ~0 ~4 minecraft:stone_bricks
fill ~0 ~1 ~0 ~4 ~6 ~4 minecraft:stone_bricks hollow
fill ~1 ~1 ~1 ~3 ~5 ~3 minecraft:air
setblock ~2 ~1 ~4 minecraft:oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~2 ~2 ~4 minecraft:oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
setblock ~0 ~3 ~2 minecraft:iron_bars
setblock ~4 ~3 ~2 minecraft:iron_bars
# Battlements.
fill ~0 ~7 ~0 ~4 ~7 ~4 minecraft:stone_brick_slab[type=bottom]
setblock ~0 ~8 ~0 minecraft:stone_brick_wall
setblock ~4 ~8 ~0 minecraft:stone_brick_wall
setblock ~0 ~8 ~4 minecraft:stone_brick_wall
setblock ~4 ~8 ~4 minecraft:stone_brick_wall
