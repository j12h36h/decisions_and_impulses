# v0.3.5 FUNGAL BOG WATER SAFETY
# Remove legacy loose surface water, then rebuild two explicitly banked one-block-deep bog pools.
fill ~-16 ~1 ~-16 ~16 ~1 ~16 minecraft:air replace minecraft:water

# Northwest bog basin: water is fully surrounded at water level by mud/moss banks.
fill ~-15 ~1 ~-15 ~-8 ~1 ~-15 minecraft:mud
fill ~-15 ~1 ~-8 ~-8 ~1 ~-8 minecraft:mud
fill ~-15 ~1 ~-14 ~-15 ~1 ~-9 minecraft:mud
fill ~-8 ~1 ~-14 ~-8 ~1 ~-9 minecraft:mud
fill ~-14 ~1 ~-14 ~-9 ~1 ~-9 minecraft:water
setblock ~-15 ~1 ~-12 minecraft:moss_block
setblock ~-8 ~1 ~-10 minecraft:moss_block
setblock ~-11 ~1 ~-15 minecraft:moss_block

# Southeast hut bog: a second sealed pool with a solid bank on all four sides.
fill ~8 ~1 ~8 ~15 ~1 ~8 minecraft:mud
fill ~8 ~1 ~15 ~15 ~1 ~15 minecraft:mud
fill ~8 ~1 ~9 ~8 ~1 ~14 minecraft:mud
fill ~15 ~1 ~9 ~15 ~1 ~14 minecraft:mud
fill ~9 ~1 ~9 ~14 ~1 ~14 minecraft:water
setblock ~8 ~1 ~11 minecraft:moss_block
setblock ~15 ~1 ~13 minecraft:moss_block
setblock ~12 ~1 ~8 minecraft:moss_block

# Stable stepping stones so the witch hut is reachable without swimming through the entire room.
setblock ~7 ~1 ~10 minecraft:mossy_cobblestone
setblock ~9 ~1 ~10 minecraft:mossy_cobblestone
setblock ~11 ~1 ~10 minecraft:mossy_cobblestone
setblock ~13 ~1 ~10 minecraft:mossy_cobblestone
