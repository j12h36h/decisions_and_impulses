fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:stone replace minecraft:deepslate_tiles
# Dripstone-block cave ribs outside the connector/stair cross.
fill ~-15 ~1 ~-15 ~-11 ~5 ~-11 minecraft:dripstone_block hollow
fill ~10 ~1 ~9 ~15 ~4 ~14 minecraft:stone hollow
fill ~-14 ~1 ~8 ~-9 ~4 ~14 minecraft:dripstone_block hollow
# Spruce witch hut in northeast cavern pocket.
fill ~9 ~1 ~-14 ~15 ~1 ~-8 minecraft:spruce_planks
fill ~10 ~2 ~-13 ~14 ~5 ~-9 minecraft:spruce_planks hollow
fill ~9 ~6 ~-14 ~15 ~6 ~-8 minecraft:dark_oak_slab[type=bottom]
setblock ~12 ~2 ~-11 minecraft:cauldron
setblock ~13 ~2 ~-11 minecraft:brewing_stand
summon minecraft:witch ~11 ~2 ~-10 {Tags:["hs_hostile","hs_vanilla_mob","hs_cavern_witch"],PersistenceRequired:1b}
summon minecraft:witch ~14 ~2 ~-12 {Tags:["hs_hostile","hs_vanilla_mob","hs_cavern_witch"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"CAVERN // ","color":"dark_purple","bold":true},{"text":"DRIPSTONE HEX","color":"gray"}]
