fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:tuff replace minecraft:deepslate_tiles
fill ~-15 ~1 ~-15 ~-10 ~5 ~-9 minecraft:tuff hollow
fill ~9 ~1 ~9 ~15 ~6 ~15 minecraft:tuff hollow
fill ~8 ~1 ~-15 ~15 ~3 ~-10 minecraft:stone hollow
# Low crooked hut built into southwest cave wall.
fill ~-15 ~1 ~8 ~-9 ~1 ~14 minecraft:spruce_planks
fill ~-14 ~2 ~9 ~-10 ~4 ~13 minecraft:spruce_planks hollow
fill ~-15 ~5 ~8 ~-9 ~5 ~14 minecraft:spruce_slab[type=bottom]
setblock ~-12 ~2 ~11 minecraft:cauldron
setblock ~-11 ~2 ~11 minecraft:brewing_stand
setblock ~11 ~1 ~-12 minecraft:cauldron
summon minecraft:witch ~-11 ~2 ~10 {Tags:["hs_hostile","hs_vanilla_mob","hs_cavern_witch"],PersistenceRequired:1b}
summon minecraft:witch ~10 ~1 ~-11 {Tags:["hs_hostile","hs_vanilla_mob","hs_cavern_witch"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"CAVERN // ","color":"dark_purple","bold":true},{"text":"TUFF CAULDRON","color":"gray"}]
