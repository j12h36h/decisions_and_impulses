fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:mud replace minecraft:deepslate_tiles
# v0.3.5: water is rebuilt as sealed shallow basins instead of loose source fields.
function hollow_spire:dungeon/caverns/fungal_bog_water_fix
# Mossy bank / fungal growth outside the pools.
fill ~-14 ~1 ~8 ~-9 ~3 ~14 minecraft:moss_block hollow
# Dark-oak witch hut on stilts inside the southeast bog.
fill ~9 ~1 ~9 ~14 ~1 ~14 minecraft:oak_log
fill ~9 ~2 ~9 ~14 ~2 ~14 minecraft:dark_oak_planks
fill ~10 ~3 ~10 ~13 ~5 ~13 minecraft:dark_oak_planks hollow
fill ~9 ~6 ~9 ~14 ~6 ~14 minecraft:dark_oak_slab[type=bottom]
setblock ~11 ~3 ~11 minecraft:cauldron
setblock ~12 ~3 ~11 minecraft:red_mushroom
setblock ~-11 ~1 ~11 minecraft:brown_mushroom
summon minecraft:witch ~12 ~3 ~12 {Tags:["hs_hostile","hs_vanilla_mob","hs_cavern_witch"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"CAVERN // ","color":"dark_purple","bold":true},{"text":"FUNGAL BOG","color":"dark_green"}]
