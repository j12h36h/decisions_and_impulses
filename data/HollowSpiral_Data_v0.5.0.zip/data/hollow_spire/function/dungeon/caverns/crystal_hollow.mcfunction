fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:calcite replace minecraft:deepslate_tiles
# Amethyst/calcite cave clusters.
fill ~-15 ~1 ~-15 ~-11 ~4 ~-11 minecraft:amethyst_block hollow
fill ~10 ~1 ~9 ~15 ~5 ~14 minecraft:calcite hollow
fill ~9 ~1 ~-15 ~14 ~3 ~-10 minecraft:amethyst_block hollow
# Spruce hut nested in northwest crystal pocket.
fill ~-14 ~1 ~8 ~-9 ~1 ~14 minecraft:spruce_planks
fill ~-13 ~2 ~9 ~-10 ~5 ~13 minecraft:spruce_planks hollow
fill ~-14 ~6 ~8 ~-9 ~6 ~14 minecraft:stone_slab[type=bottom]
setblock ~-11 ~2 ~11 minecraft:cauldron
setblock ~-12 ~2 ~11 minecraft:brewing_stand
summon minecraft:witch ~-11 ~2 ~10 {Tags:["hs_hostile","hs_vanilla_mob","hs_cavern_witch"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"CAVERN // ","color":"dark_purple","bold":true},{"text":"CRYSTAL HOLLOW","color":"light_purple"}]
