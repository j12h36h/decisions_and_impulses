fill ~17 ~0 ~-2 ~31 ~5 ~2 minecraft:reinforced_deepslate
fill ~18 ~1 ~-1 ~30 ~4 ~1 minecraft:air
fill ~17 ~1 ~-1 ~31 ~3 ~1 minecraft:air
setblock ~24 ~5 ~0 minecraft:sea_lantern
