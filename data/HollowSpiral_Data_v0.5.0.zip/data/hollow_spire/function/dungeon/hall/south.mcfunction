fill ~-2 ~0 ~17 ~2 ~5 ~31 minecraft:reinforced_deepslate
fill ~-1 ~1 ~18 ~1 ~4 ~30 minecraft:air
fill ~-1 ~1 ~17 ~1 ~3 ~31 minecraft:air
setblock ~0 ~5 ~24 minecraft:sea_lantern
