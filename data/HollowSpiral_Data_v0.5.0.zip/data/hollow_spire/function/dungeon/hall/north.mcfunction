fill ~-2 ~0 ~-31 ~2 ~5 ~-17 minecraft:reinforced_deepslate
fill ~-1 ~1 ~-30 ~1 ~4 ~-18 minecraft:air
fill ~-1 ~1 ~-31 ~1 ~3 ~-17 minecraft:air
setblock ~0 ~5 ~-24 minecraft:sea_lantern
