fill ~-31 ~0 ~-2 ~-17 ~5 ~2 minecraft:reinforced_deepslate
fill ~-30 ~1 ~-1 ~-18 ~4 ~1 minecraft:air
fill ~-31 ~1 ~-1 ~-17 ~3 ~1 minecraft:air
setblock ~-24 ~5 ~0 minecraft:sea_lantern
