scoreboard players set @s hs_type 16
# Mine depth starts at 1..4, then physical descent through the Spiral raises the grade.
# gy=0 -> Depth 1..4; gy=-6 -> Depth 7..10. Values are clamped to 10.
execute store result score @s hs_depth run random value 1..4
execute if score @s hs_gy matches ..-1 run scoreboard players operation @s hs_depth -= @s hs_gy
execute if score @s hs_depth matches 11.. run scoreboard players set @s hs_depth 10
# Every mine declares one secondary stone for its entire geology.
execute store result score @s hs_secondary run random value 1..6
# Two large randomized resource bodies. Each cell rolls against the depth's 100-point composition table.
function hollow_spire:dungeon/mine/build_body
# Simple mine supports/readability without blocking room connectors.
fill ~-7 ~1 ~-7 ~-7 ~6 ~-7 minecraft:oak_log[axis=y]
fill ~7 ~1 ~7 ~7 ~6 ~7 minecraft:oak_log[axis=y]
fill ~-9 ~6 ~-7 ~-5 ~6 ~-7 minecraft:oak_log[axis=x]
fill ~5 ~6 ~7 ~9 ~6 ~7 minecraft:oak_log[axis=x]
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"DEPTH MINE // DEPTH ","color":"gray","bold":true},{"score":{"name":"@s","objective":"hs_depth"},"color":"gold","bold":true}]
execute if score @s hs_secondary matches 1 run tellraw @a[tag=hs_player,distance=..40] [{"text":"GEOLOGY // ","color":"dark_aqua","bold":true},{"text":"ANDESITE secondary stone","color":"gray"}]
execute if score @s hs_secondary matches 2 run tellraw @a[tag=hs_player,distance=..40] [{"text":"GEOLOGY // ","color":"dark_aqua","bold":true},{"text":"DIORITE secondary stone","color":"gray"}]
execute if score @s hs_secondary matches 3 run tellraw @a[tag=hs_player,distance=..40] [{"text":"GEOLOGY // ","color":"dark_aqua","bold":true},{"text":"GRANITE secondary stone","color":"gray"}]
execute if score @s hs_secondary matches 4 run tellraw @a[tag=hs_player,distance=..40] [{"text":"GEOLOGY // ","color":"dark_aqua","bold":true},{"text":"DEEPSLATE secondary stone","color":"gray"}]
execute if score @s hs_secondary matches 5 run tellraw @a[tag=hs_player,distance=..40] [{"text":"GEOLOGY // ","color":"dark_aqua","bold":true},{"text":"TUFF secondary stone","color":"gray"}]
execute if score @s hs_secondary matches 6 run tellraw @a[tag=hs_player,distance=..40] [{"text":"GEOLOGY // ","color":"dark_aqua","bold":true},{"text":"CALCITE secondary stone","color":"gray"}]
