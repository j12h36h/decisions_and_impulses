scoreboard players set @s hs_type 6

fill ~-14 ~1 ~-13 ~-8 ~6 ~-8 minecraft:deepslate
fill ~8 ~1 ~8 ~14 ~6 ~13 minecraft:deepslate
fill ~-13 ~2 ~-12 ~-10 ~4 ~-10 minecraft:deepslate_iron_ore
fill ~9 ~2 ~9 ~12 ~4 ~11 minecraft:deepslate_iron_ore
fill ~8 ~0 ~-13 ~14 ~0 ~-8 minecraft:tuff
fill ~10 ~0 ~-12 ~13 ~0 ~-9 minecraft:deepslate_iron_ore

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"IRON MINE","color":"white","bold":true}]
