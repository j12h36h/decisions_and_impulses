# LIBRARY // Full vanilla enchanting room; 15 valid bookshelf positions around the table.
scoreboard players set @s hs_type 14
fill ~7 ~0 ~7 ~14 ~0 ~14 minecraft:oak_planks replace minecraft:deepslate_tiles
setblock ~10 ~1 ~10 minecraft:enchanting_table
# 15 shelves on the distance-two ring.
fill ~8 ~1 ~8 ~8 ~1 ~12 minecraft:bookshelf
fill ~12 ~1 ~8 ~12 ~1 ~12 minecraft:bookshelf
setblock ~9 ~1 ~8 minecraft:bookshelf
setblock ~10 ~1 ~8 minecraft:bookshelf
setblock ~11 ~1 ~8 minecraft:bookshelf
setblock ~9 ~1 ~12 minecraft:bookshelf
setblock ~10 ~1 ~12 minecraft:bookshelf
# Reading stacks / lecterns outside the stair envelope.
fill ~-14 ~1 ~8 ~-10 ~4 ~12 minecraft:bookshelf hollow
setblock ~-12 ~1 ~7 minecraft:lectern[facing=south,has_book=false]
setblock ~-9 ~1 ~11 minecraft:chiseled_bookshelf
setblock ~9 ~1 ~-11 minecraft:lectern[facing=north,has_book=false]
setblock ~13 ~1 ~-11 minecraft:candle[candles=3,lit=true]
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"LIBRARY","color":"gold","bold":true},{"text":" // ENCHANTING ROOM","color":"aqua"}]
