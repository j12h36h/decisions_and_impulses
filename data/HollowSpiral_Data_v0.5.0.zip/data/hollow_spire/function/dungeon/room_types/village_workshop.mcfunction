scoreboard players set @s hs_type 13

fill ~-14 ~0 ~-14 ~-7 ~0 ~14 minecraft:oak_planks
fill ~7 ~0 ~-14 ~14 ~0 ~14 minecraft:oak_planks
fill ~-13 ~1 ~-11 ~-8 ~4 ~-7 minecraft:oak_planks hollow
fill ~8 ~1 ~7 ~13 ~4 ~11 minecraft:spruce_planks hollow
setblock ~-11 ~1 ~-9 minecraft:crafting_table
setblock ~-9 ~1 ~-9 minecraft:stonecutter
setblock ~10 ~1 ~9 minecraft:furnace
setblock ~12 ~1 ~9 minecraft:barrel
summon minecraft:villager ~-10 ~1 ~-5

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"VILLAGE WORKSHOP","color":"aqua","bold":true}]
