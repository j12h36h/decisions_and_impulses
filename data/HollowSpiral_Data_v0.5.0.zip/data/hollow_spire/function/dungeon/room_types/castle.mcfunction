scoreboard players set @s hs_type 19
execute store result score @s hs_castle run random value 1..5
execute store result score @s hs_palette run random value 1..6
execute if score @s hs_castle matches 1 run function hollow_spire:dungeon/castle/twin_tower_keep
execute if score @s hs_castle matches 2 run function hollow_spire:dungeon/castle/moated_keep
execute if score @s hs_castle matches 3 run function hollow_spire:dungeon/castle/pillager_outpost
execute if score @s hs_castle matches 4 run function hollow_spire:dungeon/castle/broken_gate_fort
execute if score @s hs_castle matches 5 run function hollow_spire:dungeon/castle/four_tower_hold
function hollow_spire:dungeon/castle/flags
function hollow_spire:dungeon/castle/populate_defenders
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"CASTLE","color":"gold","bold":true}]
