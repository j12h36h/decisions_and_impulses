scoreboard players set @s hs_type 18
execute store result score @s hs_ocean run random value 1..4
execute if score @s hs_ocean matches 1 run function hollow_spire:dungeon/ocean/flooded_ruins
execute if score @s hs_ocean matches 2 run function hollow_spire:dungeon/ocean/shipwreck
execute if score @s hs_ocean matches 3 run function hollow_spire:dungeon/ocean/inverted_city
execute if score @s hs_ocean matches 4 run function hollow_spire:dungeon/ocean/coral_grotto
# Always finish with the same protected connector/stair service geometry.
function hollow_spire:dungeon/ocean/safety
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"OCEAN ROOM","color":"blue","bold":true}]
