function hollow_spire:dungeon/room_types/ruins
