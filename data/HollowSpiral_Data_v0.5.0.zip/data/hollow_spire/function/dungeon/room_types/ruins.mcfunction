scoreboard players set @s hs_type 1
execute store result score @s hs_ruin run random value 1..5
execute if score @s hs_ruin matches 1 run function hollow_spire:dungeon/ruins/siege_plaza
execute if score @s hs_ruin matches 2 run function hollow_spire:dungeon/ruins/breached_row
execute if score @s hs_ruin matches 3 run function hollow_spire:dungeon/ruins/shattered_chapel
execute if score @s hs_ruin matches 4 run function hollow_spire:dungeon/ruins/collapsed_market
execute if score @s hs_ruin matches 5 run function hollow_spire:dungeon/ruins/broken_watch
function hollow_spire:dungeon/ruins/populate
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"SIEGE RUINS","color":"gray","bold":true}]
