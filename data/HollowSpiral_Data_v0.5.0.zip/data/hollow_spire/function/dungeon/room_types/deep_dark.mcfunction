scoreboard players set @s hs_type 12

fill ~-14 ~0 ~-14 ~-7 ~0 ~14 minecraft:sculk
fill ~7 ~0 ~-14 ~14 ~0 ~14 minecraft:sculk
fill ~-13 ~1 ~-13 ~-10 ~3 ~-10 minecraft:deepslate_bricks
fill ~10 ~1 ~10 ~13 ~3 ~13 minecraft:deepslate_bricks
setblock ~-10 ~1 ~8 minecraft:sculk_sensor
setblock ~10 ~1 ~-8 minecraft:sculk_sensor
setblock ~-12 ~1 ~-9 minecraft:sculk_shrieker

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"DEEP DARK","color":"dark_aqua","bold":true}]
