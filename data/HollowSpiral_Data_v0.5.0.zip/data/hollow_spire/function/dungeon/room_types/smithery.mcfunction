# SMITHERY // complete compact Overworld village forge. Nether/End variants reserved for later.
scoreboard players set @s hs_type 13
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:coarse_dirt replace minecraft:deepslate_tiles
# Proper building rather than a slab silhouette.
execute positioned ~6 ~0 ~-14 run function hollow_spire:dungeon/structures/smithery_overworld
# Smith yard and approach path.
fill ~8 ~0 ~-3 ~15 ~0 ~5 minecraft:dirt_path
fill ~9 ~0 ~7 ~15 ~0 ~13 minecraft:coarse_dirt
setblock ~10 ~1 ~9 minecraft:stonecutter
setblock ~12 ~1 ~9 minecraft:cauldron
setblock ~14 ~1 ~9 minecraft:barrel
setblock ~13 ~1 ~6 minecraft:bell[attachment=floor,facing=north,powered=false]
summon minecraft:villager ~11 ~1 ~11 {Tags:["hs_villager"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"SMITHERY","color":"gray","bold":true}]
