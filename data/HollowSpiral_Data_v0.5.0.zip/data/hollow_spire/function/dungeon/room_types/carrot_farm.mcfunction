
scoreboard players set @s hs_type 2

# Exact crop strips stay hydrated and supported; irrigation/grow lights occupy x=-11/+11.
fill ~-14 ~0 ~-12 ~-12 ~0 ~12 minecraft:farmland[moisture=7]
fill ~-10 ~0 ~-12 ~-7 ~0 ~12 minecraft:farmland[moisture=7]
fill ~7 ~0 ~-12 ~10 ~0 ~12 minecraft:farmland[moisture=7]
fill ~12 ~0 ~-12 ~14 ~0 ~12 minecraft:farmland[moisture=7]
function hollow_spire:dungeon/farm/irrigation_lights
fill ~-14 ~1 ~-12 ~-12 ~1 ~12 minecraft:carrots[age=7]
fill ~-10 ~1 ~-12 ~-7 ~1 ~12 minecraft:carrots[age=7]
fill ~7 ~1 ~-12 ~10 ~1 ~12 minecraft:carrots[age=7]
fill ~12 ~1 ~-12 ~14 ~1 ~12 minecraft:carrots[age=7]

# Farm-specific passive ecology.
summon minecraft:rabbit ~-4 ~1 ~7 {Tags:["hs_passive","hs_carrot_farm"],PersistenceRequired:1b}
summon minecraft:rabbit ~4 ~1 ~7 {Tags:["hs_passive","hs_carrot_farm"],PersistenceRequired:1b}
summon minecraft:pig ~-4 ~1 ~-7 {Tags:["hs_passive","hs_carrot_farm"],PersistenceRequired:1b}
summon minecraft:pig ~4 ~1 ~-7 {Tags:["hs_passive","hs_carrot_farm"],PersistenceRequired:1b}

tag @s add hs_v028_farmanimals
scoreboard players set @s hs_farmfix 3
tag @s add hs_farm_settle

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"CARROT FARM","color":"gold","bold":true}]
