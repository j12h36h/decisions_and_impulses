scoreboard players set @s hs_type 20
execute store result score @s hs_cavern run random value 1..4
execute if score @s hs_cavern matches 1 run function hollow_spire:dungeon/caverns/dripstone_hex
execute if score @s hs_cavern matches 2 run function hollow_spire:dungeon/caverns/fungal_bog
execute if score @s hs_cavern matches 3 run function hollow_spire:dungeon/caverns/tuff_cauldron
execute if score @s hs_cavern matches 4 run function hollow_spire:dungeon/caverns/crystal_hollow
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"WITCH CAVERNS","color":"dark_purple","bold":true}]
