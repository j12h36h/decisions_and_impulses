# CRYPT // Ritual combat family. Each room rolls one one-time vanilla combat scenario.
scoreboard players set @s hs_type 9
# Grave architecture stays outside the protected central 13x13 stair envelope.
fill ~-15 ~0 ~-15 ~-7 ~0 ~15 minecraft:stone_bricks replace minecraft:deepslate_tiles
fill ~7 ~0 ~-15 ~15 ~0 ~15 minecraft:stone_bricks replace minecraft:deepslate_tiles
fill ~-14 ~1 ~-13 ~-10 ~2 ~-11 minecraft:stone_bricks hollow
fill ~10 ~1 ~11 ~14 ~2 ~13 minecraft:mossy_stone_bricks hollow
fill ~-14 ~1 ~8 ~-11 ~1 ~10 minecraft:cobbled_deepslate
fill ~11 ~1 ~-10 ~14 ~1 ~-8 minecraft:cobbled_deepslate
setblock ~-12 ~2 ~-12 minecraft:soul_lantern
setblock ~12 ~2 ~12 minecraft:soul_lantern
setblock ~-12 ~2 ~9 minecraft:soul_lantern
setblock ~12 ~2 ~-9 minecraft:soul_lantern
setblock ~-8 ~0 ~-8 minecraft:crying_obsidian
setblock ~8 ~0 ~-8 minecraft:crying_obsidian
setblock ~8 ~0 ~8 minecraft:crying_obsidian
setblock ~-8 ~0 ~8 minecraft:crying_obsidian
execute store result score @s hs_ritual run random value 1..8
execute if score @s hs_ritual matches 1 run function hollow_spire:dungeon/crypt/rituals/threefold_grave
execute if score @s hs_ritual matches 2 run function hollow_spire:dungeon/crypt/rituals/bone_choir
execute if score @s hs_ritual matches 3 run function hollow_spire:dungeon/crypt/rituals/rotting_circle
execute if score @s hs_ritual matches 4 run function hollow_spire:dungeon/crypt/rituals/webbed_dead
execute if score @s hs_ritual matches 5 run function hollow_spire:dungeon/crypt/rituals/drowned_wake
execute if score @s hs_ritual matches 6 run function hollow_spire:dungeon/crypt/rituals/desert_dead
execute if score @s hs_ritual matches 7 run function hollow_spire:dungeon/crypt/rituals/witching_hour
execute if score @s hs_ritual matches 8 run function hollow_spire:dungeon/crypt/rituals/last_procession
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"CRYPT","color":"dark_gray","bold":true},{"text":" // RITUAL ACTIVE","color":"red"}]
