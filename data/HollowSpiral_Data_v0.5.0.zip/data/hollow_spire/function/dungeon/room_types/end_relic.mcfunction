scoreboard players set @s hs_type 15

fill ~-14 ~0 ~-14 ~-7 ~0 ~14 minecraft:end_stone
fill ~7 ~0 ~-14 ~14 ~0 ~14 minecraft:end_stone
fill ~-13 ~1 ~-12 ~-9 ~5 ~-8 minecraft:purpur_block
fill ~9 ~1 ~8 ~13 ~5 ~12 minecraft:purpur_pillar
setblock ~-11 ~1 ~10 minecraft:chorus_flower
setblock ~11 ~1 ~-10 minecraft:chorus_flower
summon minecraft:enderman ~-10 ~1 ~-10 {Tags:["hs_hostile","hs_vanilla_mob"],PersistenceRequired:1b}
summon minecraft:enderman ~10 ~1 ~10 {Tags:["hs_hostile","hs_vanilla_mob"],PersistenceRequired:1b}

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"END RELIC","color":"light_purple","bold":true}]
