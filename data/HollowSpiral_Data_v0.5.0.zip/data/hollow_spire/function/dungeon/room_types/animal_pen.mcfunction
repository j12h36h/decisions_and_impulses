scoreboard players set @s hs_type 8

fill ~-14 ~0 ~-14 ~-7 ~0 ~14 minecraft:grass_block
fill ~7 ~0 ~-14 ~14 ~0 ~14 minecraft:grass_block
fill ~-14 ~1 ~-14 ~-7 ~1 ~-14 minecraft:oak_fence
fill ~-14 ~1 ~14 ~-7 ~1 ~14 minecraft:oak_fence
fill ~-14 ~1 ~-14 ~-14 ~1 ~14 minecraft:oak_fence
fill ~-7 ~1 ~-14 ~-7 ~1 ~14 minecraft:oak_fence
fill ~7 ~1 ~-14 ~14 ~1 ~-14 minecraft:oak_fence
fill ~7 ~1 ~14 ~14 ~1 ~14 minecraft:oak_fence
fill ~7 ~1 ~-14 ~7 ~1 ~14 minecraft:oak_fence
fill ~14 ~1 ~-14 ~14 ~1 ~14 minecraft:oak_fence
summon minecraft:cow ~-10 ~1 ~-4
summon minecraft:cow ~-11 ~1 ~4
summon minecraft:sheep ~10 ~1 ~-4
summon minecraft:chicken ~11 ~1 ~4

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"ANIMAL PEN","color":"yellow","bold":true}]
