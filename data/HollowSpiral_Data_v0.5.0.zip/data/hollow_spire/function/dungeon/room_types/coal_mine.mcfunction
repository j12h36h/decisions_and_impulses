scoreboard players set @s hs_type 5

fill ~-14 ~1 ~-13 ~-8 ~5 ~-8 minecraft:stone
fill ~8 ~1 ~8 ~14 ~6 ~13 minecraft:stone
fill ~-13 ~2 ~-12 ~-10 ~4 ~-10 minecraft:coal_ore
fill ~9 ~2 ~9 ~12 ~4 ~11 minecraft:coal_ore
fill ~-14 ~0 ~7 ~-8 ~0 ~13 minecraft:stone
fill ~-12 ~0 ~9 ~-9 ~0 ~12 minecraft:coal_ore

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"COAL MINE","color":"dark_gray","bold":true}]
