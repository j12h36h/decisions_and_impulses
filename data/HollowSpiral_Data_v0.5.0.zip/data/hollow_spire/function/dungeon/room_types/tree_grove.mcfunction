
scoreboard players set @s hs_type 4
execute store result score @s hs_grove run random value 1..8
execute if score @s hs_grove matches 1 run function hollow_spire:dungeon/grove/forest
execute if score @s hs_grove matches 2 run function hollow_spire:dungeon/grove/birch_forest
execute if score @s hs_grove matches 3 run function hollow_spire:dungeon/grove/taiga
execute if score @s hs_grove matches 4 run function hollow_spire:dungeon/grove/jungle
execute if score @s hs_grove matches 5 run function hollow_spire:dungeon/grove/savanna
execute if score @s hs_grove matches 6 run function hollow_spire:dungeon/grove/dark_forest
execute if score @s hs_grove matches 7 run function hollow_spire:dungeon/grove/cherry_grove
execute if score @s hs_grove matches 8 run function hollow_spire:dungeon/grove/mangrove_swamp
function hollow_spire:dungeon/grove/populate
