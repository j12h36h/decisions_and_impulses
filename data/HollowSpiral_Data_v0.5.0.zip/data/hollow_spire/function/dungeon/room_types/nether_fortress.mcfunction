scoreboard players set @s hs_type 11

fill ~-14 ~1 ~-3 ~-7 ~4 ~3 minecraft:nether_bricks
fill ~7 ~1 ~-3 ~14 ~4 ~3 minecraft:nether_bricks
fill ~-14 ~4 ~-2 ~14 ~4 ~2 minecraft:nether_bricks
fill ~-13 ~5 ~-1 ~13 ~5 ~1 minecraft:nether_brick_fence
fill ~9 ~0 ~8 ~14 ~0 ~13 minecraft:soul_sand
fill ~9 ~1 ~8 ~14 ~1 ~13 minecraft:nether_wart[age=3]
summon minecraft:blaze ~-10 ~5 ~0 {Tags:["hs_hostile","hs_vanilla_mob"],PersistenceRequired:1b}
summon minecraft:blaze ~10 ~5 ~0 {Tags:["hs_hostile","hs_vanilla_mob"],PersistenceRequired:1b}

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"NETHER FORTRESS","color":"dark_red","bold":true}]
