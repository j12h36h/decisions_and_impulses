scoreboard players set @s hs_type 21
execute store result score @s hs_volcano run random value 1..4
execute if score @s hs_volcano matches 1 run function hollow_spire:dungeon/volcano/lava_river
execute if score @s hs_volcano matches 2 run function hollow_spire:dungeon/volcano/basalt_tube
execute if score @s hs_volcano matches 3 run function hollow_spire:dungeon/volcano/fractured_caldera
execute if score @s hs_volcano matches 4 run function hollow_spire:dungeon/volcano/magma_falls
# Like Ocean, finish by making connector/stair geometry authoritative and lava-tight.
function hollow_spire:dungeon/volcano/safety
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"VOLCANO","color":"red","bold":true}]
