scoreboard players set @s hs_type 10

fill ~-14 ~0 ~-14 ~-7 ~0 ~14 minecraft:netherrack
fill ~7 ~0 ~-14 ~14 ~0 ~14 minecraft:netherrack
fill ~-13 ~1 ~-12 ~-10 ~3 ~-9 minecraft:nether_quartz_ore
fill ~9 ~1 ~9 ~13 ~3 ~12 minecraft:nether_gold_ore
fill ~-13 ~0 ~8 ~-9 ~0 ~12 minecraft:magma_block
fill ~9 ~0 ~-12 ~13 ~0 ~-8 minecraft:soul_sand
summon minecraft:magma_cube ~-10 ~1 ~-10 {Tags:["hs_hostile","hs_vanilla_mob"],PersistenceRequired:1b}
summon minecraft:zombified_piglin ~10 ~1 ~10 {Tags:["hs_hostile","hs_vanilla_mob"],PersistenceRequired:1b}

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"NETHER WASTES","color":"red","bold":true}]
