scoreboard players set @s hs_type 17
execute store result score @s hs_village run random value 1..5
execute if score @s hs_village matches 1 run function hollow_spire:dungeon/village/plains
execute if score @s hs_village matches 2 run function hollow_spire:dungeon/village/desert
execute if score @s hs_village matches 3 run function hollow_spire:dungeon/village/savanna
execute if score @s hs_village matches 4 run function hollow_spire:dungeon/village/taiga
execute if score @s hs_village matches 5 run function hollow_spire:dungeon/village/snowy
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TINY VILLAGE","color":"yellow","bold":true}]
