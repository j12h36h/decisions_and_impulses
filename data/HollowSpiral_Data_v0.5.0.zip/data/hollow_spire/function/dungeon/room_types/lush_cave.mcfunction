scoreboard players set @s hs_type 7

fill ~-14 ~0 ~-14 ~-7 ~0 ~14 minecraft:moss_block
fill ~7 ~0 ~-14 ~14 ~0 ~14 minecraft:moss_block
fill ~-3 ~0 ~8 ~3 ~0 ~14 minecraft:clay
fill ~-2 ~0 ~9 ~2 ~0 ~13 minecraft:water
setblock ~-11 ~1 ~-10 minecraft:azalea
setblock ~10 ~1 ~-9 minecraft:flowering_azalea
setblock ~-10 ~11 ~10 minecraft:spore_blossom
setblock ~10 ~1 ~10 minecraft:big_dripleaf
fill ~-14 ~8 ~-14 ~-12 ~11 ~-12 minecraft:moss_block
setblock ~-13 ~7 ~-13 minecraft:glowstone

function hollow_spire:dungeon/room/lush_slimes

tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"LUSH CAVE","color":"green","bold":true}]
