# v0.3.6 room controls — horizontal wall buttons + collision-safe raised vertical controls.
# Clean every legacy control location first.
execute if block ~2 ~1 ~-15 minecraft:stone_button run setblock ~2 ~1 ~-15 minecraft:air
execute if block ~-2 ~1 ~15 minecraft:stone_button run setblock ~-2 ~1 ~15 minecraft:air
execute if block ~15 ~1 ~2 minecraft:stone_button run setblock ~15 ~1 ~2 minecraft:air
execute if block ~-15 ~1 ~-2 minecraft:stone_button run setblock ~-15 ~1 ~-2 minecraft:air
execute if block ~-5 ~1 ~0 minecraft:warped_button run setblock ~-5 ~1 ~0 minecraft:air
execute if block ~5 ~1 ~0 minecraft:crimson_button run setblock ~5 ~1 ~0 minecraft:air
execute if block ~-5 ~2 ~0 minecraft:warped_button run setblock ~-5 ~2 ~0 minecraft:air
execute if block ~5 ~2 ~0 minecraft:crimson_button run setblock ~5 ~2 ~0 minecraft:air
fill ~-6 ~1 ~0 ~-6 ~2 ~0 minecraft:air replace minecraft:warped_planks
fill ~6 ~1 ~0 ~6 ~2 ~0 minecraft:air replace minecraft:crimson_planks
# Old vertical pylons occupied pressure/retaining walls in fluid rooms; restore those cells before relocating controls.
execute if score @s hs_type matches 18 run fill ~-6 ~1 ~0 ~-6 ~2 ~0 minecraft:glass
execute if score @s hs_type matches 18 run fill ~6 ~1 ~0 ~6 ~2 ~0 minecraft:glass
execute if score @s hs_type matches 21 run setblock ~-6 ~1 ~0 minecraft:polished_blackstone_bricks
execute if score @s hs_type matches 21 run setblock ~6 ~1 ~0 minecraft:polished_blackstone_bricks
execute if score @s hs_type matches 21 run setblock ~-6 ~2 ~0 minecraft:air
execute if score @s hs_type matches 21 run setblock ~6 ~2 ~0 minecraft:air
# Remove stale v0.3.6 buttons before conditionally restoring only unopened exits.
setblock ~2 ~2 ~-16 minecraft:air
setblock ~-2 ~2 ~16 minecraft:air
setblock ~16 ~2 ~2 minecraft:air
setblock ~-16 ~2 ~-2 minecraft:air
setblock ~-2 ~2 ~-5 minecraft:air
setblock ~2 ~2 ~-5 minecraft:air
# Horizontal discovery buttons only exist while their iron door remains sealed.
execute if block ~0 ~1 ~-17 minecraft:iron_door run setblock ~2 ~2 ~-16 minecraft:stone_button[face=wall,facing=south,powered=false]
execute if block ~0 ~1 ~17 minecraft:iron_door run setblock ~-2 ~2 ~16 minecraft:stone_button[face=wall,facing=north,powered=false]
execute if block ~17 ~1 ~0 minecraft:iron_door run setblock ~16 ~2 ~2 minecraft:stone_button[face=wall,facing=west,powered=false]
execute if block ~-17 ~1 ~0 minecraft:iron_door run setblock ~-16 ~2 ~-2 minecraft:stone_button[face=wall,facing=east,powered=false]
# UP and DOWN now have separate two-block pylons in the north side of the protected center.
# They are outside every stair flight and remain compatible with Ocean/Volcano fluid levels.
execute positioned ~ ~20 ~ unless entity @e[type=minecraft:marker,tag=hs_room,distance=..1] positioned ~ ~-20 ~ run fill ~-2 ~1 ~-6 ~-2 ~2 ~-6 minecraft:warped_planks
execute positioned ~ ~20 ~ unless entity @e[type=minecraft:marker,tag=hs_room,distance=..1] positioned ~ ~-20 ~ run setblock ~-2 ~2 ~-5 minecraft:warped_button[face=wall,facing=south,powered=false]
execute positioned ~ ~-20 ~ unless entity @e[type=minecraft:marker,tag=hs_room,distance=..1] positioned ~ ~20 ~ run fill ~2 ~1 ~-6 ~2 ~2 ~-6 minecraft:crimson_planks
execute positioned ~ ~-20 ~ unless entity @e[type=minecraft:marker,tag=hs_room,distance=..1] positioned ~ ~20 ~ run setblock ~2 ~2 ~-5 minecraft:crimson_button[face=wall,facing=south,powered=false]
tag @s add hs_v032_wallcontrols
tag @s add hs_v036_controls
