# Remove misplaced stairwell lanterns from older builds using valid 26.2 command syntax.
execute if block ~-3 ~6 ~3 minecraft:sea_lantern run setblock ~-3 ~6 ~3 minecraft:air
execute if block ~3 ~12 ~-3 minecraft:sea_lantern run setblock ~3 ~12 ~-3 minecraft:air
execute if block ~-3 ~18 ~-3 minecraft:sea_lantern run setblock ~-3 ~18 ~-3 minecraft:air
tag @s add hs_v023_stairfix
