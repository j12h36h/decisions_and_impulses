
# Re-stabilize legacy conventional farms and add the requested farm animals once.
function hollow_spire:dungeon/farm/irrigation_lights
execute if score @s hs_type matches 2 run fill ~-14 ~0 ~-12 ~-12 ~0 ~12 minecraft:farmland[moisture=7]
execute if score @s hs_type matches 2 run fill ~-10 ~0 ~-12 ~-7 ~0 ~12 minecraft:farmland[moisture=7]
execute if score @s hs_type matches 2 run fill ~7 ~0 ~-12 ~10 ~0 ~12 minecraft:farmland[moisture=7]
execute if score @s hs_type matches 2 run fill ~12 ~0 ~-12 ~14 ~0 ~12 minecraft:farmland[moisture=7]
execute if score @s hs_type matches 3 run fill ~-14 ~0 ~-12 ~-12 ~0 ~12 minecraft:farmland[moisture=7]
execute if score @s hs_type matches 3 run fill ~-10 ~0 ~-12 ~-7 ~0 ~12 minecraft:farmland[moisture=7]
execute if score @s hs_type matches 3 run fill ~7 ~0 ~-12 ~10 ~0 ~12 minecraft:farmland[moisture=7]
execute if score @s hs_type matches 3 run fill ~12 ~0 ~-12 ~14 ~0 ~12 minecraft:farmland[moisture=7]
execute if score @s hs_type matches 2 run fill ~-14 ~1 ~-12 ~-12 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run fill ~-10 ~1 ~-12 ~-7 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run fill ~7 ~1 ~-12 ~10 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run fill ~12 ~1 ~-12 ~14 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~-14 ~1 ~-12 ~-12 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~-10 ~1 ~-12 ~-7 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~7 ~1 ~-12 ~10 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~12 ~1 ~-12 ~14 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run summon minecraft:rabbit ~-4 ~1 ~7 {Tags:["hs_passive","hs_carrot_farm"],PersistenceRequired:1b}
execute if score @s hs_type matches 2 run summon minecraft:rabbit ~4 ~1 ~7 {Tags:["hs_passive","hs_carrot_farm"],PersistenceRequired:1b}
execute if score @s hs_type matches 2 run summon minecraft:pig ~-4 ~1 ~-7 {Tags:["hs_passive","hs_carrot_farm"],PersistenceRequired:1b}
execute if score @s hs_type matches 2 run summon minecraft:pig ~4 ~1 ~-7 {Tags:["hs_passive","hs_carrot_farm"],PersistenceRequired:1b}
execute if score @s hs_type matches 3 run summon minecraft:chicken ~-4 ~1 ~7 {Tags:["hs_passive","hs_wheat_farm"],PersistenceRequired:1b}
execute if score @s hs_type matches 3 run summon minecraft:chicken ~4 ~1 ~7 {Tags:["hs_passive","hs_wheat_farm"],PersistenceRequired:1b}
execute if score @s hs_type matches 3 run summon minecraft:cow ~-4 ~1 ~-7 {Tags:["hs_passive","hs_wheat_farm"],PersistenceRequired:1b}
execute if score @s hs_type matches 3 run summon minecraft:cow ~4 ~1 ~-7 {Tags:["hs_passive","hs_wheat_farm"],PersistenceRequired:1b}
scoreboard players set @s hs_farmfix 3
tag @s add hs_farm_settle
tag @s add hs_v028_farmanimals
