# v0.2.7: one-time vanilla slime population for each Lush Cave.
# Two small slimes and one medium slime provide early slimeballs without creating a rapid respawn farm.
summon minecraft:slime ~-9 ~1 ~7 {Size:0,Tags:["hs_hostile","hs_vanilla_mob","hs_lush_slime"],PersistenceRequired:1b}
summon minecraft:slime ~9 ~1 ~6 {Size:0,Tags:["hs_hostile","hs_vanilla_mob","hs_lush_slime"],PersistenceRequired:1b}
summon minecraft:slime ~0 ~1 ~-9 {Size:1,Tags:["hs_hostile","hs_vanilla_mob","hs_lush_slime"],PersistenceRequired:1b}
tag @s add hs_v027_lushslimes
