
# Rebuild an already-open vertical connection into the v0.2.8 three-wide spiral.
execute if block ~-5 ~1 ~0 minecraft:air if block ~5 ~21 ~0 minecraft:air positioned ~ ~20 ~ if entity @e[type=minecraft:marker,tag=hs_room,distance=..1,limit=1] positioned ~ ~-20 ~ run function hollow_spire:dungeon/vertical/build_up
tag @s add hs_v028_stair3
