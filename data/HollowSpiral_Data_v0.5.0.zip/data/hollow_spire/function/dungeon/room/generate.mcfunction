function hollow_spire:dungeon/room/base
execute store result score @s hs_room_roll run random value 1..100
execute if score @s hs_room_roll matches 1..7 run function hollow_spire:dungeon/room_types/ruins
execute if score @s hs_room_roll matches 8..13 run function hollow_spire:dungeon/room_types/carrot_farm
execute if score @s hs_room_roll matches 14..19 run function hollow_spire:dungeon/room_types/wheat_farm
execute if score @s hs_room_roll matches 20..26 run function hollow_spire:dungeon/room_types/tree_grove
execute if score @s hs_room_roll matches 27..41 run function hollow_spire:dungeon/room_types/depth_mine
execute if score @s hs_room_roll matches 42..47 run function hollow_spire:dungeon/room_types/lush_cave
execute if score @s hs_room_roll matches 48..50 run function hollow_spire:dungeon/room_types/animal_pen
execute if score @s hs_room_roll matches 51..57 run function hollow_spire:dungeon/room_types/crypt
execute if score @s hs_room_roll matches 58..61 run function hollow_spire:dungeon/room_types/library
execute if score @s hs_room_roll matches 62..65 run function hollow_spire:dungeon/room_types/smithery
execute if score @s hs_room_roll matches 66..70 run function hollow_spire:dungeon/room_types/village
execute if score @s hs_room_roll matches 71..76 run function hollow_spire:dungeon/room_types/ocean
execute if score @s hs_room_roll matches 77..81 run function hollow_spire:dungeon/room_types/castle
execute if score @s hs_room_roll matches 82..86 run function hollow_spire:dungeon/room_types/caverns
execute if score @s hs_room_roll matches 87..90 run function hollow_spire:dungeon/room_types/volcano
execute if score @s hs_room_roll matches 91..94 run function hollow_spire:dungeon/room_types/nether_wastes
execute if score @s hs_room_roll matches 95..97 run function hollow_spire:dungeon/room_types/nether_fortress
execute if score @s hs_room_roll matches 98..99 run function hollow_spire:dungeon/room_types/deep_dark
execute if score @s hs_room_roll matches 100 run function hollow_spire:dungeon/room_types/end_relic
# Room-specific construction may touch floor controls; make the six discovery controls authoritative after generation.
function hollow_spire:dungeon/room/restore_controls
scoreboard players add #rooms hs_world 1
tag @s remove hs_new
