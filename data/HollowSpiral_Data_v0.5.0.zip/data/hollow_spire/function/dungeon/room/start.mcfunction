function hollow_spire:dungeon/room/base
scoreboard players set @s hs_type 0
# Starter utilities/resources. Enough to begin, not enough to bypass exploration.
fill ~-13 ~1 ~8 ~-10 ~1 ~11 minecraft:oak_log[axis=y]
setblock ~-12 ~1 ~-10 minecraft:crafting_table
setblock ~-10 ~1 ~-10 minecraft:furnace[facing=south]
fill ~9 ~1 ~-12 ~12 ~3 ~-9 minecraft:cobblestone
setblock ~10 ~1 ~10 minecraft:barrel
setblock ~11 ~1 ~10 minecraft:barrel

function hollow_spire:dungeon/room/home_lighting
