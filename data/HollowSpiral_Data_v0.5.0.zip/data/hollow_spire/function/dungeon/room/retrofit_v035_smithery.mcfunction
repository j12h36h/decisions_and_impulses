# Existing v0.3.4 Smitheries placed their eastern roof overhang into the x=+17 room shell.
# Restore only the affected shell segment; leave the existing building/interior intact.
fill ~17 ~5 ~-15 ~17 ~8 ~-5 minecraft:reinforced_deepslate
# Reassert the east doorway/control in case a previous roof touched nearby shell geometry.
setblock ~17 ~1 ~0 minecraft:iron_door[half=lower,facing=west,hinge=left,open=false,powered=false]
setblock ~17 ~2 ~0 minecraft:iron_door[half=upper,facing=west,hinge=left,open=false,powered=false]
function hollow_spire:dungeon/room/restore_controls
