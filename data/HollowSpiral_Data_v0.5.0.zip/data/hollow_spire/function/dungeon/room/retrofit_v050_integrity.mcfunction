# Hollow Spiral v0.5.0 universal room connector integrity pass.
# Reuses proven repair routines at the room marker, then marks the room so this runs only once.
function hollow_spire:dungeon/room/retrofit_v036_stairs
function hollow_spire:dungeon/room/restore_controls
tag @s add hs_v050_integrity
