execute if block ~2 ~2 ~-16 minecraft:stone_button[powered=true] run function hollow_spire:dungeon/exit/north
execute if block ~-2 ~2 ~16 minecraft:stone_button[powered=true] run function hollow_spire:dungeon/exit/south
execute if block ~16 ~2 ~2 minecraft:stone_button[powered=true] run function hollow_spire:dungeon/exit/east
execute if block ~-16 ~2 ~-2 minecraft:stone_button[powered=true] run function hollow_spire:dungeon/exit/west
execute if block ~-2 ~2 ~-5 minecraft:warped_button[powered=true] run function hollow_spire:dungeon/exit/up
execute if block ~2 ~2 ~-5 minecraft:crimson_button[powered=true] run function hollow_spire:dungeon/exit/down
