# v0.2.7: modest Home Room lighting increase. Four extra ceiling lights sit outside the central stairwell envelope.
setblock ~-7 ~12 ~-7 minecraft:sea_lantern
setblock ~7 ~12 ~-7 minecraft:sea_lantern
setblock ~-7 ~12 ~7 minecraft:sea_lantern
setblock ~7 ~12 ~7 minecraft:sea_lantern
tag @s add hs_v027_homelight
