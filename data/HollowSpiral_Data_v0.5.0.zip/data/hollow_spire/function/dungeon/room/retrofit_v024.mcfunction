# A vertical link is represented by the lower room's opened UP control and the
# upper room's opened DOWN control. Require both plus the upper room marker so
# an accidentally broken button cannot create a phantom staircase.
execute if block ~-5 ~1 ~0 minecraft:air if block ~5 ~21 ~0 minecraft:air positioned ~ ~20 ~ if entity @e[type=minecraft:marker,tag=hs_room,distance=..1,limit=1] positioned ~ ~-20 ~ run function hollow_spire:dungeon/vertical/build_up
tag @s add hs_v024_stairwide
