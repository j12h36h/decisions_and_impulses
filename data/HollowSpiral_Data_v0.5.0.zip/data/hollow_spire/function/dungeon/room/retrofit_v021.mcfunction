# v0.2.1 per-room safety retrofit. Runs lazily when an older room is loaded/visited.
fill ~-16 ~-4 ~-16 ~16 ~-1 ~16 minecraft:reinforced_deepslate
# If this room already had a DOWN connection in v0.2.0, keep that stair aperture open.
execute unless block ~5 ~1 ~0 minecraft:crimson_button positioned ~ ~-20 ~ if entity @e[type=minecraft:marker,tag=hs_room,distance=..1,limit=1] positioned ~ ~20 ~ run fill ~-4 ~-4 ~-4 ~4 ~-1 ~4 minecraft:air
tag @s add hs_v021_safe
