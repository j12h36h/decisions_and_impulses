# Rebuild an already-existing upward link from this room using the v0.3.6 endpoint geometry.
execute positioned ~ ~20 ~ if entity @e[type=minecraft:marker,tag=hs_room,distance=..1] positioned ~ ~-20 ~ run function hollow_spire:dungeon/vertical/build_up
tag @s add hs_v036_stairfix
