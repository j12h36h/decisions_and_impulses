# v0.2.6: add local grow lighting only to conventional crop farms.
# hs_type 2 = carrot farm, hs_type 3 = wheat farm.
execute if score @s hs_type matches 2..3 run function hollow_spire:dungeon/farm/irrigation_lights

# Replant only empty original crop cells so the migration does not overwrite
# player-built blocks or surviving plants.
execute if score @s hs_type matches 2 run fill ~-14 ~1 ~-12 ~-12 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run fill ~-10 ~1 ~-12 ~-7 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run fill ~7 ~1 ~-12 ~10 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run fill ~12 ~1 ~-12 ~14 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~-14 ~1 ~-12 ~-12 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~-10 ~1 ~-12 ~-7 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~7 ~1 ~-12 ~10 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~12 ~1 ~-12 ~14 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air

tag @s add hs_v026_farmlight
