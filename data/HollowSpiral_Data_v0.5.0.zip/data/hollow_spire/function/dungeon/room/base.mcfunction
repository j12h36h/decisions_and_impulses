# 35x35 room, 13 blocks tall.
# Outer shell is survival-proof; a four-block reinforced foundation sits below the editable surface.
fill ~-17 ~0 ~-17 ~17 ~12 ~17 minecraft:reinforced_deepslate hollow
fill ~-16 ~-4 ~-16 ~16 ~-1 ~16 minecraft:reinforced_deepslate
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:deepslate_tiles
# Ceiling lighting outside the central spiral shaft.
setblock ~-10 ~12 ~-10 minecraft:sea_lantern
setblock ~0 ~12 ~-10 minecraft:sea_lantern
setblock ~10 ~12 ~-10 minecraft:sea_lantern
setblock ~-10 ~12 ~0 minecraft:sea_lantern
setblock ~10 ~12 ~0 minecraft:sea_lantern
setblock ~-10 ~12 ~10 minecraft:sea_lantern
setblock ~0 ~12 ~10 minecraft:sea_lantern
setblock ~10 ~12 ~10 minecraft:sea_lantern
# Four sealed horizontal exits.
setblock ~0 ~1 ~-17 minecraft:iron_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~0 ~2 ~-17 minecraft:iron_door[half=upper,facing=south,hinge=left,open=false,powered=false]
setblock ~0 ~1 ~17 minecraft:iron_door[half=lower,facing=north,hinge=left,open=false,powered=false]
setblock ~0 ~2 ~17 minecraft:iron_door[half=upper,facing=north,hinge=left,open=false,powered=false]
setblock ~17 ~1 ~0 minecraft:iron_door[half=lower,facing=west,hinge=left,open=false,powered=false]
setblock ~17 ~2 ~0 minecraft:iron_door[half=upper,facing=west,hinge=left,open=false,powered=false]
setblock ~-17 ~1 ~0 minecraft:iron_door[half=lower,facing=east,hinge=left,open=false,powered=false]
setblock ~-17 ~2 ~0 minecraft:iron_door[half=upper,facing=east,hinge=left,open=false,powered=false]
# Horizontal controls are mounted on the room walls beside the doors, never on the floor.
setblock ~2 ~2 ~-16 minecraft:stone_button[face=wall,facing=south,powered=false]
setblock ~-2 ~2 ~16 minecraft:stone_button[face=wall,facing=north,powered=false]
setblock ~16 ~2 ~2 minecraft:stone_button[face=wall,facing=west,powered=false]
setblock ~-16 ~2 ~-2 minecraft:stone_button[face=wall,facing=east,powered=false]
# Independent raised UP/DOWN pylons on the north edge of the protected stair center.
# This footprint is outside both the lower stair start and upper stair landing.
fill ~-2 ~1 ~-6 ~-2 ~2 ~-6 minecraft:warped_planks
setblock ~-2 ~2 ~-5 minecraft:warped_button[face=wall,facing=south,powered=false]
fill ~2 ~1 ~-6 ~2 ~2 ~-6 minecraft:crimson_planks
setblock ~2 ~2 ~-5 minecraft:crimson_button[face=wall,facing=south,powered=false]
tag @s add hs_v021_safe
tag @s add hs_v023_stairfix
tag @s add hs_v024_stairwide
tag @s add hs_v028_stair3
tag @s add hs_v032_wallcontrols
tag @s add hs_v036_controls
