function hollow_spire:dungeon/volcano/floor_is_lava_base
# MAGMA FALLS: floor-is-lava parkour with contained lava curtains on far walls.
fill ~-15 ~2 ~-15 ~-13 ~10 ~-15 minecraft:basalt
fill ~13 ~2 ~15 ~15 ~10 ~15 minecraft:basalt
# Source-backed wall falls; the room shell/foundation contains every stream.
fill ~-10 ~8 ~-16 ~-6 ~8 ~-16 minecraft:lava
fill ~6 ~9 ~16 ~10 ~9 ~16 minecraft:lava
# Safe raised rocks in the fall sight-lines.
fill ~-12 ~1 ~-8 ~-10 ~3 ~-6 minecraft:tuff
fill ~-7 ~1 ~7 ~-5 ~2 ~9 minecraft:stone
fill ~5 ~1 ~-10 ~7 ~3 ~-8 minecraft:basalt
fill ~10 ~1 ~7 ~12 ~2 ~9 minecraft:andesite
summon minecraft:magma_cube ~6 ~2 ~-9 {Tags:["hs_volcano_magma"],PersistenceRequired:1b,Invisible:0b,Size:1}
tellraw @a[tag=hs_player,distance=..40] [{"text":"VOLCANO // ","color":"red","bold":true},{"text":"FLOOR IS LAVA — MAGMA FALLS","color":"gold"}]
