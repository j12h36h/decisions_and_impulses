# VOLCANO SAFETY v0.3.4 — open floor-is-lava containment
# No tall internal walls or doors. Lava is retained by one-block-high solid dams at the room connectors and central shaft border.
# The safe traversal surface sits at y+1 (player feet y+2), so every entrance is kept open above that level.

# Remove legacy v0.3.2/v0.3.3 central walls, roof and crimson doors while preserving the structural floor.
fill ~-6 ~2 ~-6 ~6 ~12 ~6 minecraft:air
# Dry central shaft footprint. The y+1 perimeter is a complete fluid-retaining border; the interior remains dry.
fill ~-5 ~1 ~-5 ~5 ~1 ~5 minecraft:air
fill ~-6 ~1 ~-6 ~6 ~1 ~-6 minecraft:polished_blackstone_bricks
fill ~-6 ~1 ~6 ~6 ~1 ~6 minecraft:polished_blackstone_bricks
fill ~-6 ~1 ~-5 ~-6 ~1 ~5 minecraft:polished_blackstone_bricks
fill ~6 ~1 ~-5 ~6 ~1 ~5 minecraft:polished_blackstone_bricks

# Raised solid bridges cross the retaining border without creating a fluid opening.
# North / South bridges.
fill ~-2 ~1 ~-8 ~2 ~1 ~-3 minecraft:basalt
fill ~-2 ~1 ~3 ~2 ~1 ~8 minecraft:basalt
# East / West bridges.
fill ~3 ~1 ~-2 ~8 ~1 ~2 minecraft:blackstone
fill ~-8 ~1 ~-2 ~-3 ~1 ~2 minecraft:blackstone
# Full headroom over every bridge.
fill ~-2 ~2 ~-8 ~2 ~4 ~-3 minecraft:air
fill ~-2 ~2 ~3 ~2 ~4 ~8 minecraft:air
fill ~3 ~2 ~-2 ~8 ~4 ~2 minecraft:air
fill ~-8 ~2 ~-2 ~-3 ~4 ~2 minecraft:air

# Remove the old four boxed connector vestibules and their interior crimson doors.
fill ~-3 ~1 ~-16 ~3 ~4 ~-12 minecraft:air
fill ~-3 ~1 ~12 ~3 ~4 ~16 minecraft:air
fill ~12 ~1 ~-3 ~16 ~4 ~3 minecraft:air
fill ~-16 ~1 ~-3 ~-12 ~4 ~3 minecraft:air

# Replace them with open, raised landing dams. These stop lava from reaching an opened hallway while leaving 3+ blocks of headroom.
# North landing.
fill ~-2 ~1 ~-16 ~2 ~1 ~-11 minecraft:basalt
fill ~-2 ~2 ~-16 ~2 ~4 ~-11 minecraft:air
# South landing.
fill ~-2 ~1 ~11 ~2 ~1 ~16 minecraft:basalt
fill ~-2 ~2 ~11 ~2 ~4 ~16 minecraft:air
# East landing.
fill ~11 ~1 ~-2 ~16 ~1 ~2 minecraft:blackstone
fill ~11 ~2 ~-2 ~16 ~4 ~2 minecraft:air
# West landing.
fill ~-16 ~1 ~-2 ~-11 ~1 ~2 minecraft:blackstone
fill ~-16 ~2 ~-2 ~-11 ~4 ~2 minecraft:air

# The room shell's normal iron doorway is the only door. Room controls are restored after all fluid-safety edits.
function hollow_spire:dungeon/room/restore_controls
