function hollow_spire:dungeon/volcano/floor_is_lava_base
# BASALT TUBES: narrow basalt stacks, arches and stepping columns over the lava floor.
fill ~-14 ~1 ~-14 ~-12 ~5 ~-12 minecraft:basalt
fill ~12 ~1 ~-14 ~14 ~6 ~-12 minecraft:basalt
fill ~-14 ~1 ~12 ~-12 ~6 ~14 minecraft:basalt
fill ~12 ~1 ~12 ~14 ~5 ~14 minecraft:basalt
fill ~-13 ~6 ~-13 ~13 ~6 ~-13 minecraft:blackstone
# Isolated stepping pillars; top surfaces remain jumpable.
fill ~-7 ~1 ~-3 ~-6 ~2 ~-2 minecraft:basalt
fill ~-3 ~1 ~3 ~-2 ~3 ~4 minecraft:basalt
fill ~4 ~1 ~5 ~5 ~2 ~6 minecraft:basalt
fill ~6 ~1 ~-5 ~7 ~3 ~-4 minecraft:basalt
summon minecraft:magma_cube ~13 ~2 ~13 {Tags:["hs_volcano_magma"],PersistenceRequired:1b,Invisible:0b,Size:1}
tellraw @a[tag=hs_player,distance=..40] [{"text":"VOLCANO // ","color":"red","bold":true},{"text":"FLOOR IS LAVA — BASALT TUBES","color":"dark_gray"}]
