function hollow_spire:dungeon/volcano/floor_is_lava_base
# LAVA RIVER variant: large natural boulders poke through an almost total lava floor.
fill ~-14 ~1 ~-12 ~-11 ~2 ~-9 minecraft:stone
setblock ~-13 ~3 ~-11 minecraft:stone
fill ~-6 ~1 ~-13 ~-4 ~2 ~-11 minecraft:andesite
fill ~3 ~1 ~-14 ~6 ~2 ~-12 minecraft:tuff
fill ~11 ~1 ~-11 ~14 ~3 ~-8 minecraft:basalt
fill ~-14 ~1 ~8 ~-11 ~3 ~11 minecraft:tuff
fill ~9 ~1 ~9 ~13 ~2 ~13 minecraft:stone
setblock ~11 ~3 ~11 minecraft:stone
summon minecraft:magma_cube ~-6 ~2 ~-12 {Tags:["hs_volcano_magma"],PersistenceRequired:1b,Invisible:0b,Size:1}
summon minecraft:magma_cube ~11 ~3 ~10 {Tags:["hs_volcano_magma"],PersistenceRequired:1b,Invisible:0b,Size:1}
tellraw @a[tag=hs_player,distance=..40] [{"text":"VOLCANO // ","color":"red","bold":true},{"text":"FLOOR IS LAVA — BOULDER RUN","color":"gold"}]
