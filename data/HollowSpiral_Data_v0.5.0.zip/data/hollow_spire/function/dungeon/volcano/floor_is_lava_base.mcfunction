# FLOOR IS LAVA base: continuous contained lava surface over a structural volcanic floor.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:blackstone replace minecraft:deepslate_tiles
fill ~-16 ~1 ~-16 ~16 ~1 ~16 minecraft:lava
# Guaranteed outer landing chains to the protected central stair shaft.
# North / South direct stepping chains.
fill ~-2 ~1 ~-11 ~2 ~1 ~-10 minecraft:basalt
fill ~-1 ~1 ~-8 ~1 ~1 ~-7 minecraft:tuff
fill ~-2 ~1 ~10 ~2 ~1 ~11 minecraft:basalt
fill ~-1 ~1 ~7 ~1 ~1 ~8 minecraft:tuff
# East route curls toward the north shaft entrance.
fill ~10 ~1 ~-2 ~11 ~1 ~2 minecraft:blackstone
fill ~8 ~1 ~-1 ~9 ~1 ~1 minecraft:basalt
fill ~7 ~1 ~-5 ~9 ~1 ~-3 minecraft:tuff
fill ~7 ~1 ~-9 ~9 ~1 ~-7 minecraft:stone
fill ~3 ~1 ~-9 ~5 ~1 ~-7 minecraft:andesite
# West route curls toward the south shaft entrance.
fill ~-11 ~1 ~-2 ~-10 ~1 ~2 minecraft:blackstone
fill ~-9 ~1 ~-1 ~-8 ~1 ~1 minecraft:basalt
fill ~-9 ~1 ~3 ~-7 ~1 ~5 minecraft:tuff
fill ~-9 ~1 ~7 ~-7 ~1 ~9 minecraft:stone
fill ~-5 ~1 ~7 ~-3 ~1 ~9 minecraft:andesite
# Small optional central-side landing stones make missed routes recoverable without forming bridges.
fill ~3 ~1 ~7 ~5 ~1 ~9 minecraft:basalt
fill ~-5 ~1 ~-9 ~-3 ~1 ~-7 minecraft:basalt
