function hollow_spire:dungeon/volcano/floor_is_lava_base
# FRACTURED CALDERA: broad broken islands with one-block lava gaps between them.
fill ~-15 ~1 ~-15 ~-11 ~1 ~-11 minecraft:tuff
fill ~-8 ~1 ~-14 ~-5 ~2 ~-11 minecraft:andesite
fill ~4 ~1 ~-14 ~8 ~1 ~-11 minecraft:blackstone
fill ~11 ~1 ~-15 ~15 ~2 ~-11 minecraft:basalt
fill ~-15 ~1 ~10 ~-11 ~2 ~14 minecraft:blackstone
fill ~-7 ~1 ~11 ~-4 ~1 ~14 minecraft:tuff
fill ~5 ~1 ~11 ~8 ~2 ~14 minecraft:andesite
fill ~11 ~1 ~10 ~15 ~1 ~14 minecraft:basalt
# Raised center-side crags as optional shortcuts.
fill ~-8 ~1 ~-7 ~-7 ~3 ~-6 minecraft:tuff
fill ~7 ~1 ~6 ~8 ~3 ~7 minecraft:basalt
summon minecraft:magma_cube ~-13 ~2 ~-13 {Tags:["hs_volcano_magma"],PersistenceRequired:1b,Invisible:0b,Size:1}
summon minecraft:magma_cube ~13 ~2 ~12 {Tags:["hs_volcano_magma"],PersistenceRequired:1b,Invisible:0b,Size:1}
tellraw @a[tag=hs_player,distance=..40] [{"text":"VOLCANO // ","color":"red","bold":true},{"text":"FLOOR IS LAVA — FRACTURED CALDERA","color":"gold"}]
