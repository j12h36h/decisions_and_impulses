
# Room-local vanilla threats. Natural spawning stays disabled so the hidden flat substrate cannot consume the mob cap.
# Monster Crypt was removed from the room pool in v0.2.8.
effect clear @e[tag=hs_vanilla_mob] minecraft:invisibility
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=10},distance=..28] at @s unless entity @e[type=minecraft:zombified_piglin,tag=hs_hostile,distance=..14,limit=1] run summon minecraft:zombified_piglin ~10 ~1 ~10 {Tags:["hs_hostile","hs_vanilla_mob"],PersistenceRequired:1b}
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=11},distance=..28] at @s unless entity @e[type=minecraft:blaze,tag=hs_hostile,distance=..14,limit=1] run summon minecraft:blaze ~10 ~5 ~0 {Tags:["hs_hostile","hs_vanilla_mob"],PersistenceRequired:1b}
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=15},distance=..28] at @s unless entity @e[type=minecraft:enderman,tag=hs_hostile,distance=..14,limit=1] run summon minecraft:enderman ~10 ~1 ~10 {Tags:["hs_hostile","hs_vanilla_mob"],PersistenceRequired:1b}
