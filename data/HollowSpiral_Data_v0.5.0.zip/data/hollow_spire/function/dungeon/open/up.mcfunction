setblock ~-2 ~2 ~-5 minecraft:air
