fill ~-17 ~1 ~-1 ~-17 ~3 ~1 minecraft:air
setblock ~-16 ~2 ~-2 minecraft:air
