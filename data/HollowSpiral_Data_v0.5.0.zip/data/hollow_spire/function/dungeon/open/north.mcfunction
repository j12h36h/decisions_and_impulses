fill ~-1 ~1 ~-17 ~1 ~3 ~-17 minecraft:air
setblock ~2 ~2 ~-16 minecraft:air
