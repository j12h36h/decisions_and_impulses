# Pure vanilla ritual entities: no legacy Hollow-Spire hostile/render tags.
summon minecraft:drowned ~-10 ~1 ~-8 {Tags:["hs_ritual_mob"],PersistenceRequired:1b,Invisible:0b}
summon minecraft:drowned ~10 ~1 ~-8 {Tags:["hs_ritual_mob"],PersistenceRequired:1b,Invisible:0b}
summon minecraft:zombie ~ ~1 ~10 {Tags:["hs_ritual_mob"],PersistenceRequired:1b,Invisible:0b}
effect clear @e[tag=hs_ritual_mob,distance=..18] minecraft:invisibility
execute as @e[tag=hs_ritual_mob,distance=..18] run data merge entity @s {Invisible:0b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"RITUAL // ","color":"dark_red","bold":true},{"text":"DROWNED WAKE","color":"gray"}]
