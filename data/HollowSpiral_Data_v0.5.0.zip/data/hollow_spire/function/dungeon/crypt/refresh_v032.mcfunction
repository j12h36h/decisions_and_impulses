# One-time cleanup of pre-v0.3.2 ritual mobs and clean vanilla respawn.
kill @e[tag=hs_ritual_mob,distance=..18]
execute unless score @s hs_ritual matches 1..8 store result score @s hs_ritual run random value 1..8
execute if score @s hs_ritual matches 1 run function hollow_spire:dungeon/crypt/rituals/threefold_grave
execute if score @s hs_ritual matches 2 run function hollow_spire:dungeon/crypt/rituals/bone_choir
execute if score @s hs_ritual matches 3 run function hollow_spire:dungeon/crypt/rituals/rotting_circle
execute if score @s hs_ritual matches 4 run function hollow_spire:dungeon/crypt/rituals/webbed_dead
execute if score @s hs_ritual matches 5 run function hollow_spire:dungeon/crypt/rituals/drowned_wake
execute if score @s hs_ritual matches 6 run function hollow_spire:dungeon/crypt/rituals/desert_dead
execute if score @s hs_ritual matches 7 run function hollow_spire:dungeon/crypt/rituals/witching_hour
execute if score @s hs_ritual matches 8 run function hollow_spire:dungeon/crypt/rituals/last_procession
tag @s add hs_v032_ritual_clean
