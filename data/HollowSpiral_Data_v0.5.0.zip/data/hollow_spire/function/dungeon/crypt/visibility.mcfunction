# Force ritual entities to normal vanilla visibility state.
tag @e[tag=hs_ritual_mob,distance=..18] remove hs_hostile
tag @e[tag=hs_ritual_mob,distance=..18] remove hs_vanilla_mob
effect clear @e[tag=hs_ritual_mob,distance=..18] minecraft:invisibility
execute as @e[tag=hs_ritual_mob,distance=..18] run data merge entity @s {Invisible:0b}
