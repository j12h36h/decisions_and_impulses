execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v050_integrity,distance=..28] at @s run function hollow_spire:dungeon/room/retrofit_v050_integrity
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v036_grotto,scores={hs_type=18,hs_ocean=4},distance=..28] at @s run function hollow_spire:dungeon/ocean/retrofit_v036_grotto
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v036_stairfix,distance=..28] at @s run function hollow_spire:dungeon/room/retrofit_v036_stairs
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v036_controls,distance=..28] at @s run function hollow_spire:dungeon/room/restore_controls
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v036_castleguard,scores={hs_type=19},distance=..28] at @s run function hollow_spire:dungeon/castle/populate_defenders
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v032_ritual_clean,scores={hs_type=9},distance=..28] at @s run function hollow_spire:dungeon/crypt/refresh_v032
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v032_wallcontrols,distance=..28] at @s run function hollow_spire:dungeon/room/restore_controls
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,scores={hs_type=9},distance=..28] at @s run function hollow_spire:dungeon/crypt/visibility
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v030_ruininfest,scores={hs_type=1},distance=..28] at @s run function hollow_spire:dungeon/ruins/populate
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=hs_farm_settle,distance=..32] at @s run function hollow_spire:dungeon/farm/settle
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v028_farmanimals,scores={hs_type=2..3},distance=..28] at @s run function hollow_spire:dungeon/room/retrofit_v028_farm
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v028_groveanimals,scores={hs_type=4},distance=..28] at @s run scoreboard players set @s hs_grove 1
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v028_groveanimals,scores={hs_type=4},distance=..28] at @s run function hollow_spire:dungeon/grove/populate
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v028_stair3,distance=..28] at @s run function hollow_spire:dungeon/room/retrofit_v028
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_start_room,tag=!hs_v027_homelight,distance=..28] at @s run function hollow_spire:dungeon/room/home_lighting
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v027_lushslimes,scores={hs_type=7},distance=..28] at @s run function hollow_spire:dungeon/room/lush_slimes
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v026_farmlight,distance=..28] at @s run function hollow_spire:dungeon/room/retrofit_v026
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v024_stairwide,distance=..28] at @s run function hollow_spire:dungeon/room/retrofit_v024
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v023_stairfix,distance=..28] at @s run function hollow_spire:dungeon/room/retrofit_v023
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,tag=!hs_v021_safe,distance=..28] at @s run function hollow_spire:dungeon/room/retrofit_v021
# Poll only room markers spatially near players; cost scales with active players, not total generated rooms.
execute as @a[tag=hs_player] at @s as @e[type=minecraft:marker,tag=hs_room,distance=..28] at @s run function hollow_spire:dungeon/room/check_controls
