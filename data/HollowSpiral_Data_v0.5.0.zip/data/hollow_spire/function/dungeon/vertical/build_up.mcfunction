# v0.3.6 central 20-block spiral link with expanded DOWN-side exposure and fluid-safe endpoint carving.
# Three-block-wide flights with a flat 3x3x1 platform at every corner.
# UP/DOWN controls now live independently at z=-5 against two north-wall pylons and are outside every flight.

# Clear the old central stair volume; the v0.3.6 controls are outside this footprint.
fill ~-4 ~1 ~-4 ~4 ~12 ~4 minecraft:air
# Clear the new outer third lanes where required in the lower room.
fill ~-4 ~1 ~3 ~1 ~5 ~5 minecraft:air
fill ~3 ~6 ~-2 ~5 ~10 ~2 minecraft:air
fill ~0 ~11 ~-5 ~2 ~12 ~-3 minecraft:air
# Enclosed inter-room shaft. The controls live outside this vertical band.
fill ~-7 ~13 ~-7 ~7 ~19 ~7 minecraft:reinforced_deepslate hollow
fill ~-6 ~13 ~-6 ~6 ~19 ~6 minecraft:air
# Restore the upper-room center floor, then carve the actual 3-wide stair aperture through it.
# The old build restored this whole layer solid, leaving the last south-flight steps capped by the receiving room floor.
fill ~-6 ~20 ~-6 ~6 ~20 ~6 minecraft:deepslate_tiles
# Four floor rows above the final approach remain open. The extra z=-2..-1 rows expose two more descending stairs from the upper room for easier access.
fill ~-5 ~20 ~-2 ~-3 ~20 ~1 minecraft:air
# Clear receiving-room headroom only inside the protected center. This never cuts an Ocean pressure wall at x/z=+/-6.
fill ~-5 ~21 ~-2 ~-2 ~24 ~5 minecraft:air
# Slim visual/support core.
fill ~0 ~1 ~0 ~0 ~19 ~0 minecraft:polished_deepslate
# Lower shaft/rim finish.
fill ~-4 ~0 ~-4 ~4 ~0 ~4 minecraft:polished_blackstone_bricks replace minecraft:deepslate_tiles

# Lower-room entry apron/headroom. Room-specific structures are never allowed to cap the first flight.
fill ~-5 ~1 ~2 ~1 ~4 ~6 minecraft:air

# EAST flight — three lanes z=3..5, five rises.
setblock ~-4 ~1 ~3 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-4 ~1 ~4 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-4 ~1 ~5 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-3 ~2 ~3 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-3 ~2 ~4 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-3 ~2 ~5 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-2 ~3 ~3 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-2 ~3 ~4 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-2 ~3 ~5 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-1 ~4 ~3 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-1 ~4 ~4 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~-1 ~4 ~5 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~0 ~5 ~3 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~0 ~5 ~4 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
setblock ~0 ~5 ~5 minecraft:polished_blackstone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]
# Northeast 3x3x1 landing.
fill ~1 ~5 ~3 ~3 ~5 ~5 minecraft:polished_blackstone_bricks

# NORTH flight — three lanes x=3..5, five rises.
setblock ~3 ~6 ~2 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~4 ~6 ~2 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~5 ~6 ~2 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~3 ~7 ~1 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~4 ~7 ~1 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~5 ~7 ~1 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~3 ~8 ~0 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~4 ~8 ~0 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~5 ~8 ~0 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~3 ~9 ~-1 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~4 ~9 ~-1 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~5 ~9 ~-1 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~3 ~10 ~-2 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~4 ~10 ~-2 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
setblock ~5 ~10 ~-2 minecraft:polished_blackstone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]
# Northwest 3x3x1 landing.
fill ~3 ~10 ~-5 ~5 ~10 ~-3 minecraft:polished_blackstone_bricks

# WEST flight — three lanes z=-5..-3, five rises.
setblock ~2 ~11 ~-5 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~2 ~11 ~-4 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~2 ~11 ~-3 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~1 ~12 ~-5 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~1 ~12 ~-4 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~1 ~12 ~-3 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~0 ~13 ~-5 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~0 ~13 ~-4 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~0 ~13 ~-3 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~-1 ~14 ~-5 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~-1 ~14 ~-4 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~-1 ~14 ~-3 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~-2 ~15 ~-5 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~-2 ~15 ~-4 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
setblock ~-2 ~15 ~-3 minecraft:polished_blackstone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]
# Southwest 3x3x1 landing.
fill ~-5 ~15 ~-5 ~-3 ~15 ~-3 minecraft:polished_blackstone_bricks

# SOUTH flight — three lanes x=-5..-3, five rises; the fifth stair replaces part of the upper floor cleanly.
setblock ~-5 ~16 ~-2 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-4 ~16 ~-2 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-3 ~16 ~-2 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-5 ~17 ~-1 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-4 ~17 ~-1 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-3 ~17 ~-1 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-5 ~18 ~0 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-4 ~18 ~0 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-3 ~18 ~0 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-5 ~19 ~1 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-4 ~19 ~1 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-3 ~19 ~1 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-5 ~20 ~2 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-4 ~20 ~2 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
setblock ~-3 ~20 ~2 minecraft:polished_blackstone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]
# Southeast / upper-room 3x3x1 landing.
fill ~-5 ~20 ~3 ~-3 ~20 ~5 minecraft:polished_blackstone_bricks
# The 3x3 upper landing remains entirely inside the protected center. Ocean glass at z=6 is never removed.
fill ~-5 ~21 ~2 ~-3 ~23 ~5 minecraft:air

# No lanterns are placed inside the stairwell path.

# Re-evaluate controls at both endpoints after carving. A room with both vertical links keeps whichever direction is still unopened.
function hollow_spire:dungeon/room/restore_controls
execute positioned ~ ~20 ~ as @e[type=minecraft:marker,tag=hs_room,distance=..1,limit=1] at @s run function hollow_spire:dungeon/room/restore_controls
