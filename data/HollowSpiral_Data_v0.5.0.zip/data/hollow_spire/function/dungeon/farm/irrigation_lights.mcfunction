# Farm-only grow lighting. Crops such as wheat/carrots can uproot in low light;
# nether wart is intentionally untouched because it has no equivalent light requirement.
# Keep water in every odd Z cell and recess sea lanterns into every even Z cell.
# The remaining water sources stay within hydration range of all farmland.
fill ~-11 ~0 ~-12 ~-11 ~0 ~12 minecraft:water
fill ~11 ~0 ~-12 ~11 ~0 ~12 minecraft:water
setblock ~-11 ~0 ~-12 minecraft:sea_lantern
setblock ~-11 ~0 ~-10 minecraft:sea_lantern
setblock ~-11 ~0 ~-8 minecraft:sea_lantern
setblock ~-11 ~0 ~-6 minecraft:sea_lantern
setblock ~-11 ~0 ~-4 minecraft:sea_lantern
setblock ~-11 ~0 ~-2 minecraft:sea_lantern
setblock ~-11 ~0 ~0 minecraft:sea_lantern
setblock ~-11 ~0 ~2 minecraft:sea_lantern
setblock ~-11 ~0 ~4 minecraft:sea_lantern
setblock ~-11 ~0 ~6 minecraft:sea_lantern
setblock ~-11 ~0 ~8 minecraft:sea_lantern
setblock ~-11 ~0 ~10 minecraft:sea_lantern
setblock ~-11 ~0 ~12 minecraft:sea_lantern
setblock ~11 ~0 ~-12 minecraft:sea_lantern
setblock ~11 ~0 ~-10 minecraft:sea_lantern
setblock ~11 ~0 ~-8 minecraft:sea_lantern
setblock ~11 ~0 ~-6 minecraft:sea_lantern
setblock ~11 ~0 ~-4 minecraft:sea_lantern
setblock ~11 ~0 ~-2 minecraft:sea_lantern
setblock ~11 ~0 ~0 minecraft:sea_lantern
setblock ~11 ~0 ~2 minecraft:sea_lantern
setblock ~11 ~0 ~4 minecraft:sea_lantern
setblock ~11 ~0 ~6 minecraft:sea_lantern
setblock ~11 ~0 ~8 minecraft:sea_lantern
setblock ~11 ~0 ~10 minecraft:sea_lantern
setblock ~11 ~0 ~12 minecraft:sea_lantern
