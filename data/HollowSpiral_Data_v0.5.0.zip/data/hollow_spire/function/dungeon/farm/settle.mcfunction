
# Short post-generation stabilization pass. It runs before the player normally reaches
# a newly generated farm, removing crop items created by block-update settling and
# restoring only empty intended crop cells.
kill @e[type=minecraft:item,distance=..17]
execute if score @s hs_type matches 2 run fill ~-14 ~0 ~-12 ~-12 ~0 ~12 minecraft:farmland[moisture=7] replace minecraft:farmland
execute if score @s hs_type matches 2 run fill ~-10 ~0 ~-12 ~-7 ~0 ~12 minecraft:farmland[moisture=7] replace minecraft:farmland
execute if score @s hs_type matches 2 run fill ~7 ~0 ~-12 ~10 ~0 ~12 minecraft:farmland[moisture=7] replace minecraft:farmland
execute if score @s hs_type matches 2 run fill ~12 ~0 ~-12 ~14 ~0 ~12 minecraft:farmland[moisture=7] replace minecraft:farmland
execute if score @s hs_type matches 2 run fill ~-14 ~1 ~-12 ~-12 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run fill ~-10 ~1 ~-12 ~-7 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run fill ~7 ~1 ~-12 ~10 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 2 run fill ~12 ~1 ~-12 ~14 ~1 ~12 minecraft:carrots[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~-14 ~0 ~-12 ~-12 ~0 ~12 minecraft:farmland[moisture=7] replace minecraft:farmland
execute if score @s hs_type matches 3 run fill ~-10 ~0 ~-12 ~-7 ~0 ~12 minecraft:farmland[moisture=7] replace minecraft:farmland
execute if score @s hs_type matches 3 run fill ~7 ~0 ~-12 ~10 ~0 ~12 minecraft:farmland[moisture=7] replace minecraft:farmland
execute if score @s hs_type matches 3 run fill ~12 ~0 ~-12 ~14 ~0 ~12 minecraft:farmland[moisture=7] replace minecraft:farmland
execute if score @s hs_type matches 3 run fill ~-14 ~1 ~-12 ~-12 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~-10 ~1 ~-12 ~-7 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~7 ~1 ~-12 ~10 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
execute if score @s hs_type matches 3 run fill ~12 ~1 ~-12 ~14 ~1 ~12 minecraft:wheat[age=7] replace minecraft:air
scoreboard players remove @s hs_farmfix 1
execute if score @s hs_farmfix matches ..0 run tag @s remove hs_farm_settle
