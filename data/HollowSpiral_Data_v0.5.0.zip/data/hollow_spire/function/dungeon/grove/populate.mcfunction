
# Requested grove fauna. These are ordinary vanilla passive mobs and are spawned once with the room.
summon minecraft:sheep ~-8 ~1 ~8 {Tags:["hs_passive","hs_grove_mob"],PersistenceRequired:1b}
summon minecraft:sheep ~8 ~1 ~-8 {Tags:["hs_passive","hs_grove_mob"],PersistenceRequired:1b}
summon minecraft:ocelot ~8 ~1 ~8 {Tags:["hs_passive","hs_grove_mob"],PersistenceRequired:1b}
tag @s add hs_v028_groveanimals
