
# Declared grove biome: FOREST
fill ~-14 ~0 ~-14 ~-7 ~0 ~-7 minecraft:grass_block
fill ~7 ~0 ~-14 ~14 ~0 ~-7 minecraft:grass_block
fill ~-14 ~0 ~7 ~-7 ~0 ~14 minecraft:grass_block
fill ~7 ~0 ~7 ~14 ~0 ~14 minecraft:grass_block
fill ~-11 ~1 ~-11 ~-11 ~5 ~-11 minecraft:oak_log[axis=y]
fill ~10 ~1 ~-10 ~10 ~5 ~-10 minecraft:oak_log[axis=y]
fill ~-10 ~1 ~10 ~-10 ~5 ~10 minecraft:oak_log[axis=y]
fill ~11 ~1 ~11 ~11 ~5 ~11 minecraft:oak_log[axis=y]
fill ~-13 ~4 ~-13 ~-9 ~7 ~-9 minecraft:oak_leaves[persistent=true]
fill ~8 ~4 ~-12 ~12 ~7 ~-8 minecraft:oak_leaves[persistent=true]
fill ~-12 ~4 ~8 ~-8 ~7 ~12 minecraft:oak_leaves[persistent=true]
fill ~9 ~4 ~9 ~13 ~7 ~13 minecraft:oak_leaves[persistent=true]
setblock ~-8 ~1 ~9 minecraft:dandelion
setblock ~8 ~1 ~-9 minecraft:poppy
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TREE GROVE // FOREST","color":"green","bold":true}]
