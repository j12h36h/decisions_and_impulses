
# Declared grove biome: DARK FOREST
fill ~-14 ~0 ~-14 ~-7 ~0 ~-7 minecraft:podzol
fill ~7 ~0 ~-14 ~14 ~0 ~-7 minecraft:podzol
fill ~-14 ~0 ~7 ~-7 ~0 ~14 minecraft:podzol
fill ~7 ~0 ~7 ~14 ~0 ~14 minecraft:podzol
fill ~-11 ~1 ~-11 ~-11 ~5 ~-11 minecraft:dark_oak_log[axis=y]
fill ~10 ~1 ~-10 ~10 ~5 ~-10 minecraft:dark_oak_log[axis=y]
fill ~-10 ~1 ~10 ~-10 ~5 ~10 minecraft:dark_oak_log[axis=y]
fill ~11 ~1 ~11 ~11 ~5 ~11 minecraft:dark_oak_log[axis=y]
fill ~-13 ~4 ~-13 ~-9 ~7 ~-9 minecraft:dark_oak_leaves[persistent=true]
fill ~8 ~4 ~-12 ~12 ~7 ~-8 minecraft:dark_oak_leaves[persistent=true]
fill ~-12 ~4 ~8 ~-8 ~7 ~12 minecraft:dark_oak_leaves[persistent=true]
fill ~9 ~4 ~9 ~13 ~7 ~13 minecraft:dark_oak_leaves[persistent=true]
setblock ~-8 ~1 ~9 minecraft:red_mushroom
setblock ~8 ~1 ~-9 minecraft:brown_mushroom
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TREE GROVE // DARK FOREST","color":"dark_green","bold":true}]
