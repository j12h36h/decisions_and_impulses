
# Declared grove biome: MANGROVE SWAMP
fill ~-14 ~0 ~-14 ~-7 ~0 ~-7 minecraft:mud
fill ~7 ~0 ~-14 ~14 ~0 ~-7 minecraft:mud
fill ~-14 ~0 ~7 ~-7 ~0 ~14 minecraft:mud
fill ~7 ~0 ~7 ~14 ~0 ~14 minecraft:mud
fill ~-11 ~1 ~-11 ~-11 ~5 ~-11 minecraft:mangrove_log[axis=y]
fill ~10 ~1 ~-10 ~10 ~5 ~-10 minecraft:mangrove_log[axis=y]
fill ~-10 ~1 ~10 ~-10 ~5 ~10 minecraft:mangrove_log[axis=y]
fill ~11 ~1 ~11 ~11 ~5 ~11 minecraft:mangrove_log[axis=y]
fill ~-13 ~4 ~-13 ~-9 ~7 ~-9 minecraft:mangrove_leaves[persistent=true]
fill ~8 ~4 ~-12 ~12 ~7 ~-8 minecraft:mangrove_leaves[persistent=true]
fill ~-12 ~4 ~8 ~-8 ~7 ~12 minecraft:mangrove_leaves[persistent=true]
fill ~9 ~4 ~9 ~13 ~7 ~13 minecraft:mangrove_leaves[persistent=true]
setblock ~-11 ~1 ~-10 minecraft:mangrove_roots
setblock ~10 ~1 ~-9 minecraft:mangrove_roots
setblock ~-10 ~1 ~9 minecraft:mangrove_roots
setblock ~11 ~1 ~10 minecraft:mangrove_roots
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TREE GROVE // MANGROVE SWAMP","color":"dark_green","bold":true}]
