
# Declared grove biome: SAVANNA
fill ~-14 ~0 ~-14 ~-7 ~0 ~-7 minecraft:grass_block
fill ~7 ~0 ~-14 ~14 ~0 ~-7 minecraft:grass_block
fill ~-14 ~0 ~7 ~-7 ~0 ~14 minecraft:grass_block
fill ~7 ~0 ~7 ~14 ~0 ~14 minecraft:grass_block
fill ~-11 ~1 ~-11 ~-11 ~5 ~-11 minecraft:acacia_log[axis=y]
fill ~10 ~1 ~-10 ~10 ~5 ~-10 minecraft:acacia_log[axis=y]
fill ~-10 ~1 ~10 ~-10 ~5 ~10 minecraft:acacia_log[axis=y]
fill ~11 ~1 ~11 ~11 ~5 ~11 minecraft:acacia_log[axis=y]
fill ~-13 ~4 ~-13 ~-9 ~7 ~-9 minecraft:acacia_leaves[persistent=true]
fill ~8 ~4 ~-12 ~12 ~7 ~-8 minecraft:acacia_leaves[persistent=true]
fill ~-12 ~4 ~8 ~-8 ~7 ~12 minecraft:acacia_leaves[persistent=true]
fill ~9 ~4 ~9 ~13 ~7 ~13 minecraft:acacia_leaves[persistent=true]
fill ~-9 ~0 ~8 ~-7 ~0 ~10 minecraft:coarse_dirt
fill ~7 ~0 ~-10 ~9 ~0 ~-8 minecraft:coarse_dirt
tellraw @a[tag=hs_player,distance=..40] [{"text":"DISCOVERED // ","color":"dark_aqua","bold":true},{"text":"TREE GROVE // SAVANNA","color":"gold","bold":true}]
