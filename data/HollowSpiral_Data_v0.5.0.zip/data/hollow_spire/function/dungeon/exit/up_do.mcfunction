scoreboard players operation #gx hs_tmp = @s hs_gx
scoreboard players operation #gy hs_tmp = @s hs_gy
scoreboard players operation #gz hs_tmp = @s hs_gz
execute positioned ~ ~20 ~ unless entity @e[type=minecraft:marker,tag=hs_room,distance=..1] run summon minecraft:marker ~ ~ ~ {Tags:["hs_room","hs_new"]}
execute positioned ~ ~20 ~ as @e[type=minecraft:marker,tag=hs_room,tag=hs_new,distance=..1,limit=1] run scoreboard players operation @s hs_gx = #gx hs_tmp
execute positioned ~ ~20 ~ as @e[type=minecraft:marker,tag=hs_room,tag=hs_new,distance=..1,limit=1] run scoreboard players operation @s hs_gy = #gy hs_tmp
execute positioned ~ ~20 ~ as @e[type=minecraft:marker,tag=hs_room,tag=hs_new,distance=..1,limit=1] run scoreboard players operation @s hs_gz = #gz hs_tmp
execute positioned ~ ~20 ~ as @e[type=minecraft:marker,tag=hs_room,tag=hs_new,distance=..1,limit=1] run scoreboard players add @s hs_gy 1
execute positioned ~ ~20 ~ as @e[type=minecraft:marker,tag=hs_room,tag=hs_new,distance=..1,limit=1] at @s run function hollow_spire:dungeon/room/generate
function hollow_spire:dungeon/open/up
execute positioned ~ ~20 ~ as @e[type=minecraft:marker,tag=hs_room,distance=..1,limit=1] at @s run function hollow_spire:dungeon/open/down
function hollow_spire:dungeon/vertical/build_up
playsound minecraft:block.beacon.activate block @a[tag=hs_player,distance=..28] ~ ~ ~ 1 1.1
tellraw @a[tag=hs_player,distance=..28] [{"text":"SPIRAL // ","color":"dark_aqua","bold":true},{"text":"UPPER staircase unfolded.","color":"gray"}]
