execute if score @s hs_gy matches ..-6 run tellraw @a[tag=hs_player,distance=..24] [{"text":"SPIRAL // ","color":"dark_aqua","bold":true},{"text":"The lower pressure boundary will not open here. Continue horizontally or ascend.","color":"gray"}]
execute unless score @s hs_gy matches ..-6 run function hollow_spire:dungeon/exit/down_do
