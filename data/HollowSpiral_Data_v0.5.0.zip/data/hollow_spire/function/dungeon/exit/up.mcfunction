execute if score @s hs_gy matches 11.. run tellraw @a[tag=hs_player,distance=..24] [{"text":"SPIRAL // ","color":"dark_aqua","bold":true},{"text":"The upper pressure boundary will not open here. Continue horizontally or descend.","color":"gray"}]
execute unless score @s hs_gy matches 11.. run function hollow_spire:dungeon/exit/up_do
