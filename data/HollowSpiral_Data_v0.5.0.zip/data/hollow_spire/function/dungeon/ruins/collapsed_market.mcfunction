# COLLAPSED MARKET: complete stone village buildings/stalls first, then simulated bombardment.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:cobblestone replace minecraft:deepslate_tiles
fill ~-3 ~0 ~-16 ~3 ~0 ~-7 minecraft:gravel
fill ~-3 ~0 ~7 ~3 ~0 ~16 minecraft:gravel
fill ~-16 ~0 ~-3 ~-7 ~0 ~3 minecraft:gravel
fill ~7 ~0 ~-3 ~16 ~0 ~3 minecraft:gravel
execute positioned ~-15 ~0 ~-14 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~9 ~0 ~8 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~-14 ~0 ~7 run function hollow_spire:dungeon/structures/ruin_market_stall
execute positioned ~9 ~0 ~-13 run function hollow_spire:dungeon/structures/ruin_market_stall
execute positioned ~8 ~0 ~1 run function hollow_spire:dungeon/structures/ruin_market_stall
execute positioned ~-12 ~3 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~12 ~6 ~11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~-12 ~3 ~9 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~11 ~3 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
setblock ~-9 ~1 ~11 minecraft:cobweb
setblock ~11 ~1 ~-7 minecraft:grindstone
tellraw @a[tag=hs_player,distance=..40] [{"text":"RUINS // ","color":"gray","bold":true},{"text":"COLLAPSED MARKET","color":"dark_red"}]
