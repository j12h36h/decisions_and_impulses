# SIEGE PLAZA: intact masonry village translated from vanilla forms, then bombarded.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:cobblestone replace minecraft:deepslate_tiles
fill ~-3 ~0 ~-16 ~3 ~0 ~-7 minecraft:gravel
fill ~-3 ~0 ~7 ~3 ~0 ~16 minecraft:gravel
fill ~-16 ~0 ~-3 ~-7 ~0 ~3 minecraft:gravel
fill ~7 ~0 ~-3 ~16 ~0 ~3 minecraft:gravel
execute positioned ~-15 ~0 ~-14 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~9 ~0 ~-14 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~-15 ~0 ~8 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~9 ~0 ~8 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~9 ~0 ~-2 run function hollow_spire:dungeon/structures/ruin_well
setblock ~-9 ~1 ~2 minecraft:bell[attachment=floor,facing=north,powered=false]
# Safe, structure-local simulated shell impacts.
execute positioned ~-12 ~3 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~12 ~3 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~-12 ~3 ~11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~12 ~6 ~11 run function hollow_spire:dungeon/ruins/damage/random_at
tellraw @a[tag=hs_player,distance=..40] [{"text":"RUINS // ","color":"gray","bold":true},{"text":"SIEGE PLAZA","color":"dark_red"}]
