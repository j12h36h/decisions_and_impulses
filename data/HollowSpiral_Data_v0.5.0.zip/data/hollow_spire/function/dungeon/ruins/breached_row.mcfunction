# BREACHED ROW: recognizable masonry village homes lining a damaged road.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:stone replace minecraft:deepslate_tiles
fill ~-3 ~0 ~-16 ~3 ~0 ~16 minecraft:gravel
execute positioned ~-15 ~0 ~-14 run function hollow_spire:dungeon/structures/ruin_house_long
execute positioned ~7 ~0 ~-14 run function hollow_spire:dungeon/structures/ruin_house_long
execute positioned ~-15 ~0 ~8 run function hollow_spire:dungeon/structures/ruin_house_long
execute positioned ~7 ~0 ~8 run function hollow_spire:dungeon/structures/ruin_house_long
execute positioned ~-11 ~3 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~11 ~3 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~-11 ~6 ~11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~11 ~3 ~11 run function hollow_spire:dungeon/ruins/damage/random_at
# Non-destructive crater language in the roadway: rubble instead of holes into the void.
fill ~-2 ~0 ~-10 ~2 ~0 ~-7 minecraft:gravel
setblock ~0 ~0 ~-8 minecraft:cracked_stone_bricks
fill ~-2 ~0 ~7 ~1 ~0 ~10 minecraft:gravel
tellraw @a[tag=hs_player,distance=..40] [{"text":"RUINS // ","color":"gray","bold":true},{"text":"BREACHED VILLAGE ROW","color":"dark_red"}]
