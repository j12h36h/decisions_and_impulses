# Variable infestation: 2..7 silverfish. New rooms and legacy type-1 rooms receive this once.
execute store result score @s hs_infest run random value 2..7
summon minecraft:silverfish ~-11 ~1 ~-11 {Tags:["hs_hostile","hs_vanilla_mob","hs_ruin_silverfish"],PersistenceRequired:1b}
summon minecraft:silverfish ~11 ~1 ~11 {Tags:["hs_hostile","hs_vanilla_mob","hs_ruin_silverfish"],PersistenceRequired:1b}
execute if score @s hs_infest matches 3.. run summon minecraft:silverfish ~11 ~1 ~-11 {Tags:["hs_hostile","hs_vanilla_mob","hs_ruin_silverfish"],PersistenceRequired:1b}
execute if score @s hs_infest matches 4.. run summon minecraft:silverfish ~-11 ~1 ~11 {Tags:["hs_hostile","hs_vanilla_mob","hs_ruin_silverfish"],PersistenceRequired:1b}
execute if score @s hs_infest matches 5.. run summon minecraft:silverfish ~-8 ~1 ~-13 {Tags:["hs_hostile","hs_vanilla_mob","hs_ruin_silverfish"],PersistenceRequired:1b}
execute if score @s hs_infest matches 6.. run summon minecraft:silverfish ~13 ~1 ~8 {Tags:["hs_hostile","hs_vanilla_mob","hs_ruin_silverfish"],PersistenceRequired:1b}
execute if score @s hs_infest matches 7 run summon minecraft:silverfish ~-13 ~1 ~8 {Tags:["hs_hostile","hs_vanilla_mob","hs_ruin_silverfish"],PersistenceRequired:1b}
tag @s add hs_v030_ruininfest
