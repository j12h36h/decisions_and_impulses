# SHATTERED CHAPEL: masonry village chapel plus homes, all built whole before siege damage.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:stone replace minecraft:deepslate_tiles
fill ~-3 ~0 ~-16 ~3 ~0 ~16 minecraft:gravel
execute positioned ~8 ~0 ~-14 run function hollow_spire:dungeon/structures/ruin_chapel
execute positioned ~-15 ~0 ~-14 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~-15 ~0 ~8 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~11 ~4 ~-10 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~10 ~8 ~-8 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~-12 ~3 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~-12 ~6 ~11 run function hollow_spire:dungeon/ruins/damage/random_at
# Small graveyard remnants.
setblock ~8 ~1 ~8 minecraft:stone_brick_wall
setblock ~11 ~1 ~10 minecraft:stone_brick_wall
setblock ~14 ~1 ~8 minecraft:stone_brick_wall
tellraw @a[tag=hs_player,distance=..40] [{"text":"RUINS // ","color":"gray","bold":true},{"text":"SHATTERED CHAPEL","color":"dark_red"}]
