# Irregular shell/TNT-style side impact centered on this safe structure-local point.
fill ~-2 ~-1 ~-1 ~2 ~2 ~1 minecraft:air replace minecraft:stone_bricks
fill ~-1 ~-2 ~-2 ~1 ~2 ~2 minecraft:air replace minecraft:stone_bricks
fill ~-1 ~-1 ~-1 ~1 ~3 ~1 minecraft:air replace minecraft:polished_andesite
fill ~-2 ~-1 ~-2 ~2 ~2 ~2 minecraft:air replace minecraft:glass_pane
fill ~-2 ~-1 ~-2 ~2 ~2 ~2 minecraft:air replace minecraft:oak_door
setblock ~-2 ~-1 ~2 minecraft:cracked_stone_bricks
setblock ~2 ~-1 ~-2 minecraft:cobblestone
setblock ~1 ~0 ~2 minecraft:gravel
setblock ~-1 ~0 ~-2 minecraft:cobblestone_slab[type=bottom]
