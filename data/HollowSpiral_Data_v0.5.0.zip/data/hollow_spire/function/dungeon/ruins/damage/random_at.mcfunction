# Pick one TNT-like damage profile for the current safe blast center.
execute store result score @s hs_roll run random value 1..4
execute if score @s hs_roll matches 1 run function hollow_spire:dungeon/ruins/damage/shell_impact
execute if score @s hs_roll matches 2 run function hollow_spire:dungeon/ruins/damage/interior_blast
execute if score @s hs_roll matches 3 run function hollow_spire:dungeon/ruins/damage/roof_collapse
execute if score @s hs_roll matches 4 run function hollow_spire:dungeon/ruins/damage/wall_breach
