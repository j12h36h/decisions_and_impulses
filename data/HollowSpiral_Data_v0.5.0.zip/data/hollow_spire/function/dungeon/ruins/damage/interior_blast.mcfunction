# Interior detonation: broad low cavity with uneven surviving corners.
fill ~-2 ~-1 ~-2 ~2 ~2 ~2 minecraft:air replace minecraft:stone_bricks
fill ~-1 ~-1 ~-3 ~1 ~1 ~3 minecraft:air replace minecraft:stone_bricks
fill ~-2 ~-1 ~-2 ~2 ~2 ~2 minecraft:air replace minecraft:polished_andesite
fill ~-2 ~-1 ~-2 ~2 ~2 ~2 minecraft:air replace minecraft:glass_pane
fill ~-2 ~-1 ~-2 ~2 ~2 ~2 minecraft:air replace minecraft:brick_slab
setblock ~-2 ~-1 ~-1 minecraft:mossy_cobblestone
setblock ~2 ~-1 ~1 minecraft:cracked_stone_bricks
setblock ~0 ~0 ~-3 minecraft:gravel
setblock ~1 ~0 ~2 minecraft:stone_brick_stairs[facing=east,half=bottom]
