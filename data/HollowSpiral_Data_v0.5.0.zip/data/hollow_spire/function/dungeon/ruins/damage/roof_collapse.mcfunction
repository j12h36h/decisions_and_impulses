# Roof-collapse profile, analogous to blast pressure lifting a roof section away.
fill ~-3 ~-1 ~-2 ~3 ~1 ~2 minecraft:air replace minecraft:stone_brick_stairs
fill ~-3 ~-1 ~-2 ~3 ~1 ~2 minecraft:air replace minecraft:smooth_stone_slab
fill ~-2 ~-2 ~-1 ~2 ~0 ~1 minecraft:air replace minecraft:stone_bricks
setblock ~-2 ~-2 ~2 minecraft:stone_brick_stairs[facing=south,half=bottom]
setblock ~2 ~-2 ~-2 minecraft:stone_brick_stairs[facing=north,half=bottom]
setblock ~0 ~-2 ~2 minecraft:cracked_stone_bricks
