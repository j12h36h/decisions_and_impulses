# Narrow directional breach, like a siege projectile punching through a facade.
fill ~-2 ~-2 ~0 ~2 ~2 ~0 minecraft:air replace minecraft:stone_bricks
fill ~-1 ~-1 ~-1 ~1 ~1 ~1 minecraft:air replace minecraft:stone_bricks
fill ~-1 ~-2 ~0 ~1 ~2 ~0 minecraft:air replace minecraft:polished_andesite
fill ~-2 ~-2 ~0 ~2 ~2 ~0 minecraft:air replace minecraft:glass_pane
setblock ~-2 ~-2 ~1 minecraft:cobblestone
setblock ~2 ~-2 ~-1 minecraft:gravel
setblock ~0 ~-1 ~1 minecraft:cracked_stone_bricks
