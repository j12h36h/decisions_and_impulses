# BROKEN WATCH: a village watch structure and supporting masonry homes.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:stone replace minecraft:deepslate_tiles
fill ~-3 ~0 ~-16 ~3 ~0 ~16 minecraft:gravel
execute positioned ~-15 ~0 ~-14 run function hollow_spire:dungeon/structures/ruin_watch
execute positioned ~8 ~0 ~-14 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~7 ~0 ~8 run function hollow_spire:dungeon/structures/ruin_house_long
execute positioned ~-12 ~5 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~-12 ~8 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~11 ~3 ~-11 run function hollow_spire:dungeon/ruins/damage/random_at
execute positioned ~11 ~6 ~11 run function hollow_spire:dungeon/ruins/damage/random_at
setblock ~-12 ~9 ~-11 minecraft:campfire[lit=false]
tellraw @a[tag=hs_player,distance=..40] [{"text":"RUINS // ","color":"gray","bold":true},{"text":"BROKEN WATCH","color":"dark_red"}]
