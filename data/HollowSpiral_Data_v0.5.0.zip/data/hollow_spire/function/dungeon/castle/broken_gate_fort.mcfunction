# Siege-broken fort built from real tower modules and a damaged south gate wall.
execute positioned ~-15 ~0 ~10 run function hollow_spire:dungeon/structures/castle_tower_stone
execute positioned ~11 ~0 ~10 run function hollow_spire:dungeon/structures/castle_tower_stone
fill ~-10 ~2 ~13 ~10 ~6 ~15 minecraft:stone_bricks
# Breached gate and impact damage.
fill ~-4 ~1 ~12 ~4 ~5 ~16 minecraft:air
fill ~-2 ~0 ~8 ~2 ~0 ~15 minecraft:gravel
setblock ~-6 ~2 ~14 minecraft:cracked_stone_bricks
setblock ~7 ~3 ~14 minecraft:mossy_stone_bricks
setblock ~-12 ~1 ~11 minecraft:barrel
setblock ~12 ~1 ~11 minecraft:barrel
tellraw @a[tag=hs_player,distance=..40] [{"text":"CASTLE // ","color":"gold","bold":true},{"text":"BROKEN-GATE FORT","color":"dark_red"}]
