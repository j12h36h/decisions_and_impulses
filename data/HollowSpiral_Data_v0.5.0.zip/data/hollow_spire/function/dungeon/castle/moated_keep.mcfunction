# MOATED KEEP — one coherent northern castle island with a contained moat and drawbridge.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:grass_block replace minecraft:deepslate_tiles
# Moat basin: completely supported by the reinforced foundation and kept north of the central stair reserve.
fill ~-15 ~0 ~-15 ~15 ~0 ~-7 minecraft:stone_bricks
fill ~-15 ~1 ~-15 ~15 ~1 ~-7 minecraft:water
# Castle island and drawbridge.
fill ~-8 ~1 ~-13 ~8 ~1 ~-9 minecraft:stone_bricks
fill ~-2 ~1 ~-16 ~2 ~1 ~-7 minecraft:oak_planks
# Two real towers joined into a small keep.
execute positioned ~-8 ~1 ~-13 run function hollow_spire:dungeon/structures/castle_tower_stone
execute positioned ~4 ~1 ~-13 run function hollow_spire:dungeon/structures/castle_tower_stone
fill ~-3 ~2 ~-13 ~3 ~6 ~-9 minecraft:stone_bricks hollow
fill ~-2 ~2 ~-12 ~2 ~5 ~-10 minecraft:air
setblock ~0 ~2 ~-9 minecraft:oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~0 ~3 ~-9 minecraft:oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
setblock ~0 ~2 ~-11 minecraft:chest
# Moat edge details.
setblock ~-11 ~2 ~-9 minecraft:lily_pad
setblock ~11 ~2 ~-9 minecraft:lily_pad
tellraw @a[tag=hs_player,distance=..40] [{"text":"CASTLE // ","color":"gold","bold":true},{"text":"MOATED KEEP","color":"aqua"}]
