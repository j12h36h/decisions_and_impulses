# Twin modular towers linked by a gatehouse on the north side.
execute positioned ~-14 ~0 ~-14 run function hollow_spire:dungeon/structures/castle_tower_stone
execute positioned ~10 ~0 ~-14 run function hollow_spire:dungeon/structures/castle_tower_stone
fill ~-9 ~3 ~-14 ~9 ~7 ~-10 minecraft:stone_bricks hollow
fill ~-3 ~1 ~-14 ~3 ~5 ~-10 minecraft:air
fill ~-2 ~0 ~-16 ~2 ~0 ~-7 minecraft:stone_bricks
setblock ~-12 ~1 ~-12 minecraft:barrel
setblock ~12 ~1 ~-12 minecraft:barrel
tellraw @a[tag=hs_player,distance=..40] [{"text":"CASTLE // ","color":"gold","bold":true},{"text":"TWIN-TOWER KEEP","color":"gray"}]
