# Every Castle receives one defensive roll: one Iron Golem OR two named villager guards.
execute store result score @s hs_roll run random value 1..2
execute if score @s hs_roll matches 1 run summon minecraft:iron_golem ~0 ~1 ~8 {Tags:["hs_castle_defender"],PersistenceRequired:1b,PlayerCreated:1b,CustomName:'{"text":"Castle Golem","color":"gray"}',CustomNameVisible:0b}
execute if score @s hs_roll matches 2 run summon minecraft:villager ~-2 ~1 ~8 {Tags:["hs_castle_defender","hs_castle_guard"],PersistenceRequired:1b,CustomName:'{"text":"Castle Guard","color":"gold"}',CustomNameVisible:0b,VillagerData:{profession:"minecraft:weaponsmith",level:3,type:"minecraft:plains"}}
execute if score @s hs_roll matches 2 run summon minecraft:villager ~2 ~1 ~8 {Tags:["hs_castle_defender","hs_castle_guard"],PersistenceRequired:1b,CustomName:'{"text":"Castle Guard","color":"gold"}',CustomNameVisible:0b,VillagerData:{profession:"minecraft:armorer",level:3,type:"minecraft:plains"}}
tag @s add hs_v036_castleguard
