# Four modular towers joined by battlement walls around the room perimeter.
execute positioned ~-15 ~0 ~-15 run function hollow_spire:dungeon/structures/castle_tower_stone
execute positioned ~11 ~0 ~-15 run function hollow_spire:dungeon/structures/castle_tower_stone
execute positioned ~-15 ~0 ~11 run function hollow_spire:dungeon/structures/castle_tower_stone
execute positioned ~11 ~0 ~11 run function hollow_spire:dungeon/structures/castle_tower_stone
fill ~-10 ~5 ~-15 ~10 ~6 ~-13 minecraft:stone_bricks
fill ~-10 ~5 ~13 ~10 ~6 ~15 minecraft:stone_bricks
fill ~-15 ~5 ~-10 ~-13 ~6 ~10 minecraft:stone_bricks
fill ~13 ~5 ~-10 ~15 ~6 ~10 minecraft:stone_bricks
# Gate openings on all four axes.
fill ~-2 ~1 ~-16 ~2 ~4 ~-13 minecraft:air
fill ~-2 ~1 ~13 ~2 ~4 ~16 minecraft:air
fill ~-16 ~1 ~-2 ~-13 ~4 ~2 minecraft:air
fill ~13 ~1 ~-2 ~16 ~4 ~2 minecraft:air
tellraw @a[tag=hs_player,distance=..40] [{"text":"CASTLE // ","color":"gold","bold":true},{"text":"FOUR-TOWER HOLD","color":"gray"}]
