# Four flagpoles are common to all variants; heraldry is a random two-color wool pattern.
fill ~-13 ~6 ~-13 ~-13 ~10 ~-13 minecraft:stone_brick_wall
fill ~13 ~6 ~-13 ~13 ~10 ~-13 minecraft:stone_brick_wall
fill ~-13 ~6 ~13 ~-13 ~10 ~13 minecraft:stone_brick_wall
fill ~13 ~6 ~13 ~13 ~10 ~13 minecraft:stone_brick_wall
execute if score @s hs_palette matches 1 run function hollow_spire:dungeon/castle/flags/red_white
execute if score @s hs_palette matches 2 run function hollow_spire:dungeon/castle/flags/blue_yellow
execute if score @s hs_palette matches 3 run function hollow_spire:dungeon/castle/flags/green_black
execute if score @s hs_palette matches 4 run function hollow_spire:dungeon/castle/flags/purple_white
execute if score @s hs_palette matches 5 run function hollow_spire:dungeon/castle/flags/orange_black
execute if score @s hs_palette matches 6 run function hollow_spire:dungeon/castle/flags/cyan_white
