fill ~-12 ~8 ~-13 ~-10 ~9 ~-13 minecraft:red_wool
fill ~-12 ~7 ~-13 ~-10 ~7 ~-13 minecraft:white_wool
fill ~10 ~8 ~-13 ~12 ~9 ~-13 minecraft:red_wool
fill ~10 ~7 ~-13 ~12 ~7 ~-13 minecraft:white_wool
fill ~-12 ~8 ~13 ~-10 ~9 ~13 minecraft:red_wool
fill ~-12 ~7 ~13 ~-10 ~7 ~13 minecraft:white_wool
fill ~10 ~8 ~13 ~12 ~9 ~13 minecraft:red_wool
fill ~10 ~7 ~13 ~12 ~7 ~13 minecraft:white_wool
