fill ~-12 ~8 ~-13 ~-10 ~9 ~-13 minecraft:green_wool
fill ~-12 ~7 ~-13 ~-10 ~7 ~-13 minecraft:black_wool
fill ~10 ~8 ~-13 ~12 ~9 ~-13 minecraft:green_wool
fill ~10 ~7 ~-13 ~12 ~7 ~-13 minecraft:black_wool
fill ~-12 ~8 ~13 ~-10 ~9 ~13 minecraft:green_wool
fill ~-12 ~7 ~13 ~-10 ~7 ~13 minecraft:black_wool
fill ~10 ~8 ~13 ~12 ~9 ~13 minecraft:green_wool
fill ~10 ~7 ~13 ~12 ~7 ~13 minecraft:black_wool
