# Compact modular vanilla-style pillager outpost.
execute positioned ~-15 ~0 ~8 run function hollow_spire:dungeon/structures/castle_outpost_wood
fill ~-14 ~0 ~-14 ~-9 ~0 ~-9 minecraft:cobblestone
setblock ~-12 ~1 ~-11 minecraft:target
setblock ~-10 ~1 ~-11 minecraft:hay_block
summon minecraft:pillager ~-11 ~1 ~10 {Tags:["hs_castle_guard"],PersistenceRequired:1b}
summon minecraft:pillager ~-13 ~1 ~13 {Tags:["hs_castle_guard"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"CASTLE // ","color":"gold","bold":true},{"text":"PILLAGER OUTPOST","color":"dark_gray"}]
