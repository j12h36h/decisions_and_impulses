execute store result score @s hs_roll run random value 1..100
execute if score @s hs_roll matches 1..59 run setblock ~ ~ ~ minecraft:stone
execute if score @s hs_roll matches 60..79 run function hollow_spire:dungeon/mine/place_secondary
execute if score @s hs_roll matches 80..89 run setblock ~ ~ ~ minecraft:gravel
execute if score @s hs_roll matches 90..96 run setblock ~ ~ ~ minecraft:coal_ore
execute if score @s hs_roll matches 97..99 run setblock ~ ~ ~ minecraft:iron_ore
execute if score @s hs_roll matches 100 run setblock ~ ~ ~ minecraft:copper_ore
