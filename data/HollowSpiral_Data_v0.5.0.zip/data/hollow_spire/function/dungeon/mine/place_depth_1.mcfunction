execute store result score @s hs_roll run random value 1..100
execute if score @s hs_roll matches 1..60 run setblock ~ ~ ~ minecraft:stone
execute if score @s hs_roll matches 61..80 run function hollow_spire:dungeon/mine/place_secondary
execute if score @s hs_roll matches 81..90 run setblock ~ ~ ~ minecraft:gravel
execute if score @s hs_roll matches 91..97 run setblock ~ ~ ~ minecraft:coal_ore
execute if score @s hs_roll matches 98..100 run setblock ~ ~ ~ minecraft:iron_ore
