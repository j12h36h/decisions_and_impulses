execute store result score @s hs_roll run random value 1..100
execute if score @s hs_roll matches 1..53 run setblock ~ ~ ~ minecraft:stone
execute if score @s hs_roll matches 54..73 run function hollow_spire:dungeon/mine/place_secondary
execute if score @s hs_roll matches 74..83 run setblock ~ ~ ~ minecraft:gravel
execute if score @s hs_roll matches 84..88 run setblock ~ ~ ~ minecraft:coal_ore
execute if score @s hs_roll matches 89..93 run setblock ~ ~ ~ minecraft:iron_ore
execute if score @s hs_roll matches 94..95 run setblock ~ ~ ~ minecraft:copper_ore
execute if score @s hs_roll matches 96..97 run setblock ~ ~ ~ minecraft:gold_ore
execute if score @s hs_roll matches 98..99 run setblock ~ ~ ~ minecraft:redstone_ore
execute if score @s hs_roll matches 100 run setblock ~ ~ ~ minecraft:lapis_ore
