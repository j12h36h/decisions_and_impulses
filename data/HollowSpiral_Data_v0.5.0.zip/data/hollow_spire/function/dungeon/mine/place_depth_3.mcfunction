execute store result score @s hs_roll run random value 1..100
execute if score @s hs_roll matches 1..58 run setblock ~ ~ ~ minecraft:stone
execute if score @s hs_roll matches 59..78 run function hollow_spire:dungeon/mine/place_secondary
execute if score @s hs_roll matches 79..88 run setblock ~ ~ ~ minecraft:gravel
execute if score @s hs_roll matches 89..94 run setblock ~ ~ ~ minecraft:coal_ore
execute if score @s hs_roll matches 95..98 run setblock ~ ~ ~ minecraft:iron_ore
execute if score @s hs_roll matches 99..100 run setblock ~ ~ ~ minecraft:copper_ore
