execute store result score @s hs_roll run random value 1..100
execute if score @s hs_roll matches 1..55 run setblock ~ ~ ~ minecraft:stone
execute if score @s hs_roll matches 56..75 run function hollow_spire:dungeon/mine/place_secondary
execute if score @s hs_roll matches 76..85 run setblock ~ ~ ~ minecraft:gravel
execute if score @s hs_roll matches 86..91 run setblock ~ ~ ~ minecraft:coal_ore
execute if score @s hs_roll matches 92..95 run setblock ~ ~ ~ minecraft:iron_ore
execute if score @s hs_roll matches 96..97 run setblock ~ ~ ~ minecraft:copper_ore
execute if score @s hs_roll matches 98 run setblock ~ ~ ~ minecraft:gold_ore
execute if score @s hs_roll matches 99..100 run setblock ~ ~ ~ minecraft:redstone_ore
