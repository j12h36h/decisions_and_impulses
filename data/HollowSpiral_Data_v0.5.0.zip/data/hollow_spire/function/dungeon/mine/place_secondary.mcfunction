execute if score @s hs_secondary matches 1 run setblock ~ ~ ~ minecraft:andesite
execute if score @s hs_secondary matches 2 run setblock ~ ~ ~ minecraft:diorite
execute if score @s hs_secondary matches 3 run setblock ~ ~ ~ minecraft:granite
execute if score @s hs_secondary matches 4 run setblock ~ ~ ~ minecraft:deepslate
execute if score @s hs_secondary matches 5 run setblock ~ ~ ~ minecraft:tuff
execute if score @s hs_secondary matches 6 run setblock ~ ~ ~ minecraft:calcite
