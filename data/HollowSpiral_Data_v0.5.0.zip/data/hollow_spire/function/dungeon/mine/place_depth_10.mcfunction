execute store result score @s hs_roll run random value 1..100
execute if score @s hs_roll matches 1..45 run setblock ~ ~ ~ minecraft:stone
execute if score @s hs_roll matches 46..65 run function hollow_spire:dungeon/mine/place_secondary
execute if score @s hs_roll matches 66..75 run setblock ~ ~ ~ minecraft:gravel
execute if score @s hs_roll matches 76..79 run setblock ~ ~ ~ minecraft:coal_ore
execute if score @s hs_roll matches 80..84 run setblock ~ ~ ~ minecraft:iron_ore
execute if score @s hs_roll matches 85..86 run setblock ~ ~ ~ minecraft:copper_ore
execute if score @s hs_roll matches 87..90 run setblock ~ ~ ~ minecraft:gold_ore
execute if score @s hs_roll matches 91..95 run setblock ~ ~ ~ minecraft:redstone_ore
execute if score @s hs_roll matches 96 run setblock ~ ~ ~ minecraft:lapis_ore
execute if score @s hs_roll matches 97..100 run setblock ~ ~ ~ minecraft:diamond_ore
