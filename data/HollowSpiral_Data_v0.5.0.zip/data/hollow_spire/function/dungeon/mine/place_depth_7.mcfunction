execute store result score @s hs_roll run random value 1..100
execute if score @s hs_roll matches 1..51 run setblock ~ ~ ~ minecraft:stone
execute if score @s hs_roll matches 52..71 run function hollow_spire:dungeon/mine/place_secondary
execute if score @s hs_roll matches 72..81 run setblock ~ ~ ~ minecraft:gravel
execute if score @s hs_roll matches 82..86 run setblock ~ ~ ~ minecraft:coal_ore
execute if score @s hs_roll matches 87..91 run setblock ~ ~ ~ minecraft:iron_ore
execute if score @s hs_roll matches 92..93 run setblock ~ ~ ~ minecraft:copper_ore
execute if score @s hs_roll matches 94..95 run setblock ~ ~ ~ minecraft:gold_ore
execute if score @s hs_roll matches 96..98 run setblock ~ ~ ~ minecraft:redstone_ore
execute if score @s hs_roll matches 99 run setblock ~ ~ ~ minecraft:lapis_ore
execute if score @s hs_roll matches 100 run setblock ~ ~ ~ minecraft:diamond_ore
