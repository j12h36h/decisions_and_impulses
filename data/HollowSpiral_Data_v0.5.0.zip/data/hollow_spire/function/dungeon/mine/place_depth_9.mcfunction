execute store result score @s hs_roll run random value 1..100
execute if score @s hs_roll matches 1..47 run setblock ~ ~ ~ minecraft:stone
execute if score @s hs_roll matches 48..67 run function hollow_spire:dungeon/mine/place_secondary
execute if score @s hs_roll matches 68..77 run setblock ~ ~ ~ minecraft:gravel
execute if score @s hs_roll matches 78..81 run setblock ~ ~ ~ minecraft:coal_ore
execute if score @s hs_roll matches 82..86 run setblock ~ ~ ~ minecraft:iron_ore
execute if score @s hs_roll matches 87..88 run setblock ~ ~ ~ minecraft:copper_ore
execute if score @s hs_roll matches 89..91 run setblock ~ ~ ~ minecraft:gold_ore
execute if score @s hs_roll matches 92..96 run setblock ~ ~ ~ minecraft:redstone_ore
execute if score @s hs_roll matches 97 run setblock ~ ~ ~ minecraft:lapis_ore
execute if score @s hs_roll matches 98..100 run setblock ~ ~ ~ minecraft:diamond_ore
