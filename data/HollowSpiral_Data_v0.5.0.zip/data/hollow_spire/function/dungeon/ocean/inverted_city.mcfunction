# INVERTED OCEAN CITY — literal WATER / GLASS / BUILDINGS vertical stack.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:dark_prismarine replace minecraft:deepslate_tiles
# Dry city buildings underneath the suspended aquarium.
fill ~-15 ~1 ~-14 ~-9 ~5 ~-8 minecraft:prismarine_bricks hollow
fill ~8 ~1 ~-14 ~14 ~6 ~-8 minecraft:dark_prismarine hollow
fill ~-14 ~1 ~8 ~-8 ~6 ~14 minecraft:prismarine hollow
fill ~9 ~1 ~8 ~15 ~5 ~14 minecraft:prismarine_bricks hollow
fill ~-11 ~1 ~-11 ~-11 ~6 ~-11 minecraft:sea_lantern
fill ~11 ~1 ~-11 ~11 ~7 ~-11 minecraft:sea_lantern
fill ~-11 ~1 ~11 ~-11 ~7 ~11 minecraft:sea_lantern
fill ~12 ~1 ~11 ~12 ~6 ~11 minecraft:sea_lantern
# Windows and doors make the lower layer read as buildings, not blocks.
fill ~-15 ~2 ~-11 ~-15 ~3 ~-10 minecraft:glass_pane
setblock ~-12 ~1 ~-8 minecraft:dark_oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~-12 ~2 ~-8 minecraft:dark_oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
fill ~14 ~2 ~-11 ~14 ~3 ~-10 minecraft:glass_pane
setblock ~11 ~1 ~-8 minecraft:warped_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~11 ~2 ~-8 minecraft:warped_door[half=upper,facing=south,hinge=left,open=false,powered=false]
# The entire water ceiling is a single glass-backed ocean layer.
fill ~-16 ~7 ~-16 ~16 ~7 ~16 minecraft:glass
fill ~-16 ~8 ~-16 ~16 ~11 ~16 minecraft:water
summon minecraft:cod ~-10 ~9 ~-10 {Tags:["hs_ocean_mob"],PersistenceRequired:1b}
summon minecraft:salmon ~10 ~10 ~9 {Tags:["hs_ocean_mob"],PersistenceRequired:1b}
summon minecraft:tropical_fish ~-9 ~10 ~10 {Tags:["hs_ocean_mob"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"OCEAN // ","color":"blue","bold":true},{"text":"INVERTED CITY","color":"aqua"}]
