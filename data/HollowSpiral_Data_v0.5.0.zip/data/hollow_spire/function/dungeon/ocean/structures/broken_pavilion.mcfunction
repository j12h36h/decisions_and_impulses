# Broken underwater pavilion with visible columns and a partially collapsed roof.
fill ~0 ~0 ~0 ~7 ~0 ~6 minecraft:mossy_stone_bricks
fill ~0 ~1 ~0 ~0 ~5 ~0 minecraft:stone_bricks
fill ~7 ~1 ~0 ~7 ~5 ~0 minecraft:stone_bricks
fill ~0 ~1 ~6 ~0 ~4 ~6 minecraft:stone_bricks
fill ~7 ~1 ~6 ~7 ~3 ~6 minecraft:cracked_stone_bricks
fill ~0 ~5 ~0 ~4 ~5 ~0 minecraft:stone_brick_slab[type=bottom]
fill ~0 ~5 ~0 ~0 ~5 ~4 minecraft:stone_brick_slab[type=bottom]
fill ~2 ~5 ~2 ~6 ~5 ~2 minecraft:stone_brick_slab[type=bottom]
setblock ~6 ~1 ~5 minecraft:gravel
setblock ~5 ~1 ~5 minecraft:stone_brick_stairs[facing=west,half=bottom,waterlogged=true]
setblock ~1 ~4 ~0 minecraft:fire_coral_block
setblock ~7 ~4 ~0 minecraft:horn_coral_block
