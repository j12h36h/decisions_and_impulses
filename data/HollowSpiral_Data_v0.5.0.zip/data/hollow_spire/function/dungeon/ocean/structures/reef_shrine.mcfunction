# Open 7x7 drowned shrine: floor, four columns, broken roof ring, central light.
fill ~0 ~0 ~0 ~6 ~0 ~6 minecraft:prismarine_bricks
fill ~0 ~1 ~0 ~0 ~5 ~0 minecraft:prismarine
fill ~6 ~1 ~0 ~6 ~5 ~0 minecraft:prismarine
fill ~0 ~1 ~6 ~0 ~5 ~6 minecraft:prismarine
fill ~6 ~1 ~6 ~6 ~4 ~6 minecraft:prismarine
fill ~0 ~5 ~0 ~6 ~5 ~0 minecraft:dark_prismarine
fill ~0 ~5 ~0 ~0 ~5 ~6 minecraft:dark_prismarine
fill ~6 ~5 ~0 ~6 ~5 ~4 minecraft:dark_prismarine
fill ~2 ~1 ~2 ~4 ~1 ~4 minecraft:cut_sandstone
setblock ~3 ~2 ~3 minecraft:sea_lantern
setblock ~0 ~6 ~0 minecraft:tube_coral_block
setblock ~6 ~5 ~6 minecraft:brain_coral_block
setblock ~1 ~1 ~5 minecraft:chiseled_stone_bricks
