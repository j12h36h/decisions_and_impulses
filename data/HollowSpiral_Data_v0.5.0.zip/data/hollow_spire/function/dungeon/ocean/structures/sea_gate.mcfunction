# Narrow broken sea gate with twin towers and an open center.
fill ~0 ~0 ~0 ~2 ~0 ~5 minecraft:prismarine_bricks
fill ~6 ~0 ~0 ~8 ~0 ~5 minecraft:prismarine_bricks
fill ~0 ~1 ~1 ~1 ~5 ~4 minecraft:prismarine
fill ~7 ~1 ~1 ~8 ~5 ~4 minecraft:prismarine
fill ~1 ~5 ~1 ~7 ~5 ~2 minecraft:dark_prismarine
fill ~3 ~1 ~0 ~5 ~4 ~4 minecraft:air
setblock ~0 ~6 ~2 minecraft:bubble_coral_block
setblock ~8 ~6 ~3 minecraft:brain_coral_block
setblock ~2 ~1 ~5 minecraft:mossy_cobblestone
setblock ~6 ~1 ~0 minecraft:cracked_stone_bricks
