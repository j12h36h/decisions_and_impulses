# 8x6 drowned coral arch, anchored at its southwest corner.
fill ~0 ~0 ~0 ~1 ~4 ~1 minecraft:prismarine_bricks
fill ~6 ~0 ~0 ~7 ~4 ~1 minecraft:prismarine_bricks
fill ~1 ~4 ~0 ~6 ~5 ~1 minecraft:dark_prismarine
fill ~2 ~1 ~0 ~5 ~3 ~1 minecraft:air
setblock ~0 ~5 ~0 minecraft:brain_coral_block
setblock ~7 ~5 ~1 minecraft:fire_coral_block
setblock ~2 ~5 ~0 minecraft:horn_coral_block
setblock ~5 ~5 ~1 minecraft:bubble_coral_block
setblock ~1 ~0 ~2 minecraft:mossy_cobblestone
setblock ~6 ~0 ~2 minecraft:cracked_stone_bricks
