# CORAL GROTTO v0.3.6 — a flooded reef settlement/ritual grotto built from real open structures.
# Rebuild cleanly so legacy giant stone/calcite/tuff/prismarine chunks disappear.
fill ~-16 ~1 ~-16 ~16 ~11 ~16 minecraft:air
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:sand
# Natural seabed patches, deliberately low and irregular rather than giant cubes.
fill ~-15 ~0 ~-13 ~-11 ~0 ~-9 minecraft:gravel
fill ~10 ~0 ~-14 ~14 ~0 ~-10 minecraft:stone
fill ~-14 ~0 ~9 ~-10 ~0 ~13 minecraft:calcite
fill ~10 ~0 ~9 ~14 ~0 ~13 minecraft:tuff
# Four recognizable submerged structures around the protected central stair core.
execute positioned ~-15 ~1 ~-12 run function hollow_spire:dungeon/ocean/structures/coral_arch
execute positioned ~8 ~1 ~-14 run function hollow_spire:dungeon/ocean/structures/reef_shrine
execute positioned ~-15 ~1 ~8 run function hollow_spire:dungeon/ocean/structures/broken_pavilion
execute positioned ~7 ~1 ~8 run function hollow_spire:dungeon/ocean/structures/sea_gate
# Small reef spires and rubble between structures.
fill ~-9 ~1 ~-13 ~-9 ~3 ~-13 minecraft:mossy_cobblestone
fill ~13 ~1 ~5 ~13 ~4 ~5 minecraft:prismarine
fill ~-11 ~1 ~5 ~-11 ~2 ~5 minecraft:calcite
setblock ~-9 ~4 ~-13 minecraft:brain_coral_block
setblock ~13 ~5 ~5 minecraft:fire_coral_block
setblock ~-11 ~3 ~5 minecraft:bubble_coral_block
setblock ~11 ~1 ~-7 minecraft:gravel
setblock ~-8 ~1 ~7 minecraft:cracked_stone_bricks
# Flood the remaining chamber as one coherent volume; ocean/safety runs afterward and restores the dry center/door vestibules.
fill ~-16 ~1 ~-16 ~16 ~10 ~16 minecraft:water replace minecraft:air
# Populate the grotto.
summon minecraft:tropical_fish ~-11 ~6 ~-9 {Tags:["hs_ocean_mob"],PersistenceRequired:1b}
summon minecraft:tropical_fish ~11 ~7 ~9 {Tags:["hs_ocean_mob"],PersistenceRequired:1b}
summon minecraft:cod ~12 ~5 ~-8 {Tags:["hs_ocean_mob"],PersistenceRequired:1b}
summon minecraft:drowned ~-12 ~2 ~10 {Tags:["hs_ocean_mob"],PersistenceRequired:1b,Invisible:0b}
tag @s add hs_v036_grotto
tellraw @a[tag=hs_player,distance=..40] [{"text":"OCEAN // ","color":"blue","bold":true},{"text":"CORAL GROTTO","color":"light_purple"}]
