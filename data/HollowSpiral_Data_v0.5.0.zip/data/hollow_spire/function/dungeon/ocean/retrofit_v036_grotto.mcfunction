kill @e[tag=hs_ocean_mob,distance=..28]
function hollow_spire:dungeon/ocean/coral_grotto
function hollow_spire:dungeon/ocean/safety
tag @s add hs_v036_grotto
