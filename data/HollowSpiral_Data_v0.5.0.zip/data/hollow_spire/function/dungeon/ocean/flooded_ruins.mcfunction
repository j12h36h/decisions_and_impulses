# FLOODED RUINS v0.3.5
# A real submerged masonry settlement: build intact village-derived structures, siege-damage them, then flood the empty volume.
# Clearing here also lets the one-time retrofit replace the old giant block chunks in existing Flooded Ruins.
fill ~-16 ~1 ~-16 ~16 ~11 ~16 minecraft:air
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:sand replace minecraft:deepslate_tiles

# Four recognizable masonry village houses around the protected central shaft.
execute positioned ~-15 ~1 ~-15 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~9 ~1 ~-15 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~-15 ~1 ~9 run function hollow_spire:dungeon/structures/ruin_house_small
execute positioned ~9 ~1 ~9 run function hollow_spire:dungeon/structures/ruin_house_small

# Underwater market remnants / street furniture make the settlement read as a place rather than four boxes.
execute positioned ~-15 ~1 ~-4 run function hollow_spire:dungeon/structures/ruin_market_stall
execute positioned ~11 ~1 ~3 run function hollow_spire:dungeon/structures/ruin_market_stall
fill ~-15 ~1 ~-2 ~-9 ~1 ~2 minecraft:mossy_cobblestone
fill ~9 ~1 ~-2 ~15 ~1 ~2 minecraft:cracked_stone_bricks
setblock ~-13 ~2 ~0 minecraft:lantern[hanging=false]
setblock ~13 ~2 ~0 minecraft:sea_lantern

# Simulated siege/TNT damage is applied while the room is still dry, so the resulting holes flood naturally afterward.
execute positioned ~-12 ~5 ~-12 run function hollow_spire:dungeon/ruins/damage/shell_impact
execute positioned ~12 ~6 ~-12 run function hollow_spire:dungeon/ruins/damage/roof_collapse
execute positioned ~-12 ~4 ~12 run function hollow_spire:dungeon/ruins/damage/wall_breach
execute positioned ~12 ~4 ~12 run function hollow_spire:dungeon/ruins/damage/interior_blast
execute positioned ~-13 ~4 ~-3 run function hollow_spire:dungeon/ruins/damage/roof_collapse

# Rubble on the seabed.
setblock ~-8 ~1 ~-12 minecraft:cracked_stone_bricks
setblock ~-7 ~1 ~-11 minecraft:cobblestone_slab[type=bottom]
setblock ~8 ~1 ~11 minecraft:mossy_cobblestone
setblock ~7 ~1 ~12 minecraft:gravel
setblock ~-10 ~1 ~7 minecraft:stone_brick_stairs[facing=east,half=bottom]
setblock ~10 ~1 ~-7 minecraft:stone_brick_wall

# Flood every remaining air cell as one coherent ocean volume. The shared ocean safety pass runs afterward and re-carves the dry shaft/vestibules.
fill ~-16 ~1 ~-16 ~16 ~10 ~16 minecraft:water replace minecraft:air

# Underwater population.
summon minecraft:drowned ~-11 ~3 ~10 {Tags:["hs_ocean_mob"],PersistenceRequired:1b,Invisible:0b}
summon minecraft:drowned ~11 ~3 ~-10 {Tags:["hs_ocean_mob"],PersistenceRequired:1b,Invisible:0b}
summon minecraft:cod ~-8 ~6 ~-8 {Tags:["hs_ocean_mob"],PersistenceRequired:1b}
summon minecraft:salmon ~9 ~7 ~9 {Tags:["hs_ocean_mob"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"OCEAN // ","color":"blue","bold":true},{"text":"FLOODED RUINS","color":"aqua"}]
