# OCEAN SAFETY v0.3.6
# The ocean is one coherent volume. Only the central vertical shaft and four short doorway vestibules stay dry.
# Central sealed 13x13 glass shaft. v0.3.6 stair carving stays within +/-5, so the +/-6 pressure wall survives vertical generation.
fill ~-6 ~0 ~-6 ~6 ~0 ~6 minecraft:deepslate_tiles
fill ~-6 ~1 ~-6 ~-6 ~11 ~6 minecraft:glass
fill ~6 ~1 ~-6 ~6 ~11 ~6 minecraft:glass
fill ~-5 ~1 ~-6 ~5 ~11 ~-6 minecraft:glass
fill ~-5 ~1 ~6 ~5 ~11 ~6 minecraft:glass
fill ~-6 ~12 ~-6 ~6 ~12 ~6 minecraft:glass
fill ~-5 ~1 ~-5 ~5 ~11 ~5 minecraft:air
# North/South manual access doors through the shaft wall. UP/DOWN pylons now replace two solid cells of the north glass wall and remain pressure-safe.
setblock ~0 ~1 ~-6 minecraft:warped_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~0 ~2 ~-6 minecraft:warped_door[half=upper,facing=south,hinge=left,open=false,powered=false]
setblock ~0 ~1 ~6 minecraft:warped_door[half=lower,facing=north,hinge=left,open=false,powered=false]
setblock ~0 ~2 ~6 minecraft:warped_door[half=upper,facing=north,hinge=left,open=false,powered=false]
# North doorway vestibule (short, not connected to center).
fill ~-3 ~1 ~-16 ~-3 ~4 ~-12 minecraft:glass
fill ~3 ~1 ~-16 ~3 ~4 ~-12 minecraft:glass
fill ~-2 ~4 ~-16 ~2 ~4 ~-12 minecraft:glass
fill ~-2 ~1 ~-16 ~2 ~3 ~-12 minecraft:air
fill ~-2 ~1 ~-12 ~2 ~3 ~-12 minecraft:glass
setblock ~0 ~1 ~-12 minecraft:warped_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~0 ~2 ~-12 minecraft:warped_door[half=upper,facing=south,hinge=left,open=false,powered=false]
# South vestibule.
fill ~-3 ~1 ~12 ~-3 ~4 ~16 minecraft:glass
fill ~3 ~1 ~12 ~3 ~4 ~16 minecraft:glass
fill ~-2 ~4 ~12 ~2 ~4 ~16 minecraft:glass
fill ~-2 ~1 ~12 ~2 ~3 ~16 minecraft:air
fill ~-2 ~1 ~12 ~2 ~3 ~12 minecraft:glass
setblock ~0 ~1 ~12 minecraft:warped_door[half=lower,facing=north,hinge=left,open=false,powered=false]
setblock ~0 ~2 ~12 minecraft:warped_door[half=upper,facing=north,hinge=left,open=false,powered=false]
# East vestibule.
fill ~12 ~1 ~-3 ~16 ~4 ~-3 minecraft:glass
fill ~12 ~1 ~3 ~16 ~4 ~3 minecraft:glass
fill ~12 ~4 ~-2 ~16 ~4 ~2 minecraft:glass
fill ~12 ~1 ~-2 ~16 ~3 ~2 minecraft:air
fill ~12 ~1 ~-2 ~12 ~3 ~2 minecraft:glass
setblock ~12 ~1 ~0 minecraft:warped_door[half=lower,facing=west,hinge=left,open=false,powered=false]
setblock ~12 ~2 ~0 minecraft:warped_door[half=upper,facing=west,hinge=left,open=false,powered=false]
# West vestibule.
fill ~-16 ~1 ~-3 ~-12 ~4 ~-3 minecraft:glass
fill ~-16 ~1 ~3 ~-12 ~4 ~3 minecraft:glass
fill ~-16 ~4 ~-2 ~-12 ~4 ~2 minecraft:glass
fill ~-16 ~1 ~-2 ~-12 ~3 ~2 minecraft:air
fill ~-12 ~1 ~-2 ~-12 ~3 ~2 minecraft:glass
setblock ~-12 ~1 ~0 minecraft:warped_door[half=lower,facing=east,hinge=left,open=false,powered=false]
setblock ~-12 ~2 ~0 minecraft:warped_door[half=upper,facing=east,hinge=left,open=false,powered=false]
function hollow_spire:dungeon/room/restore_controls
