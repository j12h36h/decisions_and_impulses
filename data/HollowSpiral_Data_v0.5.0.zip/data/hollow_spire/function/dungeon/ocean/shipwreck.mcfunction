# SHIPWRECK — coherent half-flooded room: water level y+5, rocks and a wreck across one basin.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:sand replace minecraft:deepslate_tiles
fill ~-16 ~1 ~-16 ~16 ~5 ~16 minecraft:water replace minecraft:air
# Jagged rocks rooted in the basin floor.
fill ~-13 ~1 ~-11 ~-10 ~7 ~-8 minecraft:deepslate
fill ~10 ~1 ~7 ~13 ~6 ~10 minecraft:tuff
fill ~8 ~1 ~-13 ~11 ~4 ~-10 minecraft:cobbled_deepslate
setblock ~-11 ~8 ~-9 minecraft:pointed_dripstone[vertical_direction=up,thickness=tip,waterlogged=false]
# Larger wrecked hull crossing the common water body.
fill ~-9 ~2 ~-14 ~6 ~2 ~-9 minecraft:spruce_planks
fill ~-7 ~3 ~-13 ~4 ~3 ~-10 minecraft:oak_planks
fill ~-8 ~4 ~-13 ~-6 ~4 ~-10 minecraft:spruce_stairs[facing=east,half=bottom,waterlogged=true]
fill ~3 ~4 ~-13 ~5 ~4 ~-10 minecraft:spruce_stairs[facing=west,half=bottom,waterlogged=true]
fill ~-2 ~3 ~-11 ~-2 ~10 ~-11 minecraft:stripped_spruce_log[axis=y]
fill ~-6 ~2 ~-10 ~-5 ~5 ~-9 minecraft:air
setblock ~-1 ~3 ~-11 minecraft:barrel
setblock ~2 ~3 ~-11 minecraft:chest
summon minecraft:drowned ~-10 ~2 ~-9 {Tags:["hs_ocean_mob"],PersistenceRequired:1b,Invisible:0b}
summon minecraft:cod ~8 ~3 ~-10 {Tags:["hs_ocean_mob"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"OCEAN // ","color":"blue","bold":true},{"text":"SHIPWRECK","color":"gray"}]
