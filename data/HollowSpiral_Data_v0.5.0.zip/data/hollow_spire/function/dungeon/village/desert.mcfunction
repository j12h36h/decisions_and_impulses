# DESERT TINY VILLAGE — sandstone homes + roofed sandstone well. No smithery.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:sand replace minecraft:deepslate_tiles
fill ~-3 ~0 ~-16 ~3 ~0 ~-7 minecraft:smooth_sandstone
fill ~-3 ~0 ~7 ~3 ~0 ~16 minecraft:smooth_sandstone
fill ~-16 ~0 ~-3 ~-7 ~0 ~3 minecraft:smooth_sandstone
fill ~7 ~0 ~-3 ~16 ~0 ~3 minecraft:smooth_sandstone
# NW desert house with stepped roof/parapet.
fill ~-15 ~0 ~-14 ~-8 ~0 ~-7 minecraft:cut_sandstone
fill ~-15 ~1 ~-14 ~-8 ~4 ~-7 minecraft:sandstone hollow
fill ~-14 ~1 ~-13 ~-9 ~1 ~-8 minecraft:smooth_sandstone
setblock ~-11 ~1 ~-7 minecraft:oak_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~-11 ~2 ~-7 minecraft:oak_door[half=upper,facing=south,hinge=left,open=false,powered=false]
setblock ~-15 ~2 ~-10 minecraft:glass_pane
setblock ~-8 ~2 ~-11 minecraft:glass_pane
fill ~-16 ~5 ~-15 ~-7 ~5 ~-6 minecraft:smooth_sandstone_slab[type=bottom]
fill ~-15 ~6 ~-14 ~-8 ~6 ~-7 minecraft:cut_sandstone
fill ~-14 ~6 ~-13 ~-9 ~6 ~-8 minecraft:air
setblock ~-13 ~1 ~-11 minecraft:yellow_bed[part=foot,facing=east]
setblock ~-12 ~1 ~-11 minecraft:yellow_bed[part=head,facing=east]
setblock ~-9 ~1 ~-12 minecraft:composter
# SE desert home with tower corner.
fill ~8 ~0 ~7 ~15 ~0 ~14 minecraft:cut_sandstone
fill ~8 ~1 ~7 ~15 ~4 ~14 minecraft:smooth_sandstone hollow
fill ~9 ~1 ~8 ~14 ~1 ~13 minecraft:sandstone
setblock ~11 ~1 ~7 minecraft:oak_door[half=lower,facing=north,hinge=left,open=false,powered=false]
setblock ~11 ~2 ~7 minecraft:oak_door[half=upper,facing=north,hinge=left,open=false,powered=false]
setblock ~8 ~2 ~10 minecraft:glass_pane
setblock ~15 ~2 ~11 minecraft:glass_pane
fill ~7 ~5 ~6 ~16 ~5 ~15 minecraft:sandstone_slab[type=bottom]
fill ~12 ~5 ~10 ~15 ~7 ~14 minecraft:cut_sandstone hollow
setblock ~13 ~1 ~10 minecraft:red_bed[part=foot,facing=west]
setblock ~12 ~1 ~10 minecraft:red_bed[part=head,facing=west]
setblock ~14 ~1 ~12 minecraft:loom[facing=north]
# Well.
fill ~8 ~0 ~-13 ~12 ~0 ~-9 minecraft:cut_sandstone
fill ~8 ~1 ~-13 ~12 ~1 ~-9 minecraft:sandstone hollow
fill ~9 ~1 ~-12 ~11 ~1 ~-10 minecraft:water
fill ~8 ~2 ~-13 ~8 ~3 ~-13 minecraft:sandstone_wall
fill ~12 ~2 ~-13 ~12 ~3 ~-13 minecraft:sandstone_wall
fill ~8 ~2 ~-9 ~8 ~3 ~-9 minecraft:sandstone_wall
fill ~12 ~2 ~-9 ~12 ~3 ~-9 minecraft:sandstone_wall
fill ~7 ~4 ~-14 ~13 ~4 ~-8 minecraft:smooth_sandstone_slab[type=bottom]
setblock ~13 ~1 ~-6 minecraft:bell[attachment=floor,facing=north,powered=false]
summon minecraft:villager ~-11 ~1 ~-10 {Tags:["hs_villager"],PersistenceRequired:1b}
summon minecraft:villager ~12 ~1 ~10 {Tags:["hs_villager"],PersistenceRequired:1b}
summon minecraft:villager ~7 ~1 ~-6 {Tags:["hs_villager"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"VILLAGE // ","color":"yellow","bold":true},{"text":"DESERT","color":"gold"}]

# v0.3.3 roof completion: continuous desert parapets/caps.
fill ~-15 ~5 ~-14 ~-8 ~5 ~-14 minecraft:cut_sandstone
fill ~-15 ~5 ~-7 ~-8 ~5 ~-7 minecraft:cut_sandstone
fill ~-15 ~5 ~-13 ~-15 ~5 ~-8 minecraft:cut_sandstone
fill ~-8 ~5 ~-13 ~-8 ~5 ~-8 minecraft:cut_sandstone
fill ~8 ~5 ~7 ~15 ~5 ~7 minecraft:cut_sandstone
fill ~8 ~5 ~14 ~15 ~5 ~14 minecraft:cut_sandstone
fill ~8 ~5 ~8 ~8 ~5 ~13 minecraft:cut_sandstone
fill ~15 ~5 ~8 ~15 ~5 ~13 minecraft:cut_sandstone
