# SNOWY TINY VILLAGE — actual timber homes + biome well. No smithery.
fill ~-16 ~0 ~-16 ~16 ~0 ~16 minecraft:snow_block replace minecraft:deepslate_tiles
fill ~-3 ~0 ~-16 ~3 ~0 ~-7 minecraft:dirt_path
fill ~-3 ~0 ~7 ~3 ~0 ~16 minecraft:dirt_path
fill ~-16 ~0 ~-3 ~-7 ~0 ~3 minecraft:dirt_path
fill ~7 ~0 ~-3 ~16 ~0 ~3 minecraft:dirt_path
# NW house
fill ~-15 ~0 ~-14 ~-8 ~0 ~-7 minecraft:cobblestone
fill ~-15 ~1 ~-14 ~-15 ~4 ~-7 minecraft:spruce_planks
fill ~-8 ~1 ~-14 ~-8 ~4 ~-7 minecraft:spruce_planks
fill ~-14 ~1 ~-14 ~-9 ~4 ~-14 minecraft:spruce_planks
fill ~-14 ~1 ~-7 ~-9 ~4 ~-7 minecraft:spruce_planks
fill ~-15 ~1 ~-14 ~-15 ~4 ~-14 minecraft:spruce_log[axis=y]
fill ~-8 ~1 ~-14 ~-8 ~4 ~-14 minecraft:spruce_log[axis=y]
fill ~-15 ~1 ~-7 ~-15 ~4 ~-7 minecraft:spruce_log[axis=y]
fill ~-8 ~1 ~-7 ~-8 ~4 ~-7 minecraft:spruce_log[axis=y]
fill ~-14 ~1 ~-13 ~-9 ~1 ~-8 minecraft:spruce_planks
setblock ~-11 ~1 ~-7 minecraft:spruce_door[half=lower,facing=south,hinge=left,open=false,powered=false]
setblock ~-11 ~2 ~-7 minecraft:spruce_door[half=upper,facing=south,hinge=left,open=false,powered=false]
fill ~-15 ~2 ~-11 ~-15 ~3 ~-10 minecraft:glass_pane
fill ~-8 ~2 ~-11 ~-8 ~3 ~-10 minecraft:glass_pane
setblock ~-13 ~1 ~-11 minecraft:blue_bed[part=foot,facing=east]
setblock ~-12 ~1 ~-11 minecraft:blue_bed[part=head,facing=east]
setblock ~-9 ~1 ~-12 minecraft:composter
fill ~-16 ~5 ~-15 ~-7 ~5 ~-15 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~-16 ~5 ~-6 ~-7 ~5 ~-6 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~-15 ~6 ~-14 ~-8 ~6 ~-14 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~-15 ~6 ~-7 ~-8 ~6 ~-7 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~-14 ~7 ~-13 ~-9 ~7 ~-13 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~-14 ~7 ~-8 ~-9 ~7 ~-8 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~-13 ~7 ~-12 ~-10 ~7 ~-9 minecraft:spruce_planks
# SE house
fill ~8 ~0 ~7 ~15 ~0 ~14 minecraft:cobblestone
fill ~8 ~1 ~7 ~8 ~4 ~14 minecraft:spruce_planks
fill ~15 ~1 ~7 ~15 ~4 ~14 minecraft:spruce_planks
fill ~9 ~1 ~7 ~14 ~4 ~7 minecraft:spruce_planks
fill ~9 ~1 ~14 ~14 ~4 ~14 minecraft:spruce_planks
fill ~8 ~1 ~7 ~8 ~4 ~7 minecraft:spruce_log[axis=y]
fill ~15 ~1 ~7 ~15 ~4 ~7 minecraft:spruce_log[axis=y]
fill ~8 ~1 ~14 ~8 ~4 ~14 minecraft:spruce_log[axis=y]
fill ~15 ~1 ~14 ~15 ~4 ~14 minecraft:spruce_log[axis=y]
fill ~9 ~1 ~8 ~14 ~1 ~13 minecraft:spruce_planks
setblock ~11 ~1 ~7 minecraft:spruce_door[half=lower,facing=north,hinge=left,open=false,powered=false]
setblock ~11 ~2 ~7 minecraft:spruce_door[half=upper,facing=north,hinge=left,open=false,powered=false]
fill ~8 ~2 ~10 ~8 ~3 ~11 minecraft:glass_pane
fill ~15 ~2 ~10 ~15 ~3 ~11 minecraft:glass_pane
setblock ~13 ~1 ~10 minecraft:white_bed[part=foot,facing=west]
setblock ~12 ~1 ~10 minecraft:white_bed[part=head,facing=west]
setblock ~14 ~1 ~12 minecraft:cartography_table
fill ~7 ~5 ~6 ~16 ~5 ~6 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~7 ~5 ~15 ~16 ~5 ~15 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~8 ~6 ~7 ~15 ~6 ~7 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~8 ~6 ~14 ~15 ~6 ~14 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~9 ~7 ~8 ~14 ~7 ~8 minecraft:spruce_stairs[facing=south,half=bottom]
fill ~9 ~7 ~13 ~14 ~7 ~13 minecraft:spruce_stairs[facing=north,half=bottom]
fill ~10 ~7 ~9 ~13 ~7 ~12 minecraft:spruce_planks
# Well
fill ~8 ~0 ~-13 ~12 ~0 ~-9 minecraft:cobblestone
fill ~8 ~1 ~-13 ~12 ~1 ~-9 minecraft:cobblestone hollow
fill ~9 ~1 ~-12 ~11 ~1 ~-10 minecraft:water
fill ~8 ~2 ~-13 ~8 ~3 ~-13 minecraft:spruce_fence
fill ~12 ~2 ~-13 ~12 ~3 ~-13 minecraft:spruce_fence
fill ~8 ~2 ~-9 ~8 ~3 ~-9 minecraft:spruce_fence
fill ~12 ~2 ~-9 ~12 ~3 ~-9 minecraft:spruce_fence
fill ~7 ~4 ~-14 ~13 ~4 ~-8 minecraft:spruce_slab[type=bottom]
setblock ~13 ~1 ~-6 minecraft:bell[attachment=floor,facing=north,powered=false]
summon minecraft:villager ~-11 ~1 ~-10 {Tags:["hs_villager"],PersistenceRequired:1b}
summon minecraft:villager ~12 ~1 ~10 {Tags:["hs_villager"],PersistenceRequired:1b}
summon minecraft:villager ~7 ~1 ~-6 {Tags:["hs_villager"],PersistenceRequired:1b}
tellraw @a[tag=hs_player,distance=..40] [{"text":"VILLAGE // ","color":"yellow","bold":true},{"text":"SNOWY","color":"aqua"}]

# v0.3.3 roof completion: close gable ends under the existing stepped roof.
fill ~-15 ~5 ~-14 ~-15 ~5 ~-7 minecraft:spruce_planks
fill ~-8 ~5 ~-14 ~-8 ~5 ~-7 minecraft:spruce_planks
fill ~-15 ~6 ~-13 ~-15 ~6 ~-8 minecraft:spruce_planks
fill ~-8 ~6 ~-13 ~-8 ~6 ~-8 minecraft:spruce_planks
fill ~-15 ~7 ~-12 ~-15 ~7 ~-9 minecraft:spruce_planks
fill ~-8 ~7 ~-12 ~-8 ~7 ~-9 minecraft:spruce_planks
fill ~8 ~5 ~8 ~8 ~5 ~13 minecraft:spruce_planks
fill ~15 ~5 ~8 ~15 ~5 ~13 minecraft:spruce_planks
fill ~8 ~6 ~9 ~8 ~6 ~12 minecraft:spruce_planks
fill ~15 ~6 ~9 ~15 ~6 ~12 minecraft:spruce_planks
fill ~8 ~7 ~10 ~8 ~7 ~11 minecraft:spruce_planks
fill ~15 ~7 ~10 ~15 ~7 ~11 minecraft:spruce_planks
