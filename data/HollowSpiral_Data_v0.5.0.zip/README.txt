HOLLOW SPIRAL v0.4.2

Endless survival room-grid experience for DAI 1.9.9 / Minecraft 26.2.

DAI 1.9.9 INTEGRATION
- Declares Hollow Spiral explicitly as the MAIN DAI experience.
- Adds stable managed datapack metadata: id hollow_spire, version 0.4.1.
- New expeditions use DAI high-level world_type = void generation.
- The Hollow Spiral companion resource pack is auto-managed through the legacy internal compatibility key hollow_spire.
- New expedition save identity is corrected to The Hollow Spiral.
- Existing marked Hollow Spiral saves remain discoverable because DAI 1.9.9 recognizes the experience marker independently of the corrected save_id.

NAMING / COMPATIBILITY
- Player-facing branding is Hollow Spiral everywhere.
- The internal namespace data/hollow_spire is intentionally retained so existing worlds, functions and resource references do not break.
- The internal companion key hollow_spire is intentionally retained so older installed resource-pack versions can be replaced rather than selected alongside the new pack.

GAMEPLAY RETAINED
This revision preserves the existing vertical stair fixes, Ocean pressure-shell protection, structural Coral Grotto, Castle defender rolls, stable Fungal Bogs, Smithery containment, structural Flooded Ruins, floor-is-lava Volcano traversal, Tiny Villages and siege-damaged masonry Ruins.

Hollow Spiral intentionally remains in VANILLA MOB MODE. Room encounters use ordinary minecraft:* entities; DAI native custom entities are not forced into this experience.

Use with Hollow Spiral v0.4.2 DAI 1.9.9 Resource Pack.
