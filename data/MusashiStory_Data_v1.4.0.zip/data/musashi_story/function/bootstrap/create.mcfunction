
scoreboard objectives add ms_init dummy
scoreboard objectives add ms_loadout dummy
scoreboard objectives add ms_resolve dummy
scoreboard objectives add ms_honor dummy
scoreboard objectives add ms_rank dummy
scoreboard objectives add ms_lastwp dummy
scoreboard objectives add ms_wp_e dummy
scoreboard objectives add ms_wp_w dummy
scoreboard objectives add ms_wp_n dummy
scoreboard objectives add ms_wp_s dummy
scoreboard objectives add ms_wp_ne dummy
scoreboard objectives add ms_wp_nw dummy
scoreboard objectives add ms_wp_se dummy
scoreboard objectives add ms_bounty dummy
scoreboard objectives add ms_bprog dummy
scoreboard objectives add ms_tick dummy
scoreboard objectives add ms_anim dummy
scoreboard objectives add ms_world dummy
scoreboard players set #tick ms_world 0
scoreboard players set #anim ms_world 0
scoreboard players set #built ms_world 0
scoreboard players set #gen_active ms_world 0
scoreboard players set #build_step ms_world 0
scoreboard players set #dispatch ms_world 0
scoreboard players set #ui_clock ms_world 0
scoreboard players set #100 ms_world 100
bossbar add musashi_story:loading {"text":"Raising Musashi Province","color":"red","bold":true}
bossbar set musashi_story:loading color red
bossbar set musashi_story:loading style progress
bossbar set musashi_story:loading max 126
bossbar set musashi_story:loading value 0
bossbar set musashi_story:loading visible false
data modify storage musashi_story:runtime bootstrap set value 1b
scoreboard players set #gen_village ms_world 0
scoreboard players set #gen_outskirts ms_world 0
scoreboard players set #gen_e ms_world 0
scoreboard players set #gen_n ms_world 0
scoreboard players set #gen_w ms_world 0
scoreboard players set #gen_s ms_world 0
scoreboard players set #gen_se ms_world 0
scoreboard players set #gen_ne ms_world 0
scoreboard players set #gen_nw ms_world 0
scoreboard players set #gen_rice ms_world 0
scoreboard players set #gen_river ms_world 0
scoreboard players set #region_roll ms_world 0

scoreboard objectives add ms_blade_state dummy
scoreboard objectives add ms_blade_dir dummy
scoreboard objectives add ms_draw_yaw dummy
scoreboard objectives add ms_draw_pitch dummy
scoreboard objectives add ms_now_yaw dummy
scoreboard objectives add ms_now_pitch dummy
scoreboard objectives add ms_dyaw dummy
scoreboard objectives add ms_dpitch dummy
scoreboard objectives add ms_blade_pose dummy
scoreboard objectives add ms_blade_cd dummy
