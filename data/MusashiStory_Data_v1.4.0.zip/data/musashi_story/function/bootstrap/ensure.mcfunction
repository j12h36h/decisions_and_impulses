execute unless data storage musashi_story:runtime {bootstrap:1b} run function musashi_story:bootstrap/create
