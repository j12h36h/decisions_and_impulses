scoreboard players set @s ms_wp_ne 1
scoreboard players set @s ms_lastwp 6
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.8 1.1
title @s title {"text":"WAYPOINT DISCOVERED","color":"gold","bold":true}
title @s subtitle {"text":"MOUNTAIN TEMPLE","color":"red"}
