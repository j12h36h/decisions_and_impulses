scoreboard players set @s ms_wp_se 1
scoreboard players set @s ms_lastwp 5
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.8 1.1
title @s title {"text":"WAYPOINT DISCOVERED","color":"gold","bold":true}
title @s subtitle {"text":"MOON HARBOR COAST","color":"red"}
