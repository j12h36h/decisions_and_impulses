
execute positioned 330 81 -70 if entity @s[distance=..28] unless score @s ms_wp_e matches 1.. run function musashi_story:player/unlock_east
execute positioned 330 81 -70 if entity @s[distance=..34] run scoreboard players set @s ms_lastwp 1
execute positioned 0 72 -320 if entity @s[distance=..28] unless score @s ms_wp_n matches 1.. run function musashi_story:player/unlock_north
execute positioned 0 72 -320 if entity @s[distance=..34] run scoreboard players set @s ms_lastwp 2
execute positioned -320 69 0 if entity @s[distance=..28] unless score @s ms_wp_w matches 1.. run function musashi_story:player/unlock_west
execute positioned -320 69 0 if entity @s[distance=..34] run scoreboard players set @s ms_lastwp 3
execute positioned 0 82 340 if entity @s[distance=..28] unless score @s ms_wp_s matches 1.. run function musashi_story:player/unlock_south
execute positioned 0 82 340 if entity @s[distance=..34] run scoreboard players set @s ms_lastwp 4
execute positioned 286 65 290 if entity @s[distance=..28] unless score @s ms_wp_se matches 1.. run function musashi_story:player/unlock_se
execute positioned 286 65 290 if entity @s[distance=..34] run scoreboard players set @s ms_lastwp 5
execute positioned 350 112 -350 if entity @s[distance=..28] unless score @s ms_wp_ne matches 1.. run function musashi_story:player/unlock_ne
execute positioned 350 112 -350 if entity @s[distance=..34] run scoreboard players set @s ms_lastwp 6
execute positioned -340 69 -320 if entity @s[distance=..28] unless score @s ms_wp_nw matches 1.. run function musashi_story:player/unlock_nw
execute positioned -340 69 -320 if entity @s[distance=..34] run scoreboard players set @s ms_lastwp 7
execute if score @s ms_honor matches 0..49 run scoreboard players set @s ms_rank 0
execute if score @s ms_honor matches 50..149 run scoreboard players set @s ms_rank 1
execute if score @s ms_honor matches 150..349 run scoreboard players set @s ms_rank 2
execute if score @s ms_honor matches 350.. run scoreboard players set @s ms_rank 3
