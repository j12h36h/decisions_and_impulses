
tag @s add ms_player
scoreboard players set @s ms_init 1
scoreboard players set @s ms_loadout 1
scoreboard players set @s ms_resolve 100
scoreboard players set @s ms_honor 0
scoreboard players set @s ms_rank 0
scoreboard players set @s ms_lastwp 0
scoreboard players set @s ms_wp_e 0
scoreboard players set @s ms_wp_w 0
scoreboard players set @s ms_wp_n 0
scoreboard players set @s ms_wp_s 0
scoreboard players set @s ms_wp_ne 0
scoreboard players set @s ms_wp_nw 0
scoreboard players set @s ms_wp_se 0
scoreboard players set @s ms_bounty 0
scoreboard players set @s ms_bprog 0
function musashi_story:worldgen/spawn_safety
gamemode adventure @s
teleport @s 0.5 66 0.5 180 0
spawnpoint @s 0 66 0
function musashi_story:loadout/duelist
title @s title {"text":"MUSASHI STORY","color":"red","bold":true}
title @s subtitle {"text":"One province. Many roads. Choose what your blade becomes.","color":"gold"}
