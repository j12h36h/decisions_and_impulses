# Recover to the last physically discovered waypoint; default to the village.
effect give @s minecraft:resistance 4 4 true
effect give @s minecraft:regeneration 3 2 true
execute if score @s ms_lastwp matches 1 run teleport @s 330.5 81 -70.5
execute if score @s ms_lastwp matches 2 run teleport @s 0.5 72 -320.5
execute if score @s ms_lastwp matches 3 run teleport @s -320.5 69 0.5
execute if score @s ms_lastwp matches 4 run teleport @s 0.5 82 340.5
execute if score @s ms_lastwp matches 5 run teleport @s 286.5 65 290.5
execute if score @s ms_lastwp matches 6 run teleport @s 350.5 112 -350.5
execute if score @s ms_lastwp matches 7 run teleport @s -340.5 69 -320.5
execute unless score @s ms_lastwp matches 1..7 run teleport @s 0.5 66 0.5
execute if score @s ms_lastwp matches 1 run spawnpoint @s 330 81 -70
execute if score @s ms_lastwp matches 2 run spawnpoint @s 0 72 -320
execute if score @s ms_lastwp matches 3 run spawnpoint @s -320 69 0
execute if score @s ms_lastwp matches 4 run spawnpoint @s 0 82 340
execute if score @s ms_lastwp matches 5 run spawnpoint @s 286 65 290
execute if score @s ms_lastwp matches 6 run spawnpoint @s 350 112 -350
execute if score @s ms_lastwp matches 7 run spawnpoint @s -340 69 -320
execute unless score @s ms_lastwp matches 1..7 run spawnpoint @s 0 66 0
title @s actionbar {"text":"WAYFARER RECOVERY // returned to last discovered road","color":"gold"}
