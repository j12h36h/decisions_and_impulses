scoreboard players add @s ms_honor 45
scoreboard players set @s ms_bounty 0
scoreboard players set @s ms_bprog 0
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
title @s title {"text":"BOUNTY COMPLETE","color":"gold","bold":true}
title @s subtitle {"text":"+45 Honor","color":"red"}
