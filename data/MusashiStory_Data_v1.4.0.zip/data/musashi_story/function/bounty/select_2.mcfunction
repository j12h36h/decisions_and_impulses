scoreboard players set @s ms_bounty 2
scoreboard players set @s ms_bprog 0
tellraw @s [{"text":"[BOUNTY] ","color":"gold","bold":true},{"text":"MASKS ON THE MOUNTAIN — Defeat 3 Ronin/Tengu enemies","color":"white"}]
