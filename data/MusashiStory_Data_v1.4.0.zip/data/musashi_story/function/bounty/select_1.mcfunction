scoreboard players set @s ms_bounty 1
scoreboard players set @s ms_bprog 0
tellraw @s [{"text":"[BOUNTY] ","color":"gold","bold":true},{"text":"WESTERN BANDIT PURGE — Defeat 5 Ashigaru/Bandit enemies","color":"white"}]
