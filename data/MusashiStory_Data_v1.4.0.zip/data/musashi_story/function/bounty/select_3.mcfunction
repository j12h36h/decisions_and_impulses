scoreboard players set @s ms_bounty 3
scoreboard players set @s ms_bprog 0
tellraw @s [{"text":"[BOUNTY] ","color":"gold","bold":true},{"text":"WARDEN OF THE FALLEN SHRINE — Defeat the Shrine Warden","color":"white"}]
