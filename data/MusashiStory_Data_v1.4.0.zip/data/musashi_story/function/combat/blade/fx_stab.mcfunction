# Client overlay action id: musashi_story:fx_blade_stab
particle minecraft:sweep_attack ^ ^1 ^2 0.25 0.15 0.25 0 3 force @s
