item modify entity @s weapon.mainhand musashi_story:blade_pose/right
