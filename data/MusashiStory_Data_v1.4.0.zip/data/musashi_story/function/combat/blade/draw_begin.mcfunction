# Begin a blade draw. DAI bridge calls this once on LMB down for Musashi blade weapons.
scoreboard players set @s ms_blade_state 1
scoreboard players set @s ms_blade_dir 0
scoreboard players set @s ms_blade_pose 0
execute store result score @s ms_draw_yaw run data get entity @s Rotation[0] 10
execute store result score @s ms_draw_pitch run data get entity @s Rotation[1] 10
playsound minecraft:item.armor.equip_chain player @s ~ ~ ~ 0.18 1.75
