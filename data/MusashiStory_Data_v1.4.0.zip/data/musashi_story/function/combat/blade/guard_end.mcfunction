execute if score @s ms_blade_state matches 2 run scoreboard players set @s ms_blade_state 0
