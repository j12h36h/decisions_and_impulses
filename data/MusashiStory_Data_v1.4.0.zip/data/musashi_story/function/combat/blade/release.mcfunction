# LMB release. No meaningful camera displacement becomes a forward thrust.
execute if score @s ms_blade_state matches 1 run function musashi_story:combat/blade/draw_tick
execute if score @s ms_blade_dir matches 0 run scoreboard players set @s ms_blade_dir 9
execute if score @s ms_blade_dir matches 1 run function musashi_story:combat/blade/slash/up
execute if score @s ms_blade_dir matches 2 run function musashi_story:combat/blade/slash/up_right
execute if score @s ms_blade_dir matches 3 run function musashi_story:combat/blade/slash/right
execute if score @s ms_blade_dir matches 4 run function musashi_story:combat/blade/slash/down_right
execute if score @s ms_blade_dir matches 5 run function musashi_story:combat/blade/slash/down
execute if score @s ms_blade_dir matches 6 run function musashi_story:combat/blade/slash/down_left
execute if score @s ms_blade_dir matches 7 run function musashi_story:combat/blade/slash/left
execute if score @s ms_blade_dir matches 8 run function musashi_story:combat/blade/slash/up_left
execute if score @s ms_blade_dir matches 9 run function musashi_story:combat/blade/slash/stab
scoreboard players set @s ms_blade_state 3
scoreboard players set @s ms_blade_cd 4
schedule function musashi_story:combat/blade/recover 4t append
