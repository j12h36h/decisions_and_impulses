scoreboard players set @s ms_blade_state 2
scoreboard players set @s ms_blade_dir 0
# Visual half-draw guard is selected client-side by key.use; bridge can suppress normal item use.
playsound minecraft:item.armor.equip_chain player @s ~ ~ ~ 0.12 1.35
