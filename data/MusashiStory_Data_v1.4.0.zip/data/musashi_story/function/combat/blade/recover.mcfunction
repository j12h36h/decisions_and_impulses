# Clear directional pose; keep the weapon ready for the next draw.
execute as @a[scores={ms_blade_state=3}] run function musashi_story:combat/blade/pose_clear
scoreboard players set @a[scores={ms_blade_state=3}] ms_blade_state 0
scoreboard players set @a[scores={ms_blade_state=3}] ms_blade_dir 0
