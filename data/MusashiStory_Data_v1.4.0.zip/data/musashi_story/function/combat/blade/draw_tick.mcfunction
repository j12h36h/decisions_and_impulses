# Called while LMB remains down. Camera displacement from the draw-origin chooses the screen-space cut.
execute store result score @s ms_now_yaw run data get entity @s Rotation[0] 10
execute store result score @s ms_now_pitch run data get entity @s Rotation[1] 10
scoreboard players operation @s ms_dyaw = @s ms_now_yaw
scoreboard players operation @s ms_dyaw -= @s ms_draw_yaw
scoreboard players operation @s ms_dpitch = @s ms_now_pitch
scoreboard players operation @s ms_dpitch -= @s ms_draw_pitch
# Normalize yaw delta around the +/-180-degree wrap.
execute if score @s ms_dyaw matches 1801.. run scoreboard players remove @s ms_dyaw 3600
execute if score @s ms_dyaw matches ..-1801 run scoreboard players add @s ms_dyaw 3600
scoreboard players set @s ms_blade_dir 0
# Cardinal directions: threshold ~5 degrees. Positive pitch means looking down.
execute if score @s ms_dyaw matches -49..49 if score @s ms_dpitch matches ..-50 run scoreboard players set @s ms_blade_dir 1
execute if score @s ms_dyaw matches 50.. if score @s ms_dpitch matches ..-50 run scoreboard players set @s ms_blade_dir 2
execute if score @s ms_dyaw matches 50.. if score @s ms_dpitch matches -49..49 run scoreboard players set @s ms_blade_dir 3
execute if score @s ms_dyaw matches 50.. if score @s ms_dpitch matches 50.. run scoreboard players set @s ms_blade_dir 4
execute if score @s ms_dyaw matches -49..49 if score @s ms_dpitch matches 50.. run scoreboard players set @s ms_blade_dir 5
execute if score @s ms_dyaw matches ..-50 if score @s ms_dpitch matches 50.. run scoreboard players set @s ms_blade_dir 6
execute if score @s ms_dyaw matches ..-50 if score @s ms_dpitch matches -49..49 run scoreboard players set @s ms_blade_dir 7
execute if score @s ms_dyaw matches ..-50 if score @s ms_dpitch matches ..-50 run scoreboard players set @s ms_blade_dir 8
