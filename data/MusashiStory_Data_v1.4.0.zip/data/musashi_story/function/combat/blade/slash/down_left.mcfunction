function musashi_story:combat/blade/pose_down_left
function musashi_story:combat/blade/fx_down_left
playsound minecraft:entity.player.attack.sweep player @s ~ ~ ~ 0.75 0.95
tag @s add ms_blade_attacker
execute anchored eyes positioned ^ ^-0.35 ^1.25 as @e[tag=ms_enemy,distance=..1.45,limit=5,sort=nearest] run damage @s 7 minecraft:player_attack by @a[tag=ms_blade_attacker,limit=1,sort=nearest]
execute anchored eyes positioned ^ ^-0.35 ^2.0 as @e[tag=ms_enemy,distance=..1.45,limit=5,sort=nearest] run damage @s 7 minecraft:player_attack by @a[tag=ms_blade_attacker,limit=1,sort=nearest]
execute anchored eyes positioned ^ ^-0.35 ^2.75 as @e[tag=ms_enemy,distance=..1.45,limit=5,sort=nearest] run damage @s 7 minecraft:player_attack by @a[tag=ms_blade_attacker,limit=1,sort=nearest]
execute anchored eyes positioned ^ ^-0.35 ^3.5 as @e[tag=ms_enemy,distance=..1.45,limit=5,sort=nearest] run damage @s 7 minecraft:player_attack by @a[tag=ms_blade_attacker,limit=1,sort=nearest]
tag @s remove ms_blade_attacker
