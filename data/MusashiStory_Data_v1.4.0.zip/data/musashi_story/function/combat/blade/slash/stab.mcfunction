function musashi_story:combat/blade/pose_stab
function musashi_story:combat/blade/fx_stab
playsound minecraft:entity.player.attack.strong player @s ~ ~ ~ 0.75 1.1
tag @s add ms_blade_attacker
execute anchored eyes positioned ^ ^-0.25 ^1.5 as @e[tag=ms_enemy,distance=..0.85,limit=3,sort=nearest] run damage @s 8 minecraft:player_attack by @a[tag=ms_blade_attacker,limit=1,sort=nearest]
execute anchored eyes positioned ^ ^-0.25 ^2.4 as @e[tag=ms_enemy,distance=..0.85,limit=3,sort=nearest] run damage @s 8 minecraft:player_attack by @a[tag=ms_blade_attacker,limit=1,sort=nearest]
execute anchored eyes positioned ^ ^-0.25 ^3.3 as @e[tag=ms_enemy,distance=..0.85,limit=3,sort=nearest] run damage @s 8 minecraft:player_attack by @a[tag=ms_blade_attacker,limit=1,sort=nearest]
execute anchored eyes positioned ^ ^-0.25 ^4.2 as @e[tag=ms_enemy,distance=..0.85,limit=3,sort=nearest] run damage @s 8 minecraft:player_attack by @a[tag=ms_blade_attacker,limit=1,sort=nearest]
tag @s remove ms_blade_attacker
