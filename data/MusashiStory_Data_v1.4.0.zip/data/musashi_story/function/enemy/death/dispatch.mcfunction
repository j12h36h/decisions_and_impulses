# Musashi Story v1.3.1 — local death reward dispatch.
execute if entity @s[type=musashi_story:ashigaru_raider] run function musashi_story:enemy/death/ashigaru_raider
execute if entity @s[type=musashi_story:bandit_swordsman] run function musashi_story:enemy/death/bandit_swordsman
execute if entity @s[type=musashi_story:castle_samurai] run function musashi_story:enemy/death/castle_samurai
execute if entity @s[type=musashi_story:oni_brute] run function musashi_story:enemy/death/oni_brute
execute if entity @s[type=musashi_story:shrine_warden] run function musashi_story:enemy/death/shrine_warden
execute if entity @s[type=musashi_story:tengu_duelist] run function musashi_story:enemy/death/tengu_duelist
execute if entity @s[type=musashi_story:wandering_ronin] run function musashi_story:enemy/death/wandering_ronin
execute if entity @s[type=musashi_story:yari_guard] run function musashi_story:enemy/death/yari_guard
