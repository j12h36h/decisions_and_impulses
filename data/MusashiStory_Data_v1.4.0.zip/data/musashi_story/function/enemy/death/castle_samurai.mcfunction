# Musashi Story v1.4.0 — DAI 3.3 native entity death-event reward dispatch.
# DAI tags the direct player killer with dai_entity_killer_context while this hook executes.
execute as @a[tag=ms_player,tag=dai_entity_killer_context,limit=1] run function musashi_story:progress/kill_castle_samurai
# Preserve the historical nearest-player behavior for non-player/environmental deaths.
execute unless entity @a[tag=ms_player,tag=dai_entity_killer_context,limit=1] as @a[tag=ms_player,distance=..18,sort=nearest,limit=1] run function musashi_story:progress/kill_castle_samurai
