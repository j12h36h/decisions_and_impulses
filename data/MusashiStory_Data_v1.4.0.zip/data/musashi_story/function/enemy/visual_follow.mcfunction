# Musashi Story v1.4.0 — 5 TPS articulated following with four-tick display teleport interpolation.
execute as @e[tag=ms_spawn_e1,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_e1,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_e2,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_e2,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_e3,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_e3,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_n1,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_n1,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_n2,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_n2,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_w1,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_w1,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_w2,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_w2,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_w3,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_w3,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_s1,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_s1,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_s2,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_s2,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_s3,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_s3,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_nw1,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_nw1,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_nw2,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_nw2,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_se1,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_se1,tag=ms_visual] ~ ~ ~ ~ 0
execute as @e[tag=ms_spawn_ne1,tag=ms_enemy,limit=1] at @s rotated as @s run teleport @e[tag=ms_vis_ne1,tag=ms_visual] ~ ~ ~ ~ 0
