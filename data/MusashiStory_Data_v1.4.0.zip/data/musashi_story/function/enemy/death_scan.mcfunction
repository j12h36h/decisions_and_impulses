# Musashi Story v1.3.1 — one global death selector; type dispatch only runs for a dying enemy.
execute as @e[tag=ms_enemy,tag=!ms_death_seen,nbt={DeathTime:1s}] at @s run function musashi_story:enemy/death/dispatch
