# Musashi Story v1.3.1 — edge-triggered articulated animation.
# Item-display interpolation persists between keyframes; do not resend the same transformation every tick.
execute if score #anim ms_world matches 0 run function musashi_story:enemy/pose_a
execute if score #anim ms_world matches 10 run function musashi_story:enemy/pose_b
