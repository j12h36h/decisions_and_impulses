# Musashi Story v1.4.0 — 1 TPS fallback safety; native DAI fire immunity and no-loot-pickup remain authoritative.
execute as @e[tag=ms_enemy] run data merge entity @s {Fire:-20s}
item replace entity @e[tag=ms_enemy] weapon.mainhand with minecraft:air
item replace entity @e[tag=ms_enemy] weapon.offhand with minecraft:air
