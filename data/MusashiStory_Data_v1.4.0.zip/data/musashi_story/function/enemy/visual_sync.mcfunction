# Legacy compatibility wrapper. Normal v1.3 runtime uses staggered visual cadences.
function musashi_story:enemy/visual_ensure
function musashi_story:enemy/visual_follow
function musashi_story:enemy/visual_cleanup
