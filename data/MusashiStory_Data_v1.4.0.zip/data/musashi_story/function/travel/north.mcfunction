execute unless score @s ms_wp_n matches 1.. run tellraw @s [{"text":"[WAYFARER] ","color":"gold","bold":true},{"text":"This shrine has not been discovered yet.","color":"gray"}]
execute if score @s ms_wp_n matches 1.. run teleport @s 0.5 72 -320.5
