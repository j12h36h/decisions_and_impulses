tellraw @s [{"text":"[WAYFARER] ","color":"gold","bold":true},{"text":"Travel network opened through the DAI action menu.","color":"gray"}]
