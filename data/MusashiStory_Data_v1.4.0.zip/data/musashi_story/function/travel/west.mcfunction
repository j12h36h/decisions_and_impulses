execute unless score @s ms_wp_w matches 1.. run tellraw @s [{"text":"[WAYFARER] ","color":"gold","bold":true},{"text":"This shrine has not been discovered yet.","color":"gray"}]
execute if score @s ms_wp_w matches 1.. run teleport @s -320.5 69 0.5
