execute unless score @s ms_wp_nw matches 1.. run tellraw @s [{"text":"[WAYFARER] ","color":"gold","bold":true},{"text":"This shrine has not been discovered yet.","color":"gray"}]
execute if score @s ms_wp_nw matches 1.. run teleport @s -340.5 69 -320.5
