fill ~-6 ~-4 ~-4 ~6 ~-1 ~4 minecraft:stone
fill ~-4 ~ ~-3 ~4 ~2 ~3 minecraft:andesite
fill ~-2 ~3 ~-2 ~3 ~4 ~2 minecraft:stone
setblock ~-3 ~3 ~ minecraft:mossy_cobblestone
setblock ~2 ~5 ~ minecraft:andesite
