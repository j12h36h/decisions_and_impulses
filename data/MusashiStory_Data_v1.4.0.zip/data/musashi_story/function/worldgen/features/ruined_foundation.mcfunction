fill ~-7 ~-1 ~-5 ~7 ~-1 ~5 minecraft:mossy_stone_bricks
fill ~-6 ~ ~-4 ~6 ~ ~4 minecraft:air
fill ~-7 ~ ~-5 ~-3 ~2 ~-5 minecraft:stone_bricks
fill ~2 ~ ~-5 ~7 ~3 ~-5 minecraft:cracked_stone_bricks
fill ~-7 ~ ~5 ~-1 ~1 ~5 minecraft:mossy_stone_bricks
fill ~4 ~ ~5 ~7 ~2 ~5 minecraft:stone_bricks
fill ~-7 ~ ~-4 ~-7 ~2 ~1 minecraft:cracked_stone_bricks
fill ~7 ~ ~-1 ~7 ~3 ~4 minecraft:mossy_stone_bricks
setblock ~-5 ~1 ~-5 minecraft:stone_brick_stairs[facing=east]
setblock ~5 ~1 ~5 minecraft:mossy_stone_brick_stairs[facing=west]
setblock ~-2 ~ ~2 minecraft:moss_carpet
setblock ~3 ~ ~-2 minecraft:moss_carpet
setblock ~4 ~ ~1 minecraft:fern
setblock ~-4 ~ ~-1 minecraft:short_grass
