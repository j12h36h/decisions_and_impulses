fill ~-8 ~-5 ~-8 ~8 ~5 ~8 minecraft:stone
fill ~-6 ~-3 ~-6 ~6 ~3 ~6 minecraft:air
fill ~-2 ~-3 ~7 ~2 ~1 ~12 minecraft:air
fill ~-5 ~-3 ~-5 ~5 ~-3 ~5 minecraft:mossy_cobblestone
fill ~-4 ~-2 ~-4 ~4 ~-2 ~4 minecraft:stone_bricks
setblock ~ ~-1 ~ minecraft:chiseled_stone_bricks
setblock ~ ~ ~ minecraft:soul_lantern
setblock ~-4 ~-1 ~-4 minecraft:candle[candles=4,lit=true]
setblock ~4 ~-1 ~-4 minecraft:candle[candles=4,lit=true]
setblock ~-4 ~-1 ~4 minecraft:candle[candles=4,lit=true]
setblock ~4 ~-1 ~4 minecraft:candle[candles=4,lit=true]
setblock ~-5 ~-2 ~ minecraft:moss_block
setblock ~5 ~-2 ~ minecraft:moss_block
