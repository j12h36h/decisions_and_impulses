# Slightly arched timber bridge with stone abutments and lantern rails.
fill ~-8 ~-2 ~-3 ~-6 ~-1 ~3 minecraft:stone_bricks
fill ~6 ~-2 ~-3 ~8 ~-1 ~3 minecraft:stone_bricks
fill ~-7 ~-1 ~-2 ~7 ~-1 ~2 minecraft:dark_oak_planks
fill ~-5 ~ ~-2 ~5 ~ ~2 minecraft:cherry_planks
fill ~-3 ~1 ~-2 ~3 ~1 ~2 minecraft:cherry_slab[type=bottom]
fill ~-7 ~ ~-3 ~7 ~ ~-3 minecraft:dark_oak_fence
fill ~-7 ~ ~3 ~7 ~ ~3 minecraft:dark_oak_fence
setblock ~-7 ~1 ~-3 minecraft:lantern
setblock ~ ~2 ~-3 minecraft:lantern
setblock ~7 ~1 ~-3 minecraft:lantern
setblock ~-7 ~1 ~3 minecraft:lantern
setblock ~ ~2 ~3 minecraft:lantern
setblock ~7 ~1 ~3 minecraft:lantern
