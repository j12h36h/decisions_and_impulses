fill ~-13 ~-14 ~-10 ~13 ~-1 ~10 minecraft:stone
fill ~-14 ~-6 ~-11 ~14 ~-1 ~11 minecraft:dirt
fill ~-16 ~-3 ~-12 ~16 ~-1 ~12 minecraft:dirt
fill ~-17 ~-1 ~-10 ~17 ~-1 ~10 minecraft:grass_block
fill ~-13 ~-1 ~-13 ~13 ~-1 ~13 minecraft:grass_block
