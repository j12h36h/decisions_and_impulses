fill ~-5 ~-1 ~-5 ~5 ~-1 ~5 minecraft:podzol replace minecraft:grass_block
setblock ~-4 ~ ~-2 minecraft:fern
setblock ~-2 ~ ~3 minecraft:short_grass
setblock ~1 ~ ~4 minecraft:fern
setblock ~4 ~ ~1 minecraft:brown_mushroom
setblock ~3 ~ ~-3 minecraft:red_mushroom
setblock ~-4 ~ ~4 minecraft:moss_carpet
setblock ~ ~ ~-4 minecraft:moss_carpet
