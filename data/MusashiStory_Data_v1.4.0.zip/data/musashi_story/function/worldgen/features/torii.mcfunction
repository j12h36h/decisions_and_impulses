fill ~-5 ~-1 ~-1 ~-3 ~-1 ~1 minecraft:stone_bricks
fill ~3 ~-1 ~-1 ~5 ~-1 ~1 minecraft:stone_bricks
fill ~-4 ~ ~ ~-4 ~6 ~ minecraft:stripped_cherry_log
fill ~4 ~ ~ ~4 ~6 ~ minecraft:stripped_cherry_log
fill ~-5 ~5 ~ ~5 ~5 ~ minecraft:red_concrete
fill ~-6 ~6 ~ ~6 ~6 ~ minecraft:red_concrete
fill ~-5 ~7 ~ ~5 ~7 ~ minecraft:polished_blackstone
setblock ~-6 ~7 ~ minecraft:polished_blackstone_stairs[facing=east]
setblock ~6 ~7 ~ minecraft:polished_blackstone_stairs[facing=west]
fill ~-3 ~4 ~ ~3 ~4 ~ minecraft:stripped_cherry_log[axis=x]
execute positioned ~-6 ~ ~2 run function musashi_story:worldgen/features/stone_lantern
execute positioned ~6 ~ ~2 run function musashi_story:worldgen/features/stone_lantern
