# small roadside story clutter
setblock ~ ~ ~ minecraft:barrel
setblock ~1 ~ ~ minecraft:barrel
setblock ~-1 ~ ~1 minecraft:hay_block
setblock ~2 ~ ~1 minecraft:oak_fence
setblock ~2 ~1 ~1 minecraft:lantern
setblock ~-2 ~ ~-1 minecraft:flower_pot
setblock ~-3 ~ ~ minecraft:cobblestone_wall
