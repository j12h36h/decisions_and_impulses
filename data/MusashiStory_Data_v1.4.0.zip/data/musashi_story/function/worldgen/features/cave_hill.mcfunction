# Build a grounded hill first, then carve a cavern into its face.
function musashi_story:worldgen/features/terrain_hill_large
fill ~-6 ~-1 ~-15 ~6 ~5 ~4 minecraft:stone
fill ~-4 ~ ~-17 ~4 ~4 ~0 minecraft:air
fill ~-5 ~-1 ~-18 ~5 ~-1 ~2 minecraft:stone
fill ~-2 ~-1 ~-18 ~2 ~-1 ~-4 minecraft:gravel
setblock ~-3 ~1 ~-8 minecraft:lantern
setblock ~3 ~1 ~-8 minecraft:lantern
