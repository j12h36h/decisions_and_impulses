# Cherry B — leaning trunk with low sweeping crown.
fill ~ ~ ~ ~ ~3 ~ minecraft:cherry_log[axis=y]
fill ~ ~3 ~ ~2 ~4 ~ minecraft:cherry_log[axis=x]
fill ~2 ~4 ~ ~2 ~7 ~ minecraft:cherry_log[axis=y]
fill ~2 ~5 ~ ~6 ~5 ~ minecraft:cherry_log[axis=x]
fill ~-1 ~4 ~ ~-5 ~4 ~ minecraft:cherry_log[axis=x]
fill ~2 ~6 ~ ~2 ~6 ~4 minecraft:cherry_log[axis=z]
fill ~-6 ~3 ~-3 ~-1 ~6 ~2 minecraft:cherry_leaves[persistent=true]
fill ~-2 ~4 ~-4 ~3 ~7 ~2 minecraft:cherry_leaves[persistent=true]
fill ~2 ~4 ~-3 ~7 ~7 ~2 minecraft:cherry_leaves[persistent=true]
fill ~0 ~5 ~1 ~5 ~8 ~6 minecraft:cherry_leaves[persistent=true]
fill ~-5 ~5 ~2 ~-2 ~7 ~5 minecraft:cherry_leaves[persistent=true]
fill ~6 ~6 ~1 ~7 ~7 ~2 minecraft:air replace minecraft:cherry_leaves
fill ~-6 ~4 ~-3 ~-5 ~5 ~-2 minecraft:air replace minecraft:cherry_leaves
setblock ~-5 ~ ~2 minecraft:pink_petals[flower_amount=3]
setblock ~-2 ~ ~5 minecraft:pink_petals[flower_amount=4]
setblock ~4 ~ ~4 minecraft:pink_petals[flower_amount=2]
setblock ~6 ~ ~-2 minecraft:pink_petals[flower_amount=4]
