fill ~-7 ~-1 ~-7 ~7 ~-1 ~7 minecraft:moss_block replace minecraft:grass_block
fill ~-2 ~ ~-1 ~-2 ~5 ~-1 minecraft:mushroom_stem
fill ~-5 ~5 ~-4 ~1 ~5 ~2 minecraft:red_mushroom_block
fill ~-4 ~6 ~-3 ~0 ~6 ~1 minecraft:red_mushroom_block
fill ~4 ~ ~3 ~4 ~3 ~3 minecraft:mushroom_stem
fill ~2 ~3 ~1 ~6 ~3 ~5 minecraft:brown_mushroom_block
fill ~3 ~4 ~2 ~5 ~4 ~4 minecraft:brown_mushroom_block
setblock ~-6 ~ ~5 minecraft:red_mushroom
setblock ~-4 ~ ~4 minecraft:brown_mushroom
setblock ~-1 ~ ~6 minecraft:red_mushroom
setblock ~2 ~ ~-5 minecraft:brown_mushroom
setblock ~6 ~ ~-2 minecraft:red_mushroom
setblock ~5 ~ ~6 minecraft:azalea
setblock ~-6 ~ ~-4 minecraft:flowering_azalea
setblock ~1 ~ ~2 minecraft:moss_carpet
setblock ~-3 ~ ~-5 minecraft:moss_carpet
