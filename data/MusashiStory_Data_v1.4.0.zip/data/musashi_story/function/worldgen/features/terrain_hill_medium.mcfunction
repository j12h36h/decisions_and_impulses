# Grounded medium hill: broad 1-block contour steps, no floating shelf.
fill ~-16 ~-6 ~-7 ~16 ~-1 ~7 minecraft:dirt
fill ~-12 ~-6 ~-12 ~12 ~-1 ~12 minecraft:dirt
fill ~-15 ~ ~-6 ~15 ~ ~6 minecraft:grass_block
fill ~-11 ~ ~-11 ~11 ~ ~11 minecraft:grass_block
fill ~-12 ~-5 ~-5 ~12 ~1 ~5 minecraft:dirt
fill ~-9 ~-5 ~-9 ~9 ~1 ~9 minecraft:dirt
fill ~-11 ~2 ~-4 ~11 ~2 ~4 minecraft:grass_block
fill ~-8 ~2 ~-8 ~8 ~2 ~8 minecraft:grass_block
fill ~-8 ~-3 ~-3 ~8 ~3 ~3 minecraft:dirt
fill ~-5 ~-3 ~-6 ~5 ~3 ~6 minecraft:dirt
fill ~-7 ~4 ~-2 ~7 ~4 ~2 minecraft:grass_block
fill ~-4 ~4 ~-5 ~4 ~4 ~5 minecraft:grass_block
fill ~-3 ~-2 ~-2 ~3 ~5 ~2 minecraft:dirt
fill ~-2 ~5 ~-1 ~2 ~5 ~1 minecraft:grass_block
