# Tall cedar/pine silhouette with tapered irregular boughs.
fill ~ ~ ~ ~ ~12 ~ minecraft:spruce_log[axis=y]
fill ~ ~4 ~ ~3 ~4 ~ minecraft:spruce_log[axis=x]
fill ~-3 ~6 ~ ~ ~6 ~ minecraft:spruce_log[axis=x]
fill ~ ~7 ~ ~ ~7 ~3 minecraft:spruce_log[axis=z]
fill ~ ~9 ~-2 ~ ~9 ~ minecraft:spruce_log[axis=z]
fill ~-5 ~3 ~-4 ~5 ~4 ~4 minecraft:spruce_leaves[persistent=true]
fill ~-4 ~5 ~-4 ~4 ~6 ~4 minecraft:spruce_leaves[persistent=true]
fill ~-3 ~7 ~-3 ~3 ~8 ~3 minecraft:spruce_leaves[persistent=true]
fill ~-2 ~9 ~-2 ~2 ~10 ~2 minecraft:spruce_leaves[persistent=true]
fill ~-1 ~11 ~-1 ~1 ~13 ~1 minecraft:spruce_leaves[persistent=true]
# open up branch gaps
fill ~-5 ~4 ~-4 ~-4 ~4 ~-3 minecraft:air replace minecraft:spruce_leaves
fill ~4 ~6 ~3 ~5 ~6 ~4 minecraft:air replace minecraft:spruce_leaves
setblock ~2 ~ ~2 minecraft:podzol
setblock ~-2 ~ ~-2 minecraft:podzol
setblock ~3 ~ ~-1 minecraft:moss_carpet
setblock ~-3 ~ ~1 minecraft:moss_carpet
setblock ~4 ~ ~2 minecraft:fern
setblock ~-4 ~ ~-2 minecraft:fern
