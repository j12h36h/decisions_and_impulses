# lived-in village garden / fence clutter
fill ~-4 ~-1 ~-3 ~4 ~-1 ~3 minecraft:dirt
fill ~-3 ~-1 ~-2 ~3 ~-1 ~2 minecraft:farmland[moisture=7]
fill ~-3 ~ ~-2 ~3 ~ ~-2 minecraft:wheat[age=7]
fill ~-3 ~ ~2 ~3 ~ ~2 minecraft:carrots[age=7]
fill ~-4 ~ ~-3 ~4 ~ ~-3 minecraft:oak_fence
fill ~-4 ~ ~3 ~4 ~ ~3 minecraft:oak_fence
setblock ~-4 ~ ~ minecraft:oak_fence_gate[facing=east,open=false]
setblock ~4 ~1 ~-3 minecraft:lantern
setblock ~-3 ~ ~ minecraft:barrel
