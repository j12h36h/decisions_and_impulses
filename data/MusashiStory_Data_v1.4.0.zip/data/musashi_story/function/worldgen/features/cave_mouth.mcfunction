# simple cave mouth dug into a slope
fill ~-5 ~-1 ~-2 ~5 ~4 ~8 minecraft:air
fill ~-6 ~-2 ~-3 ~6 ~-2 ~10 minecraft:stone
fill ~-7 ~-1 ~8 ~7 ~5 ~12 minecraft:stone
fill ~-3 ~-1 ~9 ~3 ~2 ~12 minecraft:air
setblock ~-2 ~0 ~8 minecraft:torch
setblock ~2 ~0 ~8 minecraft:torch
