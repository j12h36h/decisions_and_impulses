setblock ~ ~ ~ minecraft:coarse_dirt
setblock ~2 ~ ~1 minecraft:podzol
setblock ~-2 ~ ~2 minecraft:moss_block
setblock ~1 ~ ~-2 minecraft:gravel
setblock ~-3 ~ ~-1 minecraft:coarse_dirt
setblock ~3 ~ ~3 minecraft:moss_block
