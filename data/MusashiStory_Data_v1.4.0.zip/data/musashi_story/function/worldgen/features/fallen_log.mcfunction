fill ~-3 ~ ~ ~3 ~ ~ minecraft:stripped_spruce_log[axis=x]
setblock ~-3 ~ ~ minecraft:spruce_log[axis=x]
setblock ~3 ~ ~ minecraft:spruce_log[axis=x]
setblock ~-2 ~1 ~ minecraft:moss_carpet
setblock ~ ~1 ~ minecraft:moss_carpet
setblock ~2 ~1 ~ minecraft:moss_carpet
setblock ~-2 ~1 ~1 minecraft:brown_mushroom
setblock ~1 ~1 ~-1 minecraft:red_mushroom
setblock ~4 ~ ~ minecraft:fern
setblock ~-4 ~ ~1 minecraft:large_fern[half=lower]
setblock ~-4 ~1 ~1 minecraft:large_fern[half=upper]
