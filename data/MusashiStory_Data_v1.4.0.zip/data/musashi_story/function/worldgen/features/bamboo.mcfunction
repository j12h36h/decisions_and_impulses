# Dense bamboo thicket with varied heights and forest-floor clutter.
fill ~ ~ ~ ~ ~8 ~ minecraft:bamboo[age=1,leaves=large,stage=1]
fill ~2 ~ ~1 ~2 ~6 ~1 minecraft:bamboo[age=1,leaves=large,stage=1]
fill ~-2 ~ ~2 ~-2 ~9 ~2 minecraft:bamboo[age=1,leaves=large,stage=1]
fill ~1 ~ ~-2 ~1 ~5 ~-2 minecraft:bamboo[age=1,leaves=large,stage=1]
fill ~-3 ~ ~-2 ~-3 ~7 ~-2 minecraft:bamboo[age=1,leaves=large,stage=1]
fill ~3 ~ ~3 ~3 ~10 ~3 minecraft:bamboo[age=1,leaves=large,stage=1]
fill ~4 ~ ~-1 ~4 ~6 ~-1 minecraft:bamboo[age=1,leaves=large,stage=1]
fill ~-4 ~ ~3 ~-4 ~8 ~3 minecraft:bamboo[age=1,leaves=large,stage=1]
setblock ~-1 ~-1 ~ minecraft:podzol
setblock ~2 ~-1 ~1 minecraft:moss_block
setblock ~-2 ~-1 ~2 minecraft:podzol
setblock ~1 ~-1 ~-2 minecraft:moss_block
setblock ~3 ~ ~-3 minecraft:fern
setblock ~-3 ~ ~1 minecraft:short_grass
setblock ~4 ~ ~2 minecraft:fern
setblock ~-4 ~ ~-1 minecraft:brown_mushroom
