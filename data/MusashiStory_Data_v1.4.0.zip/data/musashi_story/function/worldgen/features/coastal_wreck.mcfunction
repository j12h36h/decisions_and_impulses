# weathered coastal wreck
fill ~-9 ~-2 ~-2 ~9 ~-2 ~2 minecraft:dark_oak_planks
fill ~-7 ~-1 ~-3 ~7 ~-1 ~3 minecraft:dark_oak_planks
fill ~-5 ~ ~-2 ~5 ~ ~2 minecraft:air
fill ~-9 ~-1 ~-3 ~-9 ~2 ~3 minecraft:dark_oak_log
fill ~9 ~-1 ~-3 ~9 ~1 ~3 minecraft:dark_oak_log
fill ~-7 ~ ~-4 ~-3 ~1 ~-4 minecraft:dark_oak_fence
fill ~2 ~ ~4 ~7 ~1 ~4 minecraft:dark_oak_fence
fill ~ ~ ~ ~ ~7 ~ minecraft:stripped_spruce_log
fill ~1 ~5 ~ ~6 ~5 ~ minecraft:white_wool
fill ~1 ~4 ~ ~5 ~4 ~ minecraft:white_wool
setblock ~-5 ~ ~-2 minecraft:barrel
setblock ~5 ~ ~2 minecraft:barrel
setblock ~-7 ~ ~3 minecraft:iron_bars
setblock ~7 ~ ~-3 minecraft:iron_bars
setblock ~-4 ~ ~3 minecraft:campfire[lit=false]
