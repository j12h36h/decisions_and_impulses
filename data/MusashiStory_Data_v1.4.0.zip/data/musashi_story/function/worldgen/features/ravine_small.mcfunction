# small ravine / cut with exposed stone
fill ~-3 ~-6 ~-18 ~3 ~2 ~18 minecraft:air
fill ~-4 ~-7 ~-18 ~4 ~-7 ~18 minecraft:stone
fill ~-5 ~-6 ~-18 ~-4 ~1 ~18 minecraft:stone
fill ~4 ~-6 ~-18 ~5 ~1 ~18 minecraft:stone
fill ~-2 ~-5 ~-18 ~2 ~-4 ~18 minecraft:water
