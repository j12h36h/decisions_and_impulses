# Cherry C — taller forked sakura used as a distant landmark silhouette.
fill ~ ~ ~ ~ ~8 ~ minecraft:cherry_log[axis=y]
fill ~ ~5 ~ ~-4 ~6 ~ minecraft:cherry_log[axis=x]
fill ~ ~6 ~ ~4 ~7 ~ minecraft:cherry_log[axis=x]
fill ~ ~6 ~ ~ ~6 ~-4 minecraft:cherry_log[axis=z]
fill ~ ~7 ~ ~ ~7 ~4 minecraft:cherry_log[axis=z]
fill ~-5 ~5 ~-3 ~-1 ~7 ~2 minecraft:cherry_leaves[persistent=true]
fill ~1 ~5 ~-2 ~6 ~7 ~3 minecraft:cherry_leaves[persistent=true]
fill ~-3 ~6 ~-6 ~2 ~8 ~-1 minecraft:cherry_leaves[persistent=true]
fill ~-2 ~6 ~1 ~3 ~9 ~6 minecraft:cherry_leaves[persistent=true]
fill ~-3 ~8 ~-2 ~3 ~10 ~3 minecraft:cherry_leaves[persistent=true]
fill ~-5 ~7 ~2 ~-4 ~8 ~4 minecraft:air replace minecraft:cherry_leaves
fill ~4 ~7 ~-3 ~6 ~8 ~-2 minecraft:air replace minecraft:cherry_leaves
setblock ~-5 ~ ~-4 minecraft:pink_petals[flower_amount=2]
setblock ~-3 ~ ~4 minecraft:pink_petals[flower_amount=4]
setblock ~3 ~ ~5 minecraft:pink_petals[flower_amount=3]
setblock ~6 ~ ~1 minecraft:pink_petals[flower_amount=2]
