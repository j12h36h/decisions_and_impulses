# Natural ravine with a bent footprint, stone walls and a safe floor.
fill ~-4 ~-7 ~-34 ~4 ~1 ~-8 minecraft:air
fill ~-2 ~-6 ~-34 ~2 ~-5 ~-8 minecraft:water
fill ~-7 ~-7 ~-12 ~1 ~1 ~12 minecraft:air
fill ~-5 ~-6 ~-12 ~-1 ~-5 ~12 minecraft:water
fill ~-2 ~-7 ~8 ~6 ~1 ~34 minecraft:air
fill ~ ~-6 ~8 ~4 ~-5 ~34 minecraft:water
fill ~-5 ~-8 ~-35 ~5 ~-8 ~-7 minecraft:stone
fill ~-8 ~-8 ~-13 ~2 ~-8 ~13 minecraft:stone
fill ~-3 ~-8 ~7 ~7 ~-8 ~35 minecraft:stone
