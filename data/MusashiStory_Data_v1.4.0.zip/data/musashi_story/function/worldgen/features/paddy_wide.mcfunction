# tapered rice paddy with raised walking berms
fill ~-16 ~-1 ~-5 ~16 ~-1 ~5 minecraft:mud
fill ~-13 ~-1 ~-8 ~13 ~-1 ~8 minecraft:mud
fill ~-13 ~-1 ~-5 ~13 ~-1 ~5 minecraft:water
fill ~-10 ~-1 ~-7 ~10 ~-1 ~7 minecraft:water
fill ~-16 ~ ~-4 ~-16 ~ ~4 minecraft:dirt_path
fill ~16 ~ ~-4 ~16 ~ ~4 minecraft:dirt_path
fill ~-12 ~ ~-8 ~12 ~ ~-8 minecraft:dirt_path
fill ~-12 ~ ~8 ~12 ~ ~8 minecraft:dirt_path
setblock ~-8 ~ ~-7 minecraft:oak_slab[type=bottom]
setblock ~-7 ~ ~-7 minecraft:oak_slab[type=bottom]
setblock ~8 ~ ~7 minecraft:oak_slab[type=bottom]
setblock ~7 ~ ~7 minecraft:oak_slab[type=bottom]
