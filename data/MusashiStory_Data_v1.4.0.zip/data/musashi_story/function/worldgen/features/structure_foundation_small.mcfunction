fill ~-10 ~-14 ~-10 ~10 ~-1 ~10 minecraft:stone
fill ~-12 ~-5 ~-12 ~12 ~-1 ~12 minecraft:dirt
fill ~-14 ~-3 ~-10 ~14 ~-1 ~10 minecraft:dirt
fill ~-10 ~-3 ~-14 ~10 ~-1 ~14 minecraft:dirt
fill ~-15 ~-1 ~-11 ~15 ~-1 ~11 minecraft:grass_block
fill ~-11 ~-1 ~-15 ~11 ~-1 ~15 minecraft:grass_block
