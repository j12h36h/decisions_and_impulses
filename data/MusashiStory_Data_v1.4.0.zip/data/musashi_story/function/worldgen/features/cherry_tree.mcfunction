# Cherry A — asymmetric mature sakura with visible branches and broken crown.
fill ~ ~ ~ ~ ~7 ~ minecraft:cherry_log[axis=y]
fill ~ ~4 ~ ~4 ~4 ~ minecraft:cherry_log[axis=x]
fill ~-4 ~5 ~ ~ ~5 ~ minecraft:cherry_log[axis=x]
fill ~ ~5 ~-4 ~ ~5 ~ minecraft:cherry_log[axis=z]
fill ~ ~6 ~ ~ ~6 ~4 minecraft:cherry_log[axis=z]
fill ~2 ~5 ~ ~5 ~5 ~ minecraft:cherry_log[axis=x]
fill ~-5 ~6 ~ ~-2 ~6 ~ minecraft:cherry_log[axis=x]
fill ~-6 ~4 ~-2 ~-2 ~6 ~2 minecraft:cherry_leaves[persistent=true]
fill ~-3 ~6 ~-4 ~2 ~8 ~1 minecraft:cherry_leaves[persistent=true]
fill ~1 ~4 ~-3 ~6 ~6 ~2 minecraft:cherry_leaves[persistent=true]
fill ~-2 ~5 ~1 ~3 ~8 ~6 minecraft:cherry_leaves[persistent=true]
fill ~-1 ~7 ~-2 ~4 ~9 ~3 minecraft:cherry_leaves[persistent=true]
fill ~-6 ~6 ~1 ~-5 ~7 ~2 minecraft:air replace minecraft:cherry_leaves
fill ~5 ~5 ~-3 ~6 ~6 ~-2 minecraft:air replace minecraft:cherry_leaves
fill ~-2 ~8 ~4 ~0 ~9 ~5 minecraft:air replace minecraft:cherry_leaves
setblock ~-5 ~ ~3 minecraft:pink_petals[flower_amount=4]
setblock ~-2 ~ ~-4 minecraft:pink_petals[flower_amount=2]
setblock ~3 ~ ~4 minecraft:pink_petals[flower_amount=4]
setblock ~5 ~ ~-1 minecraft:pink_petals[flower_amount=3]
setblock ~1 ~ ~6 minecraft:pink_petals[flower_amount=2]
