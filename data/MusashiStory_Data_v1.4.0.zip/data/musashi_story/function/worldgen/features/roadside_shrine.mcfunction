fill ~-3 ~-1 ~-3 ~3 ~-1 ~3 minecraft:mossy_stone_bricks
fill ~-2 ~ ~-2 ~2 ~ ~2 minecraft:cherry_planks
fill ~-2 ~1 ~-2 ~-2 ~3 ~2 minecraft:stripped_cherry_log
fill ~2 ~1 ~-2 ~2 ~3 ~2 minecraft:stripped_cherry_log
fill ~-1 ~1 ~2 ~1 ~3 ~2 minecraft:red_concrete
fill ~-3 ~4 ~-3 ~3 ~4 ~3 minecraft:deepslate_tiles
setblock ~-3 ~5 ~-3 minecraft:deepslate_tile_stairs[facing=south]
setblock ~3 ~5 ~-3 minecraft:deepslate_tile_stairs[facing=south]
setblock ~-3 ~5 ~3 minecraft:deepslate_tile_stairs[facing=north]
setblock ~3 ~5 ~3 minecraft:deepslate_tile_stairs[facing=north]
fill ~-1 ~1 ~2 ~1 ~2 ~2 minecraft:air
setblock ~ ~1 ~ minecraft:chiseled_stone_bricks
setblock ~ ~2 ~ minecraft:candle[candles=3,lit=true]
execute positioned ~-5 ~ ~1 run function musashi_story:worldgen/features/stone_lantern
execute positioned ~5 ~ ~1 run function musashi_story:worldgen/features/stone_lantern
