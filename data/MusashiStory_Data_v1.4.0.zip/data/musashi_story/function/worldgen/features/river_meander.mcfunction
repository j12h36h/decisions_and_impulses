# Curved shallow river cut, lined so it never opens to the void.
fill ~-46 ~-6 ~-3 ~-18 ~1 ~3 minecraft:stone
fill ~-45 ~-5 ~-2 ~-19 ~1 ~2 minecraft:water
fill ~-24 ~-6 ~-7 ~6 ~1 ~-1 minecraft:stone
fill ~-23 ~-5 ~-6 ~5 ~1 ~-2 minecraft:water
fill ~0 ~-6 ~-4 ~28 ~1 ~2 minecraft:stone
fill ~1 ~-5 ~-3 ~27 ~1 ~1 minecraft:water
fill ~22 ~-6 ~0 ~48 ~1 ~6 minecraft:stone
fill ~23 ~-5 ~1 ~47 ~1 ~5 minecraft:water
# irregular grassy banks
fill ~-47 ~ ~-7 ~-20 ~1 ~-5 minecraft:grass_block
fill ~-42 ~ ~5 ~-17 ~1 ~7 minecraft:grass_block
fill ~-25 ~ ~-11 ~4 ~1 ~-9 minecraft:grass_block
fill ~-20 ~ ~1 ~8 ~1 ~3 minecraft:grass_block
fill ~0 ~ ~-8 ~28 ~1 ~-6 minecraft:grass_block
fill ~4 ~ ~3 ~31 ~1 ~5 minecraft:grass_block
fill ~22 ~ ~-4 ~49 ~1 ~-2 minecraft:grass_block
fill ~25 ~ ~7 ~48 ~1 ~9 minecraft:grass_block
