# shallow north-south stream with grassy banks
fill ~-1 ~-2 ~-18 ~1 ~-2 ~18 minecraft:water
fill ~-2 ~-1 ~-16 ~2 ~-1 ~16 minecraft:water
fill ~-3 ~ ~-14 ~3 ~ ~14 minecraft:water
fill ~-4 ~-2 ~-20 ~-3 ~-2 ~20 minecraft:dirt
fill ~3 ~-2 ~-20 ~4 ~-2 ~20 minecraft:dirt
fill ~-5 ~-1 ~-18 ~-4 ~-1 ~18 minecraft:grass_block
fill ~4 ~-1 ~-18 ~5 ~-1 ~18 minecraft:grass_block
fill ~-6 ~ ~-10 ~-5 ~ ~10 minecraft:grass_block
fill ~5 ~ ~-10 ~6 ~ ~10 minecraft:grass_block
