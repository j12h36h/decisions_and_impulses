fill ~-24 ~-18 ~-20 ~24 ~-1 ~20 minecraft:stone
fill ~-26 ~-8 ~-22 ~26 ~-1 ~22 minecraft:dirt
fill ~-29 ~-4 ~-20 ~29 ~-1 ~20 minecraft:dirt
fill ~-26 ~-4 ~-25 ~26 ~-1 ~25 minecraft:dirt
fill ~-31 ~-1 ~-18 ~31 ~-1 ~18 minecraft:grass_block
fill ~-24 ~-1 ~-27 ~24 ~-1 ~27 minecraft:grass_block
