
setblock ~ ~-1 ~ minecraft:coarse_dirt
setblock ~ ~ ~ minecraft:cobblestone_wall
setblock ~ ~1 ~ minecraft:stone_slab[type=bottom]
