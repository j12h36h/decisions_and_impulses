fill ~-3 ~-1 ~-2 ~3 ~-1 ~2 minecraft:cherry_planks
fill ~-3 ~ ~-2 ~-3 ~3 ~-2 minecraft:stripped_spruce_log
fill ~3 ~ ~-2 ~3 ~3 ~-2 minecraft:stripped_spruce_log
fill ~-3 ~ ~2 ~-3 ~3 ~2 minecraft:stripped_spruce_log
fill ~3 ~ ~2 ~3 ~3 ~2 minecraft:stripped_spruce_log
fill ~-4 ~4 ~-3 ~4 ~4 ~3 minecraft:red_wool
fill ~-2 ~ ~-1 ~2 ~ ~1 minecraft:barrel
setblock ~-3 ~2 ~ minecraft:lantern
setblock ~3 ~2 ~ minecraft:lantern
