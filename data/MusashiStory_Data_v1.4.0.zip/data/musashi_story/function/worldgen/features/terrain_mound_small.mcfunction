# subtle 1-2 block micro-relief
fill ~-5 ~-1 ~-2 ~5 ~-1 ~2 minecraft:dirt
fill ~-3 ~-1 ~-4 ~3 ~-1 ~4 minecraft:dirt
fill ~-4 ~ ~-1 ~4 ~ ~1 minecraft:grass_block
fill ~-2 ~ ~-3 ~2 ~ ~3 minecraft:grass_block
setblock ~ ~1 ~ minecraft:grass_block
