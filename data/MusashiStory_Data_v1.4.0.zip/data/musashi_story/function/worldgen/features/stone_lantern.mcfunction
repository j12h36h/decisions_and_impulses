setblock ~ ~-1 ~ minecraft:stone_bricks
setblock ~ ~ ~ minecraft:cobblestone_wall
setblock ~ ~1 ~ minecraft:stone_brick_wall
setblock ~ ~2 ~ minecraft:lantern
setblock ~ ~3 ~ minecraft:stone_slab[type=bottom]
