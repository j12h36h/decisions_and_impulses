# long narrow paddy, staggered outline
fill ~-9 ~-1 ~-13 ~9 ~-1 ~13 minecraft:mud
fill ~-12 ~-1 ~-10 ~12 ~-1 ~10 minecraft:mud
fill ~-7 ~-1 ~-11 ~7 ~-1 ~11 minecraft:water
fill ~-10 ~-1 ~-8 ~10 ~-1 ~8 minecraft:water
fill ~-9 ~ ~-13 ~9 ~ ~-13 minecraft:dirt_path
fill ~-9 ~ ~13 ~9 ~ ~13 minecraft:dirt_path
fill ~-12 ~ ~-9 ~-12 ~ ~9 minecraft:dirt_path
fill ~12 ~ ~-9 ~12 ~ ~9 minecraft:dirt_path
