# Cedar B — narrow wind-shaped conifer.
fill ~ ~ ~ ~ ~14 ~ minecraft:spruce_log[axis=y]
fill ~ ~5 ~ ~4 ~5 ~ minecraft:spruce_log[axis=x]
fill ~-3 ~8 ~ ~ ~8 ~ minecraft:spruce_log[axis=x]
fill ~ ~10 ~ ~ ~10 ~3 minecraft:spruce_log[axis=z]
fill ~-4 ~4 ~-3 ~5 ~5 ~3 minecraft:spruce_leaves[persistent=true]
fill ~-5 ~6 ~-2 ~3 ~7 ~3 minecraft:spruce_leaves[persistent=true]
fill ~-3 ~8 ~-3 ~4 ~9 ~2 minecraft:spruce_leaves[persistent=true]
fill ~-2 ~10 ~-2 ~3 ~11 ~2 minecraft:spruce_leaves[persistent=true]
fill ~-1 ~12 ~-1 ~1 ~15 ~1 minecraft:spruce_leaves[persistent=true]
setblock ~2 ~ ~1 minecraft:podzol
setblock ~-2 ~ ~-1 minecraft:moss_carpet
setblock ~4 ~ ~ minecraft:fern
