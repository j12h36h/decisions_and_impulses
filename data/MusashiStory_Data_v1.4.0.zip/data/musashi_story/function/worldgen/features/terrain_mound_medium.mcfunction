# rounded stepped knoll
fill ~-8 ~-1 ~-3 ~8 ~-1 ~3 minecraft:dirt
fill ~-6 ~-1 ~-5 ~6 ~-1 ~5 minecraft:dirt
fill ~-6 ~ ~-2 ~6 ~ ~2 minecraft:dirt
fill ~-4 ~ ~-4 ~4 ~ ~4 minecraft:dirt
fill ~-5 ~1 ~-1 ~5 ~1 ~1 minecraft:grass_block
fill ~-3 ~1 ~-3 ~3 ~1 ~3 minecraft:grass_block
fill ~-1 ~2 ~-1 ~1 ~2 ~1 minecraft:grass_block
