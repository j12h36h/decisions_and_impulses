fill ~-17 ~-16 ~-13 ~17 ~-1 ~13 minecraft:stone
fill ~-18 ~-6 ~-14 ~18 ~-1 ~14 minecraft:dirt
fill ~-20 ~-3 ~-12 ~20 ~-1 ~12 minecraft:dirt
fill ~-18 ~-3 ~-16 ~18 ~-1 ~16 minecraft:dirt
fill ~-21 ~-1 ~-11 ~21 ~-1 ~11 minecraft:grass_block
fill ~-17 ~-1 ~-17 ~17 ~-1 ~17 minecraft:grass_block
