# shallow east-west stream with grassy banks
fill ~-18 ~-2 ~-1 ~18 ~-2 ~1 minecraft:water
fill ~-16 ~-1 ~-2 ~16 ~-1 ~2 minecraft:water
fill ~-14 ~ ~-3 ~14 ~ ~3 minecraft:water
fill ~-20 ~-2 ~-4 ~20 ~-2 ~-3 minecraft:dirt
fill ~-20 ~-2 ~3 ~20 ~-2 ~4 minecraft:dirt
fill ~-18 ~-1 ~-5 ~18 ~-1 ~-4 minecraft:grass_block
fill ~-18 ~-1 ~4 ~18 ~-1 ~5 minecraft:grass_block
fill ~-10 ~ ~-6 ~10 ~ ~-5 minecraft:grass_block
fill ~-10 ~ ~5 ~10 ~ ~6 minecraft:grass_block
