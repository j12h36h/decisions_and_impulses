fill ~-5 ~-2 ~-5 ~5 ~-1 ~5 minecraft:stone_bricks
fill ~-4 ~ ~-4 ~4 ~ ~4 minecraft:gravel
fill ~-3 ~ ~-3 ~3 ~ ~3 minecraft:polished_andesite
fill ~-2 ~ ~-2 ~2 ~ ~2 minecraft:mossy_stone_bricks
setblock ~ ~ ~ minecraft:lodestone
fill ~-4 ~1 ~-4 ~-4 ~2 ~4 minecraft:stone_brick_wall
fill ~4 ~1 ~-4 ~4 ~2 ~4 minecraft:stone_brick_wall
fill ~-3 ~1 ~3 ~-3 ~4 ~3 minecraft:stripped_cherry_log
fill ~3 ~1 ~3 ~3 ~4 ~3 minecraft:stripped_cherry_log
fill ~-4 ~4 ~3 ~4 ~4 ~3 minecraft:red_concrete
fill ~-5 ~5 ~3 ~5 ~5 ~3 minecraft:polished_blackstone
setblock ~ ~1 ~-4 minecraft:red_banner[rotation=8]
setblock ~-4 ~3 ~-4 minecraft:lantern
setblock ~4 ~3 ~-4 minecraft:lantern
setblock ~-4 ~3 ~4 minecraft:lantern
setblock ~4 ~3 ~4 minecraft:lantern
