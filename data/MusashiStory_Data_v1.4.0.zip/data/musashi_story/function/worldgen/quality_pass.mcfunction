scoreboard players set #quality_v050 ms_world 1
kill @e[tag=ms_ambient]
tellraw @a[tag=ms_player] [{"text":"PROVINCE DETAIL PASS // ","color":"gold","bold":true},{"text":"old roads remember new stories","color":"white"}]
schedule function musashi_story:worldgen/regions/village/detail_1 5t append
schedule function musashi_story:worldgen/regions/village/detail_2 15t append
schedule function musashi_story:worldgen/regions/village/detail_3 25t append
execute if score #gen_outskirts ms_world matches 1 run schedule function musashi_story:worldgen/regions/outskirts/detail_1 45t append
execute if score #gen_outskirts ms_world matches 1 run schedule function musashi_story:worldgen/regions/outskirts/detail_2 55t append
execute if score #gen_outskirts ms_world matches 1 run schedule function musashi_story:worldgen/regions/outskirts/detail_3 65t append
execute if score #gen_rice ms_world matches 1 run schedule function musashi_story:worldgen/regions/rice_country/detail_1 80t append
execute if score #gen_rice ms_world matches 1 run schedule function musashi_story:worldgen/regions/rice_country/detail_2 90t append
execute if score #gen_rice ms_world matches 1 run schedule function musashi_story:worldgen/regions/rice_country/detail_3 100t append
execute if score #gen_river ms_world matches 1 run schedule function musashi_story:worldgen/regions/river_province/detail_1 115t append
execute if score #gen_river ms_world matches 1 run schedule function musashi_story:worldgen/regions/river_province/detail_2 125t append
execute if score #gen_river ms_world matches 1 run schedule function musashi_story:worldgen/regions/river_province/detail_3 135t append
execute if score #gen_e ms_world matches 1 run schedule function musashi_story:worldgen/regions/east/detail_1 150t append
execute if score #gen_e ms_world matches 1 run schedule function musashi_story:worldgen/regions/east/detail_2 160t append
execute if score #gen_e ms_world matches 1 run schedule function musashi_story:worldgen/regions/east/detail_3 170t append
execute if score #gen_n ms_world matches 1 run schedule function musashi_story:worldgen/regions/north/detail_1 185t append
execute if score #gen_n ms_world matches 1 run schedule function musashi_story:worldgen/regions/north/detail_2 195t append
execute if score #gen_n ms_world matches 1 run schedule function musashi_story:worldgen/regions/north/detail_3 205t append
execute if score #gen_w ms_world matches 1 run schedule function musashi_story:worldgen/regions/west/detail_1 220t append
execute if score #gen_w ms_world matches 1 run schedule function musashi_story:worldgen/regions/west/detail_2 230t append
execute if score #gen_w ms_world matches 1 run schedule function musashi_story:worldgen/regions/west/detail_3 240t append
execute if score #gen_s ms_world matches 1 run schedule function musashi_story:worldgen/regions/south/detail_1 255t append
execute if score #gen_s ms_world matches 1 run schedule function musashi_story:worldgen/regions/south/detail_2 265t append
execute if score #gen_s ms_world matches 1 run schedule function musashi_story:worldgen/regions/south/detail_3 275t append
execute if score #gen_se ms_world matches 1 run schedule function musashi_story:worldgen/regions/se/detail_1 290t append
execute if score #gen_se ms_world matches 1 run schedule function musashi_story:worldgen/regions/se/detail_2 300t append
execute if score #gen_se ms_world matches 1 run schedule function musashi_story:worldgen/regions/se/detail_3 310t append
execute if score #gen_ne ms_world matches 1 run schedule function musashi_story:worldgen/regions/ne/detail_1 325t append
execute if score #gen_ne ms_world matches 1 run schedule function musashi_story:worldgen/regions/ne/detail_2 335t append
execute if score #gen_ne ms_world matches 1 run schedule function musashi_story:worldgen/regions/ne/detail_3 345t append
execute if score #gen_nw ms_world matches 1 run schedule function musashi_story:worldgen/regions/nw/detail_1 360t append
execute if score #gen_nw ms_world matches 1 run schedule function musashi_story:worldgen/regions/nw/detail_2 370t append
execute if score #gen_nw ms_world matches 1 run schedule function musashi_story:worldgen/regions/nw/detail_3 380t append
