forceload add 384 -128 447 -65
fill 384 60 -128 447 62 -65 minecraft:stone
fill 384 63 -128 447 63 -65 minecraft:dirt
fill 384 64 -128 447 64 -65 minecraft:grass_block
forceload remove 384 -128 447 -65
forceload add 448 -128 511 -65
fill 448 60 -128 511 62 -65 minecraft:stone
fill 448 63 -128 511 63 -65 minecraft:dirt
fill 448 64 -128 511 64 -65 minecraft:grass_block
forceload remove 448 -128 511 -65
scoreboard players add #build_step ms_world 1
