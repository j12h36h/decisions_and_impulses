forceload add 384 64 447 127
fill 384 60 64 447 62 127 minecraft:stone
fill 384 63 64 447 63 127 minecraft:dirt
fill 384 64 64 447 64 127 minecraft:grass_block
forceload remove 384 64 447 127
forceload add 448 64 511 127
fill 448 60 64 511 62 127 minecraft:stone
fill 448 63 64 511 63 127 minecraft:dirt
fill 448 64 64 511 64 127 minecraft:grass_block
forceload remove 448 64 511 127
scoreboard players add #build_step ms_world 1
