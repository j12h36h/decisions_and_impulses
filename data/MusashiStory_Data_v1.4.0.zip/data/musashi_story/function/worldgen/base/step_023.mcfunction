forceload add 384 -384 447 -321
fill 384 60 -384 447 62 -321 minecraft:stone
fill 384 63 -384 447 63 -321 minecraft:dirt
fill 384 64 -384 447 64 -321 minecraft:grass_block
forceload remove 384 -384 447 -321
forceload add 448 -384 511 -321
fill 448 60 -384 511 62 -321 minecraft:stone
fill 448 63 -384 511 63 -321 minecraft:dirt
fill 448 64 -384 511 64 -321 minecraft:grass_block
forceload remove 448 -384 511 -321
scoreboard players add #build_step ms_world 1
