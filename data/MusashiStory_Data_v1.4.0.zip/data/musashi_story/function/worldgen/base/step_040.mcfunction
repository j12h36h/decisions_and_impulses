forceload add -512 -192 -449 -129
fill -512 60 -192 -449 62 -129 minecraft:stone
fill -512 63 -192 -449 63 -129 minecraft:dirt
fill -512 64 -192 -449 64 -129 minecraft:grass_block
forceload remove -512 -192 -449 -129
forceload add -448 -192 -385 -129
fill -448 60 -192 -385 62 -129 minecraft:stone
fill -448 63 -192 -385 63 -129 minecraft:dirt
fill -448 64 -192 -385 64 -129 minecraft:grass_block
forceload remove -448 -192 -385 -129
scoreboard players add #build_step ms_world 1
