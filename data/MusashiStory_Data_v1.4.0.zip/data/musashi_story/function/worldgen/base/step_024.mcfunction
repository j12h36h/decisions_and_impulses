forceload add -512 -320 -449 -257
fill -512 60 -320 -449 62 -257 minecraft:stone
fill -512 63 -320 -449 63 -257 minecraft:dirt
fill -512 64 -320 -449 64 -257 minecraft:grass_block
forceload remove -512 -320 -449 -257
forceload add -448 -320 -385 -257
fill -448 60 -320 -385 62 -257 minecraft:stone
fill -448 63 -320 -385 63 -257 minecraft:dirt
fill -448 64 -320 -385 64 -257 minecraft:grass_block
forceload remove -448 -320 -385 -257
scoreboard players add #build_step ms_world 1
