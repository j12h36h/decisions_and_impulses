forceload add -384 -512 -321 -449
fill -384 60 -512 -321 62 -449 minecraft:stone
fill -384 63 -512 -321 63 -449 minecraft:dirt
fill -384 64 -512 -321 64 -449 minecraft:grass_block
forceload remove -384 -512 -321 -449
forceload add -320 -512 -257 -449
fill -320 60 -512 -257 62 -449 minecraft:stone
fill -320 63 -512 -257 63 -449 minecraft:dirt
fill -320 64 -512 -257 64 -449 minecraft:grass_block
forceload remove -320 -512 -257 -449
scoreboard players add #build_step ms_world 1
