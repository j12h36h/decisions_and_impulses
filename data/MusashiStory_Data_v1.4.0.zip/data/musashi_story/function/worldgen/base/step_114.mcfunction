forceload add 0 384 63 447
fill 0 60 384 63 62 447 minecraft:stone
fill 0 63 384 63 63 447 minecraft:dirt
fill 0 64 384 63 64 447 minecraft:grass_block
forceload remove 0 384 63 447
forceload add 64 384 127 447
fill 64 60 384 127 62 447 minecraft:stone
fill 64 63 384 127 63 447 minecraft:dirt
fill 64 64 384 127 64 447 minecraft:grass_block
forceload remove 64 384 127 447
scoreboard players add #build_step ms_world 1
