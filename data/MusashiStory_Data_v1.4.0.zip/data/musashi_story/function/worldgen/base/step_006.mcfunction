forceload add 256 -512 319 -449
fill 256 60 -512 319 62 -449 minecraft:stone
fill 256 63 -512 319 63 -449 minecraft:dirt
fill 256 64 -512 319 64 -449 minecraft:grass_block
forceload remove 256 -512 319 -449
forceload add 320 -512 383 -449
fill 320 60 -512 383 62 -449 minecraft:stone
fill 320 63 -512 383 63 -449 minecraft:dirt
fill 320 64 -512 383 64 -449 minecraft:grass_block
forceload remove 320 -512 383 -449
scoreboard players add #build_step ms_world 1
