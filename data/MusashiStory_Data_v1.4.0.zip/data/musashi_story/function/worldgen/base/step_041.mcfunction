forceload add -384 -192 -321 -129
fill -384 60 -192 -321 62 -129 minecraft:stone
fill -384 63 -192 -321 63 -129 minecraft:dirt
fill -384 64 -192 -321 64 -129 minecraft:grass_block
forceload remove -384 -192 -321 -129
forceload add -320 -192 -257 -129
fill -320 60 -192 -257 62 -129 minecraft:stone
fill -320 63 -192 -257 63 -129 minecraft:dirt
fill -320 64 -192 -257 64 -129 minecraft:grass_block
forceload remove -320 -192 -257 -129
scoreboard players add #build_step ms_world 1
