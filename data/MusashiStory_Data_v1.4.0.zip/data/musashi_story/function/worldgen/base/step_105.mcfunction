forceload add -128 320 -65 383
fill -128 60 320 -65 62 383 minecraft:stone
fill -128 63 320 -65 63 383 minecraft:dirt
fill -128 64 320 -65 64 383 minecraft:grass_block
forceload remove -128 320 -65 383
forceload add -64 320 -1 383
fill -64 60 320 -1 62 383 minecraft:stone
fill -64 63 320 -1 63 383 minecraft:dirt
fill -64 64 320 -1 64 383 minecraft:grass_block
forceload remove -64 320 -1 383
scoreboard players add #build_step ms_world 1
