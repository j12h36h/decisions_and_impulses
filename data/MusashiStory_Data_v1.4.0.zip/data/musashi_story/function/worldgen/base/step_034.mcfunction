forceload add -256 -256 -193 -193
fill -256 60 -256 -193 62 -193 minecraft:stone
fill -256 63 -256 -193 63 -193 minecraft:dirt
fill -256 64 -256 -193 64 -193 minecraft:grass_block
forceload remove -256 -256 -193 -193
forceload add -192 -256 -129 -193
fill -192 60 -256 -129 62 -193 minecraft:stone
fill -192 63 -256 -129 63 -193 minecraft:dirt
fill -192 64 -256 -129 64 -193 minecraft:grass_block
forceload remove -192 -256 -129 -193
scoreboard players add #build_step ms_world 1
