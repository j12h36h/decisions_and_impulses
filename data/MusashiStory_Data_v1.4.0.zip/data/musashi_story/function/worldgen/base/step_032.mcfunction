forceload add -512 -256 -449 -193
fill -512 60 -256 -449 62 -193 minecraft:stone
fill -512 63 -256 -449 63 -193 minecraft:dirt
fill -512 64 -256 -449 64 -193 minecraft:grass_block
forceload remove -512 -256 -449 -193
forceload add -448 -256 -385 -193
fill -448 60 -256 -385 62 -193 minecraft:stone
fill -448 63 -256 -385 63 -193 minecraft:dirt
fill -448 64 -256 -385 64 -193 minecraft:grass_block
forceload remove -448 -256 -385 -193
scoreboard players add #build_step ms_world 1
