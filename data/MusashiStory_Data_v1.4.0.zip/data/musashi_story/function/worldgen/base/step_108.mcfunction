forceload add 256 320 319 383
fill 256 60 320 319 62 383 minecraft:stone
fill 256 63 320 319 63 383 minecraft:dirt
fill 256 64 320 319 64 383 minecraft:grass_block
forceload remove 256 320 319 383
forceload add 320 320 383 383
fill 320 60 320 383 62 383 minecraft:stone
fill 320 63 320 383 63 383 minecraft:dirt
fill 320 64 320 383 64 383 minecraft:grass_block
forceload remove 320 320 383 383
scoreboard players add #build_step ms_world 1
