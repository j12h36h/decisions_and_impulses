forceload add -384 -256 -321 -193
fill -384 60 -256 -321 62 -193 minecraft:stone
fill -384 63 -256 -321 63 -193 minecraft:dirt
fill -384 64 -256 -321 64 -193 minecraft:grass_block
forceload remove -384 -256 -321 -193
forceload add -320 -256 -257 -193
fill -320 60 -256 -257 62 -193 minecraft:stone
fill -320 63 -256 -257 63 -193 minecraft:dirt
fill -320 64 -256 -257 64 -193 minecraft:grass_block
forceload remove -320 -256 -257 -193
scoreboard players add #build_step ms_world 1
