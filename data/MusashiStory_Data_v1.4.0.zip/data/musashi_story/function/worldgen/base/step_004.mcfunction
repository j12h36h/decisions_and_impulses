forceload add 0 -512 63 -449
fill 0 60 -512 63 62 -449 minecraft:stone
fill 0 63 -512 63 63 -449 minecraft:dirt
fill 0 64 -512 63 64 -449 minecraft:grass_block
forceload remove 0 -512 63 -449
forceload add 64 -512 127 -449
fill 64 60 -512 127 62 -449 minecraft:stone
fill 64 63 -512 127 63 -449 minecraft:dirt
fill 64 64 -512 127 64 -449 minecraft:grass_block
forceload remove 64 -512 127 -449
scoreboard players add #build_step ms_world 1
