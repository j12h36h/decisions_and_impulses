forceload add -384 -448 -321 -385
fill -384 60 -448 -321 62 -385 minecraft:stone
fill -384 63 -448 -321 63 -385 minecraft:dirt
fill -384 64 -448 -321 64 -385 minecraft:grass_block
forceload remove -384 -448 -321 -385
forceload add -320 -448 -257 -385
fill -320 60 -448 -257 62 -385 minecraft:stone
fill -320 63 -448 -257 63 -385 minecraft:dirt
fill -320 64 -448 -257 64 -385 minecraft:grass_block
forceload remove -320 -448 -257 -385
scoreboard players add #build_step ms_world 1
