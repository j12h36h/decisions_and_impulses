forceload add 128 -448 191 -385
fill 128 60 -448 191 62 -385 minecraft:stone
fill 128 63 -448 191 63 -385 minecraft:dirt
fill 128 64 -448 191 64 -385 minecraft:grass_block
forceload remove 128 -448 191 -385
forceload add 192 -448 255 -385
fill 192 60 -448 255 62 -385 minecraft:stone
fill 192 63 -448 255 63 -385 minecraft:dirt
fill 192 64 -448 255 64 -385 minecraft:grass_block
forceload remove 192 -448 255 -385
scoreboard players add #build_step ms_world 1
