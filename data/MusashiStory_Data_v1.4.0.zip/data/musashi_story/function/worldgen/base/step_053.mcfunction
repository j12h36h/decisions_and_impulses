forceload add 128 -128 191 -65
fill 128 60 -128 191 62 -65 minecraft:stone
fill 128 63 -128 191 63 -65 minecraft:dirt
fill 128 64 -128 191 64 -65 minecraft:grass_block
forceload remove 128 -128 191 -65
forceload add 192 -128 255 -65
fill 192 60 -128 255 62 -65 minecraft:stone
fill 192 63 -128 255 63 -65 minecraft:dirt
fill 192 64 -128 255 64 -65 minecraft:grass_block
forceload remove 192 -128 255 -65
scoreboard players add #build_step ms_world 1
