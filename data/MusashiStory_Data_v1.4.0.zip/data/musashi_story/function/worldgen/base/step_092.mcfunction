forceload add 256 192 319 255
fill 256 60 192 319 62 255 minecraft:stone
fill 256 63 192 319 63 255 minecraft:dirt
fill 256 64 192 319 64 255 minecraft:grass_block
forceload remove 256 192 319 255
forceload add 320 192 383 255
fill 320 60 192 383 62 255 minecraft:stone
fill 320 63 192 383 63 255 minecraft:dirt
fill 320 64 192 383 64 255 minecraft:grass_block
forceload remove 320 192 383 255
scoreboard players add #build_step ms_world 1
