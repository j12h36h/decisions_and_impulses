forceload add 128 0 191 63
fill 128 60 0 191 62 63 minecraft:stone
fill 128 63 0 191 63 63 minecraft:dirt
fill 128 64 0 191 64 63 minecraft:grass_block
forceload remove 128 0 191 63
forceload add 192 0 255 63
fill 192 60 0 255 62 63 minecraft:stone
fill 192 63 0 255 63 63 minecraft:dirt
fill 192 64 0 255 64 63 minecraft:grass_block
forceload remove 192 0 255 63
scoreboard players add #build_step ms_world 1
