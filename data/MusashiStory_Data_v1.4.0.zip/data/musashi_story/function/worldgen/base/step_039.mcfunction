forceload add 384 -256 447 -193
fill 384 60 -256 447 62 -193 minecraft:stone
fill 384 63 -256 447 63 -193 minecraft:dirt
fill 384 64 -256 447 64 -193 minecraft:grass_block
forceload remove 384 -256 447 -193
forceload add 448 -256 511 -193
fill 448 60 -256 511 62 -193 minecraft:stone
fill 448 63 -256 511 63 -193 minecraft:dirt
fill 448 64 -256 511 64 -193 minecraft:grass_block
forceload remove 448 -256 511 -193
scoreboard players add #build_step ms_world 1
