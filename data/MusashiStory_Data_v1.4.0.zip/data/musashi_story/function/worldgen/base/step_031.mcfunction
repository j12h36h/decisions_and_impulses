forceload add 384 -320 447 -257
fill 384 60 -320 447 62 -257 minecraft:stone
fill 384 63 -320 447 63 -257 minecraft:dirt
fill 384 64 -320 447 64 -257 minecraft:grass_block
forceload remove 384 -320 447 -257
forceload add 448 -320 511 -257
fill 448 60 -320 511 62 -257 minecraft:stone
fill 448 63 -320 511 63 -257 minecraft:dirt
fill 448 64 -320 511 64 -257 minecraft:grass_block
forceload remove 448 -320 511 -257
scoreboard players add #build_step ms_world 1
