forceload add 256 -128 319 -65
fill 256 60 -128 319 62 -65 minecraft:stone
fill 256 63 -128 319 63 -65 minecraft:dirt
fill 256 64 -128 319 64 -65 minecraft:grass_block
forceload remove 256 -128 319 -65
forceload add 320 -128 383 -65
fill 320 60 -128 383 62 -65 minecraft:stone
fill 320 63 -128 383 63 -65 minecraft:dirt
fill 320 64 -128 383 64 -65 minecraft:grass_block
forceload remove 320 -128 383 -65
scoreboard players add #build_step ms_world 1
