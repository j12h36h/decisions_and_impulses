forceload add 0 -384 63 -321
fill 0 60 -384 63 62 -321 minecraft:stone
fill 0 63 -384 63 63 -321 minecraft:dirt
fill 0 64 -384 63 64 -321 minecraft:grass_block
forceload remove 0 -384 63 -321
forceload add 64 -384 127 -321
fill 64 60 -384 127 62 -321 minecraft:stone
fill 64 63 -384 127 63 -321 minecraft:dirt
fill 64 64 -384 127 64 -321 minecraft:grass_block
forceload remove 64 -384 127 -321
scoreboard players add #build_step ms_world 1
