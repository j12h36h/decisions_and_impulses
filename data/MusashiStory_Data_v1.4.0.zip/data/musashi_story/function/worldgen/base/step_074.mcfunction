forceload add 0 64 63 127
fill 0 60 64 63 62 127 minecraft:stone
fill 0 63 64 63 63 127 minecraft:dirt
fill 0 64 64 63 64 127 minecraft:grass_block
forceload remove 0 64 63 127
forceload add 64 64 127 127
fill 64 60 64 127 62 127 minecraft:stone
fill 64 63 64 127 63 127 minecraft:dirt
fill 64 64 64 127 64 127 minecraft:grass_block
forceload remove 64 64 127 127
scoreboard players add #build_step ms_world 1
