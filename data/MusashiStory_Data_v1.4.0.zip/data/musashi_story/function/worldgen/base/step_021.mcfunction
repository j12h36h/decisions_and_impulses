forceload add 128 -384 191 -321
fill 128 60 -384 191 62 -321 minecraft:stone
fill 128 63 -384 191 63 -321 minecraft:dirt
fill 128 64 -384 191 64 -321 minecraft:grass_block
forceload remove 128 -384 191 -321
forceload add 192 -384 255 -321
fill 192 60 -384 255 62 -321 minecraft:stone
fill 192 63 -384 255 63 -321 minecraft:dirt
fill 192 64 -384 255 64 -321 minecraft:grass_block
forceload remove 192 -384 255 -321
scoreboard players add #build_step ms_world 1
