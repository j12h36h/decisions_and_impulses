forceload add -512 -384 -449 -321
fill -512 60 -384 -449 62 -321 minecraft:stone
fill -512 63 -384 -449 63 -321 minecraft:dirt
fill -512 64 -384 -449 64 -321 minecraft:grass_block
forceload remove -512 -384 -449 -321
forceload add -448 -384 -385 -321
fill -448 60 -384 -385 62 -321 minecraft:stone
fill -448 63 -384 -385 63 -321 minecraft:dirt
fill -448 64 -384 -385 64 -321 minecraft:grass_block
forceload remove -448 -384 -385 -321
scoreboard players add #build_step ms_world 1
