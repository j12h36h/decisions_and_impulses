forceload add -128 -192 -65 -129
fill -128 60 -192 -65 62 -129 minecraft:stone
fill -128 63 -192 -65 63 -129 minecraft:dirt
fill -128 64 -192 -65 64 -129 minecraft:grass_block
forceload remove -128 -192 -65 -129
forceload add -64 -192 -1 -129
fill -64 60 -192 -1 62 -129 minecraft:stone
fill -64 63 -192 -1 63 -129 minecraft:dirt
fill -64 64 -192 -1 64 -129 minecraft:grass_block
forceload remove -64 -192 -1 -129
scoreboard players add #build_step ms_world 1
