forceload add 0 320 63 383
fill 0 60 320 63 62 383 minecraft:stone
fill 0 63 320 63 63 383 minecraft:dirt
fill 0 64 320 63 64 383 minecraft:grass_block
forceload remove 0 320 63 383
forceload add 64 320 127 383
fill 64 60 320 127 62 383 minecraft:stone
fill 64 63 320 127 63 383 minecraft:dirt
fill 64 64 320 127 64 383 minecraft:grass_block
forceload remove 64 320 127 383
scoreboard players add #build_step ms_world 1
