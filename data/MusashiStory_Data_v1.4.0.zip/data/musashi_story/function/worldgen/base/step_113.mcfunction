forceload add -128 384 -65 447
fill -128 60 384 -65 62 447 minecraft:stone
fill -128 63 384 -65 63 447 minecraft:dirt
fill -128 64 384 -65 64 447 minecraft:grass_block
forceload remove -128 384 -65 447
forceload add -64 384 -1 447
fill -64 60 384 -1 62 447 minecraft:stone
fill -64 63 384 -1 63 447 minecraft:dirt
fill -64 64 384 -1 64 447 minecraft:grass_block
forceload remove -64 384 -1 447
scoreboard players add #build_step ms_world 1
