forceload add -256 192 -193 255
fill -256 60 192 -193 62 255 minecraft:stone
fill -256 63 192 -193 63 255 minecraft:dirt
fill -256 64 192 -193 64 255 minecraft:grass_block
forceload remove -256 192 -193 255
forceload add -192 192 -129 255
fill -192 60 192 -129 62 255 minecraft:stone
fill -192 63 192 -129 63 255 minecraft:dirt
fill -192 64 192 -129 64 255 minecraft:grass_block
forceload remove -192 192 -129 255
scoreboard players add #build_step ms_world 1
