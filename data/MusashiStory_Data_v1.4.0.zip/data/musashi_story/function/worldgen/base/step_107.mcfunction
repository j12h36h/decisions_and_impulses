forceload add 128 320 191 383
fill 128 60 320 191 62 383 minecraft:stone
fill 128 63 320 191 63 383 minecraft:dirt
fill 128 64 320 191 64 383 minecraft:grass_block
forceload remove 128 320 191 383
forceload add 192 320 255 383
fill 192 60 320 255 62 383 minecraft:stone
fill 192 63 320 255 63 383 minecraft:dirt
fill 192 64 320 255 64 383 minecraft:grass_block
forceload remove 192 320 255 383
scoreboard players add #build_step ms_world 1
