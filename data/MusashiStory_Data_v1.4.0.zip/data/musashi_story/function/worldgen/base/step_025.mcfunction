forceload add -384 -320 -321 -257
fill -384 60 -320 -321 62 -257 minecraft:stone
fill -384 63 -320 -321 63 -257 minecraft:dirt
fill -384 64 -320 -321 64 -257 minecraft:grass_block
forceload remove -384 -320 -321 -257
forceload add -320 -320 -257 -257
fill -320 60 -320 -257 62 -257 minecraft:stone
fill -320 63 -320 -257 63 -257 minecraft:dirt
fill -320 64 -320 -257 64 -257 minecraft:grass_block
forceload remove -320 -320 -257 -257
scoreboard players add #build_step ms_world 1
