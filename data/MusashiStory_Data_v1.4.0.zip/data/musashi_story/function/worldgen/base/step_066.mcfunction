forceload add -128 0 -65 63
fill -128 60 0 -65 62 63 minecraft:stone
fill -128 63 0 -65 63 63 minecraft:dirt
fill -128 64 0 -65 64 63 minecraft:grass_block
forceload remove -128 0 -65 63
forceload add 64 0 127 63
fill 64 60 0 127 62 63 minecraft:stone
fill 64 63 0 127 63 63 minecraft:dirt
fill 64 64 0 127 64 63 minecraft:grass_block
forceload remove 64 0 127 63
scoreboard players add #build_step ms_world 1
