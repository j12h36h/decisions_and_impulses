# Musashi v1.3.1 base-generation batch 080-089.
execute if score #dispatch ms_world matches 80 run function musashi_story:worldgen/base/step_080
execute if score #dispatch ms_world matches 81 run function musashi_story:worldgen/base/step_081
execute if score #dispatch ms_world matches 82 run function musashi_story:worldgen/base/step_082
execute if score #dispatch ms_world matches 83 run function musashi_story:worldgen/base/step_083
execute if score #dispatch ms_world matches 84 run function musashi_story:worldgen/base/step_084
execute if score #dispatch ms_world matches 85 run function musashi_story:worldgen/base/step_085
execute if score #dispatch ms_world matches 86 run function musashi_story:worldgen/base/step_086
execute if score #dispatch ms_world matches 87 run function musashi_story:worldgen/base/step_087
execute if score #dispatch ms_world matches 88 run function musashi_story:worldgen/base/step_088
execute if score #dispatch ms_world matches 89 run function musashi_story:worldgen/base/step_089
