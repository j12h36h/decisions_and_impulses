forceload add 256 -384 319 -321
fill 256 60 -384 319 62 -321 minecraft:stone
fill 256 63 -384 319 63 -321 minecraft:dirt
fill 256 64 -384 319 64 -321 minecraft:grass_block
forceload remove 256 -384 319 -321
forceload add 320 -384 383 -321
fill 320 60 -384 383 62 -321 minecraft:stone
fill 320 63 -384 383 63 -321 minecraft:dirt
fill 320 64 -384 383 64 -321 minecraft:grass_block
forceload remove 320 -384 383 -321
scoreboard players add #build_step ms_world 1
