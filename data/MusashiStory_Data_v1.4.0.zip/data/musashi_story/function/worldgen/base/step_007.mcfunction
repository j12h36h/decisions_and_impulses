forceload add 384 -512 447 -449
fill 384 60 -512 447 62 -449 minecraft:stone
fill 384 63 -512 447 63 -449 minecraft:dirt
fill 384 64 -512 447 64 -449 minecraft:grass_block
forceload remove 384 -512 447 -449
forceload add 448 -512 511 -449
fill 448 60 -512 511 62 -449 minecraft:stone
fill 448 63 -512 511 63 -449 minecraft:dirt
fill 448 64 -512 511 64 -449 minecraft:grass_block
forceload remove 448 -512 511 -449
scoreboard players add #build_step ms_world 1
