forceload add -384 256 -321 319
fill -384 60 256 -321 62 319 minecraft:stone
fill -384 63 256 -321 63 319 minecraft:dirt
fill -384 64 256 -321 64 319 minecraft:grass_block
forceload remove -384 256 -321 319
forceload add -320 256 -257 319
fill -320 60 256 -257 62 319 minecraft:stone
fill -320 63 256 -257 63 319 minecraft:dirt
fill -320 64 256 -257 64 319 minecraft:grass_block
forceload remove -320 256 -257 319
scoreboard players add #build_step ms_world 1
