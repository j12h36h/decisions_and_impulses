forceload add -384 192 -321 255
fill -384 60 192 -321 62 255 minecraft:stone
fill -384 63 192 -321 63 255 minecraft:dirt
fill -384 64 192 -321 64 255 minecraft:grass_block
forceload remove -384 192 -321 255
forceload add -320 192 -257 255
fill -320 60 192 -257 62 255 minecraft:stone
fill -320 63 192 -257 63 255 minecraft:dirt
fill -320 64 192 -257 64 255 minecraft:grass_block
forceload remove -320 192 -257 255
scoreboard players add #build_step ms_world 1
