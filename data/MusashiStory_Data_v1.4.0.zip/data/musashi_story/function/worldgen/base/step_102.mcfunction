forceload add -512 320 -449 383
fill -512 60 320 -449 62 383 minecraft:stone
fill -512 63 320 -449 63 383 minecraft:dirt
fill -512 64 320 -449 64 383 minecraft:grass_block
forceload remove -512 320 -449 383
forceload add -448 320 -385 383
fill -448 60 320 -385 62 383 minecraft:stone
fill -448 63 320 -385 63 383 minecraft:dirt
fill -448 64 320 -385 64 383 minecraft:grass_block
forceload remove -448 320 -385 383
scoreboard players add #build_step ms_world 1
