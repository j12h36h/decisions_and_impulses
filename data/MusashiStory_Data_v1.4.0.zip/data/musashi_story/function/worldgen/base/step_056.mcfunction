forceload add -512 -64 -449 -1
fill -512 60 -64 -449 62 -1 minecraft:stone
fill -512 63 -64 -449 63 -1 minecraft:dirt
fill -512 64 -64 -449 64 -1 minecraft:grass_block
forceload remove -512 -64 -449 -1
forceload add -448 -64 -385 -1
fill -448 60 -64 -385 62 -1 minecraft:stone
fill -448 63 -64 -385 63 -1 minecraft:dirt
fill -448 64 -64 -385 64 -1 minecraft:grass_block
forceload remove -448 -64 -385 -1
scoreboard players add #build_step ms_world 1
