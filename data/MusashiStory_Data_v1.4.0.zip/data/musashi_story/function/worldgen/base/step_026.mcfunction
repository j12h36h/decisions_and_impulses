forceload add -256 -320 -193 -257
fill -256 60 -320 -193 62 -257 minecraft:stone
fill -256 63 -320 -193 63 -257 minecraft:dirt
fill -256 64 -320 -193 64 -257 minecraft:grass_block
forceload remove -256 -320 -193 -257
forceload add -192 -320 -129 -257
fill -192 60 -320 -129 62 -257 minecraft:stone
fill -192 63 -320 -129 63 -257 minecraft:dirt
fill -192 64 -320 -129 64 -257 minecraft:grass_block
forceload remove -192 -320 -129 -257
scoreboard players add #build_step ms_world 1
