forceload add -256 448 -193 511
fill -256 60 448 -193 62 511 minecraft:stone
fill -256 63 448 -193 63 511 minecraft:dirt
fill -256 64 448 -193 64 511 minecraft:grass_block
forceload remove -256 448 -193 511
forceload add -192 448 -129 511
fill -192 60 448 -129 62 511 minecraft:stone
fill -192 63 448 -129 63 511 minecraft:dirt
fill -192 64 448 -129 64 511 minecraft:grass_block
forceload remove -192 448 -129 511
scoreboard players add #build_step ms_world 1
