forceload add 256 128 319 191
fill 256 60 128 319 62 191 minecraft:stone
fill 256 63 128 319 63 191 minecraft:dirt
fill 256 64 128 319 64 191 minecraft:grass_block
forceload remove 256 128 319 191
forceload add 320 128 383 191
fill 320 60 128 383 62 191 minecraft:stone
fill 320 63 128 383 63 191 minecraft:dirt
fill 320 64 128 383 64 191 minecraft:grass_block
forceload remove 320 128 383 191
scoreboard players add #build_step ms_world 1
