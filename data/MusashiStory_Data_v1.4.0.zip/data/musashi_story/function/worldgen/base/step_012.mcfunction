forceload add 0 -448 63 -385
fill 0 60 -448 63 62 -385 minecraft:stone
fill 0 63 -448 63 63 -385 minecraft:dirt
fill 0 64 -448 63 64 -385 minecraft:grass_block
forceload remove 0 -448 63 -385
forceload add 64 -448 127 -385
fill 64 60 -448 127 62 -385 minecraft:stone
fill 64 63 -448 127 63 -385 minecraft:dirt
fill 64 64 -448 127 64 -385 minecraft:grass_block
forceload remove 64 -448 127 -385
scoreboard players add #build_step ms_world 1
