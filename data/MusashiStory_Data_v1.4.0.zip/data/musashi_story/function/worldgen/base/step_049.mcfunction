forceload add -384 -128 -321 -65
fill -384 60 -128 -321 62 -65 minecraft:stone
fill -384 63 -128 -321 63 -65 minecraft:dirt
fill -384 64 -128 -321 64 -65 minecraft:grass_block
forceload remove -384 -128 -321 -65
forceload add -320 -128 -257 -65
fill -320 60 -128 -257 62 -65 minecraft:stone
fill -320 63 -128 -257 63 -65 minecraft:dirt
fill -320 64 -128 -257 64 -65 minecraft:grass_block
forceload remove -320 -128 -257 -65
scoreboard players add #build_step ms_world 1
