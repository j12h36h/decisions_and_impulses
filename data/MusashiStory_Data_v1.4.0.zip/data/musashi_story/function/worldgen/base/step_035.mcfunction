forceload add -128 -256 -65 -193
fill -128 60 -256 -65 62 -193 minecraft:stone
fill -128 63 -256 -65 63 -193 minecraft:dirt
fill -128 64 -256 -65 64 -193 minecraft:grass_block
forceload remove -128 -256 -65 -193
forceload add -64 -256 -1 -193
fill -64 60 -256 -1 62 -193 minecraft:stone
fill -64 63 -256 -1 63 -193 minecraft:dirt
fill -64 64 -256 -1 64 -193 minecraft:grass_block
forceload remove -64 -256 -1 -193
scoreboard players add #build_step ms_world 1
