forceload add -384 448 -321 511
fill -384 60 448 -321 62 511 minecraft:stone
fill -384 63 448 -321 63 511 minecraft:dirt
fill -384 64 448 -321 64 511 minecraft:grass_block
forceload remove -384 448 -321 511
forceload add -320 448 -257 511
fill -320 60 448 -257 62 511 minecraft:stone
fill -320 63 448 -257 63 511 minecraft:dirt
fill -320 64 448 -257 64 511 minecraft:grass_block
forceload remove -320 448 -257 511
scoreboard players add #build_step ms_world 1
