forceload add -128 256 -65 319
fill -128 60 256 -65 62 319 minecraft:stone
fill -128 63 256 -65 63 319 minecraft:dirt
fill -128 64 256 -65 64 319 minecraft:grass_block
forceload remove -128 256 -65 319
forceload add -64 256 -1 319
fill -64 60 256 -1 62 319 minecraft:stone
fill -64 63 256 -1 63 319 minecraft:dirt
fill -64 64 256 -1 64 319 minecraft:grass_block
forceload remove -64 256 -1 319
scoreboard players add #build_step ms_world 1
