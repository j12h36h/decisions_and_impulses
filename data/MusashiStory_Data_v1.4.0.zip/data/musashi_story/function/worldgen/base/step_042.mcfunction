forceload add -256 -192 -193 -129
fill -256 60 -192 -193 62 -129 minecraft:stone
fill -256 63 -192 -193 63 -129 minecraft:dirt
fill -256 64 -192 -193 64 -129 minecraft:grass_block
forceload remove -256 -192 -193 -129
forceload add -192 -192 -129 -129
fill -192 60 -192 -129 62 -129 minecraft:stone
fill -192 63 -192 -129 63 -129 minecraft:dirt
fill -192 64 -192 -129 64 -129 minecraft:grass_block
forceload remove -192 -192 -129 -129
scoreboard players add #build_step ms_world 1
