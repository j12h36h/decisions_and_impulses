forceload add 256 -64 319 -1
fill 256 60 -64 319 62 -1 minecraft:stone
fill 256 63 -64 319 63 -1 minecraft:dirt
fill 256 64 -64 319 64 -1 minecraft:grass_block
forceload remove 256 -64 319 -1
forceload add 320 -64 383 -1
fill 320 60 -64 383 62 -1 minecraft:stone
fill 320 63 -64 383 63 -1 minecraft:dirt
fill 320 64 -64 383 64 -1 minecraft:grass_block
forceload remove 320 -64 383 -1
scoreboard players add #build_step ms_world 1
