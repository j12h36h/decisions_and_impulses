forceload add -128 -448 -65 -385
fill -128 60 -448 -65 62 -385 minecraft:stone
fill -128 63 -448 -65 63 -385 minecraft:dirt
fill -128 64 -448 -65 64 -385 minecraft:grass_block
forceload remove -128 -448 -65 -385
forceload add -64 -448 -1 -385
fill -64 60 -448 -1 62 -385 minecraft:stone
fill -64 63 -448 -1 63 -385 minecraft:dirt
fill -64 64 -448 -1 64 -385 minecraft:grass_block
forceload remove -64 -448 -1 -385
scoreboard players add #build_step ms_world 1
