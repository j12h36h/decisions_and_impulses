forceload add -512 64 -449 127
fill -512 60 64 -449 62 127 minecraft:stone
fill -512 63 64 -449 63 127 minecraft:dirt
fill -512 64 64 -449 64 127 minecraft:grass_block
forceload remove -512 64 -449 127
forceload add -448 64 -385 127
fill -448 60 64 -385 62 127 minecraft:stone
fill -448 63 64 -385 63 127 minecraft:dirt
fill -448 64 64 -385 64 127 minecraft:grass_block
forceload remove -448 64 -385 127
scoreboard players add #build_step ms_world 1
