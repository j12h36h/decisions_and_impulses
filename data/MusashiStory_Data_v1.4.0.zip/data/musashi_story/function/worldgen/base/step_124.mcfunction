forceload add 256 448 319 511
fill 256 60 448 319 62 511 minecraft:stone
fill 256 63 448 319 63 511 minecraft:dirt
fill 256 64 448 319 64 511 minecraft:grass_block
forceload remove 256 448 319 511
forceload add 320 448 383 511
fill 320 60 448 383 62 511 minecraft:stone
fill 320 63 448 383 63 511 minecraft:dirt
fill 320 64 448 383 64 511 minecraft:grass_block
forceload remove 320 448 383 511
scoreboard players add #build_step ms_world 1
