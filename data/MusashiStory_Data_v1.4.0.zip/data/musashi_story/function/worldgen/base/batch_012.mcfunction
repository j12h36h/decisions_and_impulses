# Musashi v1.3.1 base-generation batch 120-125.
execute if score #dispatch ms_world matches 120 run function musashi_story:worldgen/base/step_120
execute if score #dispatch ms_world matches 121 run function musashi_story:worldgen/base/step_121
execute if score #dispatch ms_world matches 122 run function musashi_story:worldgen/base/step_122
execute if score #dispatch ms_world matches 123 run function musashi_story:worldgen/base/step_123
execute if score #dispatch ms_world matches 124 run function musashi_story:worldgen/base/step_124
execute if score #dispatch ms_world matches 125 run function musashi_story:worldgen/base/step_125
