forceload add -256 256 -193 319
fill -256 60 256 -193 62 319 minecraft:stone
fill -256 63 256 -193 63 319 minecraft:dirt
fill -256 64 256 -193 64 319 minecraft:grass_block
forceload remove -256 256 -193 319
forceload add -192 256 -129 319
fill -192 60 256 -129 62 319 minecraft:stone
fill -192 63 256 -129 63 319 minecraft:dirt
fill -192 64 256 -129 64 319 minecraft:grass_block
forceload remove -192 256 -129 319
scoreboard players add #build_step ms_world 1
