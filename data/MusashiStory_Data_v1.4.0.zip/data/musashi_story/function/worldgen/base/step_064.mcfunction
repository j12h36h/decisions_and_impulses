forceload add -384 0 -321 63
fill -384 60 0 -321 62 63 minecraft:stone
fill -384 63 0 -321 63 63 minecraft:dirt
fill -384 64 0 -321 64 63 minecraft:grass_block
forceload remove -384 0 -321 63
forceload add -320 0 -257 63
fill -320 60 0 -257 62 63 minecraft:stone
fill -320 63 0 -257 63 63 minecraft:dirt
fill -320 64 0 -257 64 63 minecraft:grass_block
forceload remove -320 0 -257 63
scoreboard players add #build_step ms_world 1
