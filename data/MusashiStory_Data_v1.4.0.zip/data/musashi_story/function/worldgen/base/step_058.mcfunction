forceload add -256 -64 -193 -1
fill -256 60 -64 -193 62 -1 minecraft:stone
fill -256 63 -64 -193 63 -1 minecraft:dirt
fill -256 64 -64 -193 64 -1 minecraft:grass_block
forceload remove -256 -64 -193 -1
forceload add -192 -64 -129 -1
fill -192 60 -64 -129 62 -1 minecraft:stone
fill -192 63 -64 -129 63 -1 minecraft:dirt
fill -192 64 -64 -129 64 -1 minecraft:grass_block
forceload remove -192 -64 -129 -1
scoreboard players add #build_step ms_world 1
