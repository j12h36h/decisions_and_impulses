forceload add 128 128 191 191
fill 128 60 128 191 62 191 minecraft:stone
fill 128 63 128 191 63 191 minecraft:dirt
fill 128 64 128 191 64 191 minecraft:grass_block
forceload remove 128 128 191 191
forceload add 192 128 255 191
fill 192 60 128 255 62 191 minecraft:stone
fill 192 63 128 255 63 191 minecraft:dirt
fill 192 64 128 255 64 191 minecraft:grass_block
forceload remove 192 128 255 191
scoreboard players add #build_step ms_world 1
