forceload add -384 64 -321 127
fill -384 60 64 -321 62 127 minecraft:stone
fill -384 63 64 -321 63 127 minecraft:dirt
fill -384 64 64 -321 64 127 minecraft:grass_block
forceload remove -384 64 -321 127
forceload add -320 64 -257 127
fill -320 60 64 -257 62 127 minecraft:stone
fill -320 63 64 -257 63 127 minecraft:dirt
fill -320 64 64 -257 64 127 minecraft:grass_block
forceload remove -320 64 -257 127
scoreboard players add #build_step ms_world 1
