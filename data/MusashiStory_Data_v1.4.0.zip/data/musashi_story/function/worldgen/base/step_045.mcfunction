forceload add 128 -192 191 -129
fill 128 60 -192 191 62 -129 minecraft:stone
fill 128 63 -192 191 63 -129 minecraft:dirt
fill 128 64 -192 191 64 -129 minecraft:grass_block
forceload remove 128 -192 191 -129
forceload add 192 -192 255 -129
fill 192 60 -192 255 62 -129 minecraft:stone
fill 192 63 -192 255 63 -129 minecraft:dirt
fill 192 64 -192 255 64 -129 minecraft:grass_block
forceload remove 192 -192 255 -129
scoreboard players add #build_step ms_world 1
