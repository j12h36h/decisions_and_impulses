forceload add -384 384 -321 447
fill -384 60 384 -321 62 447 minecraft:stone
fill -384 63 384 -321 63 447 minecraft:dirt
fill -384 64 384 -321 64 447 minecraft:grass_block
forceload remove -384 384 -321 447
forceload add -320 384 -257 447
fill -320 60 384 -257 62 447 minecraft:stone
fill -320 63 384 -257 63 447 minecraft:dirt
fill -320 64 384 -257 64 447 minecraft:grass_block
forceload remove -320 384 -257 447
scoreboard players add #build_step ms_world 1
