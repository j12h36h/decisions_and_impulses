forceload add 0 -192 63 -129
fill 0 60 -192 63 62 -129 minecraft:stone
fill 0 63 -192 63 63 -129 minecraft:dirt
fill 0 64 -192 63 64 -129 minecraft:grass_block
forceload remove 0 -192 63 -129
forceload add 64 -192 127 -129
fill 64 60 -192 127 62 -129 minecraft:stone
fill 64 63 -192 127 63 -129 minecraft:dirt
fill 64 64 -192 127 64 -129 minecraft:grass_block
forceload remove 64 -192 127 -129
scoreboard players add #build_step ms_world 1
