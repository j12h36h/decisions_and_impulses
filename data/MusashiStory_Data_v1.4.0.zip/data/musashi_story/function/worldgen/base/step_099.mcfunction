forceload add 128 256 191 319
fill 128 60 256 191 62 319 minecraft:stone
fill 128 63 256 191 63 319 minecraft:dirt
fill 128 64 256 191 64 319 minecraft:grass_block
forceload remove 128 256 191 319
forceload add 192 256 255 319
fill 192 60 256 255 62 319 minecraft:stone
fill 192 63 256 255 63 319 minecraft:dirt
fill 192 64 256 255 64 319 minecraft:grass_block
forceload remove 192 256 255 319
scoreboard players add #build_step ms_world 1
