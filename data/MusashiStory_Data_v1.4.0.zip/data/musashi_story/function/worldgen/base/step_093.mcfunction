forceload add 384 192 447 255
fill 384 60 192 447 62 255 minecraft:stone
fill 384 63 192 447 63 255 minecraft:dirt
fill 384 64 192 447 64 255 minecraft:grass_block
forceload remove 384 192 447 255
forceload add 448 192 511 255
fill 448 60 192 511 62 255 minecraft:stone
fill 448 63 192 511 63 255 minecraft:dirt
fill 448 64 192 511 64 255 minecraft:grass_block
forceload remove 448 192 511 255
scoreboard players add #build_step ms_world 1
