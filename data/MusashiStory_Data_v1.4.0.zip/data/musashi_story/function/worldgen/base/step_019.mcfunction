forceload add -128 -384 -65 -321
fill -128 60 -384 -65 62 -321 minecraft:stone
fill -128 63 -384 -65 63 -321 minecraft:dirt
fill -128 64 -384 -65 64 -321 minecraft:grass_block
forceload remove -128 -384 -65 -321
forceload add -64 -384 -1 -321
fill -64 60 -384 -1 62 -321 minecraft:stone
fill -64 63 -384 -1 63 -321 minecraft:dirt
fill -64 64 -384 -1 64 -321 minecraft:grass_block
forceload remove -64 -384 -1 -321
scoreboard players add #build_step ms_world 1
