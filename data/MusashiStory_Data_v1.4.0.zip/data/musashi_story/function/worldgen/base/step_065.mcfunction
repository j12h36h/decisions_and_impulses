forceload add -256 0 -193 63
fill -256 60 0 -193 62 63 minecraft:stone
fill -256 63 0 -193 63 63 minecraft:dirt
fill -256 64 0 -193 64 63 minecraft:grass_block
forceload remove -256 0 -193 63
forceload add -192 0 -129 63
fill -192 60 0 -129 62 63 minecraft:stone
fill -192 63 0 -129 63 63 minecraft:dirt
fill -192 64 0 -129 64 63 minecraft:grass_block
forceload remove -192 0 -129 63
scoreboard players add #build_step ms_world 1
