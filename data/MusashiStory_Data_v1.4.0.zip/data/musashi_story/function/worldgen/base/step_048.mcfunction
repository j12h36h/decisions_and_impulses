forceload add -512 -128 -449 -65
fill -512 60 -128 -449 62 -65 minecraft:stone
fill -512 63 -128 -449 63 -65 minecraft:dirt
fill -512 64 -128 -449 64 -65 minecraft:grass_block
forceload remove -512 -128 -449 -65
forceload add -448 -128 -385 -65
fill -448 60 -128 -385 62 -65 minecraft:stone
fill -448 63 -128 -385 63 -65 minecraft:dirt
fill -448 64 -128 -385 64 -65 minecraft:grass_block
forceload remove -448 -128 -385 -65
scoreboard players add #build_step ms_world 1
