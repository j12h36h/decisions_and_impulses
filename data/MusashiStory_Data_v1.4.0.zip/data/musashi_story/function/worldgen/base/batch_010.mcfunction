# Musashi v1.3.1 base-generation batch 100-109.
execute if score #dispatch ms_world matches 100 run function musashi_story:worldgen/base/step_100
execute if score #dispatch ms_world matches 101 run function musashi_story:worldgen/base/step_101
execute if score #dispatch ms_world matches 102 run function musashi_story:worldgen/base/step_102
execute if score #dispatch ms_world matches 103 run function musashi_story:worldgen/base/step_103
execute if score #dispatch ms_world matches 104 run function musashi_story:worldgen/base/step_104
execute if score #dispatch ms_world matches 105 run function musashi_story:worldgen/base/step_105
execute if score #dispatch ms_world matches 106 run function musashi_story:worldgen/base/step_106
execute if score #dispatch ms_world matches 107 run function musashi_story:worldgen/base/step_107
execute if score #dispatch ms_world matches 108 run function musashi_story:worldgen/base/step_108
execute if score #dispatch ms_world matches 109 run function musashi_story:worldgen/base/step_109
