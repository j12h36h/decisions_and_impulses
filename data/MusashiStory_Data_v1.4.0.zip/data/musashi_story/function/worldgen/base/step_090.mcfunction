forceload add 0 192 63 255
fill 0 60 192 63 62 255 minecraft:stone
fill 0 63 192 63 63 255 minecraft:dirt
fill 0 64 192 63 64 255 minecraft:grass_block
forceload remove 0 192 63 255
forceload add 64 192 127 255
fill 64 60 192 127 62 255 minecraft:stone
fill 64 63 192 127 63 255 minecraft:dirt
fill 64 64 192 127 64 255 minecraft:grass_block
forceload remove 64 192 127 255
scoreboard players add #build_step ms_world 1
