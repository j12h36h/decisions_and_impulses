forceload add 384 0 447 63
fill 384 60 0 447 62 63 minecraft:stone
fill 384 63 0 447 63 63 minecraft:dirt
fill 384 64 0 447 64 63 minecraft:grass_block
forceload remove 384 0 447 63
forceload add 448 0 511 63
fill 448 60 0 511 62 63 minecraft:stone
fill 448 63 0 511 63 63 minecraft:dirt
fill 448 64 0 511 64 63 minecraft:grass_block
forceload remove 448 0 511 63
scoreboard players add #build_step ms_world 1
