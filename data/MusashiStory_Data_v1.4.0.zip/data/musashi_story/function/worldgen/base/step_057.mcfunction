forceload add -384 -64 -321 -1
fill -384 60 -64 -321 62 -1 minecraft:stone
fill -384 63 -64 -321 63 -1 minecraft:dirt
fill -384 64 -64 -321 64 -1 minecraft:grass_block
forceload remove -384 -64 -321 -1
forceload add -320 -64 -257 -1
fill -320 60 -64 -257 62 -1 minecraft:stone
fill -320 63 -64 -257 63 -1 minecraft:dirt
fill -320 64 -64 -257 64 -1 minecraft:grass_block
forceload remove -320 -64 -257 -1
scoreboard players add #build_step ms_world 1
