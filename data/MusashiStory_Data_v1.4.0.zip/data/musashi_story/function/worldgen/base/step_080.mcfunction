forceload add -256 128 -193 191
fill -256 60 128 -193 62 191 minecraft:stone
fill -256 63 128 -193 63 191 minecraft:dirt
fill -256 64 128 -193 64 191 minecraft:grass_block
forceload remove -256 128 -193 191
forceload add -192 128 -129 191
fill -192 60 128 -129 62 191 minecraft:stone
fill -192 63 128 -129 63 191 minecraft:dirt
fill -192 64 128 -129 64 191 minecraft:grass_block
forceload remove -192 128 -129 191
scoreboard players add #build_step ms_world 1
