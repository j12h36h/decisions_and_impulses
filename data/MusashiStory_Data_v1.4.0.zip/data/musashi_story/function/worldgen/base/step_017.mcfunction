forceload add -384 -384 -321 -321
fill -384 60 -384 -321 62 -321 minecraft:stone
fill -384 63 -384 -321 63 -321 minecraft:dirt
fill -384 64 -384 -321 64 -321 minecraft:grass_block
forceload remove -384 -384 -321 -321
forceload add -320 -384 -257 -321
fill -320 60 -384 -257 62 -321 minecraft:stone
fill -320 63 -384 -257 63 -321 minecraft:dirt
fill -320 64 -384 -257 64 -321 minecraft:grass_block
forceload remove -320 -384 -257 -321
scoreboard players add #build_step ms_world 1
