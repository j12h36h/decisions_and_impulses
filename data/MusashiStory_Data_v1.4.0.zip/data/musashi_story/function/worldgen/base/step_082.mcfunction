forceload add 0 128 63 191
fill 0 60 128 63 62 191 minecraft:stone
fill 0 63 128 63 63 191 minecraft:dirt
fill 0 64 128 63 64 191 minecraft:grass_block
forceload remove 0 128 63 191
forceload add 64 128 127 191
fill 64 60 128 127 62 191 minecraft:stone
fill 64 63 128 127 63 191 minecraft:dirt
fill 64 64 128 127 64 191 minecraft:grass_block
forceload remove 64 128 127 191
scoreboard players add #build_step ms_world 1
