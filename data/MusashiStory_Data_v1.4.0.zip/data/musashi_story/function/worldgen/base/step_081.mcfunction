forceload add -128 128 -65 191
fill -128 60 128 -65 62 191 minecraft:stone
fill -128 63 128 -65 63 191 minecraft:dirt
fill -128 64 128 -65 64 191 minecraft:grass_block
forceload remove -128 128 -65 191
forceload add -64 128 -1 191
fill -64 60 128 -1 62 191 minecraft:stone
fill -64 63 128 -1 63 191 minecraft:dirt
fill -64 64 128 -1 64 191 minecraft:grass_block
forceload remove -64 128 -1 191
scoreboard players add #build_step ms_world 1
