forceload add 128 -512 191 -449
fill 128 60 -512 191 62 -449 minecraft:stone
fill 128 63 -512 191 63 -449 minecraft:dirt
fill 128 64 -512 191 64 -449 minecraft:grass_block
forceload remove 128 -512 191 -449
forceload add 192 -512 255 -449
fill 192 60 -512 255 62 -449 minecraft:stone
fill 192 63 -512 255 63 -449 minecraft:dirt
fill 192 64 -512 255 64 -449 minecraft:grass_block
forceload remove 192 -512 255 -449
scoreboard players add #build_step ms_world 1
