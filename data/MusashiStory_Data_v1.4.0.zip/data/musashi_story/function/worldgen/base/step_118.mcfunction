forceload add -512 448 -449 511
fill -512 60 448 -449 62 511 minecraft:stone
fill -512 63 448 -449 63 511 minecraft:dirt
fill -512 64 448 -449 64 511 minecraft:grass_block
forceload remove -512 448 -449 511
forceload add -448 448 -385 511
fill -448 60 448 -385 62 511 minecraft:stone
fill -448 63 448 -385 63 511 minecraft:dirt
fill -448 64 448 -385 64 511 minecraft:grass_block
forceload remove -448 448 -385 511
scoreboard players add #build_step ms_world 1
