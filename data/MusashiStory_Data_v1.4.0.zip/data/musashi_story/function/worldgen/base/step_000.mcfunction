forceload add -512 -512 -449 -449
fill -512 60 -512 -449 62 -449 minecraft:stone
fill -512 63 -512 -449 63 -449 minecraft:dirt
fill -512 64 -512 -449 64 -449 minecraft:grass_block
forceload remove -512 -512 -449 -449
forceload add -448 -512 -385 -449
fill -448 60 -512 -385 62 -449 minecraft:stone
fill -448 63 -512 -385 63 -449 minecraft:dirt
fill -448 64 -512 -385 64 -449 minecraft:grass_block
forceload remove -448 -512 -385 -449
scoreboard players add #build_step ms_world 1
