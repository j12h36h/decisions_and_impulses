forceload add -512 0 -449 63
fill -512 60 0 -449 62 63 minecraft:stone
fill -512 63 0 -449 63 63 minecraft:dirt
fill -512 64 0 -449 64 63 minecraft:grass_block
forceload remove -512 0 -449 63
forceload add -448 0 -385 63
fill -448 60 0 -385 62 63 minecraft:stone
fill -448 63 0 -385 63 63 minecraft:dirt
fill -448 64 0 -385 64 63 minecraft:grass_block
forceload remove -448 0 -385 63
scoreboard players add #build_step ms_world 1
