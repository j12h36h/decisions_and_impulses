forceload add -256 -384 -193 -321
fill -256 60 -384 -193 62 -321 minecraft:stone
fill -256 63 -384 -193 63 -321 minecraft:dirt
fill -256 64 -384 -193 64 -321 minecraft:grass_block
forceload remove -256 -384 -193 -321
forceload add -192 -384 -129 -321
fill -192 60 -384 -129 62 -321 minecraft:stone
fill -192 63 -384 -129 63 -321 minecraft:dirt
fill -192 64 -384 -129 64 -321 minecraft:grass_block
forceload remove -192 -384 -129 -321
scoreboard players add #build_step ms_world 1
