forceload add 384 -192 447 -129
fill 384 60 -192 447 62 -129 minecraft:stone
fill 384 63 -192 447 63 -129 minecraft:dirt
fill 384 64 -192 447 64 -129 minecraft:grass_block
forceload remove 384 -192 447 -129
forceload add 448 -192 511 -129
fill 448 60 -192 511 62 -129 minecraft:stone
fill 448 63 -192 511 63 -129 minecraft:dirt
fill 448 64 -192 511 64 -129 minecraft:grass_block
forceload remove 448 -192 511 -129
scoreboard players add #build_step ms_world 1
