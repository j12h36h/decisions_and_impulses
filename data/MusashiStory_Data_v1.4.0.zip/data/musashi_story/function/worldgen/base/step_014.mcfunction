forceload add 256 -448 319 -385
fill 256 60 -448 319 62 -385 minecraft:stone
fill 256 63 -448 319 63 -385 minecraft:dirt
fill 256 64 -448 319 64 -385 minecraft:grass_block
forceload remove 256 -448 319 -385
forceload add 320 -448 383 -385
fill 320 60 -448 383 62 -385 minecraft:stone
fill 320 63 -448 383 63 -385 minecraft:dirt
fill 320 64 -448 383 64 -385 minecraft:grass_block
forceload remove 320 -448 383 -385
scoreboard players add #build_step ms_world 1
