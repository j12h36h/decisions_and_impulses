forceload add 128 384 191 447
fill 128 60 384 191 62 447 minecraft:stone
fill 128 63 384 191 63 447 minecraft:dirt
fill 128 64 384 191 64 447 minecraft:grass_block
forceload remove 128 384 191 447
forceload add 192 384 255 447
fill 192 60 384 255 62 447 minecraft:stone
fill 192 63 384 255 63 447 minecraft:dirt
fill 192 64 384 255 64 447 minecraft:grass_block
forceload remove 192 384 255 447
scoreboard players add #build_step ms_world 1
