forceload add 384 128 447 191
fill 384 60 128 447 62 191 minecraft:stone
fill 384 63 128 447 63 191 minecraft:dirt
fill 384 64 128 447 64 191 minecraft:grass_block
forceload remove 384 128 447 191
forceload add 448 128 511 191
fill 448 60 128 511 62 191 minecraft:stone
fill 448 63 128 511 63 191 minecraft:dirt
fill 448 64 128 511 64 191 minecraft:grass_block
forceload remove 448 128 511 191
scoreboard players add #build_step ms_world 1
