forceload add -128 192 -65 255
fill -128 60 192 -65 62 255 minecraft:stone
fill -128 63 192 -65 63 255 minecraft:dirt
fill -128 64 192 -65 64 255 minecraft:grass_block
forceload remove -128 192 -65 255
forceload add -64 192 -1 255
fill -64 60 192 -1 62 255 minecraft:stone
fill -64 63 192 -1 63 255 minecraft:dirt
fill -64 64 192 -1 64 255 minecraft:grass_block
forceload remove -64 192 -1 255
scoreboard players add #build_step ms_world 1
