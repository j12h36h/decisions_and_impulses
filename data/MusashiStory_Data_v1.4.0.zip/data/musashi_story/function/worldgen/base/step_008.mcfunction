forceload add -512 -448 -449 -385
fill -512 60 -448 -449 62 -385 minecraft:stone
fill -512 63 -448 -449 63 -385 minecraft:dirt
fill -512 64 -448 -449 64 -385 minecraft:grass_block
forceload remove -512 -448 -449 -385
forceload add -448 -448 -385 -385
fill -448 60 -448 -385 62 -385 minecraft:stone
fill -448 63 -448 -385 63 -385 minecraft:dirt
fill -448 64 -448 -385 64 -385 minecraft:grass_block
forceload remove -448 -448 -385 -385
scoreboard players add #build_step ms_world 1
