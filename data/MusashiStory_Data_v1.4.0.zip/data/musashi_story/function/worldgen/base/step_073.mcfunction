forceload add -128 64 -65 127
fill -128 60 64 -65 62 127 minecraft:stone
fill -128 63 64 -65 63 127 minecraft:dirt
fill -128 64 64 -65 64 127 minecraft:grass_block
forceload remove -128 64 -65 127
forceload add -64 64 -1 127
fill -64 60 64 -1 62 127 minecraft:stone
fill -64 63 64 -1 63 127 minecraft:dirt
fill -64 64 64 -1 64 127 minecraft:grass_block
forceload remove -64 64 -1 127
scoreboard players add #build_step ms_world 1
