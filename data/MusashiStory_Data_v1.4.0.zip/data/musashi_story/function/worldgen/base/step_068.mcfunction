forceload add 256 0 319 63
fill 256 60 0 319 62 63 minecraft:stone
fill 256 63 0 319 63 63 minecraft:dirt
fill 256 64 0 319 64 63 minecraft:grass_block
forceload remove 256 0 319 63
forceload add 320 0 383 63
fill 320 60 0 383 62 63 minecraft:stone
fill 320 63 0 383 63 63 minecraft:dirt
fill 320 64 0 383 64 63 minecraft:grass_block
forceload remove 320 0 383 63
scoreboard players add #build_step ms_world 1
