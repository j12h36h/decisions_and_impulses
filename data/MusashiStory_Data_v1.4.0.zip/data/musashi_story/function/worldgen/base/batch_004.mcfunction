# Musashi v1.3.1 base-generation batch 040-049.
execute if score #dispatch ms_world matches 40 run function musashi_story:worldgen/base/step_040
execute if score #dispatch ms_world matches 41 run function musashi_story:worldgen/base/step_041
execute if score #dispatch ms_world matches 42 run function musashi_story:worldgen/base/step_042
execute if score #dispatch ms_world matches 43 run function musashi_story:worldgen/base/step_043
execute if score #dispatch ms_world matches 44 run function musashi_story:worldgen/base/step_044
execute if score #dispatch ms_world matches 45 run function musashi_story:worldgen/base/step_045
execute if score #dispatch ms_world matches 46 run function musashi_story:worldgen/base/step_046
execute if score #dispatch ms_world matches 47 run function musashi_story:worldgen/base/step_047
execute if score #dispatch ms_world matches 48 run function musashi_story:worldgen/base/step_048
execute if score #dispatch ms_world matches 49 run function musashi_story:worldgen/base/step_049
