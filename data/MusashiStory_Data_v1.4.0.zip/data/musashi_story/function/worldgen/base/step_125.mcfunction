forceload add 384 448 447 511
fill 384 60 448 447 62 511 minecraft:stone
fill 384 63 448 447 63 511 minecraft:dirt
fill 384 64 448 447 64 511 minecraft:grass_block
forceload remove 384 448 447 511
forceload add 448 448 511 511
fill 448 60 448 511 62 511 minecraft:stone
fill 448 63 448 511 63 511 minecraft:dirt
fill 448 64 448 511 64 511 minecraft:grass_block
forceload remove 448 448 511 511
scoreboard players set #build_step ms_world 126
function musashi_story:worldgen/base/finish
