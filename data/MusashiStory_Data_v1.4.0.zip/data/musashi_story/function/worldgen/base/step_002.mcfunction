forceload add -256 -512 -193 -449
fill -256 60 -512 -193 62 -449 minecraft:stone
fill -256 63 -512 -193 63 -449 minecraft:dirt
fill -256 64 -512 -193 64 -449 minecraft:grass_block
forceload remove -256 -512 -193 -449
forceload add -192 -512 -129 -449
fill -192 60 -512 -129 62 -449 minecraft:stone
fill -192 63 -512 -129 63 -449 minecraft:dirt
fill -192 64 -512 -129 64 -449 minecraft:grass_block
forceload remove -192 -512 -129 -449
scoreboard players add #build_step ms_world 1
