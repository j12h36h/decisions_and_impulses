
scoreboard players set #built ms_world 1
scoreboard players set #gen_active ms_world 0
scoreboard players set #modern_v120 ms_world 1
scoreboard players set #modern_v130 ms_world 1
scoreboard players set #modern_v131 ms_world 1
scoreboard players set #modern_v132 ms_world 1
scoreboard players set #modern_v134 ms_world 1
scoreboard players set #modern_v133 ms_world 1
bossbar set musashi_story:loading value 126
bossbar set musashi_story:loading visible false
data modify storage musashi_story:runtime generation_complete set value 1b
tellraw @a[tag=ms_player] [{"text":"PROVINCE FORGED // ","color":"gold","bold":true},{"text":"THE ROAD IS OPEN","color":"white"}]
