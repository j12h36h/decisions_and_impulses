forceload add -128 -512 -65 -449
fill -128 60 -512 -65 62 -449 minecraft:stone
fill -128 63 -512 -65 63 -449 minecraft:dirt
fill -128 64 -512 -65 64 -449 minecraft:grass_block
forceload remove -128 -512 -65 -449
forceload add -64 -512 -1 -449
fill -64 60 -512 -1 62 -449 minecraft:stone
fill -64 63 -512 -1 63 -449 minecraft:dirt
fill -64 64 -512 -1 64 -449 minecraft:grass_block
forceload remove -64 -512 -1 -449
scoreboard players add #build_step ms_world 1
