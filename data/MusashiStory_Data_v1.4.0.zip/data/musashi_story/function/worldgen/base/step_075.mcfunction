forceload add 128 64 191 127
fill 128 60 64 191 62 127 minecraft:stone
fill 128 63 64 191 63 127 minecraft:dirt
fill 128 64 64 191 64 127 minecraft:grass_block
forceload remove 128 64 191 127
forceload add 192 64 255 127
fill 192 60 64 255 62 127 minecraft:stone
fill 192 63 64 255 63 127 minecraft:dirt
fill 192 64 64 255 64 127 minecraft:grass_block
forceload remove 192 64 255 127
scoreboard players add #build_step ms_world 1
