forceload add 256 -256 319 -193
fill 256 60 -256 319 62 -193 minecraft:stone
fill 256 63 -256 319 63 -193 minecraft:dirt
fill 256 64 -256 319 64 -193 minecraft:grass_block
forceload remove 256 -256 319 -193
forceload add 320 -256 383 -193
fill 320 60 -256 383 62 -193 minecraft:stone
fill 320 63 -256 383 63 -193 minecraft:dirt
fill 320 64 -256 383 64 -193 minecraft:grass_block
forceload remove 320 -256 383 -193
scoreboard players add #build_step ms_world 1
