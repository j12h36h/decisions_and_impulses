forceload add 384 -448 447 -385
fill 384 60 -448 447 62 -385 minecraft:stone
fill 384 63 -448 447 63 -385 minecraft:dirt
fill 384 64 -448 447 64 -385 minecraft:grass_block
forceload remove 384 -448 447 -385
forceload add 448 -448 511 -385
fill 448 60 -448 511 62 -385 minecraft:stone
fill 448 63 -448 511 63 -385 minecraft:dirt
fill 448 64 -448 511 64 -385 minecraft:grass_block
forceload remove 448 -448 511 -385
scoreboard players add #build_step ms_world 1
