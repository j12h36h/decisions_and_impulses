forceload add -256 320 -193 383
fill -256 60 320 -193 62 383 minecraft:stone
fill -256 63 320 -193 63 383 minecraft:dirt
fill -256 64 320 -193 64 383 minecraft:grass_block
forceload remove -256 320 -193 383
forceload add -192 320 -129 383
fill -192 60 320 -129 62 383 minecraft:stone
fill -192 63 320 -129 63 383 minecraft:dirt
fill -192 64 320 -129 64 383 minecraft:grass_block
forceload remove -192 320 -129 383
scoreboard players add #build_step ms_world 1
