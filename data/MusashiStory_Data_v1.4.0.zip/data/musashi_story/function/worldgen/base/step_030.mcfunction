forceload add 256 -320 319 -257
fill 256 60 -320 319 62 -257 minecraft:stone
fill 256 63 -320 319 63 -257 minecraft:dirt
fill 256 64 -320 319 64 -257 minecraft:grass_block
forceload remove 256 -320 319 -257
forceload add 320 -320 383 -257
fill 320 60 -320 383 62 -257 minecraft:stone
fill 320 63 -320 383 63 -257 minecraft:dirt
fill 320 64 -320 383 64 -257 minecraft:grass_block
forceload remove 320 -320 383 -257
scoreboard players add #build_step ms_world 1
