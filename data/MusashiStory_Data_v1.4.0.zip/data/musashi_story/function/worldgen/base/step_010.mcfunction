forceload add -256 -448 -193 -385
fill -256 60 -448 -193 62 -385 minecraft:stone
fill -256 63 -448 -193 63 -385 minecraft:dirt
fill -256 64 -448 -193 64 -385 minecraft:grass_block
forceload remove -256 -448 -193 -385
forceload add -192 -448 -129 -385
fill -192 60 -448 -129 62 -385 minecraft:stone
fill -192 63 -448 -129 63 -385 minecraft:dirt
fill -192 64 -448 -129 64 -385 minecraft:grass_block
forceload remove -192 -448 -129 -385
scoreboard players add #build_step ms_world 1
