# Musashi v1.3.1 base-generation batch 110-119.
execute if score #dispatch ms_world matches 110 run function musashi_story:worldgen/base/step_110
execute if score #dispatch ms_world matches 111 run function musashi_story:worldgen/base/step_111
execute if score #dispatch ms_world matches 112 run function musashi_story:worldgen/base/step_112
execute if score #dispatch ms_world matches 113 run function musashi_story:worldgen/base/step_113
execute if score #dispatch ms_world matches 114 run function musashi_story:worldgen/base/step_114
execute if score #dispatch ms_world matches 115 run function musashi_story:worldgen/base/step_115
execute if score #dispatch ms_world matches 116 run function musashi_story:worldgen/base/step_116
execute if score #dispatch ms_world matches 117 run function musashi_story:worldgen/base/step_117
execute if score #dispatch ms_world matches 118 run function musashi_story:worldgen/base/step_118
execute if score #dispatch ms_world matches 119 run function musashi_story:worldgen/base/step_119
