forceload add 0 256 63 319
fill 0 60 256 63 62 319 minecraft:stone
fill 0 63 256 63 63 319 minecraft:dirt
fill 0 64 256 63 64 319 minecraft:grass_block
forceload remove 0 256 63 319
forceload add 64 256 127 319
fill 64 60 256 127 62 319 minecraft:stone
fill 64 63 256 127 63 319 minecraft:dirt
fill 64 64 256 127 64 319 minecraft:grass_block
forceload remove 64 256 127 319
scoreboard players add #build_step ms_world 1
