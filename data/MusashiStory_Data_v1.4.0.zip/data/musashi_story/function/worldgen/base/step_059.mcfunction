forceload add -128 -64 -65 -1
fill -128 60 -64 -65 62 -1 minecraft:stone
fill -128 63 -64 -65 63 -1 minecraft:dirt
fill -128 64 -64 -65 64 -1 minecraft:grass_block
forceload remove -128 -64 -65 -1
forceload add 64 -64 127 -1
fill 64 60 -64 127 62 -1 minecraft:stone
fill 64 63 -64 127 63 -1 minecraft:dirt
fill 64 64 -64 127 64 -1 minecraft:grass_block
forceload remove 64 -64 127 -1
scoreboard players add #build_step ms_world 1
