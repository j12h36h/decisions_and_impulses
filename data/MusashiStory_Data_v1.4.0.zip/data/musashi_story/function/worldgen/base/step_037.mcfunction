forceload add 128 -256 191 -193
fill 128 60 -256 191 62 -193 minecraft:stone
fill 128 63 -256 191 63 -193 minecraft:dirt
fill 128 64 -256 191 64 -193 minecraft:grass_block
forceload remove 128 -256 191 -193
forceload add 192 -256 255 -193
fill 192 60 -256 255 62 -193 minecraft:stone
fill 192 63 -256 255 63 -193 minecraft:dirt
fill 192 64 -256 255 64 -193 minecraft:grass_block
forceload remove 192 -256 255 -193
scoreboard players add #build_step ms_world 1
