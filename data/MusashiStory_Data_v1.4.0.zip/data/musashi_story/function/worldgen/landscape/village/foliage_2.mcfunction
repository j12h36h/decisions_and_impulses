# v0.6 village natural foliage pass 2
execute positioned -50 0 -8 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 48 0 -6 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned -48 0 30 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 44 0 34 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned -24 0 -48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 24 0 -48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned -48 0 52 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 48 0 52 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
