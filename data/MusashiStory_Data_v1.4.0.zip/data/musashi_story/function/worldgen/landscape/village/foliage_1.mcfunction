# v0.6 village natural foliage pass 1
execute positioned -54 0 -48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned -42 0 -58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 52 0 -48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 58 0 -25 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned -54 0 54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 58 0 54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned -12 0 56 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 14 0 54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned -52 0 -44 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 52 0 -44 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned -52 0 48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 52 0 48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
