# v0.6 village natural foliage pass 3
execute positioned -60 0 8 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 60 0 10 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -8 0 -58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 10 0 60 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -35 0 50 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 38 0 50 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
