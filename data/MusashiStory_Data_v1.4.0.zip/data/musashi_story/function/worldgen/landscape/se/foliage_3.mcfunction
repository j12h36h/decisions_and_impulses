# v0.6 se natural foliage pass 3
execute positioned 258 0 462 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 306 0 470 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 248 0 244 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 280 0 398 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
