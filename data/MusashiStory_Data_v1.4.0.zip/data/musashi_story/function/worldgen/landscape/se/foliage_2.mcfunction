# v0.6 se natural foliage pass 2
execute positioned 244 0 410 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 300 0 458 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 260 0 380 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 290 0 420 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 246 0 320 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
