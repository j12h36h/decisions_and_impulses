# v0.6 se natural foliage pass 1
execute positioned 244 0 236 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 258 0 252 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 272 0 448 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 294 0 474 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 312 0 474 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 250 0 270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 270 0 300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 246 0 360 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 290 0 460 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
