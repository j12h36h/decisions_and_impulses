# v0.6 east natural foliage pass 1
execute positioned 268 0 -136 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 286 0 -126 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 306 0 -116 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 326 0 -104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 350 0 -112 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 372 0 -126 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 402 0 -136 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 424 0 -122 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 270 0 -100 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 320 0 -80 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 390 0 -80 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
