# v0.6 east natural foliage pass 2
execute positioned 260 0 -58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 282 0 -40 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 306 0 -28 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 350 0 -32 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 384 0 -44 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 414 0 -58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 430 0 -84 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 398 0 -18 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
