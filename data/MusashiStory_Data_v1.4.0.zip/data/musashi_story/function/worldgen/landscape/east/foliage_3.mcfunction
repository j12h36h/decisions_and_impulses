# v0.6 east natural foliage pass 3
execute positioned 274 0 -98 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 314 0 -88 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 368 0 -96 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 414 0 -104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 288 0 -12 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 424 0 -30 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 392 0 -146 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
