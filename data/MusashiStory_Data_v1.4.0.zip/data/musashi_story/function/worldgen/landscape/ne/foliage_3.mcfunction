# v0.6 ne natural foliage pass 3
execute positioned 252 0 -490 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 482 0 -430 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 236 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 474 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 312 0 -420 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 408 0 -420 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
