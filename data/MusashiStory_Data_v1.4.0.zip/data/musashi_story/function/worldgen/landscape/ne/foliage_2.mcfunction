# v0.6 ne natural foliage pass 2
execute positioned 292 0 -450 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 430 0 -446 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 284 0 -280 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 438 0 -282 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 270 0 -360 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 450 0 -360 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
