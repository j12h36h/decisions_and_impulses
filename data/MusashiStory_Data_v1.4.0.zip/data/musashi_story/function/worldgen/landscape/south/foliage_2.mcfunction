# v0.6 south natural foliage pass 2
execute positioned -104 0 318 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 104 0 318 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned -104 0 400 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 104 0 400 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned -124 0 348 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 124 0 348 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
