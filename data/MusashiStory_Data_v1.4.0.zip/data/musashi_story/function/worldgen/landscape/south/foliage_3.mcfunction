# v0.6 south natural foliage pass 3
execute positioned -120 0 290 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 120 0 290 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -116 0 414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 116 0 414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -88 0 246 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 88 0 246 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
