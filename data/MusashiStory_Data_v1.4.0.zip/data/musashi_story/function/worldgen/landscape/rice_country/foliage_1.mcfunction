# v0.6 rice_country natural foliage pass 1
execute positioned 204 0 156 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 204 0 278 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 362 0 148 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 362 0 278 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 218 0 184 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 350 0 188 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 220 0 250 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 348 0 250 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 206 0 210 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 360 0 210 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
