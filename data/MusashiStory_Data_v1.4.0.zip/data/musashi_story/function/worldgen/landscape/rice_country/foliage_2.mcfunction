# v0.6 rice_country natural foliage pass 2
execute positioned 212 0 214 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 354 0 214 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 242 0 286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 330 0 288 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 242 0 136 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 330 0 136 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
