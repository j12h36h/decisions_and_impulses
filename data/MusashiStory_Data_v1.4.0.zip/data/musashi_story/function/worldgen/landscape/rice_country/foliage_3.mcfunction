# v0.6 rice_country natural foliage pass 3
execute positioned 200 0 230 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned 368 0 230 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned 216 0 286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 352 0 288 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
