# v0.6 north natural foliage pass 1
execute positioned -104 0 -402 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -84 0 -386 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -104 0 -270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -82 0 -252 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 104 0 -402 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 84 0 -386 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 104 0 -270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 82 0 -252 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -106 0 -330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 106 0 -330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
