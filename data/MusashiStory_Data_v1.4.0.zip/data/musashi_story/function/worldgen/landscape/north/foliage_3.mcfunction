# v0.6 north natural foliage pass 3
execute positioned -98 0 -370 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 96 0 -286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -92 0 -246 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 92 0 -414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -44 0 -414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 44 0 -414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
