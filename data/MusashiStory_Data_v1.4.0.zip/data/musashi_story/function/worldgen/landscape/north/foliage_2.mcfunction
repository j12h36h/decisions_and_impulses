# v0.6 north natural foliage pass 2
execute positioned -74 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned -58 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 74 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 58 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned -112 0 -330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 112 0 -330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
