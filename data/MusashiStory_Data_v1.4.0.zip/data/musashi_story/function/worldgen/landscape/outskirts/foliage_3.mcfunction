# v0.6 outskirts natural foliage pass 3
execute positioned 74 0 118 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 206 0 164 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 90 0 18 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 216 0 104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 130 0 182 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 180 0 178 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
