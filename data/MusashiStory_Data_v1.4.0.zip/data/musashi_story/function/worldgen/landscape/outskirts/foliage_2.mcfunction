# v0.6 outskirts natural foliage pass 2
execute positioned 92 0 150 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 130 0 142 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 176 0 132 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 214 0 84 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 92 0 72 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 200 0 132 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 210 0 36 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
