# v0.6 nw natural foliage pass 3
execute positioned -466 0 -400 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -234 0 -400 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -466 0 -280 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -234 0 -280 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -370 0 -440 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
