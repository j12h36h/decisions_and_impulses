# v0.6 nw natural foliage pass 2
execute positioned -450 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned -250 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned -390 0 -470 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned -320 0 -220 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned -420 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -280 0 -390 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
