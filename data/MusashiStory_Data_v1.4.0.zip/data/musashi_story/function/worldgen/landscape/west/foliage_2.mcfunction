# v0.6 west natural foliage pass 2
execute positioned -426 0 74 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -400 0 94 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -372 0 104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -246 0 -74 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -238 0 48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -300 0 -100 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned -250 0 104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
