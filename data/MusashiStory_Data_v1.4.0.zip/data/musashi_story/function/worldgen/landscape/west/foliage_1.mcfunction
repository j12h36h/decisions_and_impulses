# v0.6 west natural foliage pass 1
execute positioned -430 0 -94 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -414 0 -72 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -398 0 -48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -380 0 -24 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -360 0 4 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -338 0 28 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -310 0 58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -278 0 88 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -416 0 -20 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned -260 0 54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
