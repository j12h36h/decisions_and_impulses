# v0.6 west natural foliage pass 3
execute positioned -408 0 24 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -330 0 100 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -254 0 -46 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -430 0 -20 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -238 0 20 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -386 0 -108 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/mushroom_grove
