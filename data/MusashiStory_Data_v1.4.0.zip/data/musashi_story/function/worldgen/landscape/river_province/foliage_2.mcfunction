# v0.6 river_province natural foliage pass 2
execute positioned 272 0 64 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 394 0 96 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 286 0 148 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 398 0 28 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 300 0 112 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 376 0 34 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
