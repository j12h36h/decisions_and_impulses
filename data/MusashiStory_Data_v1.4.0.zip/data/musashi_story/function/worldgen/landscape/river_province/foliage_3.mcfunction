# v0.6 river_province natural foliage pass 3
execute positioned 275 0 126 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 394 0 126 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 286 0 50 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned 388 0 104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stone_lantern
