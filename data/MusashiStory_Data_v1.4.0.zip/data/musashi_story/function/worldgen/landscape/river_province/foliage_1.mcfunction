# v0.6 river_province natural foliage pass 1
execute positioned 276 0 18 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 280 0 142 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 394 0 20 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 400 0 150 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 286 0 104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 378 0 56 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 292 0 16 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 390 0 150 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 278 0 90 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 394 0 64 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
