forceload add 205 45
execute positioned 205 0 45 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 205 45
forceload add 211 40
execute positioned 211 0 40 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 211 40
forceload add 217 34
execute positioned 217 0 34 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 217 34
forceload add 223 29
execute positioned 223 0 29 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 223 29
forceload add 229 23
execute positioned 229 0 23 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 229 23
forceload add 235 18
execute positioned 235 0 18 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 235 18
forceload add 241 12
execute positioned 241 0 12 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 241 12
forceload add 247 7
execute positioned 247 0 7 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 247 7
forceload add 253 1
execute positioned 253 0 1 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 253 1
forceload add 259 -4
execute positioned 259 0 -4 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 259 -4
forceload add 265 -10
execute positioned 265 0 -10 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 265 -10
forceload add 270 -15
execute positioned 270 0 -15 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 270 -15
forceload add 276 -21
execute positioned 276 0 -21 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 276 -21
forceload add 282 -26
execute positioned 282 0 -26 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 282 -26
forceload add 288 -32
execute positioned 288 0 -32 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 288 -32
forceload add 294 -37
execute positioned 294 0 -37 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 294 -37
forceload add 300 -43
execute positioned 300 0 -43 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 300 -43
forceload add 306 -48
execute positioned 306 0 -48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 306 -48
forceload add 312 -54
execute positioned 312 0 -54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 312 -54
forceload add 318 -59
execute positioned 318 0 -59 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 318 -59
forceload add 324 -65
execute positioned 324 0 -65 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 324 -65
forceload add 330 -70
execute positioned 330 0 -70 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 330 -70
