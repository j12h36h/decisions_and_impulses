forceload add 0 340
execute positioned 0 0 340 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 340
forceload add 8 339
execute positioned 8 0 339 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 8 339
forceload add 16 338
execute positioned 16 0 338 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 16 338
forceload add 24 337
execute positioned 24 0 337 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 24 337
forceload add 32 336
execute positioned 32 0 336 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 32 336
forceload add 40 335
execute positioned 40 0 335 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 40 335
forceload add 48 334
execute positioned 48 0 334 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 48 334
forceload add 56 333
execute positioned 56 0 333 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 56 333
forceload add 64 332
execute positioned 64 0 332 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 64 332
forceload add 72 331
execute positioned 72 0 331 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 72 331
forceload add 80 330
execute positioned 80 0 330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 80 330
forceload add 88 329
execute positioned 88 0 329 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 88 329
forceload add 96 328
execute positioned 96 0 328 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 96 328
forceload add 104 327
execute positioned 104 0 327 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 104 327
forceload add 112 326
execute positioned 112 0 326 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 112 326
forceload add 120 325
execute positioned 120 0 325 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 120 325
forceload add 128 324
execute positioned 128 0 324 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 128 324
forceload add 136 323
execute positioned 136 0 323 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 136 323
forceload add 144 322
execute positioned 144 0 322 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 144 322
forceload add 152 321
execute positioned 152 0 321 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 152 321
forceload add 160 320
execute positioned 160 0 320 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 160 320
forceload add 168 319
execute positioned 168 0 319 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 168 319
forceload add 176 318
execute positioned 176 0 318 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 176 318
forceload add 184 317
execute positioned 184 0 317 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 184 317
forceload add 192 316
execute positioned 192 0 316 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 192 316
forceload add 200 315
execute positioned 200 0 315 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 200 315
forceload add 208 314
execute positioned 208 0 314 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 208 314
forceload add 216 313
execute positioned 216 0 313 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 216 313
forceload add 224 312
execute positioned 224 0 312 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 224 312
forceload add 232 311
execute positioned 232 0 311 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 232 311
forceload add 240 310
execute positioned 240 0 310 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 240 310
forceload add 248 309
execute positioned 248 0 309 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 248 309
forceload add 256 308
execute positioned 256 0 308 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 256 308
forceload add 264 307
execute positioned 264 0 307 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 264 307
forceload add 272 306
execute positioned 272 0 306 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 272 306
forceload add 280 305
execute positioned 280 0 305 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 280 305
forceload add 288 304
execute positioned 288 0 304 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 288 304
forceload add 296 303
execute positioned 296 0 303 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 296 303
forceload add 304 302
execute positioned 304 0 302 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 304 302
forceload add 312 301
execute positioned 312 0 301 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 312 301
forceload add 320 300
execute positioned 320 0 300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 320 300
