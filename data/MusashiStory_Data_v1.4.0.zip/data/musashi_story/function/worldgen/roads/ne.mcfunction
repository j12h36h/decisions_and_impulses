forceload add 330 -70
execute positioned 330 0 -70 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 330 -70
forceload add 331 -78
execute positioned 331 0 -78 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 331 -78
forceload add 331 -86
execute positioned 331 0 -86 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 331 -86
forceload add 332 -94
execute positioned 332 0 -94 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 332 -94
forceload add 332 -102
execute positioned 332 0 -102 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 332 -102
forceload add 333 -110
execute positioned 333 0 -110 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 333 -110
forceload add 333 -118
execute positioned 333 0 -118 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 333 -118
forceload add 334 -126
execute positioned 334 0 -126 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 334 -126
forceload add 335 -134
execute positioned 335 0 -134 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 335 -134
forceload add 335 -142
execute positioned 335 0 -142 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 335 -142
forceload add 336 -150
execute positioned 336 0 -150 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 336 -150
forceload add 336 -158
execute positioned 336 0 -158 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 336 -158
forceload add 337 -166
execute positioned 337 0 -166 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 337 -166
forceload add 337 -174
execute positioned 337 0 -174 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 337 -174
forceload add 338 -182
execute positioned 338 0 -182 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 338 -182
forceload add 339 -190
execute positioned 339 0 -190 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 339 -190
forceload add 339 -198
execute positioned 339 0 -198 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 339 -198
forceload add 340 -206
execute positioned 340 0 -206 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 340 -206
forceload add 340 -214
execute positioned 340 0 -214 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 340 -214
forceload add 341 -222
execute positioned 341 0 -222 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 341 -222
forceload add 341 -230
execute positioned 341 0 -230 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 341 -230
forceload add 342 -238
execute positioned 342 0 -238 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 342 -238
forceload add 343 -246
execute positioned 343 0 -246 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 343 -246
forceload add 343 -254
execute positioned 343 0 -254 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 343 -254
forceload add 344 -262
execute positioned 344 0 -262 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 344 -262
forceload add 344 -270
execute positioned 344 0 -270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 344 -270
forceload add 345 -278
execute positioned 345 0 -278 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 345 -278
forceload add 345 -286
execute positioned 345 0 -286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 345 -286
forceload add 346 -294
execute positioned 346 0 -294 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 346 -294
forceload add 347 -302
execute positioned 347 0 -302 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 347 -302
forceload add 347 -310
execute positioned 347 0 -310 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 347 -310
forceload add 348 -318
execute positioned 348 0 -318 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 348 -318
forceload add 348 -326
execute positioned 348 0 -326 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 348 -326
forceload add 349 -334
execute positioned 349 0 -334 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 349 -334
forceload add 349 -342
execute positioned 349 0 -342 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 349 -342
forceload add 350 -350
execute positioned 350 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 350 -350
