forceload add 55 10
execute positioned 55 0 10 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 55 10
forceload add 62 14
execute positioned 62 0 14 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 62 14
forceload add 69 18
execute positioned 69 0 18 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 69 18
forceload add 76 22
execute positioned 76 0 22 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 76 22
forceload add 83 25
execute positioned 83 0 25 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 83 25
forceload add 90 29
execute positioned 90 0 29 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 90 29
forceload add 97 33
execute positioned 97 0 33 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 97 33
forceload add 104 37
execute positioned 104 0 37 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 104 37
forceload add 111 41
execute positioned 111 0 41 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 111 41
forceload add 118 45
execute positioned 118 0 45 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 118 45
forceload add 125 49
execute positioned 125 0 49 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 125 49
forceload add 132 52
execute positioned 132 0 52 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 132 52
forceload add 140 56
execute positioned 140 0 56 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 140 56
forceload add 147 60
execute positioned 147 0 60 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 147 60
forceload add 154 64
execute positioned 154 0 64 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 154 64
forceload add 161 68
execute positioned 161 0 68 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 161 68
forceload add 168 72
execute positioned 168 0 72 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 168 72
forceload add 175 76
execute positioned 175 0 76 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 175 76
forceload add 182 80
execute positioned 182 0 80 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 182 80
forceload add 189 83
execute positioned 189 0 83 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 189 83
forceload add 196 87
execute positioned 196 0 87 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 196 87
forceload add 203 91
execute positioned 203 0 91 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 203 91
forceload add 210 95
execute positioned 210 0 95 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 210 95
