forceload add 0 -55
execute positioned 0 0 -55 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -55
forceload add 0 -63
execute positioned 0 0 -63 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -63
forceload add 0 -71
execute positioned 0 0 -71 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -71
forceload add 0 -79
execute positioned 0 0 -79 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -79
forceload add 0 -87
execute positioned 0 0 -87 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -87
forceload add 0 -95
execute positioned 0 0 -95 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -95
forceload add 0 -103
execute positioned 0 0 -103 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -103
forceload add 0 -111
execute positioned 0 0 -111 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -111
forceload add 0 -119
execute positioned 0 0 -119 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -119
forceload add 0 -127
execute positioned 0 0 -127 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -127
forceload add 0 -135
execute positioned 0 0 -135 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -135
forceload add 0 -143
execute positioned 0 0 -143 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -143
forceload add 0 -151
execute positioned 0 0 -151 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -151
forceload add 0 -159
execute positioned 0 0 -159 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -159
forceload add 0 -167
execute positioned 0 0 -167 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -167
forceload add 0 -175
execute positioned 0 0 -175 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -175
forceload add 0 -183
execute positioned 0 0 -183 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -183
forceload add 0 -192
execute positioned 0 0 -192 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -192
forceload add 0 -200
execute positioned 0 0 -200 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -200
forceload add 0 -208
execute positioned 0 0 -208 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -208
forceload add 0 -216
execute positioned 0 0 -216 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -216
forceload add 0 -224
execute positioned 0 0 -224 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -224
forceload add 0 -232
execute positioned 0 0 -232 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -232
forceload add 0 -240
execute positioned 0 0 -240 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -240
forceload add 0 -248
execute positioned 0 0 -248 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -248
forceload add 0 -256
execute positioned 0 0 -256 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -256
forceload add 0 -264
execute positioned 0 0 -264 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -264
forceload add 0 -272
execute positioned 0 0 -272 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -272
forceload add 0 -280
execute positioned 0 0 -280 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -280
forceload add 0 -288
execute positioned 0 0 -288 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -288
forceload add 0 -296
execute positioned 0 0 -296 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -296
forceload add 0 -304
execute positioned 0 0 -304 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -304
forceload add 0 -312
execute positioned 0 0 -312 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -312
forceload add 0 -320
execute positioned 0 0 -320 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -320
