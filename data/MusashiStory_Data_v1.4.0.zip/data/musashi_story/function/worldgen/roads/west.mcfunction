forceload add -55 0
execute positioned -55 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -55 0
forceload add -63 0
execute positioned -63 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -63 0
forceload add -71 0
execute positioned -71 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -71 0
forceload add -79 0
execute positioned -79 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -79 0
forceload add -87 0
execute positioned -87 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -87 0
forceload add -95 0
execute positioned -95 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -95 0
forceload add -103 0
execute positioned -103 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -103 0
forceload add -111 0
execute positioned -111 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -111 0
forceload add -119 0
execute positioned -119 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -119 0
forceload add -127 0
execute positioned -127 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -127 0
forceload add -135 0
execute positioned -135 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -135 0
forceload add -143 0
execute positioned -143 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -143 0
forceload add -151 0
execute positioned -151 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -151 0
forceload add -159 0
execute positioned -159 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -159 0
forceload add -167 0
execute positioned -167 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -167 0
forceload add -175 0
execute positioned -175 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -175 0
forceload add -183 0
execute positioned -183 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -183 0
forceload add -192 0
execute positioned -192 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -192 0
forceload add -200 0
execute positioned -200 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -200 0
forceload add -208 0
execute positioned -208 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -208 0
forceload add -216 0
execute positioned -216 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -216 0
forceload add -224 0
execute positioned -224 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -224 0
forceload add -232 0
execute positioned -232 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -232 0
forceload add -240 0
execute positioned -240 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -240 0
forceload add -248 0
execute positioned -248 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -248 0
forceload add -256 0
execute positioned -256 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -256 0
forceload add -264 0
execute positioned -264 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -264 0
forceload add -272 0
execute positioned -272 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -272 0
forceload add -280 0
execute positioned -280 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -280 0
forceload add -288 0
execute positioned -288 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -288 0
forceload add -296 0
execute positioned -296 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -296 0
forceload add -304 0
execute positioned -304 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -304 0
forceload add -312 0
execute positioned -312 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -312 0
forceload add -320 0
execute positioned -320 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -320 0
