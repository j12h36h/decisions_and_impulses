forceload add -320 0
execute positioned -320 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -320 0
forceload add -320 -8
execute positioned -320 0 -8 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -320 -8
forceload add -321 -16
execute positioned -321 0 -16 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -321 -16
forceload add -322 -24
execute positioned -322 0 -24 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -322 -24
forceload add -322 -32
execute positioned -322 0 -32 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -322 -32
forceload add -322 -40
execute positioned -322 0 -40 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -322 -40
forceload add -323 -48
execute positioned -323 0 -48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -323 -48
forceload add -324 -56
execute positioned -324 0 -56 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -324 -56
forceload add -324 -64
execute positioned -324 0 -64 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -324 -64
forceload add -324 -72
execute positioned -324 0 -72 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -324 -72
forceload add -325 -80
execute positioned -325 0 -80 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -325 -80
forceload add -326 -88
execute positioned -326 0 -88 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -326 -88
forceload add -326 -96
execute positioned -326 0 -96 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -326 -96
forceload add -326 -104
execute positioned -326 0 -104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -326 -104
forceload add -327 -112
execute positioned -327 0 -112 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -327 -112
forceload add -328 -120
execute positioned -328 0 -120 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -328 -120
forceload add -328 -128
execute positioned -328 0 -128 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -328 -128
forceload add -328 -136
execute positioned -328 0 -136 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -328 -136
forceload add -329 -144
execute positioned -329 0 -144 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -329 -144
forceload add -330 -152
execute positioned -330 0 -152 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -330 -152
forceload add -330 -160
execute positioned -330 0 -160 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -330 -160
forceload add -330 -168
execute positioned -330 0 -168 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -330 -168
forceload add -331 -176
execute positioned -331 0 -176 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -331 -176
forceload add -332 -184
execute positioned -332 0 -184 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -332 -184
forceload add -332 -192
execute positioned -332 0 -192 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -332 -192
forceload add -332 -200
execute positioned -332 0 -200 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -332 -200
forceload add -333 -208
execute positioned -333 0 -208 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -333 -208
forceload add -334 -216
execute positioned -334 0 -216 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -334 -216
forceload add -334 -224
execute positioned -334 0 -224 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -334 -224
forceload add -334 -232
execute positioned -334 0 -232 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -334 -232
forceload add -335 -240
execute positioned -335 0 -240 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -335 -240
forceload add -336 -248
execute positioned -336 0 -248 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -336 -248
forceload add -336 -256
execute positioned -336 0 -256 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -336 -256
forceload add -336 -264
execute positioned -336 0 -264 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -336 -264
forceload add -337 -272
execute positioned -337 0 -272 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -337 -272
forceload add -338 -280
execute positioned -338 0 -280 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -338 -280
forceload add -338 -288
execute positioned -338 0 -288 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -338 -288
forceload add -338 -296
execute positioned -338 0 -296 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -338 -296
forceload add -339 -304
execute positioned -339 0 -304 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -339 -304
forceload add -340 -312
execute positioned -340 0 -312 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -340 -312
forceload add -340 -320
execute positioned -340 0 -320 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -340 -320
