forceload add 190 95
execute positioned 190 0 95 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 190 95
forceload add 196 101
execute positioned 196 0 101 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 196 101
forceload add 202 107
execute positioned 202 0 107 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 202 107
forceload add 207 113
execute positioned 207 0 113 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 207 113
forceload add 213 119
execute positioned 213 0 119 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 213 119
forceload add 219 125
execute positioned 219 0 125 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 219 125
forceload add 225 131
execute positioned 225 0 131 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 225 131
forceload add 231 137
execute positioned 231 0 137 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 231 137
forceload add 236 143
execute positioned 236 0 143 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 236 143
forceload add 242 149
execute positioned 242 0 149 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 242 149
forceload add 248 156
execute positioned 248 0 156 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 248 156
forceload add 254 162
execute positioned 254 0 162 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 254 162
forceload add 259 168
execute positioned 259 0 168 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 259 168
forceload add 265 174
execute positioned 265 0 174 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 265 174
forceload add 271 180
execute positioned 271 0 180 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 271 180
forceload add 277 186
execute positioned 277 0 186 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 277 186
forceload add 283 192
execute positioned 283 0 192 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 283 192
forceload add 288 198
execute positioned 288 0 198 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 288 198
forceload add 294 204
execute positioned 294 0 204 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 294 204
forceload add 300 210
execute positioned 300 0 210 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 300 210
