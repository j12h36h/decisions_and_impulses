forceload add -58 0
execute positioned -58 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -58 0
forceload add -49 2
execute positioned -49 0 2 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -49 2
forceload add -40 3
execute positioned -40 0 3 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -40 3
forceload add -31 5
execute positioned -31 0 5 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -31 5
forceload add -22 6
execute positioned -22 0 6 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -22 6
forceload add -13 8
execute positioned -13 0 8 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -13 8
forceload add -4 9
execute positioned -4 0 9 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove -4 9
forceload add 5 11
execute positioned 5 0 11 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 5 11
forceload add 15 12
execute positioned 15 0 12 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 15 12
forceload add 24 14
execute positioned 24 0 14 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 24 14
forceload add 33 16
execute positioned 33 0 16 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 33 16
forceload add 42 17
execute positioned 42 0 17 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 42 17
forceload add 51 19
execute positioned 51 0 19 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 51 19
forceload add 60 20
execute positioned 60 0 20 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 60 20
forceload add 69 22
execute positioned 69 0 22 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 69 22
forceload add 78 23
execute positioned 78 0 23 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 78 23
forceload add 87 25
execute positioned 87 0 25 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 87 25
forceload add 96 26
execute positioned 96 0 26 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 96 26
forceload add 105 28
execute positioned 105 0 28 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 105 28
forceload add 114 29
execute positioned 114 0 29 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 114 29
forceload add 123 31
execute positioned 123 0 31 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 123 31
forceload add 132 33
execute positioned 132 0 33 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 132 33
forceload add 142 34
execute positioned 142 0 34 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 142 34
forceload add 151 36
execute positioned 151 0 36 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 151 36
forceload add 160 37
execute positioned 160 0 37 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 160 37
forceload add 169 39
execute positioned 169 0 39 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 169 39
forceload add 178 40
execute positioned 178 0 40 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 178 40
forceload add 187 42
execute positioned 187 0 42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 187 42
forceload add 196 43
execute positioned 196 0 43 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 196 43
forceload add 205 45
execute positioned 205 0 45 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 205 45
forceload add 0 -58
execute positioned 0 0 -58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -58
forceload add 0 -49
execute positioned 0 0 -49 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -49
forceload add 0 -40
execute positioned 0 0 -40 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -40
forceload add 0 -30
execute positioned 0 0 -30 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -30
forceload add 0 -21
execute positioned 0 0 -21 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -21
forceload add 0 -12
execute positioned 0 0 -12 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -12
forceload add 0 -3
execute positioned 0 0 -3 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 -3
forceload add 0 7
execute positioned 0 0 7 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 7
forceload add 0 16
execute positioned 0 0 16 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 16
forceload add 0 25
execute positioned 0 0 25 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 25
forceload add 0 34
execute positioned 0 0 34 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 34
forceload add 0 44
execute positioned 0 0 44 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 44
forceload add 0 53
execute positioned 0 0 53 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 53
forceload add 0 62
execute positioned 0 0 62 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 62
forceload add 0 71
execute positioned 0 0 71 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 71
forceload add 0 81
execute positioned 0 0 81 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 81
forceload add 0 90
execute positioned 0 0 90 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 90
forceload add 0 99
execute positioned 0 0 99 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 99
forceload add 0 108
execute positioned 0 0 108 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 108
forceload add 0 118
execute positioned 0 0 118 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 118
forceload add 0 127
execute positioned 0 0 127 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 127
forceload add 0 136
execute positioned 0 0 136 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 136
forceload add 0 145
execute positioned 0 0 145 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 145
forceload add 0 155
execute positioned 0 0 155 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 155
forceload add 0 164
execute positioned 0 0 164 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 164
forceload add 0 173
execute positioned 0 0 173 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 173
forceload add 0 182
execute positioned 0 0 182 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 182
forceload add 0 192
execute positioned 0 0 192 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 192
forceload add 0 201
execute positioned 0 0 201 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 201
forceload add 0 210
execute positioned 0 0 210 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 0 210
