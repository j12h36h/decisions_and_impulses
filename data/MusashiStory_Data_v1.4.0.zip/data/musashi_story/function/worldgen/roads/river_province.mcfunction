forceload add 205 45
execute positioned 205 0 45 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 205 45
forceload add 213 47
execute positioned 213 0 47 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 213 47
forceload add 221 49
execute positioned 221 0 49 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 221 49
forceload add 229 51
execute positioned 229 0 51 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 229 51
forceload add 238 52
execute positioned 238 0 52 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 238 52
forceload add 246 54
execute positioned 246 0 54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 246 54
forceload add 254 56
execute positioned 254 0 56 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 254 56
forceload add 262 58
execute positioned 262 0 58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 262 58
forceload add 270 60
execute positioned 270 0 60 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 270 60
forceload add 278 62
execute positioned 278 0 62 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 278 62
forceload add 287 63
execute positioned 287 0 63 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 287 63
forceload add 295 65
execute positioned 295 0 65 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 295 65
forceload add 303 67
execute positioned 303 0 67 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 303 67
forceload add 311 69
execute positioned 311 0 69 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 311 69
forceload add 319 71
execute positioned 319 0 71 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 319 71
forceload add 327 73
execute positioned 327 0 73 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 327 73
forceload add 336 74
execute positioned 336 0 74 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 336 74
forceload add 344 76
execute positioned 344 0 76 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 344 76
forceload add 352 78
execute positioned 352 0 78 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 352 78
forceload add 360 80
execute positioned 360 0 80 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/road_stamp
forceload remove 360 80
