# Emergency spawn foundation; does nothing once the authored village floor exists.
execute if block 0 64 0 minecraft:air run fill -8 60 -8 8 62 8 minecraft:stone
execute if block 0 64 0 minecraft:air run fill -8 63 -8 8 63 8 minecraft:dirt
execute if block 0 64 0 minecraft:air run fill -8 64 -8 8 64 8 minecraft:grass_block
