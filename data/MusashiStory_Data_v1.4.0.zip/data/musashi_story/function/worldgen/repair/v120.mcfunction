# Non-destructive v1.2 province migration marker.
# Structural region details already carry their own generation scores; do not duplicate authored structures.
scoreboard players set #modern_v120 ms_world 1
data modify storage musashi_story:runtime modernization_v120 set value 1b
tellraw @a[tag=ms_player] [{"text":"PROVINCE SYSTEM // ","color":"gold","bold":true},{"text":"staged generation and waypoint recovery upgraded.","color":"gray"}]
