# Musashi Story v1.3.3 non-destructive idle sword pose refinement.
scoreboard players set #modern_v133 ms_world 1
data modify storage musashi_story:runtime modernization_v133 set value 1b
