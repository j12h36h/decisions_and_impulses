# Musashi Story v1.3.1 non-destructive polish migration.
# No authored terrain, player progression, loadout, Honor, Resolve, bounty or waypoint state is reset.
scoreboard players set #modern_v131 ms_world 1
data modify storage musashi_story:runtime modernization_v131 set value 1b
tellraw @a[tag=ms_player] [{"text":"MUSASHI STORY // ","color":"gold","bold":true},{"text":"v1.3.1 blade, HUD and runtime polish applied.","color":"gray"}]
