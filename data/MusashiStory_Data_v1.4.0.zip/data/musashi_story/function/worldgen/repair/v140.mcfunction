# Musashi Story v1.4.0 non-destructive DAI 3.3 capability + efficiency migration.
# Rebuild articulated displays once so existing worlds adopt the new four-tick teleport interpolation.
# Honor, Resolve, loadouts, bounties, waypoints, province geometry and progression are preserved.
kill @e[tag=ms_visual]
scoreboard players set #modern_v140 ms_world 1
data modify storage musashi_story:runtime modernization_v140 set value 1b
tellraw @a[tag=ms_player] [{"text":"MUSASHI STORY // ","color":"gold","bold":true},{"text":"DAI 3.3 capability + efficiency modernization applied.","color":"gray"}]
