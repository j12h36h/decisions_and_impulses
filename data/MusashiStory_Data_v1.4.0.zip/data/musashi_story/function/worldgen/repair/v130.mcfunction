# Musashi Story v1.3.0 non-destructive DAI 3.1 runtime migration.
# Existing authored province geometry and progression are preserved.
kill @e[tag=ms_visual]
scoreboard players set #modern_v130 ms_world 1
data modify storage musashi_story:runtime modernization_v130 set value 1b
tellraw @a[tag=ms_player] [{"text":"MUSASHI STORY // ","color":"gold","bold":true},{"text":"DAI 3.1 experience and runtime modernization applied.","color":"gray"}]
