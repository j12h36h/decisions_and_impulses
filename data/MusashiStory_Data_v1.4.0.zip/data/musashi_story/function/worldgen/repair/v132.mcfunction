# Musashi Story v1.3.2 non-destructive idle blade stance migration.
scoreboard players set #modern_v132 ms_world 1
data modify storage musashi_story:runtime modernization_v132 set value 1b
tellraw @a[tag=ms_player] [{"text":"MUSASHI STORY // ","color":"gold","bold":true},{"text":"v1.3.2 idle blade stance refinement applied.","color":"gray"}]
