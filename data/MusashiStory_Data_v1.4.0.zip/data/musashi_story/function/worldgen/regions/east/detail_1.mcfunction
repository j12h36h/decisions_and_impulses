execute positioned 280 0 -112 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 344 0 -104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 408 0 -96 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 410 0 -58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b

execute positioned 420 0 -40 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_medium
execute positioned 362 0 -126 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cave_mouth
execute positioned 338 0 -88 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
execute positioned 286 0 -54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_z
