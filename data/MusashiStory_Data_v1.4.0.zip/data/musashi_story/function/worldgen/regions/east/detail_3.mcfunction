execute positioned 322 0 -122 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 386 0 -126 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 372 0 -38 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 394 0 -54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
schedule function musashi_story:worldgen/landscape/east/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/east/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/east/foliage_3 70t append
execute positioned 326 0 -142 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
