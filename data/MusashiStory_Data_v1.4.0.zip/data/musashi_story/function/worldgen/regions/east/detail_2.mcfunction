execute positioned 300 0 -92 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 366 0 -88 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 300 0 -42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 286 0 -62 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 420 0 -130 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cave_hill
