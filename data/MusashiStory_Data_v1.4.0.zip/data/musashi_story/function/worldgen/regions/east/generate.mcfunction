scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/east
function musashi_story:worldgen/roads/east
execute positioned 330 0 -70 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/waypoint_shrine
execute positioned 292 0 -42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/torii
execute positioned 310 0 -100 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 346 0 -86 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 390 0 -110 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
scoreboard players set #gen_e ms_world 1
schedule function musashi_story:worldgen/regions/east/detail_1 5t append
schedule function musashi_story:worldgen/regions/east/detail_2 15t append
schedule function musashi_story:worldgen/regions/east/detail_3 25t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"BAMBOO FOOTHILLS","color":"white"}]
execute positioned 374 0 -90 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mountain
