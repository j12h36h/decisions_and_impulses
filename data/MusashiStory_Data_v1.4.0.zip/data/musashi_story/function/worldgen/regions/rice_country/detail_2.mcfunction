execute positioned 346 0 146 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 244 0 218 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stone_lantern
execute positioned 286 0 268 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/torii

execute positioned 360 0 238 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_small
execute positioned 270 0 188 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/river_meander
