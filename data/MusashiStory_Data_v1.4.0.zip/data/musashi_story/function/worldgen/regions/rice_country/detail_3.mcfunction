execute positioned 218 0 270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 330 0 218 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stone_lantern
schedule function musashi_story:worldgen/landscape/rice_country/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/rice_country/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/rice_country/foliage_3 70t append
execute positioned 356 0 286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
