execute positioned 218 0 150 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 344 0 272 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 286 0 150 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine

execute positioned 210 0 202 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_props
execute positioned 246 0 224 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stream_ns
execute positioned 316 0 238 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
