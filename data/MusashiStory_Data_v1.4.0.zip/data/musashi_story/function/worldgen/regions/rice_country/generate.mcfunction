scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/rice_country
function musashi_story:worldgen/roads/rice_country
execute positioned 214 0 142 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/house
execute positioned 352 0 214 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/house
execute positioned 290 0 280 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/torii
scoreboard players set #gen_rice ms_world 1
schedule function musashi_story:worldgen/regions/rice_country/detail_1 8t append
schedule function musashi_story:worldgen/regions/rice_country/detail_2 22t append
schedule function musashi_story:worldgen/regions/rice_country/detail_3 38t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"RICE COUNTRY","color":"white"}]
execute positioned 246 0 222 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
