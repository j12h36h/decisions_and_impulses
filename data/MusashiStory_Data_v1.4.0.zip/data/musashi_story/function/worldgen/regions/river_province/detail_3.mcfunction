execute positioned 370 0 78 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 364 0 40 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
schedule function musashi_story:worldgen/landscape/river_province/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/river_province/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/river_province/foliage_3 70t append
execute positioned 286 0 138 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
