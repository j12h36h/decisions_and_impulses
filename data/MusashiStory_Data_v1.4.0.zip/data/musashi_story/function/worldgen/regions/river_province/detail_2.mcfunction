execute positioned 292 0 88 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 306 0 124 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine

execute positioned 400 0 70 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_props
execute positioned 394 0 66 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
