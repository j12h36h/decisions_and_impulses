scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/river_province
function musashi_story:worldgen/roads/river_province
execute positioned 282 0 74 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/house
execute positioned 380 0 138 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/watchtower
scoreboard players set #gen_river ms_world 1
schedule function musashi_story:worldgen/regions/river_province/detail_1 5t append
schedule function musashi_story:worldgen/regions/river_province/detail_2 15t append
schedule function musashi_story:worldgen/regions/river_province/detail_3 25t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"RIVER PROVINCE","color":"white"}]
execute positioned 282 0 74 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/structure_foundation_house
execute positioned 336 0 106 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_x
