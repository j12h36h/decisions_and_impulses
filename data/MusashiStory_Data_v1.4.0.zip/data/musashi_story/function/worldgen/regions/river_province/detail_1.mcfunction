execute positioned 286 0 32 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 382 0 132 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 332 0 74 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bridge

execute positioned 276 0 105 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_small
execute positioned 330 0 112 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stream_ew
execute positioned 366 0 86 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
execute positioned 336 0 106 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/river_meander
