scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/nw
function musashi_story:worldgen/roads/nw
execute positioned -340 0 -320 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/waypoint_shrine
execute positioned -370 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/battlefield
execute positioned -420 0 -400 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/watchtower
execute positioned -300 0 -258 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/grave
execute positioned -312 0 -270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/grave
execute positioned -326 0 -252 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/grave
scoreboard players set #gen_nw ms_world 1
schedule function musashi_story:worldgen/regions/nw/detail_1 5t append
schedule function musashi_story:worldgen/regions/nw/detail_2 15t append
schedule function musashi_story:worldgen/regions/nw/detail_3 25t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"OLD BATTLEFIELD","color":"white"}]
execute positioned -356 0 -336 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_x
