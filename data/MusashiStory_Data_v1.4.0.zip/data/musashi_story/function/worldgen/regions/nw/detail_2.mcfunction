execute positioned -390 0 -420 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -430 0 -250 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -260 0 -272 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned -430 0 -286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
