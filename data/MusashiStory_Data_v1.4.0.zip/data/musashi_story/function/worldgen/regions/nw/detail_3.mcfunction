execute positioned -276 0 -404 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -306 0 -230 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ruined_foundation
schedule function musashi_story:worldgen/landscape/nw/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/nw/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/nw/foliage_3 70t append
execute positioned -270 0 -430 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
