execute positioned -438 0 -410 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -246 0 -330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -366 0 -338 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned -294 0 -360 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ravine_winding
