execute positioned -56 0 -4 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_small
execute positioned 56 0 -2 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_small
execute positioned -10 0 52 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_small
execute positioned 14 0 -54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_small
function musashi_story:worldgen/roads/village_cross
execute positioned 0 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/waypoint_shrine
execute positioned 0 0 22 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/torii
execute positioned -30 0 10 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/house
execute positioned 30 0 12 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/house
execute positioned 0 0 -30 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/dojo
execute positioned -36 0 -28 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 36 0 -26 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned -28 0 38 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 28 0 40 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
scoreboard players set #gen_village ms_world 1
schedule function musashi_story:worldgen/regions/village/detail_1 5t append
schedule function musashi_story:worldgen/regions/village/detail_2 15t append
schedule function musashi_story:worldgen/regions/village/detail_3 25t append
execute positioned -30 0 10 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/structure_foundation_house
execute positioned 30 0 12 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/structure_foundation_house
execute positioned 0 0 -30 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/structure_foundation_dojo
execute positioned 0 0 -58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
execute positioned -62 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
execute positioned 62 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
execute positioned -70 0 -54 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
execute positioned 70 0 48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
