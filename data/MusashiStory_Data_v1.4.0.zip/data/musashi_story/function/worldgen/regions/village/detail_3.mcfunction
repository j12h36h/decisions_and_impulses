execute positioned 52 0 10 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 50 0 -42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned -38 0 18 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/house
schedule function musashi_story:worldgen/landscape/village/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/village/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/village/foliage_3 70t append
execute positioned -54 0 -4 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
