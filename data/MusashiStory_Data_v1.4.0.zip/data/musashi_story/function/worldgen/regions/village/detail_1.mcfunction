execute positioned -48 0 -18 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 24 0 48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned -20 0 8 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/market_stall
execute positioned 40 0 -14 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/house

execute positioned -48 0 30 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/garden_patch
execute positioned 46 0 28 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/garden_patch
execute positioned -72 0 42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
