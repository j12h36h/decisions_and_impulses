execute positioned -18 0 -52 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned -54 0 44 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stone_lantern
execute positioned 20 0 8 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/market_stall

execute positioned -10 0 32 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_props
execute positioned 12 0 -12 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_props
execute positioned 68 0 -46 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
