execute positioned -410 0 -96 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -328 0 4 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -392 0 32 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log

execute positioned -410 0 20 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_medium
execute positioned -332 0 -20 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ravine_small
execute positioned -340 0 22 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ravine_winding
