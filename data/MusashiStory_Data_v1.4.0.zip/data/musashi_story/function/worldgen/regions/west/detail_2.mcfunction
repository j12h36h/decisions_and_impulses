execute positioned -388 0 -70 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -300 0 64 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -286 0 -44 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned -414 0 70 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
