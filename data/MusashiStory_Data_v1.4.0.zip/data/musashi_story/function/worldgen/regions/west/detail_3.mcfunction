execute positioned -360 0 -42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -260 0 96 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
schedule function musashi_story:worldgen/landscape/west/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/west/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/west/foliage_3 70t append
execute positioned -270 0 -94 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cave_hill
