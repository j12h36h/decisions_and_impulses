scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/west
function musashi_story:worldgen/roads/west
execute positioned -320 0 0 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/waypoint_shrine
execute positioned -354 0 -34 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/bandit_camp
execute positioned -386 0 -52 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/watchtower
execute positioned -276 0 60 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/bandit_camp
execute positioned -350 0 82 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
scoreboard players set #gen_w ms_world 1
schedule function musashi_story:worldgen/regions/west/detail_1 5t append
schedule function musashi_story:worldgen/regions/west/detail_2 15t append
schedule function musashi_story:worldgen/regions/west/detail_3 25t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"BANDIT TERRITORY","color":"white"}]
execute positioned -338 0 -74 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_x
