scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/ne
function musashi_story:worldgen/roads/ne
execute positioned 350 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/waypoint_shrine
execute positioned 350 0 -372 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/temple
execute positioned 316 0 -322 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/torii
execute positioned 390 0 -330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 306 0 -402 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
scoreboard players set #gen_ne ms_world 1
schedule function musashi_story:worldgen/regions/ne/detail_1 5t append
schedule function musashi_story:worldgen/regions/ne/detail_2 15t append
schedule function musashi_story:worldgen/regions/ne/detail_3 25t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"MOUNTAIN TEMPLE","color":"white"}]
execute positioned 350 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mountain
