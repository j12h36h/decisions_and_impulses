execute positioned 410 0 -400 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 426 0 -286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
schedule function musashi_story:worldgen/landscape/ne/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/ne/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/ne/foliage_3 70t append
execute positioned 280 0 -286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cave_hill
