execute positioned 284 0 -430 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 438 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 320 0 -380 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stone_lantern
execute positioned 336 0 -344 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
execute positioned 300 0 -420 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mountain
