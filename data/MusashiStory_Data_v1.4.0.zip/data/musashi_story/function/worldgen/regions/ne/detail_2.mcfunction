execute positioned 310 0 -400 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 286 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 400 0 -380 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stone_lantern
execute positioned 426 0 -310 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_z
