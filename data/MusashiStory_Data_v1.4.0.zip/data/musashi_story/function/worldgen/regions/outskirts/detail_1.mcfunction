execute positioned 98 0 28 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 200 0 92 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 188 0 150 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log

execute positioned 80 0 82 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_medium
execute positioned 205 0 128 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_small
execute positioned 126 0 92 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
execute positioned 190 0 116 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stream_ns
execute positioned 188 0 154 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
execute positioned 130 0 180 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/river_meander
