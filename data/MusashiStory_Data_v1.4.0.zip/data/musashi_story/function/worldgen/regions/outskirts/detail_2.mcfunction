execute positioned 132 0 42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 108 0 110 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned 92 0 156 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop

execute positioned 182 0 112 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/garden_patch
execute positioned 116 0 156 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_props
execute positioned 86 0 164 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
execute positioned 78 0 154 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
