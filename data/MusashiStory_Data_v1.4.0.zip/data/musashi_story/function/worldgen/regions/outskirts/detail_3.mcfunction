execute positioned 176 0 58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 156 0 118 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/farm
schedule function musashi_story:worldgen/landscape/outskirts/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/outskirts/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/outskirts/foliage_3 70t append
execute positioned 214 0 78 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
