scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/outskirts
function musashi_story:worldgen/roads/outskirts
execute positioned 118 0 58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/farm
execute positioned 165 0 88 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/house
execute positioned 198 0 48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/watchtower
execute positioned 92 0 38 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/torii
execute positioned 145 0 130 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
scoreboard players set #gen_outskirts ms_world 1
schedule function musashi_story:worldgen/regions/outskirts/detail_1 5t append
schedule function musashi_story:worldgen/regions/outskirts/detail_2 15t append
schedule function musashi_story:worldgen/regions/outskirts/detail_3 25t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"VILLAGE OUTSKIRTS","color":"white"}]
execute positioned 165 0 88 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/structure_foundation_house
execute positioned 118 0 58 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/structure_foundation_house
execute positioned 105 0 100 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_z
