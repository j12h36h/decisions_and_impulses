execute positioned 256 0 246 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 300 0 454 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 398 0 430 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/coastal_wreck

execute positioned 246 0 314 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_small
execute positioned 334 0 296 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_medium
execute positioned 392 0 330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stream_ew
execute positioned 414 0 334 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
