execute positioned 266 0 390 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 368 0 286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/market_stall
schedule function musashi_story:worldgen/landscape/se/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/se/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/se/foliage_3 70t append
execute positioned 374 0 268 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
