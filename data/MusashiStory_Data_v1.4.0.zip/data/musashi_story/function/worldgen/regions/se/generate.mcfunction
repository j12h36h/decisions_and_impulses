scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/se
function musashi_story:worldgen/roads/se
execute positioned 286 0 290 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/waypoint_shrine
execute positioned 350 0 330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/harbor
execute positioned 270 0 260 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/house
execute positioned 250 0 350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/torii
scoreboard players set #gen_se ms_world 1
schedule function musashi_story:worldgen/regions/se/detail_1 8t append
schedule function musashi_story:worldgen/regions/se/detail_2 22t append
schedule function musashi_story:worldgen/regions/se/detail_3 38t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"MOON HARBOR COAST","color":"white"}]
execute positioned 270 0 260 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/structure_foundation_house
execute positioned 300 0 306 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_x
