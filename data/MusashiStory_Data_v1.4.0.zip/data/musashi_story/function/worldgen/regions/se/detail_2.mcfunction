execute positioned 282 0 286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 348 0 272 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/market_stall
execute positioned 282 0 420 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine

execute positioned 390 0 360 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_props
execute positioned 252 0 378 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/river_meander
