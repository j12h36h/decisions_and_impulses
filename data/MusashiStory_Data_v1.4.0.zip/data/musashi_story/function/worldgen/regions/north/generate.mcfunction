scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/north
function musashi_story:worldgen/roads/north
execute positioned 0 0 -320 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/waypoint_shrine
execute positioned 0 0 -340 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/shrine
execute positioned -44 0 -294 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 44 0 -292 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 0 0 -378 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/torii
scoreboard players set #gen_n ms_world 1
schedule function musashi_story:worldgen/regions/north/detail_1 5t append
schedule function musashi_story:worldgen/regions/north/detail_2 15t append
schedule function musashi_story:worldgen/regions/north/detail_3 25t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"FALLEN SHRINE VALLEY","color":"white"}]
execute positioned -76 0 -330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_z
execute positioned 76 0 -330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_z
