execute positioned 74 0 -302 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned -50 0 -390 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
execute positioned 84 0 -272 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned -118 0 -374 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
