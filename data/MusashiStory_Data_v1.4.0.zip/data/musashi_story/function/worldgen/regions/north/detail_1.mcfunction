execute positioned -74 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 96 0 -358 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -82 0 -270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine

execute positioned -72 0 -330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mound_medium
execute positioned 0 0 -308 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stream_ew
execute positioned 0 0 -286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/river_meander
