execute positioned -96 0 -360 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 56 0 -386 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
schedule function musashi_story:worldgen/landscape/north/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/north/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/north/foliage_3 70t append
execute positioned 104 0 -396 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/rock_outcrop
