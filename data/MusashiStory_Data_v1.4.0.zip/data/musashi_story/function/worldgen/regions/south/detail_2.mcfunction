execute positioned 92 0 292 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -64 0 346 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stone_lantern
execute positioned 84 0 428 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned 154 0 412 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
