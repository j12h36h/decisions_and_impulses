scoreboard players set #region_cd ms_world 10
function musashi_story:worldgen/terrain/south
function musashi_story:worldgen/roads/south
execute positioned 0 0 340 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/waypoint_shrine
execute positioned 0 0 370 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/castle_gate
execute positioned -52 0 322 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/watchtower
execute positioned 52 0 322 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/watchtower
execute positioned 0 0 414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/structures/dojo
scoreboard players set #gen_s ms_world 1
schedule function musashi_story:worldgen/regions/south/detail_1 5t append
schedule function musashi_story:worldgen/regions/south/detail_2 15t append
schedule function musashi_story:worldgen/regions/south/detail_3 25t append
tellraw @a[tag=ms_player,distance=..360] [{"text":"REGION AWAKENED // ","color":"gold","bold":true},{"text":"CASTLE PROVINCE","color":"white"}]
execute positioned -92 0 350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_z
execute positioned 92 0 356 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_ridge_z
