execute positioned -104 0 384 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 64 0 346 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/stone_lantern
schedule function musashi_story:worldgen/landscape/south/foliage_1 20t append
schedule function musashi_story:worldgen/landscape/south/foliage_2 45t append
schedule function musashi_story:worldgen/landscape/south/foliage_3 70t append
execute positioned 0 0 470 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_mountain
