execute positioned -92 0 290 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 104 0 386 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -84 0 430 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/roadside_shrine
execute positioned 0 0 364 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
execute positioned -148 0 404 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/terrain_hill_large
