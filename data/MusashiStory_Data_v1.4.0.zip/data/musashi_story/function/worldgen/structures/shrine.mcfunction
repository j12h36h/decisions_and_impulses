function musashi_story:worldgen/features/structure_foundation_large
# Raised Shinto sanctuary with broad veranda and deep eaves.
fill ~-10 ~-2 ~-9 ~10 ~-1 ~9 minecraft:mossy_stone_bricks
fill ~-8 ~ ~-7 ~8 ~ ~7 minecraft:cherry_planks
fill ~-10 ~ ~-9 ~10 ~ ~-8 minecraft:cherry_slab[type=top]
fill ~-10 ~ ~8 ~10 ~ ~9 minecraft:cherry_slab[type=top]
fill ~-9 ~1 ~-7 ~-9 ~6 ~7 minecraft:stripped_cherry_log
fill ~9 ~1 ~-7 ~9 ~6 ~7 minecraft:stripped_cherry_log
fill ~-8 ~1 ~-7 ~8 ~5 ~-7 minecraft:red_concrete
fill ~-8 ~1 ~7 ~8 ~5 ~7 minecraft:red_concrete
fill ~-8 ~1 ~-6 ~-8 ~5 ~6 minecraft:white_terracotta
fill ~8 ~1 ~-6 ~8 ~5 ~6 minecraft:white_terracotta
fill ~-2 ~1 ~-7 ~2 ~3 ~-7 minecraft:air
fill ~-7 ~2 ~-7 ~-4 ~3 ~-7 minecraft:white_stained_glass_pane
fill ~4 ~2 ~-7 ~7 ~3 ~-7 minecraft:white_stained_glass_pane
# roof tiers
fill ~-11 ~6 ~-10 ~11 ~6 ~10 minecraft:deepslate_tiles
fill ~-12 ~7 ~-11 ~12 ~7 ~-11 minecraft:deepslate_tile_stairs[facing=south]
fill ~-12 ~7 ~11 ~12 ~7 ~11 minecraft:deepslate_tile_stairs[facing=north]
fill ~-9 ~7 ~-8 ~9 ~7 ~8 minecraft:polished_blackstone
fill ~-10 ~8 ~-9 ~10 ~8 ~-9 minecraft:polished_blackstone_stairs[facing=south]
fill ~-10 ~8 ~9 ~10 ~8 ~9 minecraft:polished_blackstone_stairs[facing=north]
# altar and hanging lanterns
fill ~-3 ~1 ~3 ~3 ~2 ~5 minecraft:dark_oak_planks
setblock ~ ~3 ~5 minecraft:bell[attachment=floor,facing=north]
setblock ~-5 ~3 ~-6 minecraft:lantern[hanging=true]
setblock ~5 ~3 ~-6 minecraft:lantern[hanging=true]
setblock ~-7 ~1 ~ minecraft:red_candle[candles=4,lit=true]
setblock ~7 ~1 ~ minecraft:red_candle[candles=4,lit=true]
execute positioned ~-12 ~ ~-5 run function musashi_story:worldgen/features/stone_lantern
execute positioned ~12 ~ ~-5 run function musashi_story:worldgen/features/stone_lantern
