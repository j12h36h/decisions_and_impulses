function musashi_story:worldgen/features/structure_foundation_large
# War-torn field with trenches, burnt palisades and a shattered command post.
fill ~-20 ~-1 ~-20 ~20 ~-1 ~20 minecraft:coarse_dirt replace minecraft:grass_block
fill ~-18 ~ ~-12 ~-4 ~1 ~-12 minecraft:spruce_fence
fill ~5 ~ ~10 ~18 ~1 ~10 minecraft:spruce_fence
fill ~-12 ~-1 ~-3 ~12 ~-1 ~-1 minecraft:mud
fill ~-12 ~ ~-3 ~12 ~ ~-3 minecraft:oak_trapdoor[half=bottom,facing=north]
fill ~-12 ~ ~-1 ~12 ~ ~-1 minecraft:oak_trapdoor[half=bottom,facing=south]
setblock ~-13 ~ ~-11 minecraft:campfire[lit=false]
setblock ~9 ~ ~-7 minecraft:campfire[lit=false]
setblock ~4 ~ ~13 minecraft:campfire[lit=false]
fill ~-7 ~ ~5 ~-2 ~3 ~9 minecraft:cobblestone hollow
fill ~-8 ~4 ~4 ~-1 ~4 ~10 minecraft:deepslate_tiles
setblock ~-5 ~1 ~5 minecraft:oak_door[half=lower,facing=north]
setblock ~-5 ~2 ~5 minecraft:oak_door[half=upper,facing=north]
setblock ~15 ~ ~-15 minecraft:iron_bars
setblock ~-15 ~ ~15 minecraft:cobblestone_wall
execute positioned ~-17 ~ ~-5 run function musashi_story:worldgen/features/fallen_log
execute positioned ~13 ~ ~4 run function musashi_story:worldgen/features/fallen_log
