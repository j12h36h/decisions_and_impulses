function musashi_story:worldgen/features/structure_foundation_house
# Minka v4 — compact proportions, full hip roof, deep eaves, engawa and lived-in rear facade.
fill ~-8 ~-5 ~-6 ~8 ~-1 ~6 minecraft:cobblestone
fill ~-7 ~ ~-5 ~7 ~ ~5 minecraft:dark_oak_planks
# timber posts
fill ~-8 ~ ~-6 ~-8 ~5 ~6 minecraft:stripped_dark_oak_log
fill ~8 ~ ~-6 ~8 ~5 ~6 minecraft:stripped_dark_oak_log
fill ~-4 ~ ~-6 ~-4 ~5 ~-6 minecraft:stripped_dark_oak_log
fill ~4 ~ ~-6 ~4 ~5 ~-6 minecraft:stripped_dark_oak_log
fill ~-4 ~ ~6 ~-4 ~5 ~6 minecraft:stripped_dark_oak_log
fill ~4 ~ ~6 ~4 ~5 ~6 minecraft:stripped_dark_oak_log
# plaster infill
fill ~-7 ~1 ~-6 ~7 ~4 ~-6 minecraft:white_terracotta
fill ~-7 ~1 ~6 ~7 ~4 ~6 minecraft:white_terracotta
fill ~-8 ~1 ~-5 ~-8 ~4 ~5 minecraft:white_terracotta
fill ~8 ~1 ~-5 ~8 ~4 ~5 minecraft:white_terracotta
# exposed beams
fill ~-7 ~2 ~-6 ~7 ~2 ~-6 minecraft:stripped_dark_oak_log[axis=x]
fill ~-7 ~4 ~-6 ~7 ~4 ~-6 minecraft:stripped_dark_oak_log[axis=x]
fill ~-7 ~2 ~6 ~7 ~2 ~6 minecraft:stripped_dark_oak_log[axis=x]
fill ~-7 ~4 ~6 ~7 ~4 ~6 minecraft:stripped_dark_oak_log[axis=x]
fill ~-8 ~2 ~-5 ~-8 ~2 ~5 minecraft:stripped_dark_oak_log[axis=z]
fill ~8 ~2 ~-5 ~8 ~2 ~5 minecraft:stripped_dark_oak_log[axis=z]
# front and rear entrances
fill ~-2 ~1 ~6 ~2 ~3 ~6 minecraft:air
setblock ~-1 ~1 ~6 minecraft:cherry_door[half=lower,facing=north,hinge=left]
setblock ~-1 ~2 ~6 minecraft:cherry_door[half=upper,facing=north,hinge=left]
setblock ~1 ~1 ~6 minecraft:cherry_door[half=lower,facing=north,hinge=right]
setblock ~1 ~2 ~6 minecraft:cherry_door[half=upper,facing=north,hinge=right]
fill ~-1 ~1 ~-6 ~1 ~2 ~-6 minecraft:air
setblock ~ ~1 ~-6 minecraft:cherry_door[half=lower,facing=south]
setblock ~ ~2 ~-6 minecraft:cherry_door[half=upper,facing=south]
# shoji glazing and shutters
fill ~-6 ~2 ~6 ~-4 ~3 ~6 minecraft:white_stained_glass_pane
fill ~4 ~2 ~6 ~6 ~3 ~6 minecraft:white_stained_glass_pane
fill ~-6 ~2 ~-6 ~-4 ~3 ~-6 minecraft:white_stained_glass_pane
fill ~4 ~2 ~-6 ~6 ~3 ~-6 minecraft:white_stained_glass_pane
setblock ~-7 ~2 ~6 minecraft:dark_oak_trapdoor[facing=east,open=true]
setblock ~7 ~2 ~6 minecraft:dark_oak_trapdoor[facing=west,open=true]
# engawa
fill ~-9 ~ ~-8 ~9 ~ ~-7 minecraft:cherry_slab[type=top]
fill ~-9 ~ ~7 ~9 ~ ~8 minecraft:cherry_slab[type=top]
fill ~-10 ~ ~-6 ~-9 ~ ~6 minecraft:cherry_slab[type=top]
fill ~9 ~ ~-6 ~10 ~ ~6 minecraft:cherry_slab[type=top]
# full stepped hip roof rather than disconnected strips
fill ~-10 ~5 ~-8 ~10 ~5 ~8 minecraft:deepslate_tiles
fill ~-9 ~6 ~-6 ~9 ~6 ~6 minecraft:deepslate_tiles
fill ~-8 ~7 ~-4 ~8 ~7 ~4 minecraft:deepslate_tiles
fill ~-7 ~8 ~-2 ~7 ~8 ~2 minecraft:deepslate_tiles
fill ~-7 ~9 ~-1 ~7 ~9 ~1 minecraft:polished_blackstone
fill ~-11 ~5 ~-8 ~-11 ~5 ~8 minecraft:deepslate_tile_stairs[facing=east]
fill ~11 ~5 ~-8 ~11 ~5 ~8 minecraft:deepslate_tile_stairs[facing=west]
fill ~-10 ~5 ~-9 ~10 ~5 ~-9 minecraft:deepslate_tile_stairs[facing=south]
fill ~-10 ~5 ~9 ~10 ~5 ~9 minecraft:deepslate_tile_stairs[facing=north]
# interior
fill ~-6 ~1 ~-4 ~6 ~1 ~4 minecraft:yellow_carpet
fill ~ ~1 ~-5 ~ ~1 ~5 minecraft:red_carpet
setblock ~-5 ~1 ~3 minecraft:red_bed[part=foot,facing=east]
setblock ~-4 ~1 ~3 minecraft:red_bed[part=head,facing=east]
setblock ~5 ~1 ~3 minecraft:barrel
setblock ~5 ~1 ~-3 minecraft:crafting_table
setblock ~-5 ~3 ~-4 minecraft:lantern[hanging=true]
setblock ~5 ~3 ~-4 minecraft:lantern[hanging=true]
# v0.9 side/rear completion
fill ~-8 ~2 ~-2 ~-8 ~3 ~2 minecraft:white_stained_glass_pane
fill ~8 ~2 ~-2 ~8 ~3 ~2 minecraft:white_stained_glass_pane
fill ~-3 ~2 ~-6 ~-2 ~3 ~-6 minecraft:white_stained_glass_pane
fill ~2 ~2 ~-6 ~3 ~3 ~-6 minecraft:white_stained_glass_pane
setblock ~-9 ~1 ~-3 minecraft:lantern
setblock ~9 ~1 ~3 minecraft:lantern

