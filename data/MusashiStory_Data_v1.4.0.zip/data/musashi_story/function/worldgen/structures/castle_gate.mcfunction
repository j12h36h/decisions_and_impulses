function musashi_story:worldgen/features/structure_foundation_large
# Castle gate v3: earth-supported stone base; no floating gatehouse.
fill ~-28 ~-18 ~-13 ~28 ~-1 ~13 minecraft:stone
fill ~-25 ~-5 ~-11 ~25 ~-1 ~11 minecraft:stone_bricks
fill ~-24 ~ ~-9 ~-10 ~11 ~9 minecraft:stone_bricks
fill ~10 ~ ~-9 ~24 ~11 ~9 minecraft:stone_bricks
fill ~-9 ~7 ~-9 ~9 ~11 ~9 minecraft:stone_bricks
fill ~-9 ~ ~-7 ~9 ~6 ~7 minecraft:air
# battered buttresses
fill ~-28 ~-3 ~-12 ~-23 ~8 ~12 minecraft:mossy_stone_bricks
fill ~23 ~-3 ~-12 ~28 ~8 ~12 minecraft:mossy_stone_bricks
fill ~-24 ~8 ~-10 ~-10 ~9 ~10 minecraft:dark_oak_planks
fill ~10 ~8 ~-10 ~24 ~9 ~10 minecraft:dark_oak_planks
# red gate frame and portcullis
fill ~-10 ~1 ~-10 ~-10 ~8 ~10 minecraft:stripped_dark_oak_log
fill ~10 ~1 ~-10 ~10 ~8 ~10 minecraft:stripped_dark_oak_log
fill ~-9 ~6 ~-10 ~9 ~6 ~-10 minecraft:red_concrete
fill ~-6 ~1 ~-9 ~6 ~5 ~-9 minecraft:iron_bars
fill ~-2 ~1 ~-9 ~2 ~5 ~-9 minecraft:air
# layered pitched roof
fill ~-28 ~12 ~-13 ~28 ~12 ~-12 minecraft:deepslate_tile_stairs[facing=south]
fill ~-28 ~12 ~12 ~28 ~12 ~13 minecraft:deepslate_tile_stairs[facing=north]
fill ~-26 ~13 ~-10 ~26 ~13 ~-9 minecraft:deepslate_tile_stairs[facing=south]
fill ~-26 ~13 ~9 ~26 ~13 ~10 minecraft:deepslate_tile_stairs[facing=north]
fill ~-22 ~14 ~-7 ~22 ~14 ~-6 minecraft:deepslate_tile_stairs[facing=south]
fill ~-22 ~14 ~6 ~22 ~14 ~7 minecraft:deepslate_tile_stairs[facing=north]
fill ~-18 ~15 ~-4 ~18 ~15 ~-3 minecraft:deepslate_tile_stairs[facing=south]
fill ~-18 ~15 ~3 ~18 ~15 ~4 minecraft:deepslate_tile_stairs[facing=north]
fill ~-16 ~16 ~-1 ~16 ~16 ~1 minecraft:polished_blackstone
setblock ~-15 ~6 ~-10 minecraft:lantern[hanging=true]
setblock ~15 ~6 ~-10 minecraft:lantern[hanging=true]
execute positioned ~-31 ~ ~-13 run function musashi_story:worldgen/features/stone_lantern
execute positioned ~31 ~ ~-13 run function musashi_story:worldgen/features/stone_lantern
