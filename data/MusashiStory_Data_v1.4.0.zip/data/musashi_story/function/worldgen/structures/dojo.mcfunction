function musashi_story:worldgen/features/structure_foundation_dojo
# Dojo v4 — lower, stronger massing and a complete tiled hip roof.
fill ~-12 ~-6 ~-9 ~12 ~-1 ~9 minecraft:stone_bricks
fill ~-10 ~ ~-7 ~10 ~ ~7 minecraft:spruce_planks
fill ~-11 ~ ~-8 ~-11 ~6 ~8 minecraft:stripped_dark_oak_log
fill ~11 ~ ~-8 ~11 ~6 ~8 minecraft:stripped_dark_oak_log
fill ~-10 ~1 ~-8 ~10 ~5 ~-8 minecraft:white_terracotta
fill ~-10 ~1 ~8 ~10 ~5 ~8 minecraft:white_terracotta
fill ~-11 ~1 ~-7 ~-11 ~5 ~7 minecraft:white_terracotta
fill ~11 ~1 ~-7 ~11 ~5 ~7 minecraft:white_terracotta
fill ~-10 ~2 ~-8 ~10 ~2 ~-8 minecraft:stripped_dark_oak_log[axis=x]
fill ~-10 ~5 ~-8 ~10 ~5 ~-8 minecraft:stripped_dark_oak_log[axis=x]
fill ~-10 ~2 ~8 ~10 ~2 ~8 minecraft:stripped_dark_oak_log[axis=x]
fill ~-10 ~5 ~8 ~10 ~5 ~8 minecraft:stripped_dark_oak_log[axis=x]
fill ~-3 ~1 ~-8 ~3 ~4 ~-8 minecraft:air
fill ~-3 ~1 ~8 ~3 ~4 ~8 minecraft:air
setblock ~-1 ~1 ~8 minecraft:cherry_door[half=lower,facing=north,hinge=left]
setblock ~-1 ~2 ~8 minecraft:cherry_door[half=upper,facing=north,hinge=left]
setblock ~1 ~1 ~8 minecraft:cherry_door[half=lower,facing=north,hinge=right]
setblock ~1 ~2 ~8 minecraft:cherry_door[half=upper,facing=north,hinge=right]
setblock ~-1 ~1 ~-8 minecraft:cherry_door[half=lower,facing=south,hinge=left]
setblock ~-1 ~2 ~-8 minecraft:cherry_door[half=upper,facing=south,hinge=left]
setblock ~1 ~1 ~-8 minecraft:cherry_door[half=lower,facing=south,hinge=right]
setblock ~1 ~2 ~-8 minecraft:cherry_door[half=upper,facing=south,hinge=right]
fill ~-9 ~2 ~8 ~-6 ~4 ~8 minecraft:white_stained_glass_pane
fill ~6 ~2 ~8 ~9 ~4 ~8 minecraft:white_stained_glass_pane
fill ~-9 ~2 ~-8 ~-6 ~4 ~-8 minecraft:white_stained_glass_pane
fill ~6 ~2 ~-8 ~9 ~4 ~-8 minecraft:white_stained_glass_pane
fill ~-10 ~ ~-11 ~10 ~ ~-9 minecraft:cherry_slab[type=top]
fill ~-10 ~ ~9 ~10 ~ ~11 minecraft:cherry_slab[type=top]
# full roof
fill ~-13 ~6 ~-11 ~13 ~6 ~11 minecraft:deepslate_tiles
fill ~-12 ~7 ~-9 ~12 ~7 ~9 minecraft:deepslate_tiles
fill ~-11 ~8 ~-7 ~11 ~8 ~7 minecraft:deepslate_tiles
fill ~-10 ~9 ~-5 ~10 ~9 ~5 minecraft:deepslate_tiles
fill ~-9 ~10 ~-3 ~9 ~10 ~3 minecraft:deepslate_tiles
fill ~-9 ~11 ~-1 ~9 ~11 ~1 minecraft:polished_blackstone
fill ~-14 ~6 ~-11 ~-14 ~6 ~11 minecraft:deepslate_tile_stairs[facing=east]
fill ~14 ~6 ~-11 ~14 ~6 ~11 minecraft:deepslate_tile_stairs[facing=west]
fill ~-13 ~6 ~-12 ~13 ~6 ~-12 minecraft:deepslate_tile_stairs[facing=south]
fill ~-13 ~6 ~12 ~13 ~6 ~12 minecraft:deepslate_tile_stairs[facing=north]
# training floor
fill ~-8 ~1 ~-5 ~8 ~1 ~5 minecraft:yellow_carpet
fill ~-1 ~1 ~-6 ~1 ~1 ~6 minecraft:red_carpet
summon minecraft:armor_stand ~-5 ~1 ~0 {NoGravity:1b,Invulnerable:1b,PersistenceRequired:1b,Tags:['ms_static'],ShowArms:1b}
summon minecraft:armor_stand ~5 ~1 ~0 {NoGravity:1b,Invulnerable:1b,PersistenceRequired:1b,Tags:['ms_static'],ShowArms:1b}
setblock ~-8 ~4 ~-6 minecraft:lantern[hanging=true]
setblock ~8 ~4 ~-6 minecraft:lantern[hanging=true]
# v0.9 side/rear completion
fill ~-11 ~2 ~-4 ~-11 ~4 ~-1 minecraft:white_stained_glass_pane
fill ~11 ~2 ~1 ~11 ~4 ~4 minecraft:white_stained_glass_pane
fill ~-5 ~2 ~-8 ~-3 ~4 ~-8 minecraft:white_stained_glass_pane
fill ~3 ~2 ~-8 ~5 ~4 ~-8 minecraft:white_stained_glass_pane
setblock ~-10 ~1 ~6 minecraft:lantern
setblock ~10 ~1 ~-6 minecraft:lantern

