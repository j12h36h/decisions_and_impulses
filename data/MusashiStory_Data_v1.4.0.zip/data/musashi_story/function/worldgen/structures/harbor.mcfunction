function musashi_story:worldgen/features/structure_foundation_large
# Moon Harbor v4 — layered seawall, piles, warehouse, crane and two boats.
fill ~-20 ~-4 ~-20 ~20 ~-1 ~10 minecraft:water
# stone quay and timber pier
fill ~-7 ~-2 ~-20 ~7 ~-1 ~16 minecraft:stone_bricks
fill ~-5 ~ ~-20 ~5 ~ ~16 minecraft:spruce_planks
fill ~-6 ~-3 ~-17 ~-6 ~2 ~-17 minecraft:stripped_spruce_log
fill ~6 ~-3 ~-17 ~6 ~2 ~-17 minecraft:stripped_spruce_log
fill ~-6 ~-3 ~-7 ~-6 ~2 ~-7 minecraft:stripped_spruce_log
fill ~6 ~-3 ~-7 ~6 ~2 ~-7 minecraft:stripped_spruce_log
fill ~-6 ~-3 ~4 ~-6 ~2 ~4 minecraft:stripped_spruce_log
fill ~6 ~-3 ~4 ~6 ~2 ~4 minecraft:stripped_spruce_log
setblock ~-6 ~2 ~-17 minecraft:lantern
setblock ~6 ~2 ~-17 minecraft:lantern
setblock ~-6 ~2 ~4 minecraft:lantern
setblock ~6 ~2 ~4 minecraft:lantern
# warehouse with complete pitched roof
fill ~9 ~-2 ~1 ~24 ~-1 ~15 minecraft:cobblestone
fill ~10 ~ ~2 ~23 ~6 ~14 minecraft:spruce_planks hollow
fill ~10 ~1 ~2 ~10 ~6 ~14 minecraft:stripped_dark_oak_log
fill ~23 ~1 ~2 ~23 ~6 ~14 minecraft:stripped_dark_oak_log
fill ~9 ~7 ~1 ~24 ~7 ~15 minecraft:deepslate_tiles
fill ~10 ~8 ~3 ~23 ~8 ~13 minecraft:deepslate_tiles
fill ~11 ~9 ~5 ~22 ~9 ~11 minecraft:deepslate_tiles
fill ~12 ~10 ~7 ~21 ~10 ~9 minecraft:polished_blackstone
fill ~8 ~7 ~1 ~8 ~7 ~15 minecraft:deepslate_tile_stairs[facing=east]
fill ~25 ~7 ~1 ~25 ~7 ~15 minecraft:deepslate_tile_stairs[facing=west]
fill ~14 ~1 ~2 ~18 ~4 ~2 minecraft:air
setblock ~15 ~1 ~2 minecraft:spruce_door[half=lower,facing=north]
setblock ~15 ~2 ~2 minecraft:spruce_door[half=upper,facing=north]
setblock ~11 ~1 ~11 minecraft:barrel
setblock ~12 ~1 ~11 minecraft:barrel
setblock ~21 ~1 ~11 minecraft:barrel
setblock ~20 ~1 ~10 minecraft:chest[facing=west]
# crane: iron bars replace unsupported chain block id
fill ~-12 ~-1 ~6 ~-12 ~8 ~6 minecraft:stripped_spruce_log
fill ~-12 ~8 ~6 ~-3 ~8 ~6 minecraft:stripped_spruce_log[axis=x]
fill ~-3 ~8 ~6 ~-3 ~3 ~6 minecraft:iron_bars
setblock ~-3 ~2 ~6 minecraft:barrel
# fishing skiff
fill ~-17 ~-1 ~-10 ~-8 ~-1 ~-5 minecraft:dark_oak_planks
fill ~-15 ~ ~-9 ~-10 ~ ~-6 minecraft:air
fill ~-17 ~ ~-10 ~-17 ~1 ~-5 minecraft:dark_oak_fence
fill ~-8 ~ ~-10 ~-8 ~1 ~-5 minecraft:dark_oak_fence
# second smaller boat
fill ~9 ~-1 ~-14 ~16 ~-1 ~-10 minecraft:spruce_planks
fill ~11 ~ ~-13 ~14 ~ ~-11 minecraft:air
setblock ~12 ~ ~-12 minecraft:barrel
# dock clutter
setblock ~-2 ~1 ~10 minecraft:barrel
setblock ~2 ~1 ~10 minecraft:barrel
setblock ~-2 ~1 ~13 minecraft:hay_block
setblock ~3 ~1 ~13 minecraft:chest[facing=north]
