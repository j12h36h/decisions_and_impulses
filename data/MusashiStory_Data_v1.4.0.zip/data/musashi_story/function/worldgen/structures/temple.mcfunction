function musashi_story:worldgen/features/structure_foundation_large
# Mountain temple / compact three-tier pagoda silhouette.
fill ~-12 ~-3 ~-10 ~12 ~-1 ~10 minecraft:stone_bricks
fill ~-10 ~ ~-8 ~10 ~ ~8 minecraft:cherry_planks
fill ~-11 ~1 ~-9 ~-11 ~6 ~9 minecraft:stripped_dark_oak_log
fill ~11 ~1 ~-9 ~11 ~6 ~9 minecraft:stripped_dark_oak_log
fill ~-10 ~1 ~-9 ~10 ~5 ~-9 minecraft:white_terracotta
fill ~-10 ~1 ~9 ~10 ~5 ~9 minecraft:white_terracotta
fill ~-10 ~1 ~-8 ~-10 ~5 ~8 minecraft:white_terracotta
fill ~10 ~1 ~-8 ~10 ~5 ~8 minecraft:white_terracotta
fill ~-2 ~1 ~-9 ~2 ~3 ~-9 minecraft:air
fill ~-13 ~6 ~-11 ~13 ~6 ~11 minecraft:deepslate_tiles
fill ~-14 ~7 ~-12 ~14 ~7 ~-12 minecraft:deepslate_tile_stairs[facing=south]
fill ~-14 ~7 ~12 ~14 ~7 ~12 minecraft:deepslate_tile_stairs[facing=north]
# upper floor
fill ~-7 ~7 ~-6 ~7 ~7 ~6 minecraft:cherry_planks
fill ~-7 ~8 ~-6 ~-7 ~11 ~6 minecraft:stripped_dark_oak_log
fill ~7 ~8 ~-6 ~7 ~11 ~6 minecraft:stripped_dark_oak_log
fill ~-6 ~8 ~-6 ~6 ~10 ~-6 minecraft:red_concrete
fill ~-6 ~8 ~6 ~6 ~10 ~6 minecraft:red_concrete
fill ~-9 ~11 ~-8 ~9 ~11 ~8 minecraft:polished_blackstone
fill ~-10 ~12 ~-9 ~10 ~12 ~-9 minecraft:polished_blackstone_stairs[facing=south]
fill ~-10 ~12 ~9 ~10 ~12 ~9 minecraft:polished_blackstone_stairs[facing=north]
# top lantern tower
fill ~-3 ~12 ~-3 ~3 ~12 ~3 minecraft:cherry_planks
fill ~-3 ~13 ~-3 ~-3 ~16 ~3 minecraft:stripped_cherry_log
fill ~3 ~13 ~-3 ~3 ~16 ~3 minecraft:stripped_cherry_log
fill ~-5 ~16 ~-5 ~5 ~16 ~5 minecraft:deepslate_tiles
fill ~-6 ~17 ~-6 ~6 ~17 ~-6 minecraft:deepslate_tile_stairs[facing=south]
fill ~-6 ~17 ~6 ~6 ~17 ~6 minecraft:deepslate_tile_stairs[facing=north]
setblock ~ ~13 ~ minecraft:bell[attachment=floor,facing=north]
setblock ~-6 ~3 ~-8 minecraft:lantern[hanging=true]
setblock ~6 ~3 ~-8 minecraft:lantern[hanging=true]
