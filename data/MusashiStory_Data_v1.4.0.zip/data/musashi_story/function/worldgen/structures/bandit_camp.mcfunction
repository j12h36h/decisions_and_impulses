function musashi_story:worldgen/features/structure_foundation_small
# Palisaded raider encampment with tents, cages, supplies and watch fire.
fill ~-14 ~-1 ~-14 ~14 ~-1 ~14 minecraft:coarse_dirt replace minecraft:grass_block
fill ~-14 ~ ~-14 ~14 ~3 ~-14 minecraft:spruce_fence
fill ~-14 ~ ~14 ~14 ~3 ~14 minecraft:spruce_fence
fill ~-14 ~ ~-13 ~-14 ~3 ~13 minecraft:spruce_fence
fill ~14 ~ ~-13 ~14 ~3 ~13 minecraft:spruce_fence
fill ~-2 ~ ~-14 ~2 ~3 ~-14 minecraft:air
setblock ~ ~ ~ minecraft:campfire
# tents
fill ~-11 ~ ~-9 ~-4 ~ ~-3 minecraft:spruce_planks
fill ~-11 ~1 ~-9 ~-4 ~4 ~-9 minecraft:red_wool
fill ~-11 ~1 ~-3 ~-4 ~4 ~-3 minecraft:red_wool
fill ~5 ~ ~4 ~11 ~ ~10 minecraft:spruce_planks
fill ~5 ~1 ~4 ~11 ~4 ~4 minecraft:brown_wool
fill ~5 ~1 ~10 ~11 ~4 ~10 minecraft:brown_wool
# cage
fill ~-10 ~ ~5 ~-5 ~4 ~10 minecraft:iron_bars hollow
setblock ~-7 ~ ~5 minecraft:iron_door[half=lower,facing=north]
setblock ~-7 ~1 ~5 minecraft:iron_door[half=upper,facing=north]
# supplies
setblock ~8 ~ ~-8 minecraft:barrel
setblock ~9 ~ ~-8 minecraft:barrel
setblock ~10 ~ ~-8 minecraft:chest[facing=south]
setblock ~-8 ~ ~-6 minecraft:hay_block
setblock ~-9 ~ ~-6 minecraft:hay_block
# banners / fires
setblock ~-12 ~1 ~-12 minecraft:lantern
setblock ~12 ~1 ~-12 minecraft:lantern
setblock ~-8 ~ ~12 minecraft:campfire
