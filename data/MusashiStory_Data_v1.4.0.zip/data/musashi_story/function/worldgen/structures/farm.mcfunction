function musashi_story:worldgen/features/structure_foundation_large
# Farm v4 — staggered terraces and irrigation rather than one rectangle.
# terrace A
fill ~-14 ~-2 ~-8 ~12 ~-2 ~8 minecraft:dirt
fill ~-12 ~-1 ~-6 ~10 ~-1 ~6 minecraft:farmland[moisture=7]
fill ~-1 ~-1 ~-6 ~1 ~-1 ~6 minecraft:water
fill ~-12 ~ ~-6 ~-2 ~ ~6 minecraft:wheat[age=7]
fill ~2 ~ ~-6 ~10 ~ ~6 minecraft:wheat[age=7]
# terrace B offset and one block higher
fill ~-9 ~-1 ~10 ~14 ~-1 ~23 minecraft:dirt
fill ~-7 ~ ~12 ~12 ~ ~21 minecraft:farmland[moisture=7]
fill ~3 ~ ~12 ~4 ~ ~21 minecraft:water
fill ~-7 ~1 ~12 ~2 ~1 ~21 minecraft:wheat[age=7]
fill ~5 ~1 ~12 ~12 ~1 ~21 minecraft:wheat[age=7]
# berms / stepping bridge
fill ~-15 ~-1 ~-9 ~13 ~-1 ~-9 minecraft:dirt_path
fill ~-10 ~ ~9 ~15 ~ ~9 minecraft:dirt_path
fill ~-2 ~ ~-2 ~2 ~ ~2 minecraft:cherry_slab[type=bottom]
# scarecrow
fill ~9 ~ ~-5 ~9 ~3 ~-5 minecraft:oak_fence
fill ~7 ~2 ~-5 ~11 ~2 ~-5 minecraft:oak_fence
setblock ~9 ~4 ~-5 minecraft:carved_pumpkin[facing=south]
# field shelter
fill ~-13 ~ ~14 ~-9 ~3 ~19 minecraft:spruce_planks hollow
fill ~-14 ~4 ~13 ~-8 ~4 ~20 minecraft:deepslate_tiles
fill ~-15 ~4 ~12 ~-15 ~4 ~21 minecraft:deepslate_tile_stairs[facing=east]
fill ~-7 ~4 ~12 ~-7 ~4 ~21 minecraft:deepslate_tile_stairs[facing=west]
setblock ~-11 ~1 ~14 minecraft:spruce_door[half=lower,facing=north]
setblock ~-11 ~2 ~14 minecraft:spruce_door[half=upper,facing=north]
setblock ~-9 ~2 ~17 minecraft:lantern
