function musashi_story:worldgen/features/structure_foundation_small
# Supported watchtower with stone battered base and pitched roof.
fill ~-6 ~-8 ~-6 ~6 ~-1 ~6 minecraft:mossy_stone_bricks
fill ~-5 ~ ~-5 ~5 ~3 ~5 minecraft:stone_bricks hollow
fill ~-6 ~4 ~-6 ~-6 ~10 ~6 minecraft:stripped_spruce_log
fill ~6 ~4 ~-6 ~6 ~10 ~6 minecraft:stripped_spruce_log
fill ~-6 ~4 ~-6 ~6 ~10 ~-6 minecraft:stripped_spruce_log
fill ~-6 ~4 ~6 ~6 ~10 ~6 minecraft:stripped_spruce_log
fill ~-5 ~8 ~-5 ~5 ~8 ~5 minecraft:spruce_planks
fill ~-6 ~9 ~-6 ~6 ~9 ~-6 minecraft:spruce_fence
fill ~-6 ~9 ~6 ~6 ~9 ~6 minecraft:spruce_fence
fill ~-6 ~9 ~-5 ~-6 ~9 ~5 minecraft:spruce_fence
fill ~6 ~9 ~-5 ~6 ~9 ~5 minecraft:spruce_fence
fill ~-8 ~11 ~-7 ~8 ~11 ~-6 minecraft:deepslate_tile_stairs[facing=south]
fill ~-8 ~11 ~6 ~8 ~11 ~7 minecraft:deepslate_tile_stairs[facing=north]
fill ~-7 ~12 ~-5 ~7 ~12 ~-4 minecraft:deepslate_tile_stairs[facing=south]
fill ~-7 ~12 ~4 ~7 ~12 ~5 minecraft:deepslate_tile_stairs[facing=north]
fill ~-6 ~13 ~-3 ~6 ~13 ~-2 minecraft:deepslate_tile_stairs[facing=south]
fill ~-6 ~13 ~2 ~6 ~13 ~3 minecraft:deepslate_tile_stairs[facing=north]
fill ~-5 ~14 ~-1 ~5 ~14 ~1 minecraft:polished_blackstone
fill ~ ~ ~ ~ ~8 ~ minecraft:ladder[facing=north]
setblock ~-4 ~10 ~ minecraft:lantern
setblock ~4 ~10 ~ minecraft:lantern
