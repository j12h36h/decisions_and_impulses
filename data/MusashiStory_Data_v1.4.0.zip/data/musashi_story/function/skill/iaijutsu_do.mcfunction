scoreboard players remove @s ms_resolve 25
playsound minecraft:item.trident.riptide_1 player @s ~ ~ ~ 0.9 1.55
particle minecraft:sweep_attack ~ ~1 ~ 0.7 0.2 0.7 0 12 force @a[distance=..32]
teleport @s ^ ^0.1 ^6
execute at @s as @e[tag=ms_enemy,distance=..3,limit=7,sort=nearest] run damage @s 9 minecraft:player_attack by @a[tag=ms_player,distance=..7,limit=1,sort=nearest]
title @s actionbar {"text":"IAIJUTSU — DRAW / PASS / SHEATHE","color":"red","bold":true}
