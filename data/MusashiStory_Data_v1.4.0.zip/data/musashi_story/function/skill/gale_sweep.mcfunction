execute if score @s ms_resolve matches 25.. run function musashi_story:skill/gale_sweep_do
execute unless score @s ms_resolve matches 25.. run tellraw @s [{"text":"[RESOLVE] ","color":"dark_red","bold":true},{"text":"Gale Sweep requires 25 Resolve.","color":"gray"}]
