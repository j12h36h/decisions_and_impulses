scoreboard players remove @s ms_resolve 35
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 1 0.55
effect give @e[tag=ms_enemy,distance=..10] minecraft:slowness 4 10 true
effect give @e[tag=ms_enemy,distance=..10] minecraft:weakness 4 4 true
effect give @e[tag=ms_enemy,distance=..10] minecraft:glowing 4 0 true
effect give @s minecraft:speed 4 1 true
particle minecraft:reverse_portal ~ ~1 ~ 3 1 3 0.02 90 force @s
title @s title {"text":"MUSHIN","color":"white","bold":true}
title @s subtitle {"text":"The world slows. The swordsman does not.","color":"gray"}
