scoreboard players remove @s ms_resolve 15
playsound minecraft:entity.breeze.wind_burst player @s ~ ~ ~ 0.7 1.35
particle minecraft:cloud ~ ~0.3 ~ 0.4 0.2 0.4 0.04 18 force @a[distance=..24]
teleport @s ^ ^0.15 ^7
effect give @s minecraft:speed 2 2 true
title @s actionbar {"text":"WIND STEP","color":"aqua","bold":true}
