scoreboard players remove @s ms_resolve 20
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.75 1.4
particle minecraft:large_smoke ~ ~1 ~ 0.5 0.8 0.5 0.02 35 force @a[distance=..24]
effect give @s minecraft:invisibility 2 0 true
teleport @s ^ ^0.1 ^8
effect give @s minecraft:speed 2 3 true
title @s actionbar {"text":"SHADOW STEP","color":"dark_purple","bold":true}
