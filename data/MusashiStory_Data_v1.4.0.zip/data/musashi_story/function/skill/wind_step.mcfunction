execute if score @s ms_resolve matches 15.. run function musashi_story:skill/wind_step_do
execute unless score @s ms_resolve matches 15.. run tellraw @s [{"text":"[RESOLVE] ","color":"dark_red","bold":true},{"text":"Wind Step requires 15 Resolve.","color":"gray"}]
