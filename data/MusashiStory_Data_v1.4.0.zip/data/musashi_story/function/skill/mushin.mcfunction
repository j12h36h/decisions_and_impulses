execute if score @s ms_resolve matches 35.. run function musashi_story:skill/mushin_do
execute unless score @s ms_resolve matches 35.. run tellraw @s [{"text":"[RESOLVE] ","color":"dark_red","bold":true},{"text":"Mushin requires 35 Resolve.","color":"gray"}]
