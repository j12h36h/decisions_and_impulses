scoreboard players remove @s ms_resolve 30
playsound minecraft:block.fire.extinguish player @s ~ ~ ~ 1 0.7
particle minecraft:large_smoke ~ ~1 ~ 3 1 3 0.08 120 force @a[distance=..32]
effect give @s minecraft:invisibility 5 0 true
effect give @s minecraft:speed 5 1 true
effect give @e[tag=ms_enemy,distance=..8] minecraft:blindness 4 0 true
effect give @e[tag=ms_enemy,distance=..8] minecraft:slowness 4 2 true
title @s actionbar {"text":"SMOKE VEIL","color":"gray","bold":true}
