execute if score @s ms_resolve matches 20.. run function musashi_story:skill/shadow_step_do
execute unless score @s ms_resolve matches 20.. run tellraw @s [{"text":"[RESOLVE] ","color":"dark_red","bold":true},{"text":"Shadow Step requires 20 Resolve.","color":"gray"}]
