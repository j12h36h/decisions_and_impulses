execute if score @s ms_resolve matches 30.. run function musashi_story:skill/mountain_breaker_do
execute unless score @s ms_resolve matches 30.. run tellraw @s [{"text":"[RESOLVE] ","color":"dark_red","bold":true},{"text":"Mountain Breaker requires 30 Resolve.","color":"gray"}]
