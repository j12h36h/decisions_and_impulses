function musashi_story:loadout/clear
scoreboard players set @s ms_loadout 2
item replace entity @s hotbar.0 with musashi_story:nodachi
item replace entity @s hotbar.1 with musashi_story:mountain_breaker
item replace entity @s hotbar.2 with musashi_story:mushin
item replace entity @s hotbar.3 with musashi_story:wind_step
item replace entity @s armor.head with minecraft:iron_helmet
item replace entity @s armor.chest with minecraft:iron_chestplate
item replace entity @s armor.legs with minecraft:iron_leggings
item replace entity @s armor.feet with minecraft:iron_boots
execute unless items entity @s inventory.* musashi_story:wayfarer_seal run give @s musashi_story:wayfarer_seal
tellraw @s [{"text":"[MUSASHI] ","color":"red","bold":true},{"text":"Vanguard style equipped — Nodachi // Mountain Breaker // Mushin // Wind Step","color":"gold"}]
