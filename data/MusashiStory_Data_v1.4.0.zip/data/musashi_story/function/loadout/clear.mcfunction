
clear @s musashi_story:katana
clear @s musashi_story:nodachi
clear @s musashi_story:naginata
clear @s musashi_story:wakizashi
clear @s musashi_story:iaijutsu
clear @s musashi_story:mushin
clear @s musashi_story:wind_step
clear @s musashi_story:mountain_breaker
clear @s musashi_story:gale_sweep
clear @s musashi_story:shadow_step
clear @s musashi_story:smoke_veil
item replace entity @s armor.head with minecraft:air
item replace entity @s armor.chest with minecraft:air
item replace entity @s armor.legs with minecraft:air
item replace entity @s armor.feet with minecraft:air
