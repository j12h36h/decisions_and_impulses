scoreboard players add @s ms_honor 6
scoreboard players add @s ms_resolve 6
execute if score @s ms_resolve matches 101.. run scoreboard players set @s ms_resolve 100
execute if score @s ms_bounty matches 2 run scoreboard players add @s ms_bprog 1
execute if score @s ms_bounty matches 2 if score @s ms_bprog matches 3.. run function musashi_story:bounty/complete_2
playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.4 1.35
title @s actionbar [{"text":"HONOR + ","color":"gold","bold":true},{"text":"the road remembers this victory","color":"white"}]
