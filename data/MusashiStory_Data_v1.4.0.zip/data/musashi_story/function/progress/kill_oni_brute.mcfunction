scoreboard players add @s ms_honor 15
scoreboard players add @s ms_resolve 15
execute if score @s ms_resolve matches 101.. run scoreboard players set @s ms_resolve 100
playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.4 1.35
title @s actionbar [{"text":"HONOR + ","color":"gold","bold":true},{"text":"the road remembers this victory","color":"white"}]
