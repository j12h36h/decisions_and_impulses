execute as @a[tag=!bd_items_v030] run function blink_daggers:internal/init_player_v030
execute as @a unless score @s bd_pid matches 1.. run function blink_daggers:internal/assign_player_id

# Independent cooldowns. Q/W default to 5 seconds; R defaults to 15 seconds.
scoreboard players remove @a[scores={bd_cd_q=1..}] bd_cd_q 1
scoreboard players remove @a[scores={bd_cd_w=1..}] bd_cd_w 1
scoreboard players remove @a[scores={bd_cd_r=1..}] bd_cd_r 1
scoreboard players add @a bd_flash 1
execute as @a[scores={bd_flash=8..}] run scoreboard players set @s bd_flash 0

# Seamlessly migrate a selected v0.2.x dagger while keeping the legacy native id registered for old saves.
execute as @a if items entity @s weapon.mainhand blink_daggers:blink_dagger run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=1] 1

# Update whichever Kitty skill item is currently selected. The cooldown itself continues globally when unselected.
execute as @a if items entity @s weapon.mainhand blink_daggers:kitty_dagger run function blink_daggers:ui/main
execute as @a if items entity @s weapon.mainhand blink_daggers:kitty_directional_throw run function blink_daggers:ui/q_item
execute as @a if items entity @s weapon.mainhand blink_daggers:kitty_up_throw run function blink_daggers:ui/w_item
execute as @a if items entity @s weapon.mainhand blink_daggers:kitty_ultimate run function blink_daggers:ui/r_item

execute as @e[type=minecraft:item_display,tag=bd_dagger] at @s run function blink_daggers:projectile/tick
execute as @e[type=minecraft:item_display,tag=bd_ult_knife] at @s run function blink_daggers:ultimate/projectile_tick

# v0.4.0 multiplayer maintenance: remove dagger displays whose owning player is no longer online.
scoreboard players add #maintenance bd_tmp 1
execute if score #maintenance bd_tmp matches 200.. as @e[type=minecraft:item_display,tag=bd_dagger] at @s run function blink_daggers:maintenance/orphan_check
execute if score #maintenance bd_tmp matches 200.. as @e[type=minecraft:item_display,tag=bd_ult_knife] at @s run function blink_daggers:maintenance/orphan_check
execute if score #maintenance bd_tmp matches 200.. run scoreboard players set #maintenance bd_tmp 0
