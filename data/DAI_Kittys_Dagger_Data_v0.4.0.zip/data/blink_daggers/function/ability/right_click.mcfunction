# Recall has priority and does not spend W cooldown. Otherwise W places a dagger + speed burst.
scoreboard players set @s bd_ray 0
execute if entity @e[type=minecraft:item_display,tag=bd_dagger,distance=..35.8] run function blink_daggers:recall/start
execute unless score @s bd_ray matches 999 if score @s bd_cd_w matches 0 run function blink_daggers:ability/drop
