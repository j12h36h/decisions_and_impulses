# [DAI] Kitty's Dagger v0.4.0 / DAI 3.0
scoreboard objectives add bd_pid dummy
scoreboard objectives add bd_owner dummy
scoreboard objectives add bd_age dummy
scoreboard objectives add bd_spin dummy
scoreboard objectives add bd_pitch dummy
scoreboard objectives add bd_ray dummy
scoreboard objectives add bd_cd_q dummy
scoreboard objectives add bd_cd_w dummy
scoreboard objectives add bd_cd_r dummy
scoreboard objectives add bd_flash dummy
scoreboard objectives add bd_attack_ticks dummy
scoreboard objectives add bd_use_ticks dummy
scoreboard objectives add bd_combo_ticks dummy
scoreboard objectives add bd_combo_lock dummy
scoreboard objectives add bd_rand dummy
scoreboard objectives add bd_tmp dummy
scoreboard players add #next_player bd_tmp 0
scoreboard players set #maintenance bd_tmp 0

# Clear transient context tags only. Active normal daggers survive /reload.
tag @a remove bd_owner_context
tag @a remove bd_ray_user
tag @a remove bd_action_user
tag @a remove bd_ult_user
tag @e remove bd_current_dagger
tag @e remove bd_ray_hit
tag @e remove bd_ult_target
tag @e remove bd_ult_selected
