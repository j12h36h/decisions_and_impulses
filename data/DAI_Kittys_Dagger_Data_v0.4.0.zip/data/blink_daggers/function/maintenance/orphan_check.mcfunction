tag @s add bd_current_dagger
tag @a remove bd_owner_context
execute as @a if score @s bd_pid = @e[type=minecraft:item_display,tag=bd_current_dagger,limit=1,sort=nearest] bd_owner run tag @s add bd_owner_context
execute unless entity @a[tag=bd_owner_context] run kill @s
tag @a remove bd_owner_context
tag @s remove bd_current_dagger
