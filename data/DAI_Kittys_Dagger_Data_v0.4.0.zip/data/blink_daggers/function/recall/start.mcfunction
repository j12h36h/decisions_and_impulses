
execute unless score @s bd_pid matches 1.. run function blink_daggers:internal/assign_player_id
scoreboard players set @s bd_ray 0
tag @e[type=minecraft:item_display,tag=bd_dagger] remove bd_ray_hit
tag @s add bd_ray_user
execute anchored eyes positioned ^ ^ ^0.5 run function blink_daggers:recall/ray
tag @s remove bd_ray_user
tag @e[type=minecraft:item_display,tag=bd_dagger] remove bd_ray_hit
