
execute as @e[type=minecraft:item_display,tag=bd_dagger,distance=..0.75,limit=1,sort=nearest] if score @s bd_owner = @a[tag=bd_ray_user,limit=1] bd_pid run tag @s add bd_ray_hit
execute if entity @e[type=minecraft:item_display,tag=bd_ray_hit,distance=..0.75,limit=1] run function blink_daggers:recall/hit

# bd_tmp is a per-player recursion gate here: 1 means this sample is passable air.
scoreboard players set @s bd_tmp 0
execute if block ~ ~ ~ minecraft:air run scoreboard players set @s bd_tmp 1
execute if block ~ ~ ~ minecraft:cave_air run scoreboard players set @s bd_tmp 1
execute if block ~ ~ ~ minecraft:void_air run scoreboard players set @s bd_tmp 1
execute if score @s bd_ray matches ..69 if score @s bd_tmp matches 1 unless entity @e[type=minecraft:item_display,tag=bd_ray_hit,distance=..0.75,limit=1] run scoreboard players add @s bd_ray 1
execute if score @s bd_ray matches 1..70 if score @s bd_tmp matches 1 unless entity @e[type=minecraft:item_display,tag=bd_ray_hit,distance=..0.75,limit=1] positioned ^ ^ ^0.5 run function blink_daggers:recall/ray
