scoreboard players set @s bd_use_ticks 0
scoreboard players set @s bd_combo_ticks 0
execute if score @s bd_combo_lock matches 1 run return 0
scoreboard players add @s bd_attack_ticks 1
execute if score @s bd_attack_ticks matches 3 run function blink_daggers:ability/throw
