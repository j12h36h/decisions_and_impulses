scoreboard players set @s bd_attack_ticks 0
scoreboard players set @s bd_use_ticks 0
scoreboard players add @s bd_combo_ticks 1
execute if score @s bd_combo_ticks matches 20 run scoreboard players set @s bd_combo_lock 1
execute if score @s bd_combo_ticks matches 20 if score @s bd_cd_r matches 0 run function blink_daggers:ultimate/cast
execute if score @s bd_combo_ticks matches 20 unless score @s bd_cd_r matches 0 run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.45 0.65
