scoreboard players set @s bd_tmp 0
execute if score @s bd_cd_r matches 1..15 run scoreboard players set @s bd_tmp 1
execute if score @s bd_cd_r matches 16..30 run scoreboard players set @s bd_tmp 2
execute if score @s bd_cd_r matches 31..45 run scoreboard players set @s bd_tmp 3
execute if score @s bd_cd_r matches 46..60 run scoreboard players set @s bd_tmp 4
execute if score @s bd_cd_r matches 61..75 run scoreboard players set @s bd_tmp 5
execute if score @s bd_cd_r matches 76..90 run scoreboard players set @s bd_tmp 6
execute if score @s bd_cd_r matches 91..105 run scoreboard players set @s bd_tmp 7
execute if score @s bd_cd_r matches 106..120 run scoreboard players set @s bd_tmp 8
execute if score @s bd_cd_r matches 121..135 run scoreboard players set @s bd_tmp 9
execute if score @s bd_cd_r matches 136..150 run scoreboard players set @s bd_tmp 10
execute if score @s bd_cd_r matches 151..165 run scoreboard players set @s bd_tmp 11
execute if score @s bd_cd_r matches 166..180 run scoreboard players set @s bd_tmp 12
execute if score @s bd_cd_r matches 181..195 run scoreboard players set @s bd_tmp 13
execute if score @s bd_cd_r matches 196..210 run scoreboard players set @s bd_tmp 14
execute if score @s bd_cd_r matches 211..225 run scoreboard players set @s bd_tmp 15
execute if score @s bd_cd_r matches 226..240 run scoreboard players set @s bd_tmp 16
execute if score @s bd_cd_r matches 241..255 run scoreboard players set @s bd_tmp 17
execute if score @s bd_cd_r matches 256..270 run scoreboard players set @s bd_tmp 18
execute if score @s bd_cd_r matches 271..285 run scoreboard players set @s bd_tmp 19
execute if score @s bd_cd_r matches 286..300 run scoreboard players set @s bd_tmp 20
execute if score @s bd_tmp matches 0 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=1] 1
execute if score @s bd_tmp matches 1 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=5] 1
execute if score @s bd_tmp matches 2 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=10] 1
execute if score @s bd_tmp matches 3 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=15] 1
execute if score @s bd_tmp matches 4 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=20] 1
execute if score @s bd_tmp matches 5 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=25] 1
execute if score @s bd_tmp matches 6 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=30] 1
execute if score @s bd_tmp matches 7 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=35] 1
execute if score @s bd_tmp matches 8 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=40] 1
execute if score @s bd_tmp matches 9 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=45] 1
execute if score @s bd_tmp matches 10 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=50] 1
execute if score @s bd_tmp matches 11 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=55] 1
execute if score @s bd_tmp matches 12 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=60] 1
execute if score @s bd_tmp matches 13 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=65] 1
execute if score @s bd_tmp matches 14 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=70] 1
execute if score @s bd_tmp matches 15 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=75] 1
execute if score @s bd_tmp matches 16 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=80] 1
execute if score @s bd_tmp matches 17 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=85] 1
execute if score @s bd_tmp matches 18 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=90] 1
execute if score @s bd_tmp matches 19 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=95] 1
execute if score @s bd_tmp matches 20 run item replace entity @s weapon.mainhand with blink_daggers:kitty_ultimate[minecraft:damage=100] 1
