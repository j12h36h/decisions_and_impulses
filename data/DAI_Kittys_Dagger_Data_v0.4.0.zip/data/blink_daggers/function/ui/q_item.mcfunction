scoreboard players set @s bd_tmp 0
execute if score @s bd_cd_q matches 1..5 run scoreboard players set @s bd_tmp 1
execute if score @s bd_cd_q matches 6..10 run scoreboard players set @s bd_tmp 2
execute if score @s bd_cd_q matches 11..15 run scoreboard players set @s bd_tmp 3
execute if score @s bd_cd_q matches 16..20 run scoreboard players set @s bd_tmp 4
execute if score @s bd_cd_q matches 21..25 run scoreboard players set @s bd_tmp 5
execute if score @s bd_cd_q matches 26..30 run scoreboard players set @s bd_tmp 6
execute if score @s bd_cd_q matches 31..35 run scoreboard players set @s bd_tmp 7
execute if score @s bd_cd_q matches 36..40 run scoreboard players set @s bd_tmp 8
execute if score @s bd_cd_q matches 41..45 run scoreboard players set @s bd_tmp 9
execute if score @s bd_cd_q matches 46..50 run scoreboard players set @s bd_tmp 10
execute if score @s bd_cd_q matches 51..55 run scoreboard players set @s bd_tmp 11
execute if score @s bd_cd_q matches 56..60 run scoreboard players set @s bd_tmp 12
execute if score @s bd_cd_q matches 61..65 run scoreboard players set @s bd_tmp 13
execute if score @s bd_cd_q matches 66..70 run scoreboard players set @s bd_tmp 14
execute if score @s bd_cd_q matches 71..75 run scoreboard players set @s bd_tmp 15
execute if score @s bd_cd_q matches 76..80 run scoreboard players set @s bd_tmp 16
execute if score @s bd_cd_q matches 81..85 run scoreboard players set @s bd_tmp 17
execute if score @s bd_cd_q matches 86..90 run scoreboard players set @s bd_tmp 18
execute if score @s bd_cd_q matches 91..95 run scoreboard players set @s bd_tmp 19
execute if score @s bd_cd_q matches 96..100 run scoreboard players set @s bd_tmp 20
execute if score @s bd_tmp matches 0 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=1] 1
execute if score @s bd_tmp matches 1 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=5] 1
execute if score @s bd_tmp matches 2 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=10] 1
execute if score @s bd_tmp matches 3 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=15] 1
execute if score @s bd_tmp matches 4 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=20] 1
execute if score @s bd_tmp matches 5 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=25] 1
execute if score @s bd_tmp matches 6 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=30] 1
execute if score @s bd_tmp matches 7 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=35] 1
execute if score @s bd_tmp matches 8 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=40] 1
execute if score @s bd_tmp matches 9 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=45] 1
execute if score @s bd_tmp matches 10 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=50] 1
execute if score @s bd_tmp matches 11 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=55] 1
execute if score @s bd_tmp matches 12 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=60] 1
execute if score @s bd_tmp matches 13 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=65] 1
execute if score @s bd_tmp matches 14 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=70] 1
execute if score @s bd_tmp matches 15 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=75] 1
execute if score @s bd_tmp matches 16 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=80] 1
execute if score @s bd_tmp matches 17 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=85] 1
execute if score @s bd_tmp matches 18 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=90] 1
execute if score @s bd_tmp matches 19 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=95] 1
execute if score @s bd_tmp matches 20 run item replace entity @s weapon.mainhand with blink_daggers:kitty_directional_throw[minecraft:damage=100] 1
