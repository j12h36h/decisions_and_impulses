scoreboard players set @s bd_tmp 0
execute if score @s bd_cd_q matches 1..5 run scoreboard players set @s bd_tmp 1
execute if score @s bd_cd_q matches 6..10 run scoreboard players set @s bd_tmp 2
execute if score @s bd_cd_q matches 11..15 run scoreboard players set @s bd_tmp 3
execute if score @s bd_cd_q matches 16..20 run scoreboard players set @s bd_tmp 4
execute if score @s bd_cd_q matches 21..25 run scoreboard players set @s bd_tmp 5
execute if score @s bd_cd_q matches 26..30 run scoreboard players set @s bd_tmp 6
execute if score @s bd_cd_q matches 31..35 run scoreboard players set @s bd_tmp 7
execute if score @s bd_cd_q matches 36..40 run scoreboard players set @s bd_tmp 8
execute if score @s bd_cd_q matches 41..45 run scoreboard players set @s bd_tmp 9
execute if score @s bd_cd_q matches 46..50 run scoreboard players set @s bd_tmp 10
execute if score @s bd_cd_q matches 51..55 run scoreboard players set @s bd_tmp 11
execute if score @s bd_cd_q matches 56..60 run scoreboard players set @s bd_tmp 12
execute if score @s bd_cd_q matches 61..65 run scoreboard players set @s bd_tmp 13
execute if score @s bd_cd_q matches 66..70 run scoreboard players set @s bd_tmp 14
execute if score @s bd_cd_q matches 71..75 run scoreboard players set @s bd_tmp 15
execute if score @s bd_cd_q matches 76..80 run scoreboard players set @s bd_tmp 16
execute if score @s bd_cd_q matches 81..85 run scoreboard players set @s bd_tmp 17
execute if score @s bd_cd_q matches 86..90 run scoreboard players set @s bd_tmp 18
execute if score @s bd_cd_q matches 91..95 run scoreboard players set @s bd_tmp 19
execute if score @s bd_cd_q matches 96..100 run scoreboard players set @s bd_tmp 20
execute if score @s bd_cd_w matches 1.. if score @s bd_flash matches 0..3 run scoreboard players add @s bd_tmp 100
execute if score @s bd_cd_r matches 0 run scoreboard players add @s bd_tmp 200
execute if score @s bd_tmp matches 0 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=1,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 200 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=1,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 100 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=1,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 300 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=1,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 1 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=5,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 201 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=5,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 101 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=5,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 301 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=5,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 2 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=10,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 202 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=10,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 102 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=10,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 302 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=10,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 3 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=15,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 203 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=15,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 103 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=15,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 303 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=15,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 4 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=20,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 204 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=20,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 104 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=20,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 304 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=20,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 5 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=25,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 205 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=25,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 105 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=25,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 305 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=25,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 6 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=30,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 206 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=30,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 106 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=30,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 306 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=30,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 7 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=35,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 207 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=35,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 107 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=35,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 307 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=35,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 8 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=40,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 208 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=40,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 108 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=40,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 308 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=40,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 9 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=45,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 209 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=45,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 109 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=45,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 309 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=45,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 10 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=50,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 210 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=50,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 110 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=50,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 310 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=50,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 11 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=55,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 211 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=55,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 111 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=55,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 311 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=55,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 12 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=60,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 212 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=60,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 112 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=60,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 312 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=60,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 13 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=65,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 213 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=65,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 113 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=65,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 313 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=65,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 14 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=70,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 214 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=70,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 114 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=70,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 314 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=70,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 15 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=75,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 215 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=75,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 115 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=75,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 315 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=75,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 16 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=80,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 216 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=80,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 116 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=80,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 316 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=80,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 17 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=85,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 217 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=85,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 117 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=85,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 317 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=85,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 18 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=90,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 218 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=90,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 118 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=90,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 318 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=90,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 19 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=95,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 219 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=95,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 119 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=95,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 319 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=95,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 20 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=100,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 220 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=100,minecraft:item_model="blink_daggers:kitty_dagger",minecraft:enchantment_glint_override=true] 1
execute if score @s bd_tmp matches 120 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=100,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=false] 1
execute if score @s bd_tmp matches 320 run item replace entity @s weapon.mainhand with blink_daggers:kitty_dagger[minecraft:damage=100,minecraft:item_model="blink_daggers:kitty_dagger_red",minecraft:enchantment_glint_override=true] 1
