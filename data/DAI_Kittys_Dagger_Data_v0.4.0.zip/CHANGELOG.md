# Changelog

## v0.3.1 — DAI 2.1 Input API
- Updated the combined **Kitty's Dagger** controls to the finalized DAI 2.1 input API.
- Replaced `input_attack_held` with `keybind_held` + `parameter: "attack"`.
- Replaced `input_use_held` with `keybind_held` + `parameter: "use"`.
- Continues to use `player_attack_input` to suppress vanilla LMB behavior.
- Continues to use `player_input_tick` for held-input timing and the 20-tick LMB+RMB ultimate chord.
- No longer depends on the temporary raw-input compatibility conditions from the pre-2.1 patch.
- Preserved all v0.3.0 gameplay: three cooldowns, standalone skill items, five-knife ultimate, 35-block recall, 0.75-block recall tolerance, and 1.3x directional throw velocity.

## v0.3.0
- Renamed the combined item to **Kitty's Dagger**.
- Added three independent cooldowns: directional throw, up/drop, and ultimate.
- Added main-item UI channels: durability (Q), red flash (W cooldown), enchant glint (R ready).
- Added **Kitty's Directional Throw**, **Kitty's Up Throw**, and **Kitty's Ultimate** standalone skill items.
- Standalone items cast their skill on right-click and use a normal durability cooldown bar.
- Added raw held-input routing for the combined item.
- Added 20-tick LMB+RMB ultimate chord with a short basic-skill tap grace.
- Added five-projectile ultimate targeting entities within 15 blocks.
- Added randomized horizontal circular-fan fallback when no target is available.
- Preserved 35-block recall, 0.75-block recall tolerance, and 1.3x throw velocity.
