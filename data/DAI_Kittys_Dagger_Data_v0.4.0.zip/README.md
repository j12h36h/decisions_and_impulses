# [DAI] Kitty's Dagger v0.3.1

A DAI addon implementing a three-skill dagger kit plus three standalone right-click skill items.

## Combined item: Kitty's Dagger
- LMB tap/hold: directional dagger throw (3-tick tap grace so the ultimate chord can arm).
- RMB: aim at an owned dagger to blink/reclaim; otherwise place a dagger at your feet and gain Speed III.
- Hold LMB + RMB together for 20 ticks (~1 second): cast the five-knife ultimate.
- Directional cooldown is shown by durability.
- Up/drop cooldown flashes the item red via the companion resource pack.
- Ultimate readiness is shown by enchantment glint. Red flash and glint can coexist.

## Ultimate
- Throws exactly five knife projectiles.
- If entities exist within 15 blocks, unique nearby targets are preferred and remaining knives reuse the nearest target when fewer than five exist.
- If no valid targets exist, five knives fire horizontally in a randomized circular fan around the player's facing direction.
- Each ultimate knife deals 6 projectile damage.

## Standalone skill items
- Kitty's Directional Throw: right-click Q; durability bar = Q cooldown.
- Kitty's Up Throw: right-click W; durability bar = W cooldown.
- Kitty's Ultimate: right-click R; durability bar = R cooldown.
- Cooldowns are shared with the combined item.

## Defaults
- Q cooldown: 100 ticks / 5 seconds.
- W cooldown: 100 ticks / 5 seconds.
- R cooldown: 300 ticks / 15 seconds.
- Normal dagger anchors live about 100 ticks / 5 seconds.
- Recall range: 35 blocks with a 0.75-block aim tolerance.
- Directional projectile speed: 0.715 blocks/tick.

Requires **DAI 2.1+**. The combined item now uses the finalized DAI 2.1 `player_attack_input`, `player_input_tick`, and generic `keybind_held` conditions; the temporary raw-input compatibility conditions are no longer required.
