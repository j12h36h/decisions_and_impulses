scoreboard players set @s di_enable 0
tellraw @s [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'Disabled.',color:'red'}]
