scoreboard players operation @s di_prev = @s di_dealt
scoreboard players set @s di_delta 0
scoreboard players set @s di_whole 0
scoreboard players set @s di_dec 0
scoreboard players set @s di_enable 1
tag @s add dai_di_init
