DAI Damage Indicators v1.3
For Minecraft 26.2 + DAI 1.9.5
Role: ADDON

Purpose
- Floating combat damage numbers only.
- No target HUD, health panel, range panel, or survival interface logic.
- Designed to stack with DAI Survival Interface and other addons.

Behavior
- Resource-pack independent.
- Large readable damage values.
- ~3.5 second lifetime with gentle upward movement.

Commands
/function dai_damage_indicators:toggle
/function dai_damage_indicators:enable
/function dai_damage_indicators:disable
