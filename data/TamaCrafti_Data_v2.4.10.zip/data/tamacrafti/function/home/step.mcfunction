execute if score #home tc_home_step matches 373 unless block 3 200 -3 minecraft:moss_carpet run setblock 3 200 -3 minecraft:moss_carpet replace
execute if score #home tc_home_step matches 373 run particle minecraft:happy_villager 3.5 200.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 373 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 372 unless block -3 200 -3 minecraft:moss_carpet run setblock -3 200 -3 minecraft:moss_carpet replace
execute if score #home tc_home_step matches 372 run playsound minecraft:block.wood.place ambient @a -3 200 -3 0.18 1.15
execute if score #home tc_home_step matches 372 run particle minecraft:happy_villager -2.5 200.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 372 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 371 unless block 1 200 1 minecraft:pink_carpet run setblock 1 200 1 minecraft:pink_carpet replace
execute if score #home tc_home_step matches 371 run particle minecraft:happy_villager 1.5 200.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 371 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 370 unless block 0 200 1 minecraft:pink_carpet run setblock 0 200 1 minecraft:pink_carpet replace
execute if score #home tc_home_step matches 370 run particle minecraft:happy_villager 0.5 200.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 370 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 369 unless block 1 200 0 minecraft:pink_carpet run setblock 1 200 0 minecraft:pink_carpet replace
execute if score #home tc_home_step matches 369 run particle minecraft:happy_villager 1.5 200.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 369 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 368 unless block 0 200 0 minecraft:pink_carpet run setblock 0 200 0 minecraft:pink_carpet replace
execute if score #home tc_home_step matches 368 run particle minecraft:happy_villager 0.5 200.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 368 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 367 unless block -3 200 2 minecraft:lantern[hanging=false,waterlogged=false] run setblock -3 200 2 minecraft:lantern[hanging=false,waterlogged=false] replace
execute if score #home tc_home_step matches 367 run particle minecraft:happy_villager -2.5 200.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 367 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 366 unless block 3 200 2 minecraft:lantern[hanging=false,waterlogged=false] run setblock 3 200 2 minecraft:lantern[hanging=false,waterlogged=false] replace
execute if score #home tc_home_step matches 366 run playsound minecraft:block.wood.place ambient @a 3 200 2 0.18 1.15
execute if score #home tc_home_step matches 366 run particle minecraft:happy_villager 3.5 200.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 366 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 365 unless block 3 200 -2 minecraft:potted_azalea_bush run setblock 3 200 -2 minecraft:potted_azalea_bush replace
execute if score #home tc_home_step matches 365 run particle minecraft:happy_villager 3.5 200.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 365 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 364 unless block 2 200 -2 minecraft:barrel[facing=up,open=false] run setblock 2 200 -2 minecraft:barrel[facing=up,open=false] replace
execute if score #home tc_home_step matches 364 run particle minecraft:happy_villager 2.5 200.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 364 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 363 unless block -2 200 -1 minecraft:red_bed[facing=south,occupied=false,part=head] run setblock -2 200 -1 minecraft:red_bed[facing=south,occupied=false,part=head] replace
execute if score #home tc_home_step matches 363 run particle minecraft:happy_villager -1.5 200.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 363 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 362 unless block -2 200 -2 minecraft:red_bed[facing=south,occupied=false,part=foot] run setblock -2 200 -2 minecraft:red_bed[facing=south,occupied=false,part=foot] replace
execute if score #home tc_home_step matches 362 run particle minecraft:happy_villager -1.5 200.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 362 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 361 unless block 8 200 3 minecraft:dark_oak_fence run setblock 8 200 3 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 361 run particle minecraft:happy_villager 8.5 200.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 361 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 360 unless block 8 200 -3 minecraft:dark_oak_fence run setblock 8 200 -3 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 360 run playsound minecraft:block.wood.place ambient @a 8 200 -3 0.18 1.15
execute if score #home tc_home_step matches 360 run particle minecraft:happy_villager 8.5 200.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 360 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 359 unless block 7 200 3 minecraft:dark_oak_fence run setblock 7 200 3 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 359 run particle minecraft:happy_villager 7.5 200.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 359 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 358 unless block 7 200 -3 minecraft:dark_oak_fence run setblock 7 200 -3 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 358 run particle minecraft:happy_villager 7.5 200.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 358 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 357 unless block 6 200 3 minecraft:dark_oak_fence run setblock 6 200 3 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 357 run particle minecraft:happy_villager 6.5 200.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 357 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 356 unless block 6 200 -3 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false] run setblock 6 200 -3 minecraft:dark_oak_fence_gate[facing=north,in_wall=false,open=false,powered=false] replace
execute if score #home tc_home_step matches 356 run particle minecraft:happy_villager 6.5 200.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 356 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 355 unless block 5 200 3 minecraft:dark_oak_fence run setblock 5 200 3 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 355 run particle minecraft:happy_villager 5.5 200.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 355 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 354 unless block 5 200 -3 minecraft:dark_oak_fence run setblock 5 200 -3 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 354 run playsound minecraft:block.wood.place ambient @a 5 200 -3 0.18 1.15
execute if score #home tc_home_step matches 354 run particle minecraft:happy_villager 5.5 200.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 354 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 353 unless block 9 200 3 minecraft:dark_oak_fence run setblock 9 200 3 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 353 run particle minecraft:happy_villager 9.5 200.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 353 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 352 unless block 9 200 2 minecraft:dark_oak_fence run setblock 9 200 2 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 352 run particle minecraft:happy_villager 9.5 200.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 352 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 351 unless block 9 200 1 minecraft:dark_oak_fence run setblock 9 200 1 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 351 run particle minecraft:happy_villager 9.5 200.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 351 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 350 unless block 9 200 0 minecraft:dark_oak_fence run setblock 9 200 0 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 350 run particle minecraft:happy_villager 9.5 200.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 350 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 349 unless block 9 200 -1 minecraft:dark_oak_fence run setblock 9 200 -1 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 349 run particle minecraft:happy_villager 9.5 200.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 349 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 348 unless block 9 200 -2 minecraft:dark_oak_fence run setblock 9 200 -2 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 348 run playsound minecraft:block.wood.place ambient @a 9 200 -2 0.18 1.15
execute if score #home tc_home_step matches 348 run particle minecraft:happy_villager 9.5 200.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 348 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 347 unless block 9 200 -3 minecraft:dark_oak_fence run setblock 9 200 -3 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 347 run particle minecraft:happy_villager 9.5 200.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 347 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 346 unless block 7 200 0 minecraft:spruce_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false] run setblock 7 200 0 minecraft:spruce_trapdoor[facing=north,half=top,open=false,powered=false,waterlogged=false] replace
execute if score #home tc_home_step matches 346 run particle minecraft:happy_villager 7.5 200.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 346 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 345 unless block 8 199 2 minecraft:farmland[moisture=7] run setblock 8 199 2 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 345 run particle minecraft:happy_villager 8.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 345 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 344 unless block 7 199 2 minecraft:farmland[moisture=7] run setblock 7 199 2 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 344 run particle minecraft:happy_villager 7.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 344 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 343 unless block 6 199 2 minecraft:farmland[moisture=7] run setblock 6 199 2 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 343 run particle minecraft:happy_villager 6.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 343 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 342 unless block 8 199 1 minecraft:farmland[moisture=7] run setblock 8 199 1 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 342 run playsound minecraft:block.wood.place ambient @a 8 199 1 0.18 1.15
execute if score #home tc_home_step matches 342 run particle minecraft:happy_villager 8.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 342 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 341 unless block 7 199 1 minecraft:farmland[moisture=7] run setblock 7 199 1 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 341 run particle minecraft:happy_villager 7.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 341 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 340 unless block 6 199 1 minecraft:farmland[moisture=7] run setblock 6 199 1 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 340 run particle minecraft:happy_villager 6.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 340 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 339 unless block 8 199 0 minecraft:farmland[moisture=7] run setblock 8 199 0 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 339 run particle minecraft:happy_villager 8.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 339 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 338 unless block 7 199 0 minecraft:water[level=0] run setblock 7 199 0 minecraft:water[level=0] replace
execute if score #home tc_home_step matches 338 run particle minecraft:happy_villager 7.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 338 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 337 unless block 6 199 0 minecraft:farmland[moisture=7] run setblock 6 199 0 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 337 run particle minecraft:happy_villager 6.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 337 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 336 unless block 8 199 -1 minecraft:farmland[moisture=7] run setblock 8 199 -1 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 336 run playsound minecraft:block.wood.place ambient @a 8 199 -1 0.18 1.15
execute if score #home tc_home_step matches 336 run particle minecraft:happy_villager 8.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 336 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 335 unless block 7 199 -1 minecraft:farmland[moisture=7] run setblock 7 199 -1 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 335 run particle minecraft:happy_villager 7.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 335 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 334 unless block 6 199 -1 minecraft:farmland[moisture=7] run setblock 6 199 -1 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 334 run particle minecraft:happy_villager 6.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 334 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 333 unless block 8 199 -2 minecraft:farmland[moisture=7] run setblock 8 199 -2 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 333 run particle minecraft:happy_villager 8.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 333 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 332 unless block 7 199 -2 minecraft:farmland[moisture=7] run setblock 7 199 -2 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 332 run particle minecraft:happy_villager 7.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 332 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 331 unless block 6 199 -2 minecraft:farmland[moisture=7] run setblock 6 199 -2 minecraft:farmland[moisture=7] replace
execute if score #home tc_home_step matches 331 run particle minecraft:happy_villager 6.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 331 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 330 unless block 9 199 3 minecraft:spruce_planks run setblock 9 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 330 run playsound minecraft:block.wood.place ambient @a 9 199 3 0.18 1.15
execute if score #home tc_home_step matches 330 run particle minecraft:happy_villager 9.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 330 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 329 unless block 8 199 3 minecraft:spruce_planks run setblock 8 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 329 run particle minecraft:happy_villager 8.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 329 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 328 unless block 7 199 3 minecraft:spruce_planks run setblock 7 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 328 run particle minecraft:happy_villager 7.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 328 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 327 unless block 6 199 3 minecraft:spruce_planks run setblock 6 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 327 run particle minecraft:happy_villager 6.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 327 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 326 unless block 5 199 3 minecraft:spruce_planks run setblock 5 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 326 run particle minecraft:happy_villager 5.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 326 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 325 unless block 9 199 2 minecraft:spruce_planks run setblock 9 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 325 run particle minecraft:happy_villager 9.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 325 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 324 unless block 5 199 2 minecraft:spruce_planks run setblock 5 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 324 run playsound minecraft:block.wood.place ambient @a 5 199 2 0.18 1.15
execute if score #home tc_home_step matches 324 run particle minecraft:happy_villager 5.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 324 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 323 unless block 9 199 1 minecraft:spruce_planks run setblock 9 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 323 run particle minecraft:happy_villager 9.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 323 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 322 unless block 5 199 1 minecraft:spruce_planks run setblock 5 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 322 run particle minecraft:happy_villager 5.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 322 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 321 unless block 9 199 0 minecraft:spruce_planks run setblock 9 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 321 run particle minecraft:happy_villager 9.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 321 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 320 unless block 5 199 0 minecraft:spruce_planks run setblock 5 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 320 run particle minecraft:happy_villager 5.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 320 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 319 unless block 9 199 -1 minecraft:spruce_planks run setblock 9 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 319 run particle minecraft:happy_villager 9.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 319 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 318 unless block 5 199 -1 minecraft:spruce_planks run setblock 5 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 318 run playsound minecraft:block.wood.place ambient @a 5 199 -1 0.18 1.15
execute if score #home tc_home_step matches 318 run particle minecraft:happy_villager 5.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 318 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 317 unless block 9 199 -2 minecraft:spruce_planks run setblock 9 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 317 run particle minecraft:happy_villager 9.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 317 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 316 unless block 5 199 -2 minecraft:spruce_planks run setblock 5 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 316 run particle minecraft:happy_villager 5.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 316 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 315 unless block 9 199 -3 minecraft:spruce_planks run setblock 9 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 315 run particle minecraft:happy_villager 9.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 315 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 314 unless block 8 199 -3 minecraft:spruce_planks run setblock 8 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 314 run particle minecraft:happy_villager 8.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 314 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 313 unless block 7 199 -3 minecraft:spruce_planks run setblock 7 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 313 run particle minecraft:happy_villager 7.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 313 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 312 unless block 6 199 -3 minecraft:spruce_planks run setblock 6 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 312 run playsound minecraft:block.wood.place ambient @a 6 199 -3 0.18 1.15
execute if score #home tc_home_step matches 312 run particle minecraft:happy_villager 6.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 312 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 311 unless block 5 199 -3 minecraft:spruce_planks run setblock 5 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 311 run particle minecraft:happy_villager 5.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 311 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 310 unless block 2 201 8 minecraft:lantern[hanging=false,waterlogged=false] run setblock 2 201 8 minecraft:lantern[hanging=false,waterlogged=false] replace
execute if score #home tc_home_step matches 310 run particle minecraft:happy_villager 2.5 201.6 8.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 310 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 309 unless block 2 200 8 minecraft:dark_oak_fence run setblock 2 200 8 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 309 run particle minecraft:happy_villager 2.5 200.6 8.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 309 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 308 unless block 2 199 8 minecraft:stone_bricks run setblock 2 199 8 minecraft:stone_bricks replace
execute if score #home tc_home_step matches 308 run particle minecraft:happy_villager 2.5 199.6 8.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 308 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 307 unless block -2 201 8 minecraft:lantern[hanging=false,waterlogged=false] run setblock -2 201 8 minecraft:lantern[hanging=false,waterlogged=false] replace
execute if score #home tc_home_step matches 307 run particle minecraft:happy_villager -1.5 201.6 8.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 307 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 306 unless block -2 200 8 minecraft:dark_oak_fence run setblock -2 200 8 minecraft:dark_oak_fence replace
execute if score #home tc_home_step matches 306 run playsound minecraft:block.wood.place ambient @a -2 200 8 0.18 1.15
execute if score #home tc_home_step matches 306 run particle minecraft:happy_villager -1.5 200.6 8.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 306 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 305 unless block -2 199 8 minecraft:stone_bricks run setblock -2 199 8 minecraft:stone_bricks replace
execute if score #home tc_home_step matches 305 run particle minecraft:happy_villager -1.5 199.6 8.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 305 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 304 unless block 1 199 9 minecraft:spruce_planks run setblock 1 199 9 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 304 run particle minecraft:happy_villager 1.5 199.6 9.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 304 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 303 unless block 0 199 9 minecraft:spruce_planks run setblock 0 199 9 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 303 run particle minecraft:happy_villager 0.5 199.6 9.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 303 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 302 unless block -1 199 9 minecraft:spruce_planks run setblock -1 199 9 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 302 run particle minecraft:happy_villager -0.5 199.6 9.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 302 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 301 unless block 1 199 8 minecraft:spruce_planks run setblock 1 199 8 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 301 run particle minecraft:happy_villager 1.5 199.6 8.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 301 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 300 unless block 0 199 8 minecraft:spruce_planks run setblock 0 199 8 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 300 run playsound minecraft:block.wood.place ambient @a 0 199 8 0.18 1.15
execute if score #home tc_home_step matches 300 run particle minecraft:happy_villager 0.5 199.6 8.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 300 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 299 unless block -1 199 8 minecraft:spruce_planks run setblock -1 199 8 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 299 run particle minecraft:happy_villager -0.5 199.6 8.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 299 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 298 unless block 1 199 7 minecraft:spruce_planks run setblock 1 199 7 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 298 run particle minecraft:happy_villager 1.5 199.6 7.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 298 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 297 unless block 0 199 7 minecraft:spruce_planks run setblock 0 199 7 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 297 run particle minecraft:happy_villager 0.5 199.6 7.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 297 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 296 unless block -1 199 7 minecraft:spruce_planks run setblock -1 199 7 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 296 run particle minecraft:happy_villager -0.5 199.6 7.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 296 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 295 unless block 1 199 6 minecraft:spruce_planks run setblock 1 199 6 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 295 run particle minecraft:happy_villager 1.5 199.6 6.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 295 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 294 unless block 0 199 6 minecraft:spruce_planks run setblock 0 199 6 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 294 run playsound minecraft:block.wood.place ambient @a 0 199 6 0.18 1.15
execute if score #home tc_home_step matches 294 run particle minecraft:happy_villager 0.5 199.6 6.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 294 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 293 unless block -1 199 6 minecraft:spruce_planks run setblock -1 199 6 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 293 run particle minecraft:happy_villager -0.5 199.6 6.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 293 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 292 unless block 1 199 5 minecraft:spruce_planks run setblock 1 199 5 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 292 run particle minecraft:happy_villager 1.5 199.6 5.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 292 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 291 unless block 0 199 5 minecraft:spruce_planks run setblock 0 199 5 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 291 run particle minecraft:happy_villager 0.5 199.6 5.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 291 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 290 unless block -1 199 5 minecraft:spruce_planks run setblock -1 199 5 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 290 run particle minecraft:happy_villager -0.5 199.6 5.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 290 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 289 unless block 4 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 4 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 289 run particle minecraft:happy_villager 4.5 204.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 289 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 288 unless block 3 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 3 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 288 run playsound minecraft:block.wood.place ambient @a 3 204 4 0.18 1.15
execute if score #home tc_home_step matches 288 run particle minecraft:happy_villager 3.5 204.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 288 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 287 unless block 2 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 2 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 287 run particle minecraft:happy_villager 2.5 204.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 287 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 286 unless block 1 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 1 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 286 run particle minecraft:happy_villager 1.5 204.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 286 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 285 unless block 0 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 0 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 285 run particle minecraft:happy_villager 0.5 204.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 285 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 284 unless block -1 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -1 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 284 run particle minecraft:happy_villager -0.5 204.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 284 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 283 unless block -2 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -2 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 283 run particle minecraft:happy_villager -1.5 204.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 283 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 282 unless block -3 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -3 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 282 run playsound minecraft:block.wood.place ambient @a -3 204 4 0.18 1.15
execute if score #home tc_home_step matches 282 run particle minecraft:happy_villager -2.5 204.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 282 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 281 unless block -4 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -4 204 4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 281 run particle minecraft:happy_villager -3.5 204.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 281 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 280 unless block -4 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -4 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 280 run particle minecraft:happy_villager -3.5 204.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 280 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 279 unless block -3 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -3 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 279 run particle minecraft:happy_villager -2.5 204.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 279 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 278 unless block -2 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -2 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 278 run particle minecraft:happy_villager -1.5 204.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 278 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 277 unless block -1 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -1 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 277 run particle minecraft:happy_villager -0.5 204.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 277 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 276 unless block 0 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 0 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 276 run playsound minecraft:block.wood.place ambient @a 0 204 3 0.18 1.15
execute if score #home tc_home_step matches 276 run particle minecraft:happy_villager 0.5 204.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 276 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 275 unless block 1 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 1 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 275 run particle minecraft:happy_villager 1.5 204.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 275 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 274 unless block 2 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 2 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 274 run particle minecraft:happy_villager 2.5 204.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 274 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 273 unless block 3 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 3 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 273 run particle minecraft:happy_villager 3.5 204.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 273 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 272 unless block 4 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 4 204 3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 272 run particle minecraft:happy_villager 4.5 204.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 272 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 271 unless block 4 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 4 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 271 run particle minecraft:happy_villager 4.5 204.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 271 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 270 unless block 3 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 3 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 270 run playsound minecraft:block.wood.place ambient @a 3 204 2 0.18 1.15
execute if score #home tc_home_step matches 270 run particle minecraft:happy_villager 3.5 204.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 270 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 269 unless block 2 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 2 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 269 run particle minecraft:happy_villager 2.5 204.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 269 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 268 unless block 1 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 1 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 268 run particle minecraft:happy_villager 1.5 204.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 268 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 267 unless block 0 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 0 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 267 run particle minecraft:happy_villager 0.5 204.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 267 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 266 unless block -1 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -1 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 266 run particle minecraft:happy_villager -0.5 204.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 266 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 265 unless block -2 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -2 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 265 run particle minecraft:happy_villager -1.5 204.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 265 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 264 unless block -3 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -3 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 264 run playsound minecraft:block.wood.place ambient @a -3 204 2 0.18 1.15
execute if score #home tc_home_step matches 264 run particle minecraft:happy_villager -2.5 204.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 264 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 263 unless block -4 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -4 204 2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 263 run particle minecraft:happy_villager -3.5 204.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 263 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 262 unless block -4 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -4 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 262 run particle minecraft:happy_villager -3.5 204.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 262 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 261 unless block -3 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -3 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 261 run particle minecraft:happy_villager -2.5 204.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 261 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 260 unless block -2 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -2 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 260 run particle minecraft:happy_villager -1.5 204.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 260 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 259 unless block -1 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -1 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 259 run particle minecraft:happy_villager -0.5 204.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 259 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 258 unless block 0 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 0 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 258 run playsound minecraft:block.wood.place ambient @a 0 204 1 0.18 1.15
execute if score #home tc_home_step matches 258 run particle minecraft:happy_villager 0.5 204.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 258 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 257 unless block 1 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 1 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 257 run particle minecraft:happy_villager 1.5 204.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 257 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 256 unless block 2 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 2 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 256 run particle minecraft:happy_villager 2.5 204.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 256 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 255 unless block 3 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 3 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 255 run particle minecraft:happy_villager 3.5 204.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 255 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 254 unless block 4 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 4 204 1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 254 run particle minecraft:happy_villager 4.5 204.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 254 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 253 unless block 4 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 4 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 253 run particle minecraft:happy_villager 4.5 204.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 253 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 252 unless block 3 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 3 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 252 run playsound minecraft:block.wood.place ambient @a 3 204 0 0.18 1.15
execute if score #home tc_home_step matches 252 run particle minecraft:happy_villager 3.5 204.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 252 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 251 unless block 2 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 2 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 251 run particle minecraft:happy_villager 2.5 204.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 251 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 250 unless block 1 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 1 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 250 run particle minecraft:happy_villager 1.5 204.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 250 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 249 unless block 0 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 0 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 249 run particle minecraft:happy_villager 0.5 204.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 249 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 248 unless block -1 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -1 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 248 run particle minecraft:happy_villager -0.5 204.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 248 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 247 unless block -2 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -2 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 247 run particle minecraft:happy_villager -1.5 204.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 247 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 246 unless block -3 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -3 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 246 run playsound minecraft:block.wood.place ambient @a -3 204 0 0.18 1.15
execute if score #home tc_home_step matches 246 run particle minecraft:happy_villager -2.5 204.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 246 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 245 unless block -4 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -4 204 0 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 245 run particle minecraft:happy_villager -3.5 204.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 245 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 244 unless block -4 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -4 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 244 run particle minecraft:happy_villager -3.5 204.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 244 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 243 unless block -3 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -3 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 243 run particle minecraft:happy_villager -2.5 204.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 243 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 242 unless block -2 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -2 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 242 run particle minecraft:happy_villager -1.5 204.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 242 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 241 unless block -1 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -1 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 241 run particle minecraft:happy_villager -0.5 204.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 241 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 240 unless block 0 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 0 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 240 run playsound minecraft:block.wood.place ambient @a 0 204 -1 0.18 1.15
execute if score #home tc_home_step matches 240 run particle minecraft:happy_villager 0.5 204.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 240 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 239 unless block 1 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 1 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 239 run particle minecraft:happy_villager 1.5 204.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 239 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 238 unless block 2 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 2 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 238 run particle minecraft:happy_villager 2.5 204.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 238 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 237 unless block 3 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 3 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 237 run particle minecraft:happy_villager 3.5 204.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 237 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 236 unless block 4 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 4 204 -1 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 236 run particle minecraft:happy_villager 4.5 204.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 236 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 235 unless block 4 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 4 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 235 run particle minecraft:happy_villager 4.5 204.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 235 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 234 unless block 3 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 3 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 234 run playsound minecraft:block.wood.place ambient @a 3 204 -2 0.18 1.15
execute if score #home tc_home_step matches 234 run particle minecraft:happy_villager 3.5 204.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 234 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 233 unless block 2 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 2 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 233 run particle minecraft:happy_villager 2.5 204.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 233 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 232 unless block 1 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 1 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 232 run particle minecraft:happy_villager 1.5 204.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 232 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 231 unless block 0 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 0 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 231 run particle minecraft:happy_villager 0.5 204.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 231 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 230 unless block -1 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -1 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 230 run particle minecraft:happy_villager -0.5 204.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 230 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 229 unless block -2 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -2 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 229 run particle minecraft:happy_villager -1.5 204.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 229 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 228 unless block -3 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -3 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 228 run playsound minecraft:block.wood.place ambient @a -3 204 -2 0.18 1.15
execute if score #home tc_home_step matches 228 run particle minecraft:happy_villager -2.5 204.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 228 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 227 unless block -4 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -4 204 -2 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 227 run particle minecraft:happy_villager -3.5 204.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 227 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 226 unless block -4 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -4 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 226 run particle minecraft:happy_villager -3.5 204.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 226 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 225 unless block -3 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -3 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 225 run particle minecraft:happy_villager -2.5 204.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 225 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 224 unless block -2 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -2 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 224 run particle minecraft:happy_villager -1.5 204.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 224 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 223 unless block -1 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -1 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 223 run particle minecraft:happy_villager -0.5 204.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 223 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 222 unless block 0 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 0 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 222 run playsound minecraft:block.wood.place ambient @a 0 204 -3 0.18 1.15
execute if score #home tc_home_step matches 222 run particle minecraft:happy_villager 0.5 204.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 222 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 221 unless block 1 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 1 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 221 run particle minecraft:happy_villager 1.5 204.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 221 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 220 unless block 2 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 2 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 220 run particle minecraft:happy_villager 2.5 204.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 220 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 219 unless block 3 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 3 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 219 run particle minecraft:happy_villager 3.5 204.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 219 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 218 unless block 4 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 4 204 -3 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 218 run particle minecraft:happy_villager 4.5 204.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 218 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 217 unless block 4 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 4 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 217 run particle minecraft:happy_villager 4.5 204.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 217 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 216 unless block 3 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 3 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 216 run playsound minecraft:block.wood.place ambient @a 3 204 -4 0.18 1.15
execute if score #home tc_home_step matches 216 run particle minecraft:happy_villager 3.5 204.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 216 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 215 unless block 2 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 2 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 215 run particle minecraft:happy_villager 2.5 204.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 215 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 214 unless block 1 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 1 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 214 run particle minecraft:happy_villager 1.5 204.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 214 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 213 unless block 0 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock 0 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 213 run particle minecraft:happy_villager 0.5 204.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 213 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 212 unless block -1 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -1 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 212 run particle minecraft:happy_villager -0.5 204.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 212 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 211 unless block -2 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -2 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 211 run particle minecraft:happy_villager -1.5 204.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 211 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 210 unless block -3 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -3 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 210 run playsound minecraft:block.wood.place ambient @a -3 204 -4 0.18 1.15
execute if score #home tc_home_step matches 210 run particle minecraft:happy_villager -2.5 204.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 210 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 209 unless block -4 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] run setblock -4 204 -4 minecraft:dark_oak_slab[type=bottom,waterlogged=false] replace
execute if score #home tc_home_step matches 209 run particle minecraft:happy_villager -3.5 204.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 209 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 208 unless block 0 201 4 minecraft:spruce_door[facing=south,half=upper,hinge=left,open=false,powered=false] run setblock 0 201 4 minecraft:spruce_door[facing=south,half=upper,hinge=left,open=false,powered=false] replace
execute if score #home tc_home_step matches 208 run particle minecraft:happy_villager 0.5 201.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 208 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 207 unless block 0 200 4 minecraft:spruce_door[facing=south,half=lower,hinge=left,open=false,powered=false] run setblock 0 200 4 minecraft:spruce_door[facing=south,half=lower,hinge=left,open=false,powered=false] replace
execute if score #home tc_home_step matches 207 run particle minecraft:happy_villager 0.5 200.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 207 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 206 unless block 4 203 3 minecraft:dark_oak_planks run setblock 4 203 3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 206 run particle minecraft:happy_villager 4.5 203.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 206 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 205 unless block -4 203 3 minecraft:dark_oak_planks run setblock -4 203 3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 205 run particle minecraft:happy_villager -3.5 203.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 205 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 204 unless block 4 203 2 minecraft:dark_oak_planks run setblock 4 203 2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 204 run playsound minecraft:block.wood.place ambient @a 4 203 2 0.18 1.15
execute if score #home tc_home_step matches 204 run particle minecraft:happy_villager 4.5 203.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 204 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 203 unless block -4 203 2 minecraft:dark_oak_planks run setblock -4 203 2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 203 run particle minecraft:happy_villager -3.5 203.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 203 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 202 unless block 4 203 1 minecraft:dark_oak_planks run setblock 4 203 1 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 202 run particle minecraft:happy_villager 4.5 203.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 202 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 201 unless block -4 203 1 minecraft:dark_oak_planks run setblock -4 203 1 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 201 run particle minecraft:happy_villager -3.5 203.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 201 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 200 unless block 4 203 0 minecraft:dark_oak_planks run setblock 4 203 0 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 200 run particle minecraft:happy_villager 4.5 203.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 200 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 199 unless block -4 203 0 minecraft:dark_oak_planks run setblock -4 203 0 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 199 run particle minecraft:happy_villager -3.5 203.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 199 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 198 unless block 4 203 -1 minecraft:dark_oak_planks run setblock 4 203 -1 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 198 run playsound minecraft:block.wood.place ambient @a 4 203 -1 0.18 1.15
execute if score #home tc_home_step matches 198 run particle minecraft:happy_villager 4.5 203.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 198 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 197 unless block -4 203 -1 minecraft:dark_oak_planks run setblock -4 203 -1 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 197 run particle minecraft:happy_villager -3.5 203.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 197 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 196 unless block 4 203 -2 minecraft:dark_oak_planks run setblock 4 203 -2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 196 run particle minecraft:happy_villager 4.5 203.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 196 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 195 unless block -4 203 -2 minecraft:dark_oak_planks run setblock -4 203 -2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 195 run particle minecraft:happy_villager -3.5 203.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 195 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 194 unless block 4 203 -3 minecraft:dark_oak_planks run setblock 4 203 -3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 194 run particle minecraft:happy_villager 4.5 203.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 194 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 193 unless block -4 203 -3 minecraft:dark_oak_planks run setblock -4 203 -3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 193 run particle minecraft:happy_villager -3.5 203.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 193 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 192 unless block 4 203 4 minecraft:stripped_dark_oak_log[axis=y] run setblock 4 203 4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 192 run playsound minecraft:block.wood.place ambient @a 4 203 4 0.18 1.15
execute if score #home tc_home_step matches 192 run particle minecraft:happy_villager 4.5 203.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 192 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 191 unless block 4 203 -4 minecraft:stripped_dark_oak_log[axis=y] run setblock 4 203 -4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 191 run particle minecraft:happy_villager 4.5 203.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 191 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 190 unless block 3 203 4 minecraft:dark_oak_planks run setblock 3 203 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 190 run particle minecraft:happy_villager 3.5 203.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 190 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 189 unless block 3 203 -4 minecraft:dark_oak_planks run setblock 3 203 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 189 run particle minecraft:happy_villager 3.5 203.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 189 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 188 unless block 2 203 4 minecraft:dark_oak_planks run setblock 2 203 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 188 run particle minecraft:happy_villager 2.5 203.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 188 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 187 unless block 2 203 -4 minecraft:dark_oak_planks run setblock 2 203 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 187 run particle minecraft:happy_villager 2.5 203.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 187 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 186 unless block 1 203 4 minecraft:dark_oak_planks run setblock 1 203 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 186 run playsound minecraft:block.wood.place ambient @a 1 203 4 0.18 1.15
execute if score #home tc_home_step matches 186 run particle minecraft:happy_villager 1.5 203.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 186 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 185 unless block 1 203 -4 minecraft:dark_oak_planks run setblock 1 203 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 185 run particle minecraft:happy_villager 1.5 203.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 185 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 184 unless block 0 203 4 minecraft:dark_oak_planks run setblock 0 203 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 184 run particle minecraft:happy_villager 0.5 203.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 184 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 183 unless block 0 203 -4 minecraft:dark_oak_planks run setblock 0 203 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 183 run particle minecraft:happy_villager 0.5 203.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 183 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 182 unless block -1 203 4 minecraft:dark_oak_planks run setblock -1 203 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 182 run particle minecraft:happy_villager -0.5 203.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 182 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 181 unless block -1 203 -4 minecraft:dark_oak_planks run setblock -1 203 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 181 run particle minecraft:happy_villager -0.5 203.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 181 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 180 unless block -2 203 4 minecraft:dark_oak_planks run setblock -2 203 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 180 run playsound minecraft:block.wood.place ambient @a -2 203 4 0.18 1.15
execute if score #home tc_home_step matches 180 run particle minecraft:happy_villager -1.5 203.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 180 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 179 unless block -2 203 -4 minecraft:dark_oak_planks run setblock -2 203 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 179 run particle minecraft:happy_villager -1.5 203.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 179 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 178 unless block -3 203 4 minecraft:dark_oak_planks run setblock -3 203 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 178 run particle minecraft:happy_villager -2.5 203.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 178 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 177 unless block -3 203 -4 minecraft:dark_oak_planks run setblock -3 203 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 177 run particle minecraft:happy_villager -2.5 203.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 177 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 176 unless block -4 203 4 minecraft:stripped_dark_oak_log[axis=y] run setblock -4 203 4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 176 run particle minecraft:happy_villager -3.5 203.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 176 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 175 unless block -4 203 -4 minecraft:stripped_dark_oak_log[axis=y] run setblock -4 203 -4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 175 run particle minecraft:happy_villager -3.5 203.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 175 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 174 unless block 4 202 3 minecraft:dark_oak_planks run setblock 4 202 3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 174 run playsound minecraft:block.wood.place ambient @a 4 202 3 0.18 1.15
execute if score #home tc_home_step matches 174 run particle minecraft:happy_villager 4.5 202.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 174 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 173 unless block -4 202 3 minecraft:dark_oak_planks run setblock -4 202 3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 173 run particle minecraft:happy_villager -3.5 202.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 173 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 172 unless block 4 202 2 minecraft:dark_oak_planks run setblock 4 202 2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 172 run particle minecraft:happy_villager 4.5 202.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 172 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 171 unless block -4 202 2 minecraft:dark_oak_planks run setblock -4 202 2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 171 run particle minecraft:happy_villager -3.5 202.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 171 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 170 unless block 4 202 1 minecraft:glass run setblock 4 202 1 minecraft:glass replace
execute if score #home tc_home_step matches 170 run particle minecraft:happy_villager 4.5 202.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 170 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 169 unless block -4 202 1 minecraft:glass run setblock -4 202 1 minecraft:glass replace
execute if score #home tc_home_step matches 169 run particle minecraft:happy_villager -3.5 202.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 169 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 168 unless block 4 202 0 minecraft:glass run setblock 4 202 0 minecraft:glass replace
execute if score #home tc_home_step matches 168 run playsound minecraft:block.wood.place ambient @a 4 202 0 0.18 1.15
execute if score #home tc_home_step matches 168 run particle minecraft:happy_villager 4.5 202.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 168 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 167 unless block -4 202 0 minecraft:glass run setblock -4 202 0 minecraft:glass replace
execute if score #home tc_home_step matches 167 run particle minecraft:happy_villager -3.5 202.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 167 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 166 unless block 4 202 -1 minecraft:glass run setblock 4 202 -1 minecraft:glass replace
execute if score #home tc_home_step matches 166 run particle minecraft:happy_villager 4.5 202.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 166 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 165 unless block -4 202 -1 minecraft:glass run setblock -4 202 -1 minecraft:glass replace
execute if score #home tc_home_step matches 165 run particle minecraft:happy_villager -3.5 202.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 165 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 164 unless block 4 202 -2 minecraft:dark_oak_planks run setblock 4 202 -2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 164 run particle minecraft:happy_villager 4.5 202.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 164 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 163 unless block -4 202 -2 minecraft:dark_oak_planks run setblock -4 202 -2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 163 run particle minecraft:happy_villager -3.5 202.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 163 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 162 unless block 4 202 -3 minecraft:dark_oak_planks run setblock 4 202 -3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 162 run playsound minecraft:block.wood.place ambient @a 4 202 -3 0.18 1.15
execute if score #home tc_home_step matches 162 run particle minecraft:happy_villager 4.5 202.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 162 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 161 unless block -4 202 -3 minecraft:dark_oak_planks run setblock -4 202 -3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 161 run particle minecraft:happy_villager -3.5 202.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 161 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 160 unless block 4 202 4 minecraft:stripped_dark_oak_log[axis=y] run setblock 4 202 4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 160 run particle minecraft:happy_villager 4.5 202.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 160 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 159 unless block 4 202 -4 minecraft:stripped_dark_oak_log[axis=y] run setblock 4 202 -4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 159 run particle minecraft:happy_villager 4.5 202.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 159 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 158 unless block 3 202 4 minecraft:dark_oak_planks run setblock 3 202 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 158 run particle minecraft:happy_villager 3.5 202.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 158 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 157 unless block 3 202 -4 minecraft:dark_oak_planks run setblock 3 202 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 157 run particle minecraft:happy_villager 3.5 202.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 157 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 156 unless block 2 202 4 minecraft:glass run setblock 2 202 4 minecraft:glass replace
execute if score #home tc_home_step matches 156 run playsound minecraft:block.wood.place ambient @a 2 202 4 0.18 1.15
execute if score #home tc_home_step matches 156 run particle minecraft:happy_villager 2.5 202.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 156 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 155 unless block 2 202 -4 minecraft:glass run setblock 2 202 -4 minecraft:glass replace
execute if score #home tc_home_step matches 155 run particle minecraft:happy_villager 2.5 202.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 155 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 154 unless block 1 202 4 minecraft:dark_oak_planks run setblock 1 202 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 154 run particle minecraft:happy_villager 1.5 202.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 154 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 153 unless block 1 202 -4 minecraft:glass run setblock 1 202 -4 minecraft:glass replace
execute if score #home tc_home_step matches 153 run particle minecraft:happy_villager 1.5 202.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 153 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 152 unless block 0 202 4 minecraft:dark_oak_planks run setblock 0 202 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 152 run particle minecraft:happy_villager 0.5 202.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 152 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 151 unless block 0 202 -4 minecraft:glass run setblock 0 202 -4 minecraft:glass replace
execute if score #home tc_home_step matches 151 run particle minecraft:happy_villager 0.5 202.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 151 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 150 unless block -1 202 4 minecraft:dark_oak_planks run setblock -1 202 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 150 run playsound minecraft:block.wood.place ambient @a -1 202 4 0.18 1.15
execute if score #home tc_home_step matches 150 run particle minecraft:happy_villager -0.5 202.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 150 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 149 unless block -1 202 -4 minecraft:glass run setblock -1 202 -4 minecraft:glass replace
execute if score #home tc_home_step matches 149 run particle minecraft:happy_villager -0.5 202.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 149 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 148 unless block -2 202 4 minecraft:glass run setblock -2 202 4 minecraft:glass replace
execute if score #home tc_home_step matches 148 run particle minecraft:happy_villager -1.5 202.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 148 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 147 unless block -2 202 -4 minecraft:glass run setblock -2 202 -4 minecraft:glass replace
execute if score #home tc_home_step matches 147 run particle minecraft:happy_villager -1.5 202.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 147 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 146 unless block -3 202 4 minecraft:dark_oak_planks run setblock -3 202 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 146 run particle minecraft:happy_villager -2.5 202.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 146 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 145 unless block -3 202 -4 minecraft:dark_oak_planks run setblock -3 202 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 145 run particle minecraft:happy_villager -2.5 202.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 145 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 144 unless block -4 202 4 minecraft:stripped_dark_oak_log[axis=y] run setblock -4 202 4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 144 run playsound minecraft:block.wood.place ambient @a -4 202 4 0.18 1.15
execute if score #home tc_home_step matches 144 run particle minecraft:happy_villager -3.5 202.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 144 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 143 unless block -4 202 -4 minecraft:stripped_dark_oak_log[axis=y] run setblock -4 202 -4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 143 run particle minecraft:happy_villager -3.5 202.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 143 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 142 unless block 4 201 3 minecraft:dark_oak_planks run setblock 4 201 3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 142 run particle minecraft:happy_villager 4.5 201.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 142 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 141 unless block -4 201 3 minecraft:dark_oak_planks run setblock -4 201 3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 141 run particle minecraft:happy_villager -3.5 201.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 141 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 140 unless block 4 201 2 minecraft:dark_oak_planks run setblock 4 201 2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 140 run particle minecraft:happy_villager 4.5 201.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 140 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 139 unless block -4 201 2 minecraft:dark_oak_planks run setblock -4 201 2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 139 run particle minecraft:happy_villager -3.5 201.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 139 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 138 unless block 4 201 1 minecraft:glass run setblock 4 201 1 minecraft:glass replace
execute if score #home tc_home_step matches 138 run playsound minecraft:block.wood.place ambient @a 4 201 1 0.18 1.15
execute if score #home tc_home_step matches 138 run particle minecraft:happy_villager 4.5 201.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 138 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 137 unless block -4 201 1 minecraft:glass run setblock -4 201 1 minecraft:glass replace
execute if score #home tc_home_step matches 137 run particle minecraft:happy_villager -3.5 201.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 137 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 136 unless block 4 201 0 minecraft:spruce_door[facing=east,half=upper,hinge=left,open=false,powered=false] run setblock 4 201 0 minecraft:spruce_door[facing=east,half=upper,hinge=left,open=false,powered=false] replace
execute if score #home tc_home_step matches 136 run particle minecraft:happy_villager 4.5 201.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 136 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 135 unless block -4 201 0 minecraft:glass run setblock -4 201 0 minecraft:glass replace
execute if score #home tc_home_step matches 135 run particle minecraft:happy_villager -3.5 201.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 135 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 134 unless block 4 201 -1 minecraft:glass run setblock 4 201 -1 minecraft:glass replace
execute if score #home tc_home_step matches 134 run particle minecraft:happy_villager 4.5 201.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 134 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 133 unless block -4 201 -1 minecraft:glass run setblock -4 201 -1 minecraft:glass replace
execute if score #home tc_home_step matches 133 run particle minecraft:happy_villager -3.5 201.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 133 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 132 unless block 4 201 -2 minecraft:dark_oak_planks run setblock 4 201 -2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 132 run playsound minecraft:block.wood.place ambient @a 4 201 -2 0.18 1.15
execute if score #home tc_home_step matches 132 run particle minecraft:happy_villager 4.5 201.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 132 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 131 unless block -4 201 -2 minecraft:dark_oak_planks run setblock -4 201 -2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 131 run particle minecraft:happy_villager -3.5 201.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 131 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 130 unless block 4 201 -3 minecraft:dark_oak_planks run setblock 4 201 -3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 130 run particle minecraft:happy_villager 4.5 201.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 130 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 129 unless block -4 201 -3 minecraft:dark_oak_planks run setblock -4 201 -3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 129 run particle minecraft:happy_villager -3.5 201.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 129 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 128 unless block 4 201 4 minecraft:stripped_dark_oak_log[axis=y] run setblock 4 201 4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 128 run particle minecraft:happy_villager 4.5 201.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 128 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 127 unless block 4 201 -4 minecraft:stripped_dark_oak_log[axis=y] run setblock 4 201 -4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 127 run particle minecraft:happy_villager 4.5 201.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 127 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 126 unless block 3 201 4 minecraft:dark_oak_planks run setblock 3 201 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 126 run playsound minecraft:block.wood.place ambient @a 3 201 4 0.18 1.15
execute if score #home tc_home_step matches 126 run particle minecraft:happy_villager 3.5 201.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 126 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 125 unless block 3 201 -4 minecraft:dark_oak_planks run setblock 3 201 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 125 run particle minecraft:happy_villager 3.5 201.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 125 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 124 unless block 2 201 4 minecraft:glass run setblock 2 201 4 minecraft:glass replace
execute if score #home tc_home_step matches 124 run particle minecraft:happy_villager 2.5 201.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 124 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 123 unless block 2 201 -4 minecraft:glass run setblock 2 201 -4 minecraft:glass replace
execute if score #home tc_home_step matches 123 run particle minecraft:happy_villager 2.5 201.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 123 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 122 unless block 1 201 4 minecraft:dark_oak_planks run setblock 1 201 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 122 run particle minecraft:happy_villager 1.5 201.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 122 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 121 unless block 1 201 -4 minecraft:glass run setblock 1 201 -4 minecraft:glass replace
execute if score #home tc_home_step matches 121 run particle minecraft:happy_villager 1.5 201.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 121 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 120 unless block 0 201 -4 minecraft:glass run setblock 0 201 -4 minecraft:glass replace
execute if score #home tc_home_step matches 120 run playsound minecraft:block.wood.place ambient @a 0 201 -4 0.18 1.15
execute if score #home tc_home_step matches 120 run particle minecraft:happy_villager 0.5 201.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 120 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 119 unless block -1 201 4 minecraft:dark_oak_planks run setblock -1 201 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 119 run particle minecraft:happy_villager -0.5 201.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 119 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 118 unless block -1 201 -4 minecraft:glass run setblock -1 201 -4 minecraft:glass replace
execute if score #home tc_home_step matches 118 run particle minecraft:happy_villager -0.5 201.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 118 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 117 unless block -2 201 4 minecraft:glass run setblock -2 201 4 minecraft:glass replace
execute if score #home tc_home_step matches 117 run particle minecraft:happy_villager -1.5 201.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 117 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 116 unless block -2 201 -4 minecraft:glass run setblock -2 201 -4 minecraft:glass replace
execute if score #home tc_home_step matches 116 run particle minecraft:happy_villager -1.5 201.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 116 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 115 unless block -3 201 4 minecraft:dark_oak_planks run setblock -3 201 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 115 run particle minecraft:happy_villager -2.5 201.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 115 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 114 unless block -3 201 -4 minecraft:dark_oak_planks run setblock -3 201 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 114 run playsound minecraft:block.wood.place ambient @a -3 201 -4 0.18 1.15
execute if score #home tc_home_step matches 114 run particle minecraft:happy_villager -2.5 201.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 114 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 113 unless block -4 201 4 minecraft:stripped_dark_oak_log[axis=y] run setblock -4 201 4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 113 run particle minecraft:happy_villager -3.5 201.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 113 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 112 unless block -4 201 -4 minecraft:stripped_dark_oak_log[axis=y] run setblock -4 201 -4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 112 run particle minecraft:happy_villager -3.5 201.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 112 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 111 unless block 4 200 3 minecraft:dark_oak_planks run setblock 4 200 3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 111 run particle minecraft:happy_villager 4.5 200.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 111 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 110 unless block -4 200 3 minecraft:dark_oak_planks run setblock -4 200 3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 110 run particle minecraft:happy_villager -3.5 200.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 110 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 109 unless block 4 200 2 minecraft:dark_oak_planks run setblock 4 200 2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 109 run particle minecraft:happy_villager 4.5 200.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 109 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 108 unless block -4 200 2 minecraft:dark_oak_planks run setblock -4 200 2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 108 run playsound minecraft:block.wood.place ambient @a -4 200 2 0.18 1.15
execute if score #home tc_home_step matches 108 run particle minecraft:happy_villager -3.5 200.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 108 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 107 unless block 4 200 1 minecraft:dark_oak_planks run setblock 4 200 1 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 107 run particle minecraft:happy_villager 4.5 200.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 107 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 106 unless block -4 200 1 minecraft:dark_oak_planks run setblock -4 200 1 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 106 run particle minecraft:happy_villager -3.5 200.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 106 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 105 unless block 4 200 0 minecraft:spruce_door[facing=east,half=lower,hinge=left,open=false,powered=false] run setblock 4 200 0 minecraft:spruce_door[facing=east,half=lower,hinge=left,open=false,powered=false] replace
execute if score #home tc_home_step matches 105 run particle minecraft:happy_villager 4.5 200.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 105 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 104 unless block -4 200 0 minecraft:dark_oak_planks run setblock -4 200 0 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 104 run particle minecraft:happy_villager -3.5 200.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 104 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 103 unless block 4 200 -1 minecraft:dark_oak_planks run setblock 4 200 -1 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 103 run particle minecraft:happy_villager 4.5 200.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 103 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 102 unless block -4 200 -1 minecraft:dark_oak_planks run setblock -4 200 -1 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 102 run playsound minecraft:block.wood.place ambient @a -4 200 -1 0.18 1.15
execute if score #home tc_home_step matches 102 run particle minecraft:happy_villager -3.5 200.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 102 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 101 unless block 4 200 -2 minecraft:dark_oak_planks run setblock 4 200 -2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 101 run particle minecraft:happy_villager 4.5 200.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 101 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 100 unless block -4 200 -2 minecraft:dark_oak_planks run setblock -4 200 -2 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 100 run particle minecraft:happy_villager -3.5 200.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 100 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 99 unless block 4 200 -3 minecraft:dark_oak_planks run setblock 4 200 -3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 99 run particle minecraft:happy_villager 4.5 200.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 99 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 98 unless block -4 200 -3 minecraft:dark_oak_planks run setblock -4 200 -3 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 98 run particle minecraft:happy_villager -3.5 200.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 98 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 97 unless block 4 200 4 minecraft:stripped_dark_oak_log[axis=y] run setblock 4 200 4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 97 run particle minecraft:happy_villager 4.5 200.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 97 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 96 unless block 4 200 -4 minecraft:stripped_dark_oak_log[axis=y] run setblock 4 200 -4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 96 run playsound minecraft:block.wood.place ambient @a 4 200 -4 0.18 1.15
execute if score #home tc_home_step matches 96 run particle minecraft:happy_villager 4.5 200.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 96 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 95 unless block 3 200 4 minecraft:dark_oak_planks run setblock 3 200 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 95 run particle minecraft:happy_villager 3.5 200.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 95 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 94 unless block 3 200 -4 minecraft:dark_oak_planks run setblock 3 200 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 94 run particle minecraft:happy_villager 3.5 200.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 94 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 93 unless block 2 200 4 minecraft:dark_oak_planks run setblock 2 200 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 93 run particle minecraft:happy_villager 2.5 200.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 93 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 92 unless block 2 200 -4 minecraft:dark_oak_planks run setblock 2 200 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 92 run particle minecraft:happy_villager 2.5 200.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 92 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 91 unless block 1 200 4 minecraft:dark_oak_planks run setblock 1 200 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 91 run particle minecraft:happy_villager 1.5 200.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 91 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 90 unless block 1 200 -4 minecraft:dark_oak_planks run setblock 1 200 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 90 run playsound minecraft:block.wood.place ambient @a 1 200 -4 0.18 1.15
execute if score #home tc_home_step matches 90 run particle minecraft:happy_villager 1.5 200.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 90 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 89 unless block 0 200 -4 minecraft:dark_oak_planks run setblock 0 200 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 89 run particle minecraft:happy_villager 0.5 200.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 89 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 88 unless block -1 200 4 minecraft:dark_oak_planks run setblock -1 200 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 88 run particle minecraft:happy_villager -0.5 200.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 88 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 87 unless block -1 200 -4 minecraft:dark_oak_planks run setblock -1 200 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 87 run particle minecraft:happy_villager -0.5 200.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 87 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 86 unless block -2 200 4 minecraft:dark_oak_planks run setblock -2 200 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 86 run particle minecraft:happy_villager -1.5 200.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 86 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 85 unless block -2 200 -4 minecraft:dark_oak_planks run setblock -2 200 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 85 run particle minecraft:happy_villager -1.5 200.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 85 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 84 unless block -3 200 4 minecraft:dark_oak_planks run setblock -3 200 4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 84 run playsound minecraft:block.wood.place ambient @a -3 200 4 0.18 1.15
execute if score #home tc_home_step matches 84 run particle minecraft:happy_villager -2.5 200.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 84 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 83 unless block -3 200 -4 minecraft:dark_oak_planks run setblock -3 200 -4 minecraft:dark_oak_planks replace
execute if score #home tc_home_step matches 83 run particle minecraft:happy_villager -2.5 200.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 83 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 82 unless block -4 200 4 minecraft:stripped_dark_oak_log[axis=y] run setblock -4 200 4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 82 run particle minecraft:happy_villager -3.5 200.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 82 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 81 unless block -4 200 -4 minecraft:stripped_dark_oak_log[axis=y] run setblock -4 200 -4 minecraft:stripped_dark_oak_log[axis=y] replace
execute if score #home tc_home_step matches 81 run particle minecraft:happy_villager -3.5 200.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 81 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 80 unless block 4 199 4 minecraft:spruce_planks run setblock 4 199 4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 80 run particle minecraft:happy_villager 4.5 199.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 80 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 79 unless block 3 199 4 minecraft:spruce_planks run setblock 3 199 4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 79 run particle minecraft:happy_villager 3.5 199.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 79 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 78 unless block 2 199 4 minecraft:spruce_planks run setblock 2 199 4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 78 run playsound minecraft:block.wood.place ambient @a 2 199 4 0.18 1.15
execute if score #home tc_home_step matches 78 run particle minecraft:happy_villager 2.5 199.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 78 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 77 unless block 1 199 4 minecraft:spruce_planks run setblock 1 199 4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 77 run particle minecraft:happy_villager 1.5 199.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 77 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 76 unless block 0 199 4 minecraft:spruce_planks run setblock 0 199 4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 76 run particle minecraft:happy_villager 0.5 199.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 76 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 75 unless block -1 199 4 minecraft:spruce_planks run setblock -1 199 4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 75 run particle minecraft:happy_villager -0.5 199.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 75 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 74 unless block -2 199 4 minecraft:spruce_planks run setblock -2 199 4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 74 run particle minecraft:happy_villager -1.5 199.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 74 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 73 unless block -3 199 4 minecraft:spruce_planks run setblock -3 199 4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 73 run particle minecraft:happy_villager -2.5 199.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 73 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 72 unless block -4 199 4 minecraft:spruce_planks run setblock -4 199 4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 72 run playsound minecraft:block.wood.place ambient @a -4 199 4 0.18 1.15
execute if score #home tc_home_step matches 72 run particle minecraft:happy_villager -3.5 199.6 4.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 72 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 71 unless block -4 199 3 minecraft:spruce_planks run setblock -4 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 71 run particle minecraft:happy_villager -3.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 71 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 70 unless block -3 199 3 minecraft:spruce_planks run setblock -3 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 70 run particle minecraft:happy_villager -2.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 70 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 69 unless block -2 199 3 minecraft:spruce_planks run setblock -2 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 69 run particle minecraft:happy_villager -1.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 69 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 68 unless block -1 199 3 minecraft:spruce_planks run setblock -1 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 68 run particle minecraft:happy_villager -0.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 68 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 67 unless block 0 199 3 minecraft:spruce_planks run setblock 0 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 67 run particle minecraft:happy_villager 0.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 67 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 66 unless block 1 199 3 minecraft:spruce_planks run setblock 1 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 66 run playsound minecraft:block.wood.place ambient @a 1 199 3 0.18 1.15
execute if score #home tc_home_step matches 66 run particle minecraft:happy_villager 1.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 66 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 65 unless block 2 199 3 minecraft:spruce_planks run setblock 2 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 65 run particle minecraft:happy_villager 2.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 65 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 64 unless block 3 199 3 minecraft:spruce_planks run setblock 3 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 64 run particle minecraft:happy_villager 3.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 64 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 63 unless block 4 199 3 minecraft:spruce_planks run setblock 4 199 3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 63 run particle minecraft:happy_villager 4.5 199.6 3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 63 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 62 unless block 4 199 2 minecraft:spruce_planks run setblock 4 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 62 run particle minecraft:happy_villager 4.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 62 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 61 unless block 3 199 2 minecraft:spruce_planks run setblock 3 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 61 run particle minecraft:happy_villager 3.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 61 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 60 unless block 2 199 2 minecraft:spruce_planks run setblock 2 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 60 run playsound minecraft:block.wood.place ambient @a 2 199 2 0.18 1.15
execute if score #home tc_home_step matches 60 run particle minecraft:happy_villager 2.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 60 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 59 unless block 1 199 2 minecraft:spruce_planks run setblock 1 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 59 run particle minecraft:happy_villager 1.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 59 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 58 unless block 0 199 2 minecraft:spruce_planks run setblock 0 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 58 run particle minecraft:happy_villager 0.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 58 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 57 unless block -1 199 2 minecraft:spruce_planks run setblock -1 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 57 run particle minecraft:happy_villager -0.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 57 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 56 unless block -2 199 2 minecraft:spruce_planks run setblock -2 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 56 run particle minecraft:happy_villager -1.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 56 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 55 unless block -3 199 2 minecraft:spruce_planks run setblock -3 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 55 run particle minecraft:happy_villager -2.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 55 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 54 unless block -4 199 2 minecraft:spruce_planks run setblock -4 199 2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 54 run playsound minecraft:block.wood.place ambient @a -4 199 2 0.18 1.15
execute if score #home tc_home_step matches 54 run particle minecraft:happy_villager -3.5 199.6 2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 54 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 53 unless block -4 199 1 minecraft:spruce_planks run setblock -4 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 53 run particle minecraft:happy_villager -3.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 53 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 52 unless block -3 199 1 minecraft:spruce_planks run setblock -3 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 52 run particle minecraft:happy_villager -2.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 52 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 51 unless block -2 199 1 minecraft:spruce_planks run setblock -2 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 51 run particle minecraft:happy_villager -1.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 51 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 50 unless block -1 199 1 minecraft:spruce_planks run setblock -1 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 50 run particle minecraft:happy_villager -0.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 50 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 49 unless block 0 199 1 minecraft:spruce_planks run setblock 0 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 49 run particle minecraft:happy_villager 0.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 49 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 48 unless block 1 199 1 minecraft:spruce_planks run setblock 1 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 48 run playsound minecraft:block.wood.place ambient @a 1 199 1 0.18 1.15
execute if score #home tc_home_step matches 48 run particle minecraft:happy_villager 1.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 48 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 47 unless block 2 199 1 minecraft:spruce_planks run setblock 2 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 47 run particle minecraft:happy_villager 2.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 47 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 46 unless block 3 199 1 minecraft:spruce_planks run setblock 3 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 46 run particle minecraft:happy_villager 3.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 46 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 45 unless block 4 199 1 minecraft:spruce_planks run setblock 4 199 1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 45 run particle minecraft:happy_villager 4.5 199.6 1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 45 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 44 unless block 4 199 0 minecraft:spruce_planks run setblock 4 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 44 run particle minecraft:happy_villager 4.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 44 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 43 unless block 3 199 0 minecraft:spruce_planks run setblock 3 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 43 run particle minecraft:happy_villager 3.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 43 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 42 unless block 2 199 0 minecraft:spruce_planks run setblock 2 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 42 run playsound minecraft:block.wood.place ambient @a 2 199 0 0.18 1.15
execute if score #home tc_home_step matches 42 run particle minecraft:happy_villager 2.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 42 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 41 unless block 1 199 0 minecraft:spruce_planks run setblock 1 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 41 run particle minecraft:happy_villager 1.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 41 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 40 unless block 0 199 0 minecraft:spruce_planks run setblock 0 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 40 run particle minecraft:happy_villager 0.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 40 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 39 unless block -1 199 0 minecraft:spruce_planks run setblock -1 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 39 run particle minecraft:happy_villager -0.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 39 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 38 unless block -2 199 0 minecraft:spruce_planks run setblock -2 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 38 run particle minecraft:happy_villager -1.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 38 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 37 unless block -3 199 0 minecraft:spruce_planks run setblock -3 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 37 run particle minecraft:happy_villager -2.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 37 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 36 unless block -4 199 0 minecraft:spruce_planks run setblock -4 199 0 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 36 run playsound minecraft:block.wood.place ambient @a -4 199 0 0.18 1.15
execute if score #home tc_home_step matches 36 run particle minecraft:happy_villager -3.5 199.6 0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 36 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 35 unless block -4 199 -1 minecraft:spruce_planks run setblock -4 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 35 run particle minecraft:happy_villager -3.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 35 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 34 unless block -3 199 -1 minecraft:spruce_planks run setblock -3 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 34 run particle minecraft:happy_villager -2.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 34 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 33 unless block -2 199 -1 minecraft:spruce_planks run setblock -2 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 33 run particle minecraft:happy_villager -1.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 33 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 32 unless block -1 199 -1 minecraft:spruce_planks run setblock -1 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 32 run particle minecraft:happy_villager -0.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 32 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 31 unless block 0 199 -1 minecraft:spruce_planks run setblock 0 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 31 run particle minecraft:happy_villager 0.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 31 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 30 unless block 1 199 -1 minecraft:spruce_planks run setblock 1 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 30 run playsound minecraft:block.wood.place ambient @a 1 199 -1 0.18 1.15
execute if score #home tc_home_step matches 30 run particle minecraft:happy_villager 1.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 30 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 29 unless block 2 199 -1 minecraft:spruce_planks run setblock 2 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 29 run particle minecraft:happy_villager 2.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 29 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 28 unless block 3 199 -1 minecraft:spruce_planks run setblock 3 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 28 run particle minecraft:happy_villager 3.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 28 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 27 unless block 4 199 -1 minecraft:spruce_planks run setblock 4 199 -1 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 27 run particle minecraft:happy_villager 4.5 199.6 -0.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 27 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 26 unless block 4 199 -2 minecraft:spruce_planks run setblock 4 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 26 run particle minecraft:happy_villager 4.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 26 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 25 unless block 3 199 -2 minecraft:spruce_planks run setblock 3 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 25 run particle minecraft:happy_villager 3.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 25 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 24 unless block 2 199 -2 minecraft:spruce_planks run setblock 2 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 24 run playsound minecraft:block.wood.place ambient @a 2 199 -2 0.18 1.15
execute if score #home tc_home_step matches 24 run particle minecraft:happy_villager 2.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 24 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 23 unless block 1 199 -2 minecraft:spruce_planks run setblock 1 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 23 run particle minecraft:happy_villager 1.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 23 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 22 unless block 0 199 -2 minecraft:spruce_planks run setblock 0 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 22 run particle minecraft:happy_villager 0.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 22 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 21 unless block -1 199 -2 minecraft:spruce_planks run setblock -1 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 21 run particle minecraft:happy_villager -0.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 21 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 20 unless block -2 199 -2 minecraft:spruce_planks run setblock -2 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 20 run particle minecraft:happy_villager -1.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 20 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 19 unless block -3 199 -2 minecraft:spruce_planks run setblock -3 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 19 run particle minecraft:happy_villager -2.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 19 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 18 unless block -4 199 -2 minecraft:spruce_planks run setblock -4 199 -2 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 18 run playsound minecraft:block.wood.place ambient @a -4 199 -2 0.18 1.15
execute if score #home tc_home_step matches 18 run particle minecraft:happy_villager -3.5 199.6 -1.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 18 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 17 unless block -4 199 -3 minecraft:spruce_planks run setblock -4 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 17 run particle minecraft:happy_villager -3.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 17 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 16 unless block -3 199 -3 minecraft:spruce_planks run setblock -3 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 16 run particle minecraft:happy_villager -2.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 16 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 15 unless block -2 199 -3 minecraft:spruce_planks run setblock -2 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 15 run particle minecraft:happy_villager -1.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 15 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 14 unless block -1 199 -3 minecraft:spruce_planks run setblock -1 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 14 run particle minecraft:happy_villager -0.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 14 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 13 unless block 0 199 -3 minecraft:spruce_planks run setblock 0 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 13 run particle minecraft:happy_villager 0.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 13 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 12 unless block 1 199 -3 minecraft:spruce_planks run setblock 1 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 12 run playsound minecraft:block.wood.place ambient @a 1 199 -3 0.18 1.15
execute if score #home tc_home_step matches 12 run particle minecraft:happy_villager 1.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 12 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 11 unless block 2 199 -3 minecraft:spruce_planks run setblock 2 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 11 run particle minecraft:happy_villager 2.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 11 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 10 unless block 3 199 -3 minecraft:spruce_planks run setblock 3 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 10 run particle minecraft:happy_villager 3.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 10 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 9 unless block 4 199 -3 minecraft:spruce_planks run setblock 4 199 -3 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 9 run particle minecraft:happy_villager 4.5 199.6 -2.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 9 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 8 unless block 4 199 -4 minecraft:spruce_planks run setblock 4 199 -4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 8 run particle minecraft:happy_villager 4.5 199.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 8 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 7 unless block 3 199 -4 minecraft:spruce_planks run setblock 3 199 -4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 7 run particle minecraft:happy_villager 3.5 199.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 7 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 6 unless block 2 199 -4 minecraft:spruce_planks run setblock 2 199 -4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 6 run playsound minecraft:block.wood.place ambient @a 2 199 -4 0.18 1.15
execute if score #home tc_home_step matches 6 run particle minecraft:happy_villager 2.5 199.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 6 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 5 unless block 1 199 -4 minecraft:spruce_planks run setblock 1 199 -4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 5 run particle minecraft:happy_villager 1.5 199.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 5 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 4 unless block 0 199 -4 minecraft:spruce_planks run setblock 0 199 -4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 4 run particle minecraft:happy_villager 0.5 199.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 4 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 3 unless block -1 199 -4 minecraft:spruce_planks run setblock -1 199 -4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 3 run particle minecraft:happy_villager -0.5 199.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 3 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 2 unless block -2 199 -4 minecraft:spruce_planks run setblock -2 199 -4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 2 run particle minecraft:happy_villager -1.5 199.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 2 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 1 unless block -3 199 -4 minecraft:spruce_planks run setblock -3 199 -4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 1 run particle minecraft:happy_villager -2.5 199.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 1 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 0 unless block -4 199 -4 minecraft:spruce_planks run setblock -4 199 -4 minecraft:spruce_planks replace
execute if score #home tc_home_step matches 0 run playsound minecraft:block.wood.place ambient @a -4 199 -4 0.18 1.15
execute if score #home tc_home_step matches 0 run particle minecraft:happy_villager -3.5 199.6 -3.5 0.04 0.04 0.04 0 1 force @a
execute if score #home tc_home_step matches 0 run scoreboard players add #home tc_home_step 1
execute if score #home tc_home_step matches 374.. run function tamacrafti:home/complete
