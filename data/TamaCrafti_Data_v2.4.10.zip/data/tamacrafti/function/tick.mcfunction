# TamaCrafti runtime.
# Installing the pack no longer hijacks arbitrary worlds into Journey mode.
# Journey initialization is owned by D.A.I.'s launch_experience first-join hook
# (or can still be invoked manually with /function tamacrafti:journey/init).
execute as @a unless score @s tc_init matches 1 run function tamacrafti:player/init
execute if score #home tc_home_active matches 1 run function tamacrafti:home/tick
execute as @a[scores={tc_init=1,tc_journey=1}] at @s run function tamacrafti:player/tick
execute as @a[scores={tc_journey=1}] at @s run function tamacrafti:rewards/tick

# v2.4.0 low-frequency home integrity watchdog.
scoreboard players add #home tc_integrity 1
execute if score #home tc_integrity matches 200.. if score #home tc_home_complete matches 1 unless block 0 199 0 minecraft:spruce_planks run function tamacrafti:home/repair
execute if score #home tc_integrity matches 200.. run scoreboard players set #home tc_integrity 0
