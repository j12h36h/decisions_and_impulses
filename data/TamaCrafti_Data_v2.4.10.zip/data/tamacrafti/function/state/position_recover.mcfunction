# Journey home lives around Y=200. Falling below Y137 is never intentional Journey traversal.
effect give @s minecraft:resistance 4 4 true
teleport @s 0.5 201 0.5
spawnpoint @s 0 201 0
tellraw @s [{"text":"[TamaCrafti] ","color":"light_purple","bold":true},{"text":"Home recovery returned you safely to the garden.","color":"gray"}]
