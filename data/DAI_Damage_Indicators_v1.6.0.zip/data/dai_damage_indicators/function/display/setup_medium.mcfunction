tag @s add dai_di_display
scoreboard players set @s di_age 0

# Full 26.2 display transformation with 2-tick teleport interpolation.
# Minecraft's default font keeps this addon completely resource-pack independent.
$data merge entity @s {billboard:'center',shadow:1b,see_through:1b,background:0,alignment:'center',view_range:2.5f,teleport_duration:2,transformation:{translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.95f,1.95f,1.95f],right_rotation:[0.0f,0.0f,0.0f,1.0f]},text:{text:'$(whole).$(dec)',color:'#ff9f43',bold:true}}
