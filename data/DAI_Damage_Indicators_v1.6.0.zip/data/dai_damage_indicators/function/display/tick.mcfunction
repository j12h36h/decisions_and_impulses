scoreboard players set #display_clock di_const 0

# Age by two ticks because this function runs at 10 TPS.
scoreboard players add @e[type=minecraft:text_display,tag=dai_di_display] di_age 2

# Move the number the same total distance as v1.5.0. teleport_duration=2 on each
# display interpolates these half-rate server teleports smoothly client-side.
execute as @e[type=minecraft:text_display,tag=dai_di_display,scores={di_age=..68}] at @s run tp @s ~ ~0.028 ~

# Keep the original ~3.5 second lifetime.
kill @e[type=minecraft:text_display,tag=dai_di_display,scores={di_age=70..}]
