# Prefer the resolved victim. If the target disappeared on the killing blow,
# keep the proven attacker-relative fallback used by earlier releases.
execute as @e[distance=..8,tag=dai_di_victim,sort=nearest,limit=1] at @s run function dai_damage_indicators:display/spawn_medium with storage dai_damage_indicators:runtime
execute unless entity @e[distance=..8,tag=dai_di_victim,sort=nearest,limit=1] positioned ^ ^1.15 ^2 run function dai_damage_indicators:display/spawn_medium with storage dai_damage_indicators:runtime
