# Initialize new/reloaded players once.
execute as @a[tag=!dai_di_init] run function dai_damage_indicators:player/init

# Damage sampling remains 20 TPS so consecutive hits, projectiles, and DAI-native
# combat sources are not merged or missed.
execute as @a[tag=dai_di_init,scores={di_enable=1..}] at @s run function dai_damage_indicators:player/tick

# Display animation is intentionally decoupled from combat sampling.
# Updating at 10 TPS with text_display teleport interpolation halves the recurring
# entity-command cost while remaining visually smooth on the client.
scoreboard players add #display_clock di_const 1
execute if score #display_clock di_const matches 2.. run function dai_damage_indicators:display/tick
