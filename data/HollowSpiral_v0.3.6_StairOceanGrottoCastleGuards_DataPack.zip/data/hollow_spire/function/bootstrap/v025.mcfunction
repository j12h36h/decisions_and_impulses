# v0.2.5 vanilla-only mob migration.
# Purge legacy v0.1.x custom enemy carriers and their item-display rigs by tag only,
# so this function remains valid even when no hollow_spire custom entity IDs are registered.
kill @e[tag=hs_enemy]
kill @e[type=minecraft:item_display,tag=hs_visual]

# Refresh any Endless Survival hostiles that were created while the old Hollow Spire
# resource/custom visual layer was active. Room-local ecology will repopulate them as
# clean minecraft:* entities when the player is nearby.
kill @e[tag=hs_hostile]

data modify storage hollow_spire:runtime v025 set value 1b
