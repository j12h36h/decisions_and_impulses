HOLLOW SPIRAL v0.3.6

Endless survival room-grid datapack for DAI 1.9.1 / Minecraft 26.2.

This revision makes vertical stair controls coexist safely when a room has both UP and DOWN links, exposes two additional descending steps at upper stair endpoints, limits staircase carving so Ocean glass pressure walls survive, rebuilds Coral Grotto as a flooded structural ruin/reef environment instead of block masses, and gives Castles a random defensive population of either one Iron Golem or two named villager guards.

Use with HollowSpire v0.1.1 VanillaMobTextureFix ResourcePack for the current visual stage.
