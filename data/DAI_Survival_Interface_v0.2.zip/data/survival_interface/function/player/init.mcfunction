scoreboard players add #next_slot si_const 1
execute if score #next_slot si_const matches 9.. run scoreboard players set #next_slot si_const 1
scoreboard players operation @s si_slot = #next_slot si_const
# Preserve an existing v0.1/v0.2 preference; only players without a score default to Enabled.
execute unless score @s si_enable = @s si_enable run scoreboard players set @s si_enable 1
scoreboard players set @s si_lock 0
scoreboard players set @s si_ray 0
tag @s add si_init
function survival_interface:ui/hide
