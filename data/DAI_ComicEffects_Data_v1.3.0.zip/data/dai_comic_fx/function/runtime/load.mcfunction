# DAI Comic Effects v1.3.0 runtime state
scoreboard objectives add dai_cfx_fall dummy
scoreboard objectives add dai_cfx_age dummy
scoreboard objectives add dai_cfx_creep dummy
scoreboard objectives add dai_cfx_fuse dummy
kill @e[type=minecraft:text_display,tag=dai_cfx_effect]
