tag @s add dai_cfx_creeper_init
scoreboard players set @s dai_cfx_creep 0
scoreboard players set @s dai_cfx_fuse 29
execute if data entity @s Fuse store result score @s dai_cfx_fuse run data get entity @s Fuse
execute if score @s dai_cfx_fuse matches 2.. run scoreboard players remove @s dai_cfx_fuse 1
