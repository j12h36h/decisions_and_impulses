# Age and gently float active world-space comic sprites.
scoreboard players add @e[type=minecraft:text_display,tag=dai_cfx_effect] dai_cfx_age 1
execute as @e[type=minecraft:text_display,tag=dai_cfx_effect] at @s run tp @s ~ ~0.025 ~
kill @e[type=minecraft:text_display,tag=dai_cfx_effect,scores={dai_cfx_age=16..}]

# Process each nearby entity only once per tick even with multiple players online.
tag @e[tag=dai_cfx_scanned] remove dai_cfx_scanned
execute as @a at @s run function dai_comic_fx:runtime/scan_nearby
