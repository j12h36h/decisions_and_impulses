tag @s add dai_cfx_scanned

# Living entities: arm while airborne, splash on water entry, crash on a significant landing.
execute if data entity @s Health run function dai_comic_fx:runtime/living

# Gravity blocks (sand, gravel, concrete powder, anvils through falling_block, etc.).
execute if entity @s[type=minecraft:falling_block] run function dai_comic_fx:runtime/falling_block

# World events that should be visible anywhere the event would reasonably be heard.
execute if entity @s[type=minecraft:lightning_bolt,tag=!dai_cfx_event_seen] run function dai_comic_fx:event/zap
execute if entity @s[type=minecraft:tnt] run function dai_comic_fx:runtime/tnt
execute if entity @s[type=minecraft:creeper] run function dai_comic_fx:runtime/creeper
