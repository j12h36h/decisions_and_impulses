execute as @e[distance=..32,tag=!dai_cfx_scanned] at @s run function dai_comic_fx:runtime/nearby_entity
