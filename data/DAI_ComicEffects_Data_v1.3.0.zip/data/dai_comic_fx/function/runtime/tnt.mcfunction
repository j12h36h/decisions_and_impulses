# TNT exposes its live fuse in entity NBT. Support both current and legacy casing.
scoreboard players set @s dai_cfx_fuse 999
execute if data entity @s fuse store result score @s dai_cfx_fuse run data get entity @s fuse
execute unless data entity @s fuse if data entity @s Fuse store result score @s dai_cfx_fuse run data get entity @s Fuse
execute if score @s dai_cfx_fuse matches ..2 unless entity @s[tag=dai_cfx_event_seen] run function dai_comic_fx:event/boom
