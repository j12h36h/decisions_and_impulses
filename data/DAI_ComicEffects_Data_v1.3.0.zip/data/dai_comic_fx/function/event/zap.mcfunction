tag @s add dai_cfx_event_seen
summon minecraft:text_display ~ ~1.6 ~ {Tags:['dai_cfx_effect'],text:{text:'',font:'dai_comic_fx:comic'},billboard:'center',background:0,shadow:1b,see_through:1b,view_range:0.6f,alignment:'center'}
