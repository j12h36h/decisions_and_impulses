# DirtBikeLife v0.1.0
scoreboard objectives add dbl_crashes dummy
scoreboard objectives add dbl_gear dummy
scoreboard objectives modify dbl_crashes displayname {"text":"DirtBikeLife | Crashes","color":"aqua","bold":true}
scoreboard objectives setdisplay sidebar dbl_crashes
scoreboard players add @a dbl_crashes 0
scoreboard players add @a dbl_gear 0
tellraw @a [{"text":"[DirtBikeLife] ","color":"aqua","bold":true},{"text":"v0.1.0 loaded — use /function dirtbikelife:starter/give to get a DirtBikeLife Key.","color":"white"}]
