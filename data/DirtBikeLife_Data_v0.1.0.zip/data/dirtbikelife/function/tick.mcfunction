scoreboard players add @a dbl_crashes 0
scoreboard players add @a dbl_gear 0
