scoreboard players remove @s dbl_gear 1
execute if score @s dbl_gear matches ..-1 run scoreboard players set @s dbl_gear 0
playsound dirtbikelife:vehicle.shift_down master @s ~ ~ ~ 0.65 0.92
title @s actionbar [{"text":"GEAR ","color":"gray"},{"score":{"name":"@s","objective":"dbl_gear"}},{"text":"  ↓","color":"yellow"}]
