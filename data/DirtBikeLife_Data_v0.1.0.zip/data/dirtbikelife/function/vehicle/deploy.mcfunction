# RMB on the key only reaches this while unmounted; mouse use is intercepted by DAI while riding.
execute on vehicle if entity @s[tag=dbl_bike] run return 0
execute at @s run summon dirtbikelife:dirtbike ~ ~0.05 ~ {Tags:["dbl_bike","dbl_new"],Silent:1b,Invulnerable:1b}
execute at @s run tp @e[tag=dbl_new,sort=nearest,limit=1,distance=..4] ~ ~0.05 ~ ~ 0
execute at @s run ride @s mount @e[tag=dbl_new,sort=nearest,limit=1,distance=..4]
execute at @s run tag @e[tag=dbl_new,sort=nearest,limit=1,distance=..4] remove dbl_new
scoreboard players set @s dbl_gear 1
playsound dirtbikelife:vehicle.engine_start master @s ~ ~ ~ 0.75 1.0
tellraw @s [{"text":"[DirtBikeLife] ","color":"aqua","bold":true},{"text":"LMB hold = throttle | RMB tap = upshift | RMB double-tap = downshift | RMB hold 1s = full brake | W/S = lean | A/D = steer | Shift = dismount","color":"white"}]
