scoreboard players add @s dbl_crashes 1
playsound dirtbikelife:vehicle.crash master @s ~ ~ ~ 1.0 1.0
title @s times 0 40 10
title @s title [{"text":"CRASH #","color":"red","bold":true},{"score":{"name":"@s","objective":"dbl_crashes"}}]
title @s subtitle {"text":"3 SECOND ECHO SIMULATION","color":"white"}
