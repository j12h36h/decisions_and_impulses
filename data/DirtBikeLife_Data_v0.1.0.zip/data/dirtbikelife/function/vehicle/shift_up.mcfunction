scoreboard players add @s dbl_gear 1
execute if score @s dbl_gear matches 6.. run scoreboard players set @s dbl_gear 5
playsound dirtbikelife:vehicle.shift_up master @s ~ ~ ~ 0.65 1.0
title @s actionbar [{"text":"GEAR ","color":"gray"},{"score":{"name":"@s","objective":"dbl_gear"}},{"text":"  ↑","color":"green"}]
