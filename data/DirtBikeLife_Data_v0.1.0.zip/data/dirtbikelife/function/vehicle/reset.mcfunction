scoreboard players set @s dbl_gear 1
playsound dirtbikelife:vehicle.echo_reset master @s ~ ~ ~ 0.9 1.0
title @s times 0 20 8
title @s title {"text":"ECHO RESET","color":"aqua","bold":true}
title @s subtitle {"text":"RIDER RESTORED • BIKE UPRIGHT • GEAR 1","color":"white"}
