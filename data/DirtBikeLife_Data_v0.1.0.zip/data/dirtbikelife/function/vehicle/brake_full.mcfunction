playsound dirtbikelife:vehicle.brake master @s ~ ~ ~ 0.55 0.95
title @s actionbar {"text":"FULL BRAKE","color":"red","bold":true}
