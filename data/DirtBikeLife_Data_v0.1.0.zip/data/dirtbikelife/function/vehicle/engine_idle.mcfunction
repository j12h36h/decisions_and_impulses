playsound dirtbikelife:vehicle.engine_idle master @s ~ ~ ~ 0.32 1.0
