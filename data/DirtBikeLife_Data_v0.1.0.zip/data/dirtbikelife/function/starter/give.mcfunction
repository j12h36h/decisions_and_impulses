give @s dirtbikelife:dirtbike_key 1
tellraw @s [{"text":"[DirtBikeLife] ","color":"aqua","bold":true},{"text":"DirtBikeLife Key added. Right-click while unmounted to deploy the bike.","color":"white"}]
