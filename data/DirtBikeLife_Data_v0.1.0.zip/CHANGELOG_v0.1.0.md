# DirtBikeLife v0.1.0 — Development Revision r3

## Vehicle behavior fixes
- Reworked manual motorcycle drive output around gear-owned target road speeds.
- Each gear now actively converges toward its own authored maximum instead of losing higher-gear gains to native mob friction.
- Preserved lower-gear torque feel while allowing higher gears to produce materially higher real movement speeds.
- Added configurable `throttle_response`.

## Terrain / wheelie traversal
- Added normal and wheelie-specific step-height tuning.
- While actively throttling with the front end lifted, the dirtbike raises its native step height enough to climb a one-block ledge.
- Added `normal_step_height`, `wheelie_step_height`, and `wheelie_step_min_angle` tuning values.

## Wheelie presentation
- DirtBikeLife now opts its rider seat into vehicle pitch following.
- Added a rear-wheel pitch pivot at `0 0 -1.05` so the bike visually rotates around the rear tire during a wheelie instead of pitching through its center.
- Rider seat position now follows the same pitch pivot during wheelies, jumps and crash rotation.

This revision requires the matching DAI DirtBikeLife Vehicle Patch r3.


## r4 test correction
- Calibrated carrier-command velocity so authored gear speeds correspond much more closely to real world displacement.
- Added speed-dependent native-carrier compensation while preserving gear-specific acceleration and RPM behavior.
- Added active wheelie ledge assist: when a front-lifted bike stalls against terrain, the suspension applies a short upward impulse so one-block ledges can be ridden over.
- Wheelie ledge assist is gated by throttle, wheelie angle, measured movement stall, and a cooldown; normal riding does not auto-jump.


## r5 handling tune
- Increased grounded wheelie self-righting from `0.006` to `0.0085`.
- Front-end drop after reducing rear lean is now roughly 40% more assertive while preserving the existing balance point and wheelie lift power.
- No DAI native-code change is required beyond Vehicle Patch r4.

- r6: added throttle-release timing/braking and wheelie-release damping parameters for DAI vehicle patch r5.
