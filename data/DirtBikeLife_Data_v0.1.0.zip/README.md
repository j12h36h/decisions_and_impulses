# DirtBikeLife Data v0.1.0 — r3

DAI-powered manual dirtbike prototype.

Controls:
- LMB hold: throttle
- RMB tap: shift up
- RMB double tap: shift down
- RMB hold: soft brake, then full brake after 1 second
- A / D: steer
- W / S: rider lean
- Shift: dismount

Obtain the bike key with:

`/function dirtbikelife:starter/give`

Revision r3 pairs with the DAI DirtBikeLife Vehicle Patch r3 and adds true gear-target road speeds, wheelie-aware one-block terrain traversal, rear-wheel visual pitch pivoting, and pitch-aware rider seating.


### r4 runtime calibration
The manual motorcycle controller now treats `gear_N_speed` as intended road speed rather than raw native-entity command velocity. Wheelie terrain traversal also has an active one-block ledge assist when the bike is visibly front-lifted and driving into an obstacle.


### r6 throttle-release tuning
LMB release now pairs with DAI vehicle patch r5: powered drive cuts on the release edge, a brief engine-braking pulse removes residual drive feel, and upward wheelie carry is damped without eliminating coasting.
