MineTrigger — Border Training v0.9.1
=====================================
DAI 3.3 / Minecraft 26.2

This is a clean rebuild from the known-loadable v0.6.0 MAIN experience.
The v0.6 world-loading/worldgen lifecycle is preserved, while the intended PvP, drone, mobility and combat systems from later development are reintroduced without the v0.8.3/v0.8.4 staged/preload experiments.

Highlights
- 193-block Border PvP arena generated during the normal DAI worldgen bootstrap.
- PvP Level 0-9 progression; five drone kills grant one PvP-equivalent progression point.
- Native DAI Target / Evasion / Combat training drones with 0.8x movement, larger mesh, hit shake, straight projectiles and safe flight lanes.
- Trigger OFF -> ON restores the saved loadout.
- Egret, Asteroid/Meteor, Hound and Force Blaster use repaired ranged paths.
- Grasshopper is the normal Jump key pressed again while airborne.
- Trion-first damage, offline recovery, sidebar HUD, Grave-key MineTrigger UI.
- Companion resource pack supplies native drone art, energy bolts and context-selected 3D held Trigger models while keeping flat GUI/hotbar icons.

Install as the MineTrigger MAIN datapack plus its matching v0.9.1 companion resource pack. Do not stack older MineTrigger versions.
