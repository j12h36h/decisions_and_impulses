# MineTrigger v0.6.0 / DAI 3.3 objectives.
scoreboard objectives add wt_init dummy
scoreboard objectives add wt_active dummy
scoreboard objectives add wt_trion dummy
scoreboard objectives add wt_trion_max dummy
scoreboard objectives add wt_loadout dummy
scoreboard objectives add wt_clock dummy
scoreboard objectives add wt_ray_step dummy
scoreboard objectives add wt_proj_age dummy
scoreboard objectives add wt_proj_dist dummy
scoreboard objectives add wt_bagworm dummy
scoreboard objectives add wt_chameleon dummy
scoreboard objectives add wt_rank dummy
scoreboard objectives add wt_world dummy
scoreboard players add #clock wt_clock 0
# v0.9.4 arena/platform self-heal
execute unless score #arena wt_world matches 2 run function minetrigger:world/ensure_training_sector
execute as @a unless score @s wt_init matches 1 run function minetrigger:player/init
# One-time training-sector structural repair for upgraded worlds.
execute if score #arena wt_world matches 2 unless score #modern_v050 wt_world matches 1 run function minetrigger:world/repair_v050

# v0.9.4 positioning-platform upgrade for existing worlds
execute unless score #platforms_v094 wt_world matches 1 run function minetrigger:world/add_positioning_platforms_v094

# v0.9.4 one-time migration from zombie-carrier kill criterion to native training-drone criterion
execute unless score #native_kills_v094 wt_world matches 1 run scoreboard objectives remove mt_drone_kills
execute unless score #native_kills_v094 wt_world matches 1 run scoreboard objectives add mt_drone_kills minecraft.killed:minetrigger.training_drone
execute unless score #native_kills_v094 wt_world matches 1 as @a run scoreboard players set @s mt_drone_prev 0
execute unless score #native_kills_v094 wt_world matches 1 run kill @e[type=minecraft:zombie,tag=mt_drone]
execute unless score #native_kills_v094 wt_world matches 1 run kill @e[type=minecraft:item_display,tag=mt_drone_visual]
execute unless score #native_kills_v094 wt_world matches 1 run scoreboard players set #native_kills_v094 wt_world 1
