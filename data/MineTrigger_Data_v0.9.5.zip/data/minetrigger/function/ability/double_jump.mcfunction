execute unless entity @s[tag=mt_pvp_initialized] run return 0
execute unless score @s wt_active matches 1.. run return 0
execute unless score @s wt_loadout matches 1..4 run return 0
execute if score @s wt_loadout matches 3 run return 0
execute unless score @s wt_trion matches 10.. run return 0
execute if entity @s[nbt={OnGround:1b}] run return 0
execute unless score @s mt_air_ticks matches 2.. run return 0
execute unless score @s mt_double_used matches 0 run return 0
scoreboard players remove @s wt_trion 8
scoreboard players set @s mt_double_used 1
scoreboard players set @s mt_jump_lift 7
scoreboard players set @s mt_levitation_owned 1
effect give @s minecraft:levitation 1 10 true
particle minecraft:electric_spark ~ ~0.2 ~ 0.35 0.15 0.35 0.08 22 force @s
playsound minecraft:block.amethyst_block.resonate player @s ~ ~ ~ 0.9 1.62
