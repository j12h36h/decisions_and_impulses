execute unless score @s wt_active matches 1.. run tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Trigger body is offline.","color":"gray"}]
execute if score @s wt_active matches 1.. unless score @s wt_trion matches 4.. run tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Insufficient Trion for Shield.","color":"red"}]
execute if score @s wt_active matches 1.. if score @s wt_trion matches 4.. run function minetrigger:ability/shield_guard_commit
