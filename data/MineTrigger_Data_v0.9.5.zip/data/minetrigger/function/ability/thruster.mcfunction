execute unless score @s wt_active matches 1.. run tellraw @s {"text":"[BORDER] Trigger On is required.","color":"red"}
execute if score @s wt_active matches 1.. unless score @s wt_trion matches 10.. run tellraw @s {"text":"[BORDER] Insufficient Trion for Thruster.","color":"red"}
execute if score @s wt_active matches 1.. if score @s wt_trion matches 10.. run scoreboard players remove @s wt_trion 10
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run teleport @s ^ ^0.4 ^8
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run playsound minecraft:entity.firework_rocket.launch player @s ~ ~ ~ 0.7 1.2
execute if score @s wt_active matches 1.. if score @s wt_trion matches ..0 run function minetrigger:trigger/trion_break
