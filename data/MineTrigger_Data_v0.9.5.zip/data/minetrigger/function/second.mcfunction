# MineTrigger v0.6.0: one global player pass per second.
scoreboard players set #clock wt_clock 0
execute as @a run function minetrigger:player/second
