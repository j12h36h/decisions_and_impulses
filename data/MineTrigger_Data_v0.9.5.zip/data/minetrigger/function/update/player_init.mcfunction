
scoreboard players set @s mt_level 0
scoreboard players set @s mt_level_last -1
scoreboard players operation @s mt_pvp_prev = @s mt_pvp_kills
scoreboard players set @s mt_progress 0
scoreboard players set @s mt_required 1
scoreboard players operation @s mt_deaths_prev = @s mt_deaths
scoreboard players set @s mt_recovery 1
scoreboard players set @s mt_regen_clock 0
scoreboard players set @s mt_regen_window 0
scoreboard players set @s mt_air_ticks 0
scoreboard players set @s mt_double_used 0
scoreboard players set @s mt_fb_lift 0
scoreboard players set @s mt_jump_lift 0
scoreboard players set @s mt_force_lift 0
scoreboard players set @s mt_levitation_owned 0
scoreboard players set @s mt_regen_owned 0
scoreboard players set @s mt_training_kills 0
scoreboard players set @s mt_drone_kills 0
scoreboard players set @s mt_drone_prev 0
scoreboard players set @s mt_drone_credit 0
scoreboard players set @s mt_training_hits 0
function minetrigger:update/assign_player_id
tag @s add mt_pvp_initialized
function minetrigger:update/apply_level
tellraw @s [{"text":"[BORDER] ","color":"dark_aqua"},{"text":"PvP Level 0 initialized. First promotion requires 1 PvP-equivalent point. Every 5 drone kills also grant 1 point.","color":"gray"}]
