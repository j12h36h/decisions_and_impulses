execute unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run return 0
execute if entity @a[scores={wt_active=1},distance=..0.75,limit=1] run function minetrigger:update/drones/fire
execute if entity @a[scores={wt_active=1},distance=..0.75,limit=1] run return 0
scoreboard players add @s mt_los_step 1
execute if score @s mt_los_step matches ..199 positioned ^ ^ ^0.5 run function minetrigger:update/drones/los
