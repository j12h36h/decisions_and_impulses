scoreboard players set #players mt_tmp 0
execute as @a run scoreboard players add #players mt_tmp 1
scoreboard players set #drones mt_tmp 0
execute as @e[tag=mt_drone] run scoreboard players add #drones mt_tmp 1

# Solo/empty arena: maintain up to five training drones.
execute if score #players mt_tmp matches 0..1 if score #drones mt_tmp matches 0 run function minetrigger:update/drones/spawn_five
execute if score #players mt_tmp matches 0..1 if score #drones mt_tmp matches 1..4 run function minetrigger:update/drones/spawn_one

# Two players: maintain exactly two or fewer training targets and remove all excess in this cycle.
execute if score #players mt_tmp matches 2 if score #drones mt_tmp matches 0 run function minetrigger:update/drones/spawn_two
execute if score #players mt_tmp matches 2 if score #drones mt_tmp matches 1 run function minetrigger:update/drones/spawn_one
execute if score #players mt_tmp matches 2 run tag @e[tag=mt_drone] remove mt_keep
execute if score #players mt_tmp matches 2 positioned 0 -45 0 run tag @e[tag=mt_drone,sort=nearest,limit=2] add mt_keep
execute if score #players mt_tmp matches 2 run kill @e[tag=mt_drone,tag=!mt_keep]
execute if score #players mt_tmp matches 2 run tag @e[tag=mt_drone] remove mt_keep

# Three or more players: clear training traffic for PvP.
execute if score #players mt_tmp matches 3.. run kill @e[tag=mt_drone]
