# v0.9.4: native DAI drone entities own health, hitbox, rendering and function-driven flight.
scoreboard players add @e[tag=mt_drone] mt_drone_age 1
scoreboard players add @e[tag=mt_drone] mt_drone_hit_anim 0

# A vanilla hurt pulse starts a full one-second visual shake. Explicit projectile paths also set this score.
execute as @e[tag=mt_drone,nbt={HurtTime:10s}] run scoreboard players set @s mt_drone_hit_anim 20

# v0.9.5 damage reaction: fixed-position yaw recoil; never moves the hitbox or flight lane.
# Each 4-tick cycle sums to 0 degrees, so the drone always returns to its pre-hit heading.
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=20}] at @s run tp @s ~ ~ ~ ~7 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=19}] at @s run tp @s ~ ~ ~ ~-14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=18}] at @s run tp @s ~ ~ ~ ~14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=17}] at @s run tp @s ~ ~ ~ ~-7 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=16}] at @s run tp @s ~ ~ ~ ~7 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=15}] at @s run tp @s ~ ~ ~ ~-14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=14}] at @s run tp @s ~ ~ ~ ~14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=13}] at @s run tp @s ~ ~ ~ ~-7 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=12}] at @s run tp @s ~ ~ ~ ~7 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=11}] at @s run tp @s ~ ~ ~ ~-14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=10}] at @s run tp @s ~ ~ ~ ~14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=9}] at @s run tp @s ~ ~ ~ ~-7 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=8}] at @s run tp @s ~ ~ ~ ~7 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=7}] at @s run tp @s ~ ~ ~ ~-14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=6}] at @s run tp @s ~ ~ ~ ~14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=5}] at @s run tp @s ~ ~ ~ ~-7 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=4}] at @s run tp @s ~ ~ ~ ~7 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=3}] at @s run tp @s ~ ~ ~ ~-14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=2}] at @s run tp @s ~ ~ ~ ~14 ~
execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=1}] at @s run tp @s ~ ~ ~ ~-7 ~

execute as @e[tag=mt_drone,scores={mt_drone_hit_anim=1..}] run scoreboard players remove @s mt_drone_hit_anim 1

# Gentle target drone patrol with zero net drift; this prevents long-session migration into arena structures.
execute as @e[tag=mt_drone_target,scores={mt_drone_age=..19,mt_drone_hit_anim=0}] at @s run tp @s ~0.08 ~0.016 ~
execute as @e[tag=mt_drone_target,scores={mt_drone_age=20..39,mt_drone_hit_anim=0}] at @s run tp @s ~-0.08 ~0.016 ~
execute as @e[tag=mt_drone_target,scores={mt_drone_age=40..59,mt_drone_hit_anim=0}] at @s run tp @s ~-0.08 ~-0.016 ~
execute as @e[tag=mt_drone_target,scores={mt_drone_age=60..79,mt_drone_hit_anim=0}] at @s run tp @s ~0.08 ~-0.016 ~

# Evasion drones orbit the closest player and change vertical lane; freeze locomotion during the hit reaction.
execute as @e[tag=mt_drone_evasion,scores={mt_drone_age=..39,mt_drone_hit_anim=0}] at @s facing entity @p[scores={wt_active=1}] eyes run tp @s ^0.176 ^0.036 ^0.032
execute as @e[tag=mt_drone_evasion,scores={mt_drone_age=40..79,mt_drone_hit_anim=0}] at @s facing entity @p[scores={wt_active=1}] eyes run tp @s ^-0.224 ^-0.020 ^0.048

# Combat drone movement.
execute as @e[tag=mt_drone_combat,scores={mt_drone_age=..39,mt_drone_hit_anim=0}] at @s facing entity @p[scores={wt_active=1}] eyes run tp @s ^0.128 ^0.016 ^0.024
execute as @e[tag=mt_drone_combat,scores={mt_drone_age=40..79,mt_drone_hit_anim=0}] at @s facing entity @p[scores={wt_active=1}] eyes run tp @s ^-0.128 ^-0.016 ^0.024

# Fire only after a true air-line reaches a player; walls terminate the LOS ray.
scoreboard players set @e[tag=mt_drone_combat,scores={mt_drone_age=20}] mt_los_step 0
scoreboard players set @e[tag=mt_drone_combat,scores={mt_drone_age=60}] mt_los_step 0
execute as @e[tag=mt_drone_combat,scores={mt_drone_age=20}] at @s positioned ~ ~0.2 ~ facing entity @p[scores={wt_active=1}] eyes positioned ^ ^ ^0.5 run function minetrigger:update/drones/los
execute as @e[tag=mt_drone_combat,scores={mt_drone_age=60}] at @s positioned ~ ~0.2 ~ facing entity @p[scores={wt_active=1}] eyes positioned ^ ^ ^0.5 run function minetrigger:update/drones/los

# Reset patrol cycle.
scoreboard players set @e[tag=mt_drone,scores={mt_drone_age=80..}] mt_drone_age 0

# Energy projectiles use quarter-block collision steps: no wall tunneling, first contact terminates, 100m max.
execute as @e[tag=mt_drone_shot] at @s run particle minecraft:electric_spark ~ ~ ~ 0.045 0.045 0.045 0.012 3 force
execute as @e[tag=mt_drone_shot] at @s run particle minecraft:end_rod ~ ~ ~ 0.008 0.008 0.008 0.001 1 force
execute as @e[tag=mt_drone_shot,tag=!mt_proj_dead] at @s run function minetrigger:update/drones/shot_step
execute as @e[tag=mt_drone_shot,tag=!mt_proj_dead] at @s run function minetrigger:update/drones/shot_step
execute as @e[tag=mt_drone_shot,tag=!mt_proj_dead] at @s run function minetrigger:update/drones/shot_step
kill @e[tag=mt_drone_shot,tag=mt_proj_dead]

# Clean up detached drone visuals after a carrier dies.
