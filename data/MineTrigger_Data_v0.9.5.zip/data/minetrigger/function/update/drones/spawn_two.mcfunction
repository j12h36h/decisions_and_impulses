# Two-drone practice pattern — v0.9.4 native DAI entities.
execute positioned 0 -45 -68 run summon minetrigger:training_drone ~ ~ ~ {Tags:["mt_drone","mt_drone_target"],CustomName:'{"text":"TARGET DRONE","color":"aqua"}',CustomNameVisible:1b,NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Silent:1b,Health:10.0f}
execute positioned 68 -45 0 run summon minetrigger:training_drone ~ ~ ~ {Tags:["mt_drone","mt_drone_target"],CustomName:'{"text":"TARGET DRONE","color":"aqua"}',CustomNameVisible:1b,NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Silent:1b,Health:10.0f}
