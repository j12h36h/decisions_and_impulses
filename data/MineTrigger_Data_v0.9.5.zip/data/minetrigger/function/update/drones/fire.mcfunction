# Spawn at the combat drone muzzle and snapshot one active player's direction exactly once.
# v0.8.2 uses an invisible marker carrier; the bolt is rendered by particles in drones/tick, avoiding item-display rendering during world entry.
execute at @s positioned ~ ~0.2 ~ facing entity @p[scores={wt_active=1}] eyes positioned ^ ^ ^0.5 run summon minecraft:marker ~ ~ ~ {Tags:["mt_drone_shot","mt_drone_shot_new"]}
execute at @s as @e[type=minecraft:marker,tag=mt_drone_shot_new,limit=1,sort=nearest,distance=..3] at @s run tp @s ~ ~ ~ facing entity @p[scores={wt_active=1}] eyes
scoreboard players set @e[tag=mt_drone_shot_new] wt_proj_dist 0
scoreboard players set @e[tag=mt_drone_shot_new] mt_drone_age 0
scoreboard players set @e[tag=mt_drone_shot_new] mt_proj_owner 0
tag @e[tag=mt_drone_shot_new] remove mt_drone_shot_new
