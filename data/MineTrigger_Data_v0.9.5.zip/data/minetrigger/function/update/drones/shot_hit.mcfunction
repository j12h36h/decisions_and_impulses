scoreboard players set #incoming_owner mt_tmp 0
scoreboard players set @a[distance=..1.8,limit=1,sort=nearest] mt_drone_hit_timer 20
execute positioned ~ ~-1 ~ as @a[distance=..0.80,limit=1,sort=nearest] run function minetrigger:combat/damage/incoming_1
particle minecraft:electric_spark ~ ~ ~ 0.10 0.10 0.10 0.04 10 force
tag @s add mt_proj_dead
