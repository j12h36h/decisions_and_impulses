# Five-drone solo training pattern — v0.9.4 native DAI entities; no carriers/passenger visuals.
execute positioned 0 -45 -68 run summon minetrigger:training_drone ~ ~ ~ {Tags:["mt_drone","mt_drone_target"],CustomName:'{"text":"TARGET DRONE","color":"aqua"}',CustomNameVisible:1b,NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Silent:1b,Health:10.0f}
execute positioned 68 -45 0 run summon minetrigger:training_drone ~ ~ ~ {Tags:["mt_drone","mt_drone_target"],CustomName:'{"text":"TARGET DRONE","color":"aqua"}',CustomNameVisible:1b,NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Silent:1b,Health:10.0f}
execute positioned -68 -44 0 run summon minetrigger:training_drone ~ ~ ~ {Tags:["mt_drone","mt_drone_evasion","mt_drone_new_evasion"],CustomName:'{"text":"EVASION DRONE","color":"light_purple"}',CustomNameVisible:1b,NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Silent:1b,Health:15.0f}
execute positioned -68 -44 0 run attribute @e[type=minetrigger:training_drone,tag=mt_drone_new_evasion,sort=nearest,limit=1,distance=..2] minecraft:max_health base set 15
execute positioned -68 -44 0 run data modify entity @e[type=minetrigger:training_drone,tag=mt_drone_new_evasion,sort=nearest,limit=1,distance=..2] Health set value 15.0f
execute positioned 0 -44 68 run summon minetrigger:training_drone ~ ~ ~ {Tags:["mt_drone","mt_drone_evasion","mt_drone_new_evasion"],CustomName:'{"text":"EVASION DRONE","color":"light_purple"}',CustomNameVisible:1b,NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Silent:1b,Health:15.0f}
execute positioned 0 -44 68 run attribute @e[type=minetrigger:training_drone,tag=mt_drone_new_evasion,sort=nearest,limit=1,distance=..2] minecraft:max_health base set 15
execute positioned 0 -44 68 run data modify entity @e[type=minetrigger:training_drone,tag=mt_drone_new_evasion,sort=nearest,limit=1,distance=..2] Health set value 15.0f
execute positioned 0 -42 0 run summon minetrigger:training_drone ~ ~ ~ {Tags:["mt_drone","mt_drone_combat","mt_drone_new_combat"],CustomName:'{"text":"COMBAT DRONE","color":"red"}',CustomNameVisible:1b,NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Silent:1b,Health:20.0f}
execute positioned 0 -42 0 run attribute @e[type=minetrigger:training_drone,tag=mt_drone_new_combat,sort=nearest,limit=1,distance=..2] minecraft:max_health base set 20
execute positioned 0 -42 0 run data modify entity @e[type=minetrigger:training_drone,tag=mt_drone_new_combat,sort=nearest,limit=1,distance=..2] Health set value 20.0f
tag @e[type=minetrigger:training_drone,tag=mt_drone_new_evasion] remove mt_drone_new_evasion
tag @e[type=minetrigger:training_drone,tag=mt_drone_new_combat] remove mt_drone_new_combat
