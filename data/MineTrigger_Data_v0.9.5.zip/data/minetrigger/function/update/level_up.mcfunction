
scoreboard players operation @s mt_progress -= @s mt_required
scoreboard players add @s mt_level 1
execute if score @s mt_level matches 10.. run scoreboard players set @s mt_level 9
function minetrigger:update/apply_level
title @s title [{"text":"LEVEL ","color":"aqua"},{"score":{"name":"@s","objective":"mt_level"},"color":"gold"}]
title @s subtitle [{"text":"PvP tier increased","color":"gray"}]
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.7 1.15
