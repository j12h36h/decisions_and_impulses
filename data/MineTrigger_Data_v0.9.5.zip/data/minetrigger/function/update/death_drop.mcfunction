
execute if score @s mt_level matches 1.. run scoreboard players remove @s mt_level 1
scoreboard players set @s mt_progress 0
function minetrigger:update/apply_level
tellraw @s [{"text":"[BORDER] ","color":"dark_aqua"},{"text":"Defeat registered. PvP level reduced by one tier.","color":"red"}]
