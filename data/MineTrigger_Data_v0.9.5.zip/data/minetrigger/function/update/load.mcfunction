# MineTrigger v0.9.5 v0.6-safe registry recovery
scoreboard objectives add mt_level dummy
scoreboard objectives add mt_level_last dummy
scoreboard objectives add mt_pvp_kills playerKillCount
scoreboard objectives add mt_pvp_prev dummy
scoreboard objectives add mt_progress dummy
scoreboard objectives add mt_required dummy
scoreboard objectives add mt_deaths deathCount
scoreboard objectives add mt_deaths_prev dummy
scoreboard objectives add mt_recovery dummy
scoreboard objectives add mt_regen_clock dummy
scoreboard objectives add mt_regen_window dummy
scoreboard objectives add mt_air_ticks dummy
scoreboard objectives add mt_double_used dummy
scoreboard objectives add mt_fb_lift dummy
scoreboard objectives add mt_jump_lift dummy
scoreboard objectives add mt_force_lift dummy
scoreboard objectives add mt_levitation_owned dummy
scoreboard objectives add mt_regen_owned dummy
scoreboard objectives add mt_training_kills dummy
scoreboard objectives add mt_drone_kills minecraft.killed:minecraft.zombie
scoreboard objectives add mt_drone_prev dummy
scoreboard objectives add mt_drone_credit dummy
scoreboard objectives add mt_training_hits dummy
scoreboard objectives add mt_drone_age dummy
scoreboard objectives add mt_los_step dummy
scoreboard objectives add mt_drone_hit_timer dummy
scoreboard objectives add mt_drone_hit_anim dummy
scoreboard objectives add mt_player_id dummy
scoreboard objectives add mt_proj_owner dummy
scoreboard objectives add mt_tmp dummy
scoreboard objectives add mt_health_read dummy
scoreboard objectives add mt_state dummy
scoreboard objectives add mt_hud dummy
scoreboard objectives modify mt_hud displayname {"text":"MineTrigger // DAI 3.3","color":"aqua","bold":true}
scoreboard objectives setdisplay sidebar mt_hud
scoreboard objectives setdisplay below_name mt_level
gamerule keep_inventory true
gamerule immediate_respawn true
gamerule spawn_mobs false
gamerule mob_griefing false
gamerule advance_weather false
gamerule advance_time false
weather clear
time set 6000
worldborder center 0.5 0.5
worldborder set 193
tellraw @a [{"text":"[BORDER] ","color":"dark_aqua"},{"text":"MineTrigger v0.9.5 clean rebuild online. v0.6 world lifecycle + PvP arena, native drones, repaired Trigger combat.","color":"aqua"}]
