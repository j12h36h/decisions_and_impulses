# MineTrigger v0.9.5 runtime — gameplay only. Arena geometry is worldgen-owned.
execute as @a[tag=!mt_pvp_initialized] run function minetrigger:update/player_init
execute as @a[tag=mt_pvp_initialized] run function minetrigger:update/player_tick
function minetrigger:update/forceblast_fix
function minetrigger:update/drones/tick
scoreboard players add #drone_maint mt_tmp 1
execute if score #drone_maint mt_tmp matches 100.. run function minetrigger:update/drones/maintain
execute if score #drone_maint mt_tmp matches 100.. run scoreboard players set #drone_maint mt_tmp 0
execute as @a[tag=mt_pvp_initialized] run function minetrigger:hud/sidebar
