# Assign one stable session-local numeric owner id used by visible projectile entities.
scoreboard players add #next_player_id mt_tmp 1
scoreboard players operation @s mt_player_id = #next_player_id mt_tmp
