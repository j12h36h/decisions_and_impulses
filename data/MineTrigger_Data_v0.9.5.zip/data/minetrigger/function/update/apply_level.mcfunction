# v0.9.5 traversal survivability: +2 safe-fall blocks and 50% fall damage.
attribute @s minecraft:safe_fall_distance base set 5.0
attribute @s minecraft:fall_damage_multiplier base set 0.5
# Dispatch the exact stat table.
execute if score @s mt_level matches 0 run function minetrigger:update/level/0
execute if score @s mt_level matches 1 run function minetrigger:update/level/1
execute if score @s mt_level matches 2 run function minetrigger:update/level/2
execute if score @s mt_level matches 3 run function minetrigger:update/level/3
execute if score @s mt_level matches 4 run function minetrigger:update/level/4
execute if score @s mt_level matches 5 run function minetrigger:update/level/5
execute if score @s mt_level matches 6 run function minetrigger:update/level/6
execute if score @s mt_level matches 7 run function minetrigger:update/level/7
execute if score @s mt_level matches 8 run function minetrigger:update/level/8
execute if score @s mt_level matches 9 run function minetrigger:update/level/9
scoreboard players operation @s mt_level_last = @s mt_level
