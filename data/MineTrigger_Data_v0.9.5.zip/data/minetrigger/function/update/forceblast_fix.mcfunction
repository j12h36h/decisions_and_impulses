
execute as @a at @s if items entity @s weapon.mainhand minetrigger:force_blaster as @e[type=!minecraft:player,distance=..14,nbt={HurtTime:10s}] run data modify entity @s Motion[1] set value 0.18d
execute as @a at @s if items entity @s weapon.offhand minetrigger:force_blaster as @e[type=!minecraft:player,distance=..14,nbt={HurtTime:10s}] run data modify entity @s Motion[1] set value 0.18d
execute as @a at @s if items entity @s weapon.mainhand minetrigger:force_blaster as @a[distance=0.1..14,nbt={HurtTime:10s}] run function minetrigger:update/forceblast_player_lift
execute as @a at @s if items entity @s weapon.offhand minetrigger:force_blaster as @a[distance=0.1..14,nbt={HurtTime:10s}] run function minetrigger:update/forceblast_player_lift
