
scoreboard players set @s mt_regen_clock 0
execute if score @s mt_recovery matches 1 run scoreboard players set @s mt_regen_window 8
execute if score @s mt_recovery matches 2 run scoreboard players set @s mt_regen_window 14
execute if score @s mt_recovery matches 3 run scoreboard players set @s mt_regen_window 20
execute if score @s mt_recovery matches 4 run scoreboard players set @s mt_regen_window 26
execute if score @s mt_recovery matches 5 run scoreboard players set @s mt_regen_window 32
execute if score @s mt_recovery matches 1.. run scoreboard players set @s mt_regen_owned 1
effect give @s minecraft:regeneration 2 3 true
