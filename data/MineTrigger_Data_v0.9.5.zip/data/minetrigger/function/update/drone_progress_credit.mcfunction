scoreboard players remove @s mt_drone_credit 5
scoreboard players add @s mt_progress 1
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.45 1.75
tellraw @s [{"text":"[BORDER] ","color":"dark_aqua"},{"text":"5 drone kills converted to +1 PvP-equivalent progression point.","color":"light_purple"}]
