# Ensure upgraded/existing players also receive a ranged-projectile owner id.
execute unless score @s mt_player_id matches 1.. run function minetrigger:update/assign_player_id


# Any Grasshopper carrier left by the old loadout is removed immediately.
clear @s minetrigger:grasshopper

# Track current HP for combat/HUD helpers.
execute store result score @s mt_health_read run data get entity @s Health 1
execute if score @s mt_drone_hit_timer matches 1.. run scoreboard players remove @s mt_drone_hit_timer 1

# Ground/air state for one Grasshopper double-jump per airtime.
execute if entity @s[nbt={OnGround:1b}] run scoreboard players set @s mt_air_ticks 0
execute if entity @s[nbt={OnGround:1b}] run scoreboard players set @s mt_double_used 0
execute unless entity @s[nbt={OnGround:1b}] run scoreboard players add @s mt_air_ticks 1

# Drone kill delta. Custom DAI training drones use a native killed statistic.
scoreboard players add @s mt_drone_kills 0
scoreboard players add @s mt_drone_prev 0
scoreboard players operation #drone_delta mt_tmp = @s mt_drone_kills
scoreboard players operation #drone_delta mt_tmp -= @s mt_drone_prev
execute if score #drone_delta mt_tmp matches 1.. run scoreboard players operation @s mt_training_kills += #drone_delta mt_tmp
execute if score #drone_delta mt_tmp matches 1.. run scoreboard players operation @s mt_drone_credit += #drone_delta mt_tmp
scoreboard players operation @s mt_drone_prev = @s mt_drone_kills

# Training conversion: exactly five drone kills = one PvP-equivalent progression point.
# Process one completed five-kill set per tick; large deltas naturally drain over subsequent ticks.
execute if score @s mt_drone_credit matches 5.. run function minetrigger:update/drone_progress_credit

# PvP kill delta -> progress.
scoreboard players operation #kill_delta mt_tmp = @s mt_pvp_kills
scoreboard players operation #kill_delta mt_tmp -= @s mt_pvp_prev
execute if score #kill_delta mt_tmp matches 1.. run scoreboard players operation @s mt_progress += #kill_delta mt_tmp
scoreboard players operation @s mt_pvp_prev = @s mt_pvp_kills

# Formula: current level * 3 + 1.
scoreboard players operation @s mt_required = @s mt_level
scoreboard players set #three mt_tmp 3
scoreboard players operation @s mt_required *= #three mt_tmp
scoreboard players add @s mt_required 1

# Promote one tier whenever the current tier requirement is met.
execute if score @s mt_level matches ..8 if score @s mt_progress >= @s mt_required run function minetrigger:update/level_up
execute if score @s mt_level matches 9 run scoreboard players set @s mt_progress 0

# Death demotion (never below level 0).
scoreboard players operation #death_delta mt_tmp = @s mt_deaths
scoreboard players operation #death_delta mt_tmp -= @s mt_deaths_prev
execute if score #death_delta mt_tmp matches 1.. unless score @s mt_drone_hit_timer matches 1.. run function minetrigger:update/death_drop
scoreboard players operation @s mt_deaths_prev = @s mt_deaths

# Re-apply attributes only when the level actually changed.
execute unless score @s mt_level = @s mt_level_last run function minetrigger:update/apply_level

# Recovery pulse every four seconds. Only clear an effect while MineTrigger owns that pulse.
scoreboard players add @s mt_regen_clock 1
execute if score @s mt_regen_clock matches 80.. run function minetrigger:update/recovery_start
execute if score @s mt_regen_owned matches 1 if score @s mt_regen_window matches 1.. run scoreboard players remove @s mt_regen_window 1
execute if score @s mt_regen_owned matches 1 if score @s mt_regen_window matches 0 run effect clear @s minecraft:regeneration
execute if score @s mt_regen_owned matches 1 if score @s mt_regen_window matches 0 run scoreboard players set @s mt_regen_owned 0

# Grasshopper and Force Blast have independent short lift timers; do not clear unrelated levitation.
execute if score @s mt_jump_lift matches 1.. run scoreboard players remove @s mt_jump_lift 1
execute if score @s mt_force_lift matches 1.. run scoreboard players remove @s mt_force_lift 1
execute if score @s mt_levitation_owned matches 1 if score @s mt_jump_lift matches 0 if score @s mt_force_lift matches 0 run effect clear @s minecraft:levitation
execute if score @s mt_levitation_owned matches 1 if score @s mt_jump_lift matches 0 if score @s mt_force_lift matches 0 run scoreboard players set @s mt_levitation_owned 0
