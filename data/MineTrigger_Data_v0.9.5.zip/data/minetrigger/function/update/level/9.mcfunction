
attribute @s minecraft:max_health base set 60
attribute @s minecraft:movement_speed base set 0.180
attribute @s minecraft:attack_damage base set 6
attribute @s minecraft:jump_strength base set 1.778112
scoreboard players set @s mt_recovery 5
