
attribute @s minecraft:max_health base set 20
attribute @s minecraft:movement_speed base set 0.080
attribute @s minecraft:attack_damage base set 3
attribute @s minecraft:jump_strength base set 0.790272
scoreboard players set @s mt_recovery 1
