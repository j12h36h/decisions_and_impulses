
attribute @s minecraft:max_health base set 50
attribute @s minecraft:movement_speed base set 0.140
attribute @s minecraft:attack_damage base set 5
attribute @s minecraft:jump_strength base set 1.382976
scoreboard players set @s mt_recovery 4
