
attribute @s minecraft:max_health base set 40
attribute @s minecraft:movement_speed base set 0.120
attribute @s minecraft:attack_damage base set 4
attribute @s minecraft:jump_strength base set 1.185408
scoreboard players set @s mt_recovery 3
