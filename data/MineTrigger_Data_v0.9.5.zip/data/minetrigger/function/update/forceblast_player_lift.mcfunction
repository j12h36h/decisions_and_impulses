effect give @s minecraft:levitation 1 1 true
scoreboard players set @s mt_force_lift 2
scoreboard players set @s mt_levitation_owned 1
