attribute @s minecraft:max_health base set 1000
data merge entity @s {Health:1000.0f}
tag @s add wt_dummy_043
