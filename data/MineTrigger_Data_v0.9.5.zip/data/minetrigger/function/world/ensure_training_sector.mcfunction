# MineTrigger v0.9.5 arena lifecycle bootstrap.
scoreboard objectives add wt_world dummy
execute unless score #arena wt_world matches 2 run function minetrigger:world/build_arena_v090

# One-time low positioning-platform expansion; safe for fresh and upgraded worlds.
execute unless score #platforms_v094 wt_world matches 1 run function minetrigger:world/add_positioning_platforms_v094

# Safety support under the raised deployment spawn.
fill -2 -58 66 2 -58 70 minecraft:barrier replace air
