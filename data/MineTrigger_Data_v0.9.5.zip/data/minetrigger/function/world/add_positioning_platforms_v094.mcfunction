# MineTrigger v0.9.5 low floating positioning platforms.
# 7x5 surfaces, staggered 2/3 blocks above the main combat floor and deliberately separated.
fill -42 -59 -24 -36 -59 -20 minecraft:polished_deepslate
fill -24 -58 -43 -18 -58 -39 minecraft:smooth_stone
fill 4 -59 -42 10 -59 -38 minecraft:polished_deepslate
fill 30 -58 -30 36 -58 -26 minecraft:smooth_stone
fill 42 -59 -8 48 -59 -4 minecraft:polished_deepslate
fill 30 -58 22 36 -58 26 minecraft:smooth_stone
fill 5 -59 38 11 -59 42 minecraft:polished_deepslate
fill -23 -58 34 -17 -58 38 minecraft:smooth_stone
fill -45 -59 12 -39 -59 16 minecraft:polished_deepslate
fill -18 -58 4 -12 -58 8 minecraft:smooth_stone
fill 12 -59 10 18 -59 14 minecraft:polished_deepslate
fill -6 -58 -18 0 -58 -14 minecraft:smooth_stone
scoreboard players set #platforms_v094 wt_world 1
