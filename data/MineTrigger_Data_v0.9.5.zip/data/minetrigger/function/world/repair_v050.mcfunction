# Preserve the proven v0.4.3 arena and add transparent fall-protection rails at its outer rim.
fill -31 -59 -31 31 -58 -31 minecraft:cyan_stained_glass replace minecraft:air
fill -31 -59 31 31 -58 31 minecraft:cyan_stained_glass replace minecraft:air
fill -31 -59 -30 -31 -58 30 minecraft:cyan_stained_glass replace minecraft:air
fill 31 -59 -30 31 -58 30 minecraft:cyan_stained_glass replace minecraft:air
execute as @e[tag=wt_training_dummy] run function minetrigger:world/upgrade_training_dummy
scoreboard players set #modern_v050 wt_world 1
