# MineTrigger v0.9.5 — clean Border PvP arena constructor.
# Runs from DAI worldgen before normal player gameplay; never from the live tick loop.
forceload add -96 -96 96 96
worldborder center 0.5 0.5
worldborder set 193

# Main combat floor (181x181 = 32761 blocks, intentionally below /fill limit).
fill -90 -61 -90 90 -61 90 minecraft:deepslate_tiles

# Industrial perimeter shell.
fill -90 -60 -90 90 -35 -87 minecraft:tuff_bricks
fill -90 -60 87 90 -35 90 minecraft:tuff_bricks
fill -90 -60 -86 -87 -35 86 minecraft:tuff_bricks
fill 87 -60 -86 90 -35 86 minecraft:tuff_bricks
fill -89 -59 -89 89 -57 -88 minecraft:polished_blackstone_bricks
fill -89 -59 88 89 -57 89 minecraft:polished_blackstone_bricks
fill -89 -59 -89 -88 -57 89 minecraft:polished_blackstone_bricks
fill 88 -59 -89 89 -57 89 minecraft:polished_blackstone_bricks

# Central PvP ring and cross routes.
fill -34 -60 -34 34 -60 34 minecraft:polished_deepslate
fill -28 -59 -38 28 -59 38 minecraft:cut_copper
fill -38 -59 -28 38 -59 28 minecraft:cut_copper
fill -26 -58 -26 26 -58 26 minecraft:smooth_stone
fill -22 -57 -22 22 -57 22 minecraft:polished_deepslate
fill -14 -56 -14 14 -56 14 minecraft:smooth_stone
fill -6 -55 -6 6 -55 6 minecraft:oxidized_cut_copper
fill -2 -54 -2 2 -54 2 minecraft:sea_lantern

# Ground-level high-contrast routes.
fill -82 -60 -3 82 -60 3 minecraft:yellow_concrete
fill -3 -60 -82 3 -60 82 minecraft:yellow_concrete
fill -78 -59 -2 78 -59 2 minecraft:black_concrete
fill -2 -59 -78 2 -59 78 minecraft:black_concrete

# Four cover compounds.
fill -72 -60 -28 -48 -54 -8 minecraft:polished_blackstone_bricks hollow
fill 48 -60 -28 72 -54 -8 minecraft:polished_blackstone_bricks hollow
fill -72 -60 8 -48 -54 28 minecraft:polished_blackstone_bricks hollow
fill 48 -60 8 72 -54 28 minecraft:polished_blackstone_bricks hollow
fill -68 -59 -24 -52 -55 -12 minecraft:air
fill 52 -59 -24 68 -55 -12 minecraft:air
fill -68 -59 12 -52 -55 24 minecraft:air
fill 52 -59 12 68 -55 24 minecraft:air

# Elevated cross-catwalks with safety rails.
fill -82 -48 -1 82 -48 1 minecraft:iron_block
fill -1 -48 -82 1 -48 82 minecraft:iron_block
fill -82 -47 -2 82 -47 -2 minecraft:iron_bars
fill -82 -47 2 82 -47 2 minecraft:iron_bars
fill -2 -47 -82 -2 -47 82 minecraft:iron_bars
fill 2 -47 -82 2 -47 82 minecraft:iron_bars
setblock -75 -47 0 minecraft:sea_lantern
setblock -45 -47 0 minecraft:sea_lantern
setblock -15 -47 0 minecraft:sea_lantern
setblock 15 -47 0 minecraft:sea_lantern
setblock 45 -47 0 minecraft:sea_lantern
setblock 75 -47 0 minecraft:sea_lantern
setblock 0 -47 -75 minecraft:sea_lantern
setblock 0 -47 -45 minecraft:sea_lantern
setblock 0 -47 -15 minecraft:sea_lantern
setblock 0 -47 15 minecraft:sea_lantern
setblock 0 -47 45 minecraft:sea_lantern
setblock 0 -47 75 minecraft:sea_lantern

# Drone bays — intentionally clear of catwalk hit volumes.
fill -8 -60 -86 8 -50 -72 minecraft:polished_blackstone_bricks hollow
fill -6 -58 -84 6 -52 -74 minecraft:air
fill 72 -60 -8 86 -50 8 minecraft:polished_blackstone_bricks hollow
fill 74 -58 -6 84 -52 6 minecraft:air
fill -8 -60 72 8 -50 86 minecraft:polished_blackstone_bricks hollow
fill -6 -58 74 6 -52 84 minecraft:air
fill -86 -60 -8 -72 -50 8 minecraft:polished_blackstone_bricks hollow
fill -84 -58 -6 -74 -52 6 minecraft:air
setblock 0 -58 -79 minecraft:sea_lantern
setblock 79 -58 0 minecraft:sea_lantern
setblock 0 -58 79 minecraft:sea_lantern
setblock -79 -58 0 minecraft:sea_lantern

# Machinery / vertical landmarks.
fill -43 -60 -43 -37 -45 -37 minecraft:polished_blackstone hollow
fill 37 -60 -43 43 -45 -37 minecraft:polished_blackstone hollow
fill -43 -60 37 -37 -45 43 minecraft:polished_blackstone hollow
fill 37 -60 37 43 -45 43 minecraft:polished_blackstone hollow
setblock -40 -44 -40 minecraft:sea_lantern
setblock 40 -44 -40 minecraft:sea_lantern
setblock -40 -44 40 minecraft:sea_lantern
setblock 40 -44 40 minecraft:sea_lantern

# South Border deployment room, raised above the arena floor.
fill -12 -58 56 12 -50 80 minecraft:white_concrete hollow
fill -10 -57 58 10 -51 78 minecraft:air
fill -10 -54 56 10 -52 56 minecraft:cyan_stained_glass
fill -3 -57 56 3 -53 56 minecraft:air
fill -10 -58 58 10 -58 78 minecraft:smooth_stone
fill -3 -58 65 3 -58 71 minecraft:polished_blackstone
fill -1 -58 67 1 -58 69 minecraft:sea_lantern
fill -4 -58 48 4 -58 56 minecraft:smooth_stone
fill -4 -57 48 4 -53 56 minecraft:air
fill -4 -59 44 4 -59 47 minecraft:smooth_stone
fill -4 -58 44 4 -54 47 minecraft:air

# North scoreboard backdrop / Border color split.
fill -22 -55 -86 22 -37 -84 minecraft:black_concrete
fill -20 -53 -83 20 -39 -83 minecraft:cyan_concrete
fill -16 -49 -82 -2 -43 -82 minecraft:red_concrete
fill 2 -49 -82 16 -43 -82 minecraft:light_blue_concrete
fill -1 -50 -82 1 -42 -82 minecraft:iron_block
setblock 0 -46 -81 minecraft:sea_lantern

setworldspawn 0 -57 68
scoreboard players set #arena wt_world 2
forceload remove -96 -96 96 96
