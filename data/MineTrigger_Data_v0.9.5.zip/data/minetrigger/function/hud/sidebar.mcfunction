# Vanilla sidebar stat board. No persistent actionbar text is used.
scoreboard players operation Level mt_hud = @s mt_level
scoreboard players operation PvPKills mt_hud = @s mt_pvp_kills
scoreboard players operation PvPProgress mt_hud = @s mt_progress
scoreboard players operation NextLevel mt_hud = @s mt_required
scoreboard players operation Trion mt_hud = @s wt_trion
scoreboard players operation TrionMax mt_hud = @s wt_trion_max
scoreboard players operation DroneKills mt_hud = @s mt_training_kills
scoreboard players operation DroneCredit mt_hud = @s mt_drone_credit
scoreboard players operation Loadout mt_hud = @s wt_loadout
scoreboard players operation Trigger mt_hud = @s wt_active
