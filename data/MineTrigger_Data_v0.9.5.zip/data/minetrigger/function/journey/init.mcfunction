function minetrigger:player/init
spawnpoint @s 0 -57 68
teleport @s 0.5 -57 68.5 180 0
effect give @s minecraft:resistance 10 4 true
effect give @s minecraft:slow_falling 10 0 true
gamemode adventure @s
clear @s
function minetrigger:trigger/give_on_control
kill @e[tag=wt_training_dummy]
summon minetrigger:training_trion_soldier 24 -60 0 {Tags:['wt_training_dummy','wt_dummy_043'],CustomName:{text:'Training Trion Soldier',color:'aqua'},CustomNameVisible:0b,PersistenceRequired:1b,NoAI:1b,Silent:1b,Health:1000.0f}
summon minetrigger:training_trion_soldier -24 -60 0 {Tags:['wt_training_dummy','wt_dummy_043'],CustomName:{text:'Training Trion Soldier',color:'aqua'},CustomNameVisible:0b,PersistenceRequired:1b,NoAI:1b,Silent:1b,Health:1000.0f}
summon minetrigger:training_trion_soldier 0 -60 24 {Tags:['wt_training_dummy','wt_dummy_043'],CustomName:{text:'Training Trion Soldier',color:'aqua'},CustomNameVisible:0b,PersistenceRequired:1b,NoAI:1b,Silent:1b,Health:1000.0f}
summon minetrigger:training_trion_soldier 0 -60 -24 {Tags:['wt_training_dummy','wt_dummy_043'],CustomName:{text:'Training Trion Soldier',color:'aqua'},CustomNameVisible:0b,PersistenceRequired:1b,NoAI:1b,Silent:1b,Health:1000.0f}
title @s times 10 80 20
title @s title {"text":"MINE TRIGGER","color":"aqua","bold":true}
title @s subtitle {"text":"BORDER TRAINING SYSTEM // Agent link established","color":"white"}
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Press ` to open the MineTrigger command interface.","color":"white"}]
