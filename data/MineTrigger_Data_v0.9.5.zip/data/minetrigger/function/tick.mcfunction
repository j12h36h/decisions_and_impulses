# MineTrigger v0.6.0 / DAI 3.3 hot path.
# Player initialization is owned by DAI MAIN-experience join hooks and load.mcfunction.
scoreboard players add #clock wt_clock 1
execute if score #clock wt_clock matches 20.. run function minetrigger:second

# One global projectile selector per tick; type routing happens locally.
execute as @e[type=minecraft:item_display,tag=mt_projectile] at @s run function minetrigger:projectile/tick

# Physical-position recovery remains immediate for agents below the authored training floor.
execute as @a[tag=wt_agent,y=-128,dy=62] run function minetrigger:journey/resume
