
scoreboard players set @s wt_trion_max 1000
scoreboard players set @s wt_trion 1000
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Trion capacity upgraded to 1000 / 1000 for MineTrigger v0.4.3.","color":"white"}]
