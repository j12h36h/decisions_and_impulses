execute unless score @s wt_active matches 1.. run tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Hound unavailable: Trigger body is offline.","color":"gray"}]
execute unless score @s wt_active matches 1.. run return 0
tag @s remove wt_ray_shooter
execute if score @s wt_active matches 1.. unless score @s wt_trion matches 6.. run tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Insufficient Trion for Hound.","color":"red"}]
execute if score @s wt_active matches 1.. if score @s wt_trion matches 6.. run tag @s add wt_ray_shooter
execute if entity @s[tag=wt_ray_shooter] run scoreboard players remove @s wt_trion 6
execute if entity @s[tag=wt_ray_shooter] anchored eyes positioned ^ ^ ^0.5 run summon minecraft:item_display ~ ~ ~ {Tags:["mt_projectile","mt_hound","mt_new"],billboard:"fixed",view_range:1.5f,shadow_radius:0.0f,item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.17f,0.17f,0.17f],right_rotation:[0.0f,0.0f,0.0f,1.0f]},item:{id:"minetrigger:trion_bolt",count:1}}
execute if entity @s[tag=wt_ray_shooter] run data modify entity @e[type=minecraft:item_display,tag=mt_new,tag=mt_hound,limit=1,sort=nearest,distance=..4] Rotation set from entity @s Rotation
execute if entity @s[tag=wt_ray_shooter] run scoreboard players set @e[type=minecraft:item_display,tag=mt_new,tag=mt_hound,limit=1,sort=nearest,distance=..4] wt_proj_age 0
execute if entity @s[tag=wt_ray_shooter] run scoreboard players set @e[type=minecraft:item_display,tag=mt_new,tag=mt_hound,limit=1,sort=nearest,distance=..4] wt_proj_dist 0
execute if entity @s[tag=wt_ray_shooter] run scoreboard players operation @e[type=minecraft:item_display,tag=mt_new,tag=mt_hound,limit=1,sort=nearest,distance=..4] mt_proj_owner = @s mt_player_id
execute if entity @s[tag=wt_ray_shooter] run tag @e[type=minecraft:item_display,tag=mt_new,tag=mt_hound,limit=1,sort=nearest,distance=..4] remove mt_new
execute if entity @s[tag=wt_ray_shooter] run playsound minecraft:entity.firework_rocket.blast player @s ~ ~ ~ 0.55 1.55
execute if entity @s[tag=wt_ray_shooter] if score @s wt_trion matches ..0 run function minetrigger:trigger/trion_break
tag @s remove wt_ray_shooter
