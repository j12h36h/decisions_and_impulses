scoreboard players set #incoming mt_tmp 11
function minetrigger:combat/damage/apply
