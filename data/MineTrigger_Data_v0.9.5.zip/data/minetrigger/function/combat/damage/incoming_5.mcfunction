scoreboard players set #incoming mt_tmp 5
function minetrigger:combat/damage/apply
