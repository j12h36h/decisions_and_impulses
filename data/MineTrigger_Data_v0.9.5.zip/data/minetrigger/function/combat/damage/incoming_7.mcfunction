scoreboard players set #incoming mt_tmp 7
function minetrigger:combat/damage/apply
