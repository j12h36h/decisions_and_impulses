# Called AS the damaged player. #overflow is the health damage after Trion absorption.
#incoming_owner mt_tmp is 0 for environment/drone damage or a positive ranged-player owner id.
tag @s add mt_damage_target
execute if score #overflow mt_tmp matches 1 unless score #incoming_owner mt_tmp matches 1.. run damage @s 1 minecraft:magic
execute if score #overflow mt_tmp matches 1 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 1 minecraft:magic by @s
execute if score #overflow mt_tmp matches 2 unless score #incoming_owner mt_tmp matches 1.. run damage @s 2 minecraft:magic
execute if score #overflow mt_tmp matches 2 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 2 minecraft:magic by @s
execute if score #overflow mt_tmp matches 3 unless score #incoming_owner mt_tmp matches 1.. run damage @s 3 minecraft:magic
execute if score #overflow mt_tmp matches 3 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 3 minecraft:magic by @s
execute if score #overflow mt_tmp matches 4 unless score #incoming_owner mt_tmp matches 1.. run damage @s 4 minecraft:magic
execute if score #overflow mt_tmp matches 4 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 4 minecraft:magic by @s
execute if score #overflow mt_tmp matches 5 unless score #incoming_owner mt_tmp matches 1.. run damage @s 5 minecraft:magic
execute if score #overflow mt_tmp matches 5 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 5 minecraft:magic by @s
execute if score #overflow mt_tmp matches 6 unless score #incoming_owner mt_tmp matches 1.. run damage @s 6 minecraft:magic
execute if score #overflow mt_tmp matches 6 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 6 minecraft:magic by @s
execute if score #overflow mt_tmp matches 7 unless score #incoming_owner mt_tmp matches 1.. run damage @s 7 minecraft:magic
execute if score #overflow mt_tmp matches 7 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 7 minecraft:magic by @s
execute if score #overflow mt_tmp matches 8 unless score #incoming_owner mt_tmp matches 1.. run damage @s 8 minecraft:magic
execute if score #overflow mt_tmp matches 8 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 8 minecraft:magic by @s
execute if score #overflow mt_tmp matches 9 unless score #incoming_owner mt_tmp matches 1.. run damage @s 9 minecraft:magic
execute if score #overflow mt_tmp matches 9 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 9 minecraft:magic by @s
execute if score #overflow mt_tmp matches 10 unless score #incoming_owner mt_tmp matches 1.. run damage @s 10 minecraft:magic
execute if score #overflow mt_tmp matches 10 if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 10 minecraft:magic by @s
execute if score #overflow mt_tmp matches 11.. unless score #incoming_owner mt_tmp matches 1.. run damage @s 11 minecraft:magic
execute if score #overflow mt_tmp matches 11.. if score #incoming_owner mt_tmp matches 1.. as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @a[tag=mt_damage_target,limit=1] 11 minecraft:magic by @s
tag @s remove mt_damage_target
