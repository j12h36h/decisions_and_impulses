scoreboard players set #incoming mt_tmp 1
function minetrigger:combat/damage/apply
