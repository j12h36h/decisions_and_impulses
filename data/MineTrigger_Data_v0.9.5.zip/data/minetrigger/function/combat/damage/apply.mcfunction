# Called AS the player. #incoming mt_tmp must contain positive damage.
tag @s remove mt_trion_absorb
execute if score @s wt_active matches 1.. if score @s wt_trion matches 1.. run tag @s add mt_trion_absorb
scoreboard players operation #overflow mt_tmp = #incoming mt_tmp
execute if entity @s[tag=mt_trion_absorb] run scoreboard players operation #overflow mt_tmp -= @s wt_trion

# Enough Trion: absorb the entire shot and keep health untouched.
execute if entity @s[tag=mt_trion_absorb] if score #overflow mt_tmp matches ..0 run scoreboard players operation @s wt_trion -= #incoming mt_tmp
execute if entity @s[tag=mt_trion_absorb] if score #overflow mt_tmp matches ..0 run particle minecraft:electric_spark ~ ~1 ~ 0.18 0.32 0.18 0.06 10 force @s
execute if entity @s[tag=mt_trion_absorb] if score #overflow mt_tmp matches ..0 if score @s wt_trion matches ..0 run function minetrigger:trigger/trion_break

# Trion was present but insufficient: consume it, break Trigger, then health takes only the overflow.
execute if entity @s[tag=mt_trion_absorb] if score #overflow mt_tmp matches 1.. run scoreboard players set @s wt_trion 0
execute if entity @s[tag=mt_trion_absorb] if score #overflow mt_tmp matches 1.. run function minetrigger:trigger/trion_break
execute if entity @s[tag=mt_trion_absorb] if score #overflow mt_tmp matches 1.. run function minetrigger:combat/damage/health_overflow

# Trigger off / no Trion body: the full projectile damage reaches physical health.
execute unless entity @s[tag=mt_trion_absorb] run scoreboard players operation #overflow mt_tmp = #incoming mt_tmp
execute unless entity @s[tag=mt_trion_absorb] run function minetrigger:combat/damage/health_overflow
tag @s remove mt_trion_absorb
