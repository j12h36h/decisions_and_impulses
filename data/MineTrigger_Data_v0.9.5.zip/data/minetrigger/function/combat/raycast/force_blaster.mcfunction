
particle minecraft:electric_spark ~ ~ ~ 0.08 0.08 0.08 0.02 5 force @a[distance=..48]
execute if entity @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,tag=!mt_projectile,distance=..1.8,limit=1,sort=nearest] as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,tag=!mt_projectile,distance=..1.8,limit=1,sort=nearest] run damage @s 1 minecraft:magic by @a[tag=wt_force_shooter,limit=1,sort=nearest]
execute as @e[tag=mt_drone,distance=..1.8,limit=1,sort=nearest] run scoreboard players set @s mt_drone_hit_anim 20
execute if entity @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,tag=!mt_projectile,distance=..1.8,limit=1,sort=nearest] run scoreboard players set @a[tag=wt_force_shooter,limit=1,sort=nearest] wt_ray_step 999
execute if entity @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,tag=!mt_projectile,distance=..1.8,limit=1,sort=nearest] as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,tag=!mt_projectile,distance=..1.8,limit=1,sort=nearest] at @s facing entity @a[tag=wt_force_shooter,limit=1,sort=nearest] eyes run tp @s ^ ^0.15 ^-2.5
particle minecraft:cloud ~ ~ ~ 0.05 0.05 0.05 0.01 2 force @a[distance=..48]
execute unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run scoreboard players set @a[tag=wt_force_shooter,limit=1,sort=nearest] wt_ray_step 999
execute if score @a[tag=wt_force_shooter,limit=1,sort=nearest] wt_ray_step matches ..5 run scoreboard players add @a[tag=wt_force_shooter,limit=1,sort=nearest] wt_ray_step 1
execute if score @a[tag=wt_force_shooter,limit=1,sort=nearest] wt_ray_step matches ..6 positioned ^ ^ ^1 run function minetrigger:combat/raycast/force_blaster
