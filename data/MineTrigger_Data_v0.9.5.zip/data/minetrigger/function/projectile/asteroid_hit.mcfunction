# Preserve the projectile's firing player before changing executor to the hit target.
scoreboard players operation #incoming_owner mt_tmp = @s mt_proj_owner
tag @e[tag=mt_hit_target] remove mt_hit_target

# PvP target: Trion absorption/overflow keeps the projectile owner in #incoming_owner.
execute positioned ~ ~-1 ~ if entity @a[distance=..0.95,limit=1] as @a[distance=..0.95,limit=1,sort=nearest] run function minetrigger:combat/damage/incoming_7

# Non-player target: mark once, then let the matching owner issue the attributed damage command.
execute positioned ~ ~-1 ~ unless entity @a[distance=..0.95,limit=1] run tag @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,tag=!mt_projectile,distance=..0.95,limit=1,sort=nearest] add mt_hit_target
execute if entity @e[tag=mt_hit_target] as @a if score @s mt_player_id = #incoming_owner mt_tmp run damage @e[tag=mt_hit_target,limit=1] 7 minecraft:magic by @s
execute as @e[tag=mt_hit_target,tag=mt_drone] run scoreboard players set @s mt_drone_hit_anim 20
tag @e[tag=mt_hit_target] remove mt_hit_target

particle minecraft:electric_spark ~ ~ ~ 0.14 0.14 0.14 0.05 12 force @a[distance=..64]
playsound minecraft:block.amethyst_block.hit player @a[distance=..32] ~ ~ ~ 0.5 1.8
scoreboard players set #incoming_owner mt_tmp 0
tag @s add mt_proj_dead
