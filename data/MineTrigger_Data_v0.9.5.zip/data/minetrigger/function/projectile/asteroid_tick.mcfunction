scoreboard players add @s wt_proj_age 1
particle minecraft:electric_spark ~ ~ ~ 0.04 0.04 0.04 0.01 2 force @a[distance=..64]
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/asteroid_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/asteroid_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/asteroid_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/asteroid_step
execute if entity @s[tag=mt_proj_dead] run kill @s
