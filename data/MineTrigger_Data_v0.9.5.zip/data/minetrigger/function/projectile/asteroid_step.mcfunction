execute positioned ^ ^ ^0.25 unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run tag @s add mt_proj_dead
execute unless entity @s[tag=mt_proj_dead] run tp @s ^ ^ ^0.25
execute unless entity @s[tag=mt_proj_dead] run scoreboard players add @s wt_proj_dist 1
execute unless entity @s[tag=mt_proj_dead] if score @s wt_proj_dist matches 4.. at @s positioned ~ ~-1 ~ if entity @a[distance=..0.95,limit=1] at @s run function minetrigger:projectile/asteroid_hit
execute unless entity @s[tag=mt_proj_dead] at @s positioned ~ ~-1 ~ if entity @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,tag=!mt_projectile,distance=..0.95,limit=1] at @s run function minetrigger:projectile/asteroid_hit
execute if score @s wt_proj_dist matches 400.. run tag @s add mt_proj_dead
