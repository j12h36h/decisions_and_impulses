scoreboard players add @s wt_proj_age 1
particle minecraft:electric_spark ~ ~ ~ 0.025 0.025 0.025 0.008 2 force @a[distance=..96]
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/egret_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/egret_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/egret_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/egret_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/egret_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/egret_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/egret_step
execute unless entity @s[tag=mt_proj_dead] at @s run function minetrigger:projectile/egret_step
execute if entity @s[tag=mt_proj_dead] run kill @s
