# v0.6.0: local dispatch after a single global mt_projectile scan.
execute if entity @s[tag=mt_asteroid] run function minetrigger:projectile/asteroid_tick
execute if entity @s[tag=mt_hound] run function minetrigger:projectile/hound_tick
execute if entity @s[tag=mt_egret] run function minetrigger:projectile/egret_tick
