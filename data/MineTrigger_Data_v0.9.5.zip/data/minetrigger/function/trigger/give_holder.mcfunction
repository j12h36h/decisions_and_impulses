
# Legacy compatibility alias: v0.4.3 replaces the holder hotbar lifecycle with a dedicated Trigger On control in slot 7.
function minetrigger:trigger/give_on_control
