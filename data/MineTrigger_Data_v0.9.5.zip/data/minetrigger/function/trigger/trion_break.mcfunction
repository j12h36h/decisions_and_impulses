scoreboard players set @s wt_trion 0
scoreboard players set @s wt_active 0
scoreboard players set @s wt_bagworm 0
scoreboard players set @s wt_chameleon 0
advancement revoke @s only minetrigger:state/trigger_on
advancement revoke @s only minetrigger:state/bagworm_on
advancement revoke @s only minetrigger:state/chameleon_on
effect clear @s minecraft:resistance
effect clear @s minecraft:speed
effect clear @s minecraft:jump_boost
effect clear @s minecraft:invisibility
function minetrigger:trigger/clear_items
function minetrigger:trigger/give_on_control
title @s subtitle {"text":"TRION DEPLETED // PHYSICAL BODY EXPOSED","color":"red"}
playsound minecraft:block.beacon.deactivate player @s ~ ~ ~ 0.8 0.7
