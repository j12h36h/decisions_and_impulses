
scoreboard players set @s wt_active 0
scoreboard players set @s wt_bagworm 0
scoreboard players set @s wt_chameleon 0
advancement revoke @s only minetrigger:state/trigger_on
advancement revoke @s only minetrigger:state/bagworm_on
advancement revoke @s only minetrigger:state/chameleon_on
effect clear @s minecraft:resistance
effect clear @s minecraft:speed
effect clear @s minecraft:jump_boost
effect clear @s minecraft:invisibility
function minetrigger:trigger/clear_items
function minetrigger:trigger/give_on_control
title @s title {"text":"TRIGGER OFF","color":"gray","bold":true}
playsound minecraft:block.beacon.deactivate player @s ~ ~ ~ 0.7 0.85
