
clear @s minetrigger:trigger_on
clear @s minetrigger:trigger_off
clear @s minetrigger:bailout
clear @s minetrigger:trigger_holder
item replace entity @s hotbar.6 with minetrigger:trigger_on
item replace entity @s hotbar.7 with minecraft:air
item replace entity @s hotbar.8 with minecraft:air
