execute unless score @s wt_trion matches 1.. run tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Insufficient Trion to manifest a Trigger body. Recover Trion while Trigger is off.","color":"red"}]
execute unless score @s wt_trion matches 1.. run return 0

# Reactivation must restore the complete selected Trigger Set, not just the body flag.
scoreboard players set @s wt_active 1
scoreboard players set @s wt_bagworm 0
scoreboard players set @s wt_chameleon 0
execute unless score @s wt_loadout matches 1..4 run scoreboard players set @s wt_loadout 1
advancement grant @s only minetrigger:state/trigger_on
advancement revoke @s only minetrigger:state/bagworm_on
advancement revoke @s only minetrigger:state/chameleon_on
effect give @s minecraft:resistance infinite 0 true
effect give @s minecraft:speed infinite 0 true
effect give @s minecraft:jump_boost infinite 0 true
function minetrigger:loadout/equip_selected
title @s title {"text":"TRIGGER ON","color":"aqua","bold":true}
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 0.7 1.35
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Trigger body online; saved Trigger Set restored.","color":"white"}]
