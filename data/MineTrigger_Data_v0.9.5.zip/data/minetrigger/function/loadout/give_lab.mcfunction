
give @s minetrigger:scorpion
give @s minetrigger:force_blaster
give @s minetrigger:raygust
give @s minetrigger:kogetsu
give @s minetrigger:asteroid
give @s minetrigger:hound
give @s minetrigger:egret
give @s minetrigger:shield
give @s minetrigger:bagworm
give @s minetrigger:chameleon
tellraw @s [{"text":"[BORDER LAB] ","color":"light_purple","bold":true},{"text":"Prototype Trigger set issued to inventory.","color":"white"}]
