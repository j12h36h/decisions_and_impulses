function minetrigger:trigger/clear_items
item replace entity @s hotbar.0 with minetrigger:kogetsu
item replace entity @s hotbar.1 with minetrigger:force_blaster
item replace entity @s hotbar.2 with minetrigger:shield
item replace entity @s hotbar.4 with minetrigger:bagworm
item replace entity @s hotbar.6 with minetrigger:trigger_off
item replace entity @s hotbar.7 with minecraft:air
item replace entity @s hotbar.8 with minetrigger:bailout
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Attacker Trigger Set synchronized. Slot 7: TRIGGER OFF // Slot 8: EMPTY // Slot 9: BAIL OUT","color":"white"}]
