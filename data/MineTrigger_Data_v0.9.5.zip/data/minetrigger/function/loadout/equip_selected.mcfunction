# Only an active Trion body can materialize a Trigger Set.
execute unless score @s wt_active matches 1.. run function minetrigger:trigger/clear_items
execute unless score @s wt_active matches 1.. run function minetrigger:trigger/give_on_control
execute unless score @s wt_active matches 1.. run tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Loadout saved. Trigger On to materialize the selected set.","color":"gray"}]
execute unless score @s wt_active matches 1.. run return 0

execute if score @s wt_loadout matches 1 run function minetrigger:loadout/equip_attacker
execute if score @s wt_loadout matches 2 run function minetrigger:loadout/equip_shooter
execute if score @s wt_loadout matches 3 run function minetrigger:loadout/equip_sniper
execute if score @s wt_loadout matches 4 run function minetrigger:loadout/equip_all_rounder
