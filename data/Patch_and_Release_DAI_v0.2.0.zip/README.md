# Patch & Release v0.2.0

A full-length DAI psychological traversal experience. Wiggle Wobble, a mob removed by a live MMO patch, survives maintenance and crosses deprecated content, runtime infrastructure, integrity systems, and the shard boundary while the Patcher changes from cleanup process to reluctant ally.

## Design invariants
- No reachable authored interaction has an undefined consequence.
- Story state and sub-state are persistent per world.
- Death, void falls, explicit failures, and reloads restore an authored checkpoint.
- Dialogue prompts are one-shot state, not coordinate-only state.
- Progression gates are derived from persistent state every tick, never from a transient client queue.

Target first-playthrough length is approximately 2-4 hours depending on exploration and traversal skill.
