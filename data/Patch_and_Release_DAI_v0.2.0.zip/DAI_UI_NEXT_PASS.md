# DAI UI integration targets

The datapack already includes `overlay_text` sequences supported by the TNWIM UI foundation patch. The following mechanics are intentionally marked for runtime validation because they depend on the patched DAI client rather than vanilla commands:

- continuous cursor-near-overlay evaluation
- `overlay_repel_mouse` blue-button puzzle
- mutable element locking/position conditions
- raw physical X-key capture (current baseline tracks registered Minecraft key mappings; an unbound raw-key condition may still be required for the exact opening gag)
- Creator drag/resize serialization

Vanilla story progression remains usable if one of these visual experiments fails, allowing debugger data to be gathered in-world.
