
scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Two exits. Purple carries an unauthorized patch fragment. Gray carries only you.","color":"white"}]
execute if score @s pr_timer matches 80 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"I cannot tell you which choice is correct. There is no rule for that.","color":"gray"}]
execute if entity @s[x=3210,y=63,z=-20,dx=38,dy=10,dz=14] run function patch_release:story/choose_save
execute if entity @s[x=3210,y=63,z=6,dx=38,dy=10,dz=14] run function patch_release:story/choose_leave
