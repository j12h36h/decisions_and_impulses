title @s times 10 60 20
title @s title {"text":"Quick! Hit the X button,","color":"yellow","bold":true}
title @s subtitle {"text":"before everything breaks!","color":"white"}
scoreboard players set @s pr_timer 0
