scoreboard players add @s pr_fail 1
title @s title {"text":"DELETED","color":"red","bold":true}
title @s subtitle {"text":"…almost.","color":"gray"}
tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Interesting. You restored from active session memory.","color":"white"}]
function patch_release:checkpoint/restart
