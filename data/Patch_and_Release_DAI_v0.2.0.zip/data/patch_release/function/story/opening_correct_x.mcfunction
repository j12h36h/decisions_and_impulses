# The literal instruction was satisfied with the physical keyboard X.
title @s clear
scoreboard players set @s pr_timer 0
function patch_release:story/to_01
