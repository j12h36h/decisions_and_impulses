scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run title @s actionbar {"text":"NPC QUARANTINE","color":"gold","bold":true}
execute if score @s pr_timer matches 35 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Those are retired actors. They cannot hear you. I have checked.","color":"white"}]

execute if entity @s[x=1092,y=55,z=-30,dx=18,dy=40,dz=60] run function patch_release:story/to_13
