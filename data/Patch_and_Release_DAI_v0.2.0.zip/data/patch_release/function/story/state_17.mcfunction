scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run title @s actionbar {"text":"CHUNK STREAM","color":"gold","bold":true}
execute if score @s pr_timer matches 35 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Chunks are staged here before players see them. Try not to fall between realities.","color":"white"}]

execute if entity @s[x=1632,y=55,z=-30,dx=18,dy=40,dz=60] run function patch_release:story/to_18
