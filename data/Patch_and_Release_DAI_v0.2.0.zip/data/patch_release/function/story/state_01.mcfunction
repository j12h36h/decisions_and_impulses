scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 40 run tellraw @s [{"text":"[Player_LeafKnight]: ","color":"aqua"},{"text":"lfm snails lol","color":"white"}]
execute if score @s pr_timer matches 90 run tellraw @s [{"text":"[Player_xXHeroXx]: ","color":"light_purple"},{"text":"patch notes say Wiggle Wobble got removed","color":"white"}]
execute if score @s pr_timer matches 130 run tellraw @s [{"text":"[Player_LeafKnight]: ","color":"aqua"},{"text":"which one is that","color":"white"}]
execute if score @s pr_timer matches 180 run title @s actionbar {"text":"SERVER: Scheduled maintenance in 5 seconds.","color":"yellow"}
execute if score @s pr_timer matches 280.. run function patch_release:story/to_02

# The mob has no normal survival breaking ability, but trying anyway is noticed.
execute as @e[type=minecraft:interaction,tag=pr_tree_hit] if data entity @s attack at @s run execute as @a[tag=pr_active,sort=nearest,limit=1,distance=..8] if score @s pr_state matches 1 run function patch_release:story/tree_attempt
execute as @e[type=minecraft:interaction,tag=pr_tree_hit] if data entity @s attack run data remove entity @s attack
