# Opening checkpoint. This state intentionally does NOT advance on a timer.
# The physical keyboard X is detected client-side by the DAI raw-key condition.
scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 100 run tellraw @s [{"text":"Hint: ","color":"yellow"},{"text":"The instruction says HIT X. The on-screen button is only shaped like one.","color":"gray"}]
