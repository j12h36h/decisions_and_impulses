scoreboard players set @s pr_state 1
scoreboard players set @s pr_checkpoint 1
scoreboard players set @s pr_timer 0
function patch_release:checkpoint/rebuild_scene
title @s clear
tellraw @s [{"text":"Maple Meadow // Channel 3","color":"aqua","bold":true},{"text":"    Population: 43","color":"gray"}]
