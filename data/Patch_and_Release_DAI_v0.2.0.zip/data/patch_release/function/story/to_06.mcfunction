scoreboard players set @s pr_state 6
scoreboard players set @s pr_checkpoint 6
scoreboard players set @s pr_timer 0
function patch_release:checkpoint/rebuild_scene
scoreboard players set @s pr_flags 0
fill 258 63 -3 265 63 3 minecraft:white_concrete
tp @s 260.5 64 0.5 90 0
spawnpoint @s 260 64 0
tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Stop circumventing maintenance.","color":"white"}]
