scoreboard players add @s pr_fail 1
title @s title {"text":"OOF.","color":"red","bold":true}
title @s subtitle {"text":"That’s not what I meant…","color":"gray"}
tellraw @s [{"text":"FAILURE #001 — ","color":"red"},{"text":"Clicked X instead of hitting X.","color":"white"}]
tellraw @s [{"text":"The instruction was literal. Your assumption was not.","color":"dark_gray","italic":true}]
function patch_release:checkpoint/restart
