scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run title @s actionbar {"text":"ACT IV // HOTFIX","color":"gold","bold":true}
execute if score @s pr_timer matches 35 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"New rule: when I erase a red barrier, use the hole before integrity rebuilds it.","color":"white"}]

execute if entity @s[x=2382,y=55,z=-30,dx=18,dy=40,dz=60] run function patch_release:story/to_25
