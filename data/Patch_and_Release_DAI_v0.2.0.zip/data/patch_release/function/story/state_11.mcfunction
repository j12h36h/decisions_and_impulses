scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run title @s actionbar {"text":"ASSET GRAVEYARD","color":"gold","bold":true}
execute if score @s pr_timer matches 35 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"None of this is supposed to be loaded. Please stop looking impressed.","color":"white"}]

execute if entity @s[x=992,y=55,z=-30,dx=18,dy=40,dz=60] run function patch_release:story/to_12
