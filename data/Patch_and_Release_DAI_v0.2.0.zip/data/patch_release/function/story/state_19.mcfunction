scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run title @s actionbar {"text":"LOGIN QUEUE","color":"gold","bold":true}
execute if score @s pr_timer matches 35 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"The conveyor is a queue. Yes, players really wait in one of these. No, not literally. Mostly.","color":"white"}]

execute if entity @s[x=1832,y=55,z=-30,dx=18,dy=40,dz=60] run function patch_release:story/to_20
