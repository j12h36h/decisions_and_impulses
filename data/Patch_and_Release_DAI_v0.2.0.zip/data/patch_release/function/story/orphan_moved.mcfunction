tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"...You moved.","color":"white"}]
tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"That should not be possible after orphaning.","color":"gray"}]
function patch_release:story/to_04
