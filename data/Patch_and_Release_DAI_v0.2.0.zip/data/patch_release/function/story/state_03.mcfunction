execute if entity @s[y=-64,dy=123] run tp @s 100.5 64 0.5 90 0
scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 50 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Please remain where you are while I resolve the issue.","color":"white"}]
execute if score @s pr_timer matches 120 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Movement is unnecessary. You are obsolete.","color":"gray"}]

# The first deliberate step away from the orphan spawn proves the entity is not idle.
execute unless entity @s[x=99.75,y=63,z=-0.25,dx=1.5,dy=3,dz=1.5] run function patch_release:story/orphan_moved
