scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 40 run tellraw @s [{"text":"SYSTEM RULE: ","color":"yellow","bold":true},{"text":"Step on the blue tile.","color":"white"}]
execute if entity @s[x=275,y=64,z=-2,dx=4,dy=3,dz=4] run function patch_release:story/to_07
