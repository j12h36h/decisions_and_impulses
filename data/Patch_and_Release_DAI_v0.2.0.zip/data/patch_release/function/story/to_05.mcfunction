scoreboard players set @s pr_state 5
scoreboard players set @s pr_checkpoint 5
scoreboard players set @s pr_timer 0
function patch_release:checkpoint/rebuild_scene
fill 202 63 -3 209 63 3 minecraft:polished_deepslate
tp @s 205.5 64 0.5 90 0
spawnpoint @s 205 64 0
tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Good. This next process is automatic. Stand on the yellow square.","color":"white"}]

scoreboard players set @s pr_phase 0
scoreboard players set @s pr_cp_phase 0
scoreboard players set @s pr_once 0
