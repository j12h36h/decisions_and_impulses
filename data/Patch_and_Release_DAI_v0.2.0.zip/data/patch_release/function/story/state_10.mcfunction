scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run title @s actionbar {"text":"REMOVED TUTORIAL","color":"gold","bold":true}
execute if score @s pr_timer matches 35 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"The floor ahead was removed three builds ago. Conveniently, the tutorial platforms were not.","color":"white"}]
effect give @s minecraft:speed 2 0 true
effect give @s minecraft:jump_boost 2 0 true
execute if entity @s[x=887,y=55,z=-30,dx=18,dy=40,dz=60] run function patch_release:story/to_11
