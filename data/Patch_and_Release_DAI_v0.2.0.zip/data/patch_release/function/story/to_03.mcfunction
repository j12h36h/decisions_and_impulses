scoreboard players set @s pr_state 3
scoreboard players set @s pr_checkpoint 3
scoreboard players set @s pr_timer 0
function patch_release:checkpoint/rebuild_scene
effect clear @s minecraft:blindness
fill 97 63 -3 104 63 3 minecraft:gray_concrete
tp @s 100.5 64 0.5 -90 0
spawnpoint @s 100 64 0
tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Orphaned entity detected: Wiggle Wobble.","color":"white"}]
