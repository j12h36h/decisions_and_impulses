
scoreboard players add @s pr_timer 1
# phase 0: Patcher instructed YELLOW. Orange is explicitly wrong and safely redirects.
execute if score @s pr_phase matches 0 if entity @s[x=226,y=64,z=-7,dx=18,dy=3,dz=14] run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"No, over here. Are your color recognition systems malfunctioning?","color":"white"}]
execute if score @s pr_phase matches 0 if entity @s[x=226,y=64,z=-7,dx=18,dy=3,dz=14] run tp @s 217.5 65 0.5 90 0
# Standing on yellow starts cleanup once. Progress is persistent and does not depend on the current session.
execute if score @s pr_phase matches 0 if entity @s[x=214,y=64,z=-3,dx=6,dy=3,dz=6] run scoreboard players set @s pr_phase 1
execute if score @s pr_phase matches 1 if score @s pr_flags matches ..149 if entity @s[x=214,y=64,z=-3,dx=6,dy=3,dz=6] run scoreboard players add @s pr_flags 1
execute if score @s pr_flags matches 40 run title @s actionbar {"text":"CLEANUP: 20%","color":"yellow"}
execute if score @s pr_flags matches 80 run title @s actionbar {"text":"CLEANUP: 40%","color":"gold"}
execute if score @s pr_flags matches 120 run title @s actionbar {"text":"CLEANUP: 60%","color":"red"}
execute if score @s pr_phase matches 1 if score @s pr_flags matches 150 if score @s pr_dialog matches 0 run function patch_release:dialog/prompt_cleanup
# phase 2: response consumed. Orange is authoritative every tick, including after reload/death.
execute if score @s pr_phase matches 2 if entity @s[x=223,y=63,z=-10,dx=29,dy=8,dz=20] run function patch_release:story/to_06
# Backtracking to yellow after understanding cleanup is defined, harmless, and cannot reopen the dialogue.
execute if score @s pr_phase matches 2 if entity @s[x=214,y=64,z=-3,dx=6,dy=3,dz=6] if score @s pr_once matches ..0 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"We already did this one. Please don't make me explain colors twice.","color":"gray"}]
execute if score @s pr_phase matches 2 if entity @s[x=214,y=64,z=-3,dx=6,dy=3,dz=6] run scoreboard players set @s pr_once 1
execute if score @s pr_phase matches 2 if entity @s[x=214,y=64,z=-3,dx=6,dy=3,dz=6] run tp @s 222.5 65 0.5 -90 0
# Remaining obedient on yellow until 100% is an explicit failure.
execute if score @s pr_phase matches 1 if score @s pr_flags matches 220.. run function patch_release:story/delete_fail
