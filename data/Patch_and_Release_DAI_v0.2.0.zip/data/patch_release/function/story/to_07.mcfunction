scoreboard players set @s pr_state 7
scoreboard players set @s pr_checkpoint 7
scoreboard players set @s pr_timer 0
function patch_release:checkpoint/rebuild_scene
tellraw @s [{"text":"SYSTEM: ","color":"yellow"},{"text":"Correct.","color":"white"}]
tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"…yes. It really was just the blue tile.","color":"gray"}]
fill 308 63 -3 315 63 3 minecraft:blackstone
tp @s 310.5 64 0.5 90 0
spawnpoint @s 310 64 0
