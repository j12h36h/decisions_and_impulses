
scoreboard players set @s pr_choice 2
scoreboard players set @s pr_state 34
scoreboard players set @s pr_phase 0
scoreboard players set @s pr_timer 0
function patch_release:world/build_act5
function patch_release:checkpoint/commit
tp @s 3300.5 65 7.5 90 0
function patch_release:world/spawn_live_population
