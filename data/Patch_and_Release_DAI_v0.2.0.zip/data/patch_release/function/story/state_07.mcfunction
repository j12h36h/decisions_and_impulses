
scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 30 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"I compared your movement against every behavior script in Patch 8.22.26.","color":"white"}]
execute if score @s pr_timer matches 90 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"There is no matching behavior tree.","color":"white"}]
execute if score @s pr_timer matches 150 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"You're choosing these.","color":"white"}]
execute if score @s pr_timer matches 220 run tellraw @s [{"text":"PATCHER: ","color":"red"},{"text":"OH no. This is all wrong.","color":"white"}]
execute if score @s pr_timer matches 280 run tellraw @s [{"text":"PATCHER: ","color":"red"},{"text":"I don't think this is even a game anymore.","color":"white"}]
execute if score @s pr_timer matches 350 run tellraw @s [{"text":"PATCHER: ","color":"red","bold":true},{"text":" WHAT KIND OF SICK MONSTER WOULD DIGITALLY SIMULATE FREE WILL?!?!","color":"white","bold":true}]
execute if score @s pr_timer matches 440 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"I need to inspect where you came from. Do not get deleted while I do that.","color":"gray"}]
execute if score @s pr_timer matches 500.. run function patch_release:story/to_08
