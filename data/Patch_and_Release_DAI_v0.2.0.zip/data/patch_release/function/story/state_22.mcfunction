scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run title @s actionbar {"text":"RUNTIME CORE","color":"gold","bold":true}
execute if score @s pr_timer matches 35 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"I can see the process that owns me from here. I dislike that sentence.","color":"white"}]

execute if entity @s[x=2162,y=55,z=-30,dx=18,dy=40,dz=60] run function patch_release:story/to_23
