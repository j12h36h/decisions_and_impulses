# Blackout is intentionally silent for ~7 seconds before Wiggle Wobble can respond.
# pr_flags dialogue lifecycle:
# 0 = waiting for first prompt
# 1 = Hello prompt open
# 2 = Hello chosen; 2-second pause
# 3 = Maintenance prompt open
# 4 = Maintenance chosen; 2-second pause
# 5 = Login prompt open
# 6 = final line chosen / transition out
execute if score @s pr_flags matches 0 run scoreboard players add @s pr_timer 1
execute if score @s pr_flags matches 0 if score @s pr_timer matches 20 run effect give @s minecraft:blindness 30 4 true
execute if score @s pr_flags matches 0 if score @s pr_timer matches 25 run tp @s 64.5 200 0.5 90 0
execute if score @s pr_flags matches 0 if score @s pr_timer matches 60 run title @s clear
execute if score @s pr_flags matches 0 if score @s pr_timer matches 140.. run function patch_release:dialog/prompt_hello

# Leave a deliberate two-second beat after each spoken player line before offering the next line.
execute if score @s pr_flags matches 2 run scoreboard players add @s pr_timer 1
execute if score @s pr_flags matches 2 if score @s pr_timer matches 40.. run function patch_release:dialog/prompt_maintenance
execute if score @s pr_flags matches 4 run scoreboard players add @s pr_timer 1
execute if score @s pr_flags matches 4 if score @s pr_timer matches 40.. run function patch_release:dialog/prompt_login
