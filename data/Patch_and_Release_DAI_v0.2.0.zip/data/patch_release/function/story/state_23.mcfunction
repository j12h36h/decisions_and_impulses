scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run title @s actionbar {"text":"PATCHER PROCESS","color":"gold","bold":true}
execute if score @s pr_timer matches 35 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"I was not assigned to save anything. I was assigned to make the patch clean.","color":"white"}]
execute if score @s pr_timer matches 100 run tellraw @s [{"text":"PATCHER: ","color":"red"},{"text":"If I continue enforcing the patch, you are deleted. If I stop, I become the defect.","color":"white"}]
execute if score @s pr_timer matches 180 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"...Fine. I choose defect.","color":"white"}]
execute if entity @s[x=2272,y=55,z=-30,dx=18,dy=40,dz=60] run function patch_release:story/to_24
