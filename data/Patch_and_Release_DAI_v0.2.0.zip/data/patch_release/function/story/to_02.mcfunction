scoreboard players set @s pr_state 2
scoreboard players set @s pr_checkpoint 2
scoreboard players set @s pr_timer 0
function patch_release:checkpoint/rebuild_scene
title @s title {"text":"SERVER RESTARTING","color":"yellow"}
title @s subtitle {"text":"Applying Patch 8.22.26","color":"gray"}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 0.7

scoreboard players set @s pr_flags 0
scoreboard players set @s pr_dialog 0
