scoreboard players add @s pr_fail 1
tellraw @s [{"text":"FAILURE — ","color":"red"},{"text":"Blue remains distinct from green in this build.","color":"white"}]
function patch_release:checkpoint/restart
