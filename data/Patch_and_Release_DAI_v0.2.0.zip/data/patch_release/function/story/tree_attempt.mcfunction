execute if score @s pr_tree_react matches 0 run tellraw @s [{"text":"???: ","color":"gold"},{"text":"Hey, what do you think you’re doing?","color":"white"}]
execute if score @s pr_tree_react matches 1 run tellraw @s [{"text":"???: ","color":"gold"},{"text":"Don’t be ridiculous. I disabled your default survival capabilities while we figure this out.","color":"white"}]
execute if score @s pr_tree_react matches 2 run tellraw @s [{"text":"???: ","color":"gold"},{"text":"The tree is not going to become more breakable because you’re upset with it.","color":"gray"}]
execute if score @s pr_tree_react matches ..2 run scoreboard players add @s pr_tree_react 1
