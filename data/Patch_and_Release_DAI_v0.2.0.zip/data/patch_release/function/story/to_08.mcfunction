scoreboard players set @s pr_state 8
scoreboard players set @s pr_phase 0
scoreboard players set @s pr_timer 0
scoreboard players set @s pr_once 0
function patch_release:world/build_act2
function patch_release:checkpoint/commit
tp @s 600.5 65 0.5 -90 0
