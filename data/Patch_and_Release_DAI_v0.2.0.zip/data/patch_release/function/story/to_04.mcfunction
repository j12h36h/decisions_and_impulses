scoreboard players set @s pr_state 4
scoreboard players set @s pr_checkpoint 4
scoreboard players set @s pr_timer 0
function patch_release:checkpoint/rebuild_scene
# State 4 is not valid unless its maintenance corridor exists. rebuild_scene already guarantees it here.
# Put Wiggle Wobble safely at the corridor mouth, facing the doors.
tp @s 106.5 64 0.5 -90 0
spawnpoint @s 106 64 0
tellraw @s [{"text":"SYSTEM RULE: ","color":"yellow","bold":true},{"text":"Enter the green maintenance door to continue.","color":"white"}]
