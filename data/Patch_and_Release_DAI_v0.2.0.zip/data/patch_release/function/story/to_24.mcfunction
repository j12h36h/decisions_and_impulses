scoreboard players set @s pr_state 24
scoreboard players set @s pr_phase 0
scoreboard players set @s pr_timer 0
scoreboard players set @s pr_once 0
function patch_release:world/build_act4
function patch_release:checkpoint/commit
tp @s 2290.5 65 0.5 -90 0
