scoreboard players add @s pr_fail 1
tellraw @s [{"text":"FAILURE — ","color":"red"},{"text":"The red door was not green.","color":"white"}]
tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"I am beginning to understand why cleanup takes so long.","color":"gray"}]
function patch_release:checkpoint/restart
