
scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 30 run title @s title {"text":"LIVE SERVER","color":"green","bold":true}
execute if score @s pr_timer matches 30 run title @s subtitle {"text":"Channel 3 // Population: 61","color":"gray"}
execute if score @s pr_timer matches 90 run tellraw @s [{"text":"SYSTEM: ","color":"yellow"},{"text":"Migration contains no foreign patch data.","color":"gray"}]
execute if score @s pr_timer matches 170 run tellraw @s [{"text":"[Player_LeafKnight]: ","color":"aqua"},{"text":"wait what mob is that","color":"white"}]
execute if score @s pr_timer matches 240 run tellraw @s [{"text":"PATCH & RELEASE","color":"gold","bold":true},{"text":" // Clean release.","color":"gray"}]
