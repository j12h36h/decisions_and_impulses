scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 20 run title @s actionbar {"text":"INTEGRITY SWEEP","color":"gold","bold":true}
execute if score @s pr_timer matches 35 run tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"Run. This is not a suggestion disguised as a rule. It is both.","color":"white"}]
effect give @s minecraft:speed 2 1 true
execute if entity @s[x=1312,y=55,z=-30,dx=18,dy=40,dz=60] run function patch_release:story/to_15
