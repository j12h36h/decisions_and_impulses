execute if entity @s[y=-64,dy=123] run tp @s 106.5 64 0.5 -90 0
scoreboard players add @s pr_timer 1
# Newly constructed maintenance corridor: red fails, blue fails, green continues.
execute if entity @s[x=116,y=63,z=-9,dx=8,dy=8,dz=5] run function patch_release:story/fail_red
execute if entity @s[x=116,y=63,z=4,dx=8,dy=8,dz=5] run function patch_release:story/fail_blue
execute if entity @s[x=119,y=63,z=-2,dx=5,dy=8,dz=4] run function patch_release:story/to_05
