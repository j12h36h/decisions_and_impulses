
scoreboard players add @s pr_timer 1
execute if score @s pr_timer matches 30 run title @s title {"text":"LIVE SERVER","color":"green","bold":true}
execute if score @s pr_timer matches 30 run title @s subtitle {"text":"Channel 3 // Population: 61","color":"gray"}
execute if score @s pr_timer matches 90 run tellraw @s [{"text":"??? : ","color":"light_purple"},{"text":"...I can hear the music.","color":"white"}]
execute if score @s pr_timer matches 170 run tellraw @s [{"text":"[Player_LeafKnight]: ","color":"aqua"},{"text":"wait what mob is that","color":"white"}]
execute if score @s pr_timer matches 240 run tellraw @s [{"text":"PATCH & RELEASE","color":"gold","bold":true},{"text":" // Fragment carried into live shard.","color":"light_purple"}]
