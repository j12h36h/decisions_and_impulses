
scoreboard objectives add pr_state dummy
scoreboard objectives add pr_timer dummy
scoreboard objectives add pr_fail dummy
scoreboard objectives add pr_choice dummy
scoreboard objectives add pr_flags dummy
scoreboard objectives add pr_phase dummy
scoreboard objectives add pr_cp_phase dummy
scoreboard objectives add pr_tick dummy
scoreboard objectives add pr_dialog trigger
scoreboard objectives add pr_tree_react dummy
scoreboard objectives add pr_checkpoint dummy
scoreboard objectives add pr_deaths deathCount
scoreboard objectives add pr_once dummy
scoreboard objectives add pr_version dummy
tellraw @a [{"text":"[Patch & Release] ","color":"gold"},{"text":"v0.2.0 loaded","color":"gray"}]
