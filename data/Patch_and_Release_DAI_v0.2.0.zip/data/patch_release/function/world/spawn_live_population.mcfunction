# Ambient live-server dressing. Minecraft 26.2 mannequins use the normal player avatar renderer.
# They are invulnerable + immovable and exist only as background MMO actors.
kill @e[tag=pr_live_actor]

# START meadow fake players — wide Steve / slim Alex renderer and normal held equipment.
summon minecraft:mannequin -5 64 -6 {profile:{texture:"entity/player/wide/steve",model:"wide"},hide_description:true,immovable:true,Invulnerable:1b,NoGravity:1b,Silent:1b,CustomNameVisible:1b,CustomName:{text:"LeafKnight",color:"aqua",italic:false},Tags:["pr_live_actor","pr_start_actor","pr_start_p1"]}
item replace entity @e[tag=pr_start_p1,limit=1] armor.head with minecraft:diamond_helmet
item replace entity @e[tag=pr_start_p1,limit=1] weapon.mainhand with minecraft:wooden_sword
summon minecraft:mannequin 27 64 8 {profile:{texture:"entity/player/slim/alex",model:"slim"},hide_description:true,immovable:true,Invulnerable:1b,NoGravity:1b,Silent:1b,CustomNameVisible:1b,CustomName:{text:"xXHeroXx",color:"light_purple",italic:false},Tags:["pr_live_actor","pr_start_actor","pr_start_p2"]}
item replace entity @e[tag=pr_start_p2,limit=1] armor.head with minecraft:iron_helmet
item replace entity @e[tag=pr_start_p2,limit=1] weapon.mainhand with minecraft:stone_sword
summon minecraft:mannequin 15 64 7 {profile:{texture:"entity/player/wide/steve",model:"wide"},hide_description:true,immovable:true,Invulnerable:1b,NoGravity:1b,Silent:1b,CustomNameVisible:1b,CustomName:{text:"MapleMage",color:"yellow",italic:false},Tags:["pr_live_actor","pr_start_actor","pr_start_p3"]}
item replace entity @e[tag=pr_start_p3,limit=1] armor.head with minecraft:golden_helmet
item replace entity @e[tag=pr_start_p3,limit=1] weapon.mainhand with minecraft:stick

# START meadow fake mobs: zero-hitbox marker props.
summon minecraft:armor_stand 7 64 -6 {Marker:1b,Small:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b,Tags:["pr_live_actor","pr_start_actor","pr_start_m1"]}
item replace entity @e[tag=pr_start_m1,limit=1] armor.head with minecraft:lime_wool
summon minecraft:armor_stand 35 64 8 {Marker:1b,Small:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b,Tags:["pr_live_actor","pr_start_actor","pr_start_m2"]}
item replace entity @e[tag=pr_start_m2,limit=1] armor.head with minecraft:pink_wool
summon minecraft:armor_stand 20 64 7 {Marker:1b,Small:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b,Tags:["pr_live_actor","pr_start_actor","pr_start_m3"]}
item replace entity @e[tag=pr_start_m3,limit=1] armor.head with minecraft:yellow_wool

# END meadow mirrors a populated live channel.
summon minecraft:mannequin 3295 64 -12 {profile:{texture:"entity/player/wide/steve",model:"wide"},hide_description:true,immovable:true,Invulnerable:1b,NoGravity:1b,Silent:1b,CustomNameVisible:1b,CustomName:{text:"LeafKnight",color:"aqua",italic:false},Tags:["pr_live_actor","pr_end_actor","pr_end_p1"]}
item replace entity @e[tag=pr_end_p1,limit=1] armor.head with minecraft:diamond_helmet
item replace entity @e[tag=pr_end_p1,limit=1] weapon.mainhand with minecraft:wooden_sword
summon minecraft:mannequin 3365 64 12 {profile:{texture:"entity/player/slim/alex",model:"slim"},hide_description:true,immovable:true,Invulnerable:1b,NoGravity:1b,Silent:1b,CustomNameVisible:1b,CustomName:{text:"xXHeroXx",color:"light_purple",italic:false},Tags:["pr_live_actor","pr_end_actor","pr_end_p2"]}
item replace entity @e[tag=pr_end_p2,limit=1] armor.head with minecraft:iron_helmet
item replace entity @e[tag=pr_end_p2,limit=1] weapon.mainhand with minecraft:stone_sword
summon minecraft:mannequin 3335 64 12 {profile:{texture:"entity/player/wide/steve",model:"wide"},hide_description:true,immovable:true,Invulnerable:1b,NoGravity:1b,Silent:1b,CustomNameVisible:1b,CustomName:{text:"MapleMage",color:"yellow",italic:false},Tags:["pr_live_actor","pr_end_actor","pr_end_p3"]}
item replace entity @e[tag=pr_end_p3,limit=1] armor.head with minecraft:golden_helmet
item replace entity @e[tag=pr_end_p3,limit=1] weapon.mainhand with minecraft:stick
summon minecraft:armor_stand 3310 64 -12 {Marker:1b,Small:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b,Tags:["pr_live_actor","pr_end_actor","pr_end_m1"]}
item replace entity @e[tag=pr_end_m1,limit=1] armor.head with minecraft:lime_wool
summon minecraft:armor_stand 3375 64 12 {Marker:1b,Small:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b,Tags:["pr_live_actor","pr_end_actor","pr_end_m2"]}
item replace entity @e[tag=pr_end_m2,limit=1] armor.head with minecraft:pink_wool
summon minecraft:armor_stand 3348 64 12 {Marker:1b,Small:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b,Tags:["pr_live_actor","pr_end_actor","pr_end_m3"]}
item replace entity @e[tag=pr_end_m3,limit=1] armor.head with minecraft:yellow_wool
scoreboard players set #live pr_tick 0
