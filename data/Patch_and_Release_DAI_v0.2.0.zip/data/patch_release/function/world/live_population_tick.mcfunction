scoreboard players add #live pr_tick 1
execute if score #live pr_tick matches 201.. run scoreboard players set #live pr_tick 0

# Start channel chase loops.
execute if score #live pr_tick matches 0..99 as @e[tag=pr_start_p1] at @s run tp @s ~0.055 ~ ~ -90 0
execute if score #live pr_tick matches 100..199 as @e[tag=pr_start_p1] at @s run tp @s ~-0.055 ~ ~ 90 0
execute if score #live pr_tick matches 0..99 as @e[tag=pr_start_m1] at @s run tp @s ~0.040 ~ ~
execute if score #live pr_tick matches 100..199 as @e[tag=pr_start_m1] at @s run tp @s ~-0.040 ~ ~
execute if score #live pr_tick matches 0..99 as @e[tag=pr_start_p2] at @s run tp @s ~-0.050 ~ ~ 90 0
execute if score #live pr_tick matches 100..199 as @e[tag=pr_start_p2] at @s run tp @s ~0.050 ~ ~ -90 0
execute if score #live pr_tick matches 0..99 as @e[tag=pr_start_m2] at @s run tp @s ~-0.035 ~ ~
execute if score #live pr_tick matches 100..199 as @e[tag=pr_start_m2] at @s run tp @s ~0.035 ~ ~
execute if score #live pr_tick matches 0..99 as @e[tag=pr_start_p3] at @s run tp @s ~0.040 ~ ~-0.015 -70 0
execute if score #live pr_tick matches 100..199 as @e[tag=pr_start_p3] at @s run tp @s ~-0.040 ~ ~0.015 110 0
execute if score #live pr_tick matches 0..99 as @e[tag=pr_start_m3] at @s run tp @s ~0.030 ~ ~-0.010
execute if score #live pr_tick matches 100..199 as @e[tag=pr_start_m3] at @s run tp @s ~-0.030 ~ ~0.010

# End channel chase loops.
execute if score #live pr_tick matches 0..99 as @e[tag=pr_end_p1] at @s run tp @s ~0.055 ~ ~ -90 0
execute if score #live pr_tick matches 100..199 as @e[tag=pr_end_p1] at @s run tp @s ~-0.055 ~ ~ 90 0
execute if score #live pr_tick matches 0..99 as @e[tag=pr_end_m1] at @s run tp @s ~0.040 ~ ~
execute if score #live pr_tick matches 100..199 as @e[tag=pr_end_m1] at @s run tp @s ~-0.040 ~ ~
execute if score #live pr_tick matches 0..99 as @e[tag=pr_end_p2] at @s run tp @s ~-0.050 ~ ~ 90 0
execute if score #live pr_tick matches 100..199 as @e[tag=pr_end_p2] at @s run tp @s ~0.050 ~ ~ -90 0
execute if score #live pr_tick matches 0..99 as @e[tag=pr_end_m2] at @s run tp @s ~-0.035 ~ ~
execute if score #live pr_tick matches 100..199 as @e[tag=pr_end_m2] at @s run tp @s ~0.035 ~ ~
execute if score #live pr_tick matches 0..99 as @e[tag=pr_end_p3] at @s run tp @s ~0.040 ~ ~-0.015 -70 0
execute if score #live pr_tick matches 100..199 as @e[tag=pr_end_p3] at @s run tp @s ~-0.040 ~ ~0.015 110 0
execute if score #live pr_tick matches 0..99 as @e[tag=pr_end_m3] at @s run tp @s ~0.030 ~ ~-0.010
execute if score #live pr_tick matches 100..199 as @e[tag=pr_end_m3] at @s run tp @s ~-0.030 ~ ~0.010

# Fake hit moments. Nothing here can damage or be interacted with by the real player.
execute if score #live pr_tick matches 50 as @e[tag=pr_start_m1] at @s run particle minecraft:crit ~ ~0.8 ~ 0.25 0.25 0.25 0.08 8 normal @a
execute if score #live pr_tick matches 100 as @e[tag=pr_start_m2] at @s run particle minecraft:crit ~ ~0.8 ~ 0.25 0.25 0.25 0.08 8 normal @a
execute if score #live pr_tick matches 150 as @e[tag=pr_start_m3] at @s run particle minecraft:crit ~ ~0.8 ~ 0.25 0.25 0.25 0.08 8 normal @a
execute if score #live pr_tick matches 50 as @e[tag=pr_end_m1] at @s run particle minecraft:crit ~ ~0.8 ~ 0.25 0.25 0.25 0.08 8 normal @a
execute if score #live pr_tick matches 100 as @e[tag=pr_end_m2] at @s run particle minecraft:crit ~ ~0.8 ~ 0.25 0.25 0.25 0.08 8 normal @a
execute if score #live pr_tick matches 150 as @e[tag=pr_end_m3] at @s run particle minecraft:crit ~ ~0.8 ~ 0.25 0.25 0.25 0.08 8 normal @a
