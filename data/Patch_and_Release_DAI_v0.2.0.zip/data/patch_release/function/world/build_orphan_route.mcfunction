# State-4 maintenance corridor. This function is intentionally idempotent and safe to call on resume.
# Broad safety slab around the entire route.
fill 94 63 -14 126 63 14 minecraft:gray_concrete
fill 96 64 -12 124 69 12 minecraft:air

# Corridor floor / ceiling / side walls from orphan area toward the maintenance doors.
fill 102 63 -10 118 63 10 minecraft:polished_andesite
fill 102 69 -10 118 69 10 minecraft:polished_andesite
fill 102 64 -10 118 68 -10 minecraft:polished_andesite
fill 102 64 10 118 68 10 minecraft:polished_andesite
fill 118 64 -10 118 68 10 minecraft:polished_andesite

# Three unmistakable framed openings in the east wall.
# RED
fill 118 64 -9 118 68 -4 minecraft:red_concrete
fill 118 65 -8 118 67 -5 minecraft:air
# GREEN -- literal correct route
fill 118 64 -2 118 68 2 minecraft:lime_concrete
fill 118 65 -1 118 67 1 minecraft:air
setblock 117 68 0 minecraft:green_concrete
# BLUE
fill 118 64 4 118 68 9 minecraft:blue_concrete
fill 118 65 5 118 67 8 minecraft:air

# Center guide path and safe space behind every door.
fill 103 64 -1 117 64 1 minecraft:lime_carpet
fill 119 63 -10 125 63 10 minecraft:gray_concrete
fill 119 64 -10 125 68 10 minecraft:air

playsound minecraft:block.iron_door.open master @s ~ ~ ~ 0.8 0.7
particle minecraft:happy_villager 108.5 65 0.5 0.25 0.6 0.25 0.03 18 force @s
