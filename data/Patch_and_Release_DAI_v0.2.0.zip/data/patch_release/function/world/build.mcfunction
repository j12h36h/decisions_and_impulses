# Hub / MMO meadow
fill -8 63 -12 45 63 12 minecraft:grass_block
fill -8 64 -12 45 67 12 minecraft:air
fill -8 62 -12 45 62 12 minecraft:dirt
fill 8 64 -8 8 68 -8 minecraft:oak_log
fill 6 68 -10 10 71 -6 minecraft:oak_leaves
fill 22 64 5 22 67 5 minecraft:birch_log
fill 20 67 3 24 70 7 minecraft:birch_leaves
setblock 32 64 -4 minecraft:yellow_concrete
setblock 34 64 -4 minecraft:pink_concrete
setblock 36 64 -4 minecraft:lime_concrete
# blackout cell
fill 60 199 -4 74 204 4 minecraft:black_concrete
fill 61 200 -3 73 203 3 minecraft:air
# deprecated map
fill 95 63 -12 145 63 12 minecraft:gray_concrete
fill 95 64 -12 145 70 12 minecraft:air
fill 98 64 -10 112 64 10 minecraft:light_gray_concrete
fill 118 64 -10 132 64 10 minecraft:cracked_stone_bricks
fill 136 64 -10 144 68 10 minecraft:iron_bars
fill 140 64 -2 144 67 2 minecraft:air
fill 145 63 -3 150 63 3 minecraft:gray_concrete
fill 145 64 -3 150 67 3 minecraft:air
# Maintenance corridor is intentionally deferred until Wiggle Wobble moves.

# three-door truth puzzle
fill 150 63 -22 190 63 22 minecraft:smooth_stone
fill 150 64 -22 190 70 22 minecraft:air
fill 168 64 -18 172 68 -14 minecraft:red_concrete
fill 169 65 -18 171 67 -14 minecraft:air
fill 168 64 -2 172 68 2 minecraft:lime_concrete
fill 169 65 -2 171 67 2 minecraft:air
fill 168 64 14 172 68 18 minecraft:blue_concrete
fill 169 65 14 171 67 18 minecraft:air
# cleanup room + yellow pad
fill 200 63 -12 248 63 12 minecraft:polished_deepslate
fill 200 64 -12 248 72 12 minecraft:air
fill 214 64 -3 220 64 3 minecraft:yellow_concrete
fill 226 64 -7 244 64 7 minecraft:orange_concrete
# blue obvious room
fill 255 63 -10 298 63 10 minecraft:white_concrete
fill 255 64 -10 298 70 10 minecraft:air
fill 275 64 -2 279 64 2 minecraft:blue_concrete
# revelation chamber
fill 305 63 -14 345 63 14 minecraft:blackstone
fill 305 64 -14 345 73 14 minecraft:air
fill 323 64 -12 327 70 12 minecraft:purple_stained_glass
# release path
fill 355 63 -10 455 63 10 minecraft:deepslate_tiles
fill 355 64 -10 455 70 10 minecraft:air
fill 360 64 0 450 64 0 minecraft:orange_concrete
# choice chamber
fill 465 63 -24 510 63 24 minecraft:smooth_quartz
fill 465 64 -24 510 72 24 minecraft:air
fill 490 64 -20 502 64 -8 minecraft:purple_concrete
fill 490 64 8 502 64 20 minecraft:light_gray_concrete
setblock 497 65 -14 minecraft:amethyst_block
# live world
fill 530 63 -20 590 63 20 minecraft:grass_block
fill 530 64 -20 590 72 20 minecraft:air
fill 546 64 -10 546 68 -10 minecraft:cherry_log
fill 543 68 -13 549 72 -7 minecraft:cherry_leaves
fill 570 64 8 570 68 8 minecraft:oak_log
fill 567 68 5 573 72 11 minecraft:oak_leaves
setblock 558 64 -4 minecraft:yellow_concrete
setblock 560 64 -4 minecraft:pink_concrete
setblock 562 64 -4 minecraft:lime_concrete

# Invisible interaction volumes over the two opening trees. These let adventure-mode
# "tree punching" become story input without giving the mob survival capabilities.
kill @e[type=minecraft:interaction,tag=pr_tree_hit]
summon minecraft:interaction 8 64 -8 {width:5.0f,height:8.0f,response:0b,Tags:["pr_tree_hit"]}
summon minecraft:interaction 22 64 5 {width:5.0f,height:8.0f,response:0b,Tags:["pr_tree_hit"]}

# Story transition safety pads. Reasserted by transition functions as well.
fill 97 63 -3 104 63 3 minecraft:gray_concrete
fill 202 63 -3 209 63 3 minecraft:polished_deepslate
fill 258 63 -3 265 63 3 minecraft:white_concrete
fill 308 63 -3 315 63 3 minecraft:blackstone
fill 358 63 -3 365 63 3 minecraft:deepslate_tiles
fill 468 63 -3 475 63 3 minecraft:smooth_quartz

# Populate the two live-server meadows with untouchable ambient actors.
function patch_release:world/spawn_live_population
