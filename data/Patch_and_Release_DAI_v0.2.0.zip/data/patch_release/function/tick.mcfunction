
execute as @a[tag=pr_active] run scoreboard players add @s pr_tick 1
execute as @a[tag=pr_active] run function patch_release:world/self_heal
execute as @a[tag=pr_active,scores={pr_deaths=1..}] run function patch_release:checkpoint/death_restart
# Falling out of any authored traversal area is a defined checkpoint failure, not an open end.
execute as @a[tag=pr_active,y=-64,dy=113] run function patch_release:checkpoint/fall_restart
execute as @a[tag=pr_active] run function patch_release:story/tick
execute if entity @a[tag=pr_active,limit=1] run function patch_release:world/live_population_tick
