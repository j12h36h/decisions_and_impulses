
scoreboard players operation @s pr_checkpoint = @s pr_state
scoreboard players operation @s pr_cp_phase = @s pr_phase
scoreboard players set @s pr_timer 0
scoreboard players set @s pr_dialog 0
