
function patch_release:world/build
execute if score @s pr_state matches 4.. run function patch_release:world/build_orphan_route
execute if score @s pr_state matches 8..15 run function patch_release:world/build_act2
execute if score @s pr_state matches 16..23 run function patch_release:world/build_act3
execute if score @s pr_state matches 24..28 run function patch_release:world/build_act4
execute if score @s pr_state matches 29..34 run function patch_release:world/build_act5
