scoreboard players add @s pr_fail 1
tellraw @s [{"text":"CHECKPOINT: ","color":"yellow","bold":true},{"text":"Wiggle Wobble restored after deletion/death.","color":"gray"}]
function patch_release:checkpoint/restart
