
scoreboard players operation @s pr_state = @s pr_checkpoint
scoreboard players operation @s pr_phase = @s pr_cp_phase
scoreboard players set @s pr_timer 0
scoreboard players set @s pr_dialog 0
scoreboard players set @s pr_deaths 0
function patch_release:checkpoint/rebuild_scene
function patch_release:checkpoint/fallback
gamemode adventure @s
effect give @s minecraft:saturation infinite 0 true
effect give @s minecraft:resistance infinite 4 true
execute if score @s pr_state matches 0 run function patch_release:story/scene_00_boot
scoreboard players add @s pr_fail 1
tellraw @s [{"text":"CHECKPOINT: ","color":"yellow","bold":true},{"text":"Wiggle Wobble restored.","color":"gray"}]
