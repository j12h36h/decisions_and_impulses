# Preserve which one-choice dialogue was pending when possible.
execute if score @s pr_flags matches 0 run tp @s 64.5 200 0.5 90 0
execute if score @s pr_flags matches 1..2 run tp @s 70.5 200 0.5 90 0
execute if score @s pr_flags matches 3..4 run tp @s 71.5 200 0.5 90 0
execute if score @s pr_flags matches 5.. run tp @s 72.5 200 0.5 90 0
