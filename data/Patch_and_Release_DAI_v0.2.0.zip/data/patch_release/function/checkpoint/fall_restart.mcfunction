
tellraw @s [{"text":"PATCHER: ","color":"gold"},{"text":"That route appears to terminate in nothing. Restoring you.","color":"gray"}]
function patch_release:checkpoint/restart
