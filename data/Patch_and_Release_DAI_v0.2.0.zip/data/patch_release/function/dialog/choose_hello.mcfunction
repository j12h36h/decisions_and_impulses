tellraw @s [{"text":"Wiggle Wobble: ","color":"aqua"},{"text":"Hello?","color":"white"}]
# Leave the coordinate watched by dialog_hello_auto_open immediately so the selected button cannot reopen.
tp @s 73.5 200 0.5 90 0
scoreboard players set @s pr_flags 2
scoreboard players set @s pr_timer 0
