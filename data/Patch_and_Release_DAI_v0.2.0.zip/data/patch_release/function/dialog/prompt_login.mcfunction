tp @s 72.5 200 0.5 90 0
scoreboard players set @s pr_flags 5
