tellraw @s [{"text":"Wiggle Wobble: ","color":"aqua"},{"text":"Maintenance usually doesn’t take this long.","color":"white"}]
# Neutral blackout marker during the two-second conversational pause.
tp @s 73.5 200 0.5 90 0
scoreboard players set @s pr_flags 4
scoreboard players set @s pr_timer 0
