
tellraw @s [{"text":"Wiggle Wobble: ","color":"aqua"},{"text":"Wait. Cleanup means deleting me?","color":"white"}]
scoreboard players set @s pr_dialog 0
scoreboard players set @s pr_phase 2
scoreboard players set @s pr_flags 170
# The consumed prompt is now a persistent sub-state. Move completely off the yellow watcher before the next tick.
tp @s 222.5 65 0.5 -90 0
scoreboard players operation @s pr_cp_phase = @s pr_phase
scoreboard players set @s pr_timer 0
