# Once the client has had time to open the focused dialogue, leave its watched X coordinate.
# The menu stays open, but player_input_tick can no longer enqueue duplicate open_dai_menu actions.
execute as @a[scores={pr_state=5,pr_flags=150,pr_dialog=-1}] at @s if entity @s[x=216,y=64,z=-2,dx=1,dy=3,dz=4] run tp @s 218.5 65 0.5 90 0
