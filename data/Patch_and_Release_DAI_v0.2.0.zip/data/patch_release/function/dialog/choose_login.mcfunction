tellraw @s [{"text":"Wiggle Wobble: ","color":"aqua"},{"text":"Why can’t I see the login screen?","color":"white"}]
scoreboard players set @s pr_flags 6
scoreboard players set @s pr_timer 0
function patch_release:story/to_03
