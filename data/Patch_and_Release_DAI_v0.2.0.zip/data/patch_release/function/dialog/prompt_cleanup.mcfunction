
# Only phase 1 may issue this one-shot dialogue.
tp @s 216.5 65 0.5 90 0
scoreboard players set @s pr_dialog -1
scoreboard players set @s pr_flags 150
schedule function patch_release:dialog/detach_cleanup 3t replace
