
tag @s add pr_active
scoreboard players set @s pr_state 0
scoreboard players set @s pr_checkpoint 0
scoreboard players set @s pr_phase 0
scoreboard players set @s pr_cp_phase 0
scoreboard players set @s pr_timer 0
scoreboard players set @s pr_fail 0
scoreboard players set @s pr_choice 0
scoreboard players set @s pr_flags 0
scoreboard players set @s pr_tick 0
scoreboard players set @s pr_dialog 0
scoreboard players set @s pr_tree_react 0
scoreboard players set @s pr_deaths 0
scoreboard players set @s pr_once 0
scoreboard players set @s pr_version 200
gamemode adventure @s
effect give @s minecraft:saturation infinite 0 true
effect give @s minecraft:resistance infinite 4 true
tp @s 0.5 65 0.5 90 0
spawnpoint @s 0 64 0
function patch_release:story/scene_00_boot
