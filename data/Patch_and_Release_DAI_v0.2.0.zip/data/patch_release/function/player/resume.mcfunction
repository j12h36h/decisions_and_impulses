
tag @s add pr_active
gamemode adventure @s
effect give @s minecraft:saturation infinite 0 true
effect give @s minecraft:resistance infinite 4 true
scoreboard players operation @s pr_checkpoint = @s pr_state
# v0.1.x cleanup saves: convert transient flags to the new persistent cleanup phase.
execute unless score @s pr_version matches 200.. if score @s pr_state matches 5 if score @s pr_flags matches 170.. run scoreboard players set @s pr_phase 2
execute unless score @s pr_version matches 200.. if score @s pr_state matches 5 if score @s pr_flags matches 150..169 run scoreboard players set @s pr_phase 1
execute unless score @s pr_version matches 200.. run scoreboard players operation @s pr_cp_phase = @s pr_phase
scoreboard players set @s pr_version 200
function patch_release:checkpoint/rebuild_scene
# State logic is authoritative every tick; resume never depends on a pre-quit DAI action queue.
execute if entity @s[y=-64,dy=123] run function patch_release:checkpoint/fallback
tellraw @s [{"text":"SERVER: ","color":"yellow"},{"text":"Recovered this world's saved Wiggle Wobble checkpoint.","color":"gray"}]
