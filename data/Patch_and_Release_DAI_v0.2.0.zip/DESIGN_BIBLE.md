# Patch & Release — v0.2.0 Design Bible

## Core rule
The Patcher may lie about itself, its motives, history, or identity. It never lies about an actual gameplay rule. It may mislead by exploiting assumptions.

## Interaction completeness
Every meaningful reachable action is classified as ADVANCE, REACT, FAIL/RESTORE, or INTENTIONAL IGNORE. Repeated interactions and backtracking must not corrupt state.

## Five-act structure
1. Maintenance — X misdirection, blackout, orphaning, green door, cleanup revelation.
2. Deprecated Content — archive, removed tutorial, asset graveyard, quarantine, pathfinding lab, integrity sweep.
3. Runtime — chunk stream, entity pool, login queue, memory sector, garbage collector, runtime core, free-will crisis.
4. Hotfix — Patcher reverses cleanup systems and becomes an ally.
5. Release — shard-border run, live gateway, fragment choice, MMO meadow epilogue.

## Checkpoint model
`pr_state` is the major checkpoint. `pr_phase` is its persistent sub-state. `pr_checkpoint` and `pr_cp_phase` are the death/failure mirrors. Vanilla playerdata keeps exact normal quit position; invalid positions recover to authored state starts.
