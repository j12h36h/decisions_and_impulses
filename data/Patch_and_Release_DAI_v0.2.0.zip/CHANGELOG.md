# Patch & Release v0.2.0

- Expanded the five-minute vertical slice into a five-act, long-form traversal experience targeting roughly 2-4 hours for a first playthrough.
- Added 27 new persistent story states and four large deterministic world sectors.
- Added Deprecated Content, Patch Archive, Removed Tutorial, Asset Graveyard, NPC Quarantine, Pathfinding Lab, Integrity Sweep, Runtime, Chunk Stream, Entity Pool, Login Queue, Memory Sector, Garbage Collector, Runtime Core, Hotfix, Reverse Cleanup, Integrity Hunters, Shard Border, Live Gateway, and expanded ending spaces.
- Rebuilt checkpoints around persistent major state + sub-state mirrors.
- Fixed yellow/orange cleanup semantics: orange-before-yellow corrects the player; cleanup dialogue is one-shot; clicking it moves the player off the watcher; orange readiness persists across reload/death; returning to yellow after completion gets an authored reaction and cannot reopen the dialogue.
- Added void/fall checkpoint recovery.
- Progression is re-evaluated from persistent world state every tick instead of depending on transient DAI queues.
- Added state-aware self-healing geometry across all acts.
- Added a formal interaction-completeness rule: reachable authored interactions must advance, react, fail/restore, or intentionally ignore.
