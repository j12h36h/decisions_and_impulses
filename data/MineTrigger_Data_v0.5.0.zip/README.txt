MineTrigger - Border Training v0.4.3
=====================================

Requires: Decisions & Impulses (D.A.I.) 1.9.9+
Recommended companion: MineTrigger Resource Pack v0.4.3
Namespace: minetrigger
DAI role: MAIN
Managed pack ID: minetrigger

0.3.3 updates MineTrigger to DAI 1.9.9's managed datapack / companion-pack lifecycle while preserving all existing Border Training gameplay and the v0.3.2 title texture hotfix.

CURRENT SYSTEMS
---------------
- Registry-backed minetrigger:* Trigger equipment and projectiles.
- Registry-backed DAI Training Trion Soldier entity.
- DAI JSON void world generation.
- Start New / Continue Training title screen and save browser.
- Official Packs access from the MineTrigger title screen.
- Trigger Body On/Off and Bail Out flow.
- Attacker, Shooter, Sniper, and All-Rounder loadouts.
- Trion resource and Trigger ability costs.
- Mobility, stealth, radar, melee reactions, and loadout restoration.
- Direct ` backtick MineTrigger dashboard.
- Automatic companion resource-pack enablement.

INSTALL
-------
1. Install D.A.I. 1.9.9+.
2. Put the datapack ZIP in the instance-level /datapacks folder.
3. Put the matching resource-pack ZIP in /resourcepacks.
4. Restart Minecraft. DAI automatically enables the MineTrigger companion RP.
5. Choose START NEW TRAINING or CONTINUE TRAINING.

Press ` in-game to open the MineTrigger dashboard directly.

0.3.3 COMPATIBILITY UPDATE
--------------------------
- Added stable DAI managed datapack identity: minetrigger.
- Added datapack version metadata: 0.3.3.
- Updated target compatibility to DAI 1.9.9.
- Synchronized the companion Resource Pack to v0.4.1.
- Preserved the v0.3.2 CONTINUE TRAINING icon removal that avoids the missing compass texture path.
- Preserved all native registry content, menus, worldgen, loadouts, Trigger systems, and save behavior.

OLDER HOTFIXES RETAINED
------------------------
- v0.3.1 changed the Training Trion Soldier carrier from unsupported minecraft:husk to supported minecraft:zombie.
- v0.3.1 replaced the recovery-compass title icon during the original title-screen hotfix.
- v0.3.2 removed the CONTINUE TRAINING item icon entirely to avoid the Minecraft 26.2 compass texture warning.


v0.4.3 COMBAT / HOTBAR UPDATE
-----------------------------
- Starting/default/max Trion increased to 1000. Existing 100-capacity players migrate automatically.
- Attacker slot 2 is now Force Blaster: short-range, 1-damage, high-knockback Trion sidearm.
- Asteroid/Hound/Egret collision now reaches standing Training Trion Soldiers correctly.
- Training dummies now have 1000 HP for sustained practice while still taking real damage.
- Slot 7 = Trigger On while inactive / Trigger Off while active.
- Slot 8 = intentionally empty spacer.
- Slot 9 = Bail Out while active.
