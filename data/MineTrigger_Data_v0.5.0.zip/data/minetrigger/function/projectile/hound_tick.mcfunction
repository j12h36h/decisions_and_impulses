scoreboard players add @s wt_proj_age 1
particle minecraft:witch ~ ~ ~ 0.08 0.08 0.08 0.01 2 force @a[distance=..64]
execute if entity @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,distance=..1.95,limit=1,sort=nearest] run function minetrigger:projectile/hound_hit
execute unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run tag @s add mt_proj_dead
execute if score @s wt_proj_age matches 21.. run tag @s add mt_proj_dead
execute unless entity @s[tag=mt_proj_dead] run tp @s ^ ^ ^1.0
execute if entity @s[tag=mt_proj_dead] run kill @s
