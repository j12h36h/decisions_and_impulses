execute as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,distance=..1.80,limit=1,sort=nearest] run damage @s 11 minecraft:magic
particle minecraft:crit ~ ~ ~ 0.12 0.12 0.12 0.03 12 force @a[distance=..96]
playsound minecraft:block.amethyst_block.hit player @a[distance=..48] ~ ~ ~ 0.55 2.0
tag @s add mt_proj_dead
