execute as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,distance=..1.85,limit=1,sort=nearest] run damage @s 7 minecraft:magic
particle minecraft:crit ~ ~ ~ 0.15 0.15 0.15 0.05 8 force @a[distance=..64]
playsound minecraft:block.amethyst_block.hit player @a[distance=..32] ~ ~ ~ 0.5 1.8
tag @s add mt_proj_dead
