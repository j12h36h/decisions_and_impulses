scoreboard players add @s wt_proj_age 1
particle minecraft:electric_spark ~ ~ ~ 0.05 0.05 0.05 0.01 2 force @a[distance=..64]
execute if entity @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,distance=..1.85,limit=1,sort=nearest] run function minetrigger:projectile/asteroid_hit
execute unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run tag @s add mt_proj_dead
execute if score @s wt_proj_age matches 25.. run tag @s add mt_proj_dead
execute unless entity @s[tag=mt_proj_dead] run tp @s ^ ^ ^1.0
execute if entity @s[tag=mt_proj_dead] run kill @s
