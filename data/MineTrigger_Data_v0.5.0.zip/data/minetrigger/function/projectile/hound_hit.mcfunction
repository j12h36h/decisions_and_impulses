execute as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:item_display,distance=..1.95,limit=1,sort=nearest] run damage @s 5 minecraft:magic
particle minecraft:enchanted_hit ~ ~ ~ 0.2 0.2 0.2 0.05 10 force @a[distance=..64]
playsound minecraft:block.amethyst_block.hit player @a[distance=..32] ~ ~ ~ 0.5 1.3
tag @s add mt_proj_dead
