tag @s remove wt_ray_shooter
execute if score @s wt_active matches 1.. unless score @s wt_trion matches 8.. run tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Insufficient Trion for Egret.","color":"red"}]
execute if score @s wt_active matches 1.. if score @s wt_trion matches 8.. run tag @s add wt_ray_shooter
execute if entity @s[tag=wt_ray_shooter] run scoreboard players remove @s wt_trion 8
execute if entity @s[tag=wt_ray_shooter] anchored eyes positioned ^ ^ ^1 run summon minecraft:item_display ~ ~ ~ {Tags:["mt_projectile","mt_egret","mt_new"],billboard:"center",view_range:1.0f,shadow_radius:0.0f,item_display:"fixed",transformation:{scale:[0.16f,0.16f,0.16f]},item:{id:"minetrigger:egret",count:1}}
execute if entity @s[tag=wt_ray_shooter] run data modify entity @e[type=minecraft:item_display,tag=mt_new,tag=mt_egret,limit=1,sort=nearest,distance=..4] Rotation set from entity @s Rotation
execute if entity @s[tag=wt_ray_shooter] run scoreboard players set @e[type=minecraft:item_display,tag=mt_new,tag=mt_egret,limit=1,sort=nearest,distance=..4] wt_proj_age 0
execute if entity @s[tag=wt_ray_shooter] run tag @e[type=minecraft:item_display,tag=mt_new,tag=mt_egret,limit=1,sort=nearest,distance=..4] remove mt_new
execute if entity @s[tag=wt_ray_shooter] run playsound minecraft:entity.firework_rocket.blast player @s ~ ~ ~ 0.55 1.80
execute if entity @s[tag=wt_ray_shooter] if score @s wt_trion matches ..0 run function minetrigger:trigger/bailout
tag @s remove wt_ray_shooter
