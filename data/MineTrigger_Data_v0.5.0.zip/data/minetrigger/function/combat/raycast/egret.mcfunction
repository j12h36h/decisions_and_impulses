
particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force
execute if entity @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,distance=..0.6,limit=1,sort=nearest] as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,distance=..0.6,limit=1,sort=nearest] run damage @s 11 minecraft:magic by @a[tag=wt_ray_shooter,limit=1]
execute if entity @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,distance=..0.6,limit=1,sort=nearest] run scoreboard players set @a[tag=wt_ray_shooter,limit=1] wt_ray_step 999
execute unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run scoreboard players set @a[tag=wt_ray_shooter,limit=1] wt_ray_step 999
execute if score @a[tag=wt_ray_shooter,limit=1] wt_ray_step matches ..47 run scoreboard players add @a[tag=wt_ray_shooter,limit=1] wt_ray_step 1
execute if score @a[tag=wt_ray_shooter,limit=1] wt_ray_step matches ..48 positioned ^ ^ ^1 run function minetrigger:combat/raycast/egret
