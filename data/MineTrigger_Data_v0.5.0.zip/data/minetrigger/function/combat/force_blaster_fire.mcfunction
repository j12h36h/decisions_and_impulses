
tag @s remove wt_force_shooter
execute if score @s wt_active matches 1.. unless score @s wt_trion matches 3.. run tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Insufficient Trion for Force Blaster.","color":"red"}]
execute if score @s wt_active matches 1.. if score @s wt_trion matches 3.. run tag @s add wt_force_shooter
execute if entity @s[tag=wt_force_shooter] run scoreboard players remove @s wt_trion 3
execute if entity @s[tag=wt_force_shooter] run scoreboard players set @s wt_ray_step 0
execute if entity @s[tag=wt_force_shooter] anchored eyes positioned ^ ^ ^1 run function minetrigger:combat/raycast/force_blaster
execute if entity @s[tag=wt_force_shooter] run playsound minecraft:entity.breeze.wind_burst player @s ~ ~ ~ 0.8 1.45
tag @s remove wt_force_shooter
