
execute unless score @s wt_trion matches 1.. run scoreboard players set @s wt_trion 1000
scoreboard players set @s wt_active 1
scoreboard players set @s wt_bagworm 0
scoreboard players set @s wt_chameleon 0
advancement grant @s only minetrigger:state/trigger_on
advancement revoke @s only minetrigger:state/bagworm_on
advancement revoke @s only minetrigger:state/chameleon_on
effect give @s minecraft:resistance infinite 0 true
effect give @s minecraft:speed infinite 0 true
effect give @s minecraft:jump_boost infinite 0 true
function minetrigger:trigger/clear_items
title @s title {"text":"TRIGGER ON","color":"aqua","bold":true}
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 0.7 1.35
