# MineTrigger v0.5.0 / DAI 3.0 objectives.
scoreboard objectives add wt_init dummy
scoreboard objectives add wt_active dummy
scoreboard objectives add wt_trion dummy
scoreboard objectives add wt_trion_max dummy
scoreboard objectives add wt_loadout dummy
scoreboard objectives add wt_clock dummy
scoreboard objectives add wt_ray_step dummy
scoreboard objectives add wt_proj_age dummy
scoreboard objectives add wt_bagworm dummy
scoreboard objectives add wt_chameleon dummy
scoreboard objectives add wt_rank dummy
scoreboard objectives add wt_world dummy
scoreboard players add #clock wt_clock 0
execute as @a unless score @s wt_init matches 1 run function minetrigger:player/init
# One-time training-sector structural repair for upgraded worlds.
execute if score #arena wt_world matches 2 unless score #modern_v050 wt_world matches 1 run function minetrigger:world/repair_v050
