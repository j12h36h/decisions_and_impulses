
execute if score @s wt_loadout matches 1 run function minetrigger:loadout/equip_attacker
execute if score @s wt_loadout matches 2 run function minetrigger:loadout/equip_shooter
execute if score @s wt_loadout matches 3 run function minetrigger:loadout/equip_sniper
execute if score @s wt_loadout matches 4 run function minetrigger:loadout/equip_all_rounder
