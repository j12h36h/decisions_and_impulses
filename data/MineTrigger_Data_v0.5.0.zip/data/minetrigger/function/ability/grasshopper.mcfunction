execute unless score @s wt_active matches 1.. run tellraw @s {"text":"[BORDER] Trigger On is required.","color":"red"}
execute if score @s wt_active matches 1.. unless score @s wt_trion matches 10.. run tellraw @s {"text":"[BORDER] Grasshopper needs 8 Trion plus emergency body reserve.","color":"red"}
execute if score @s wt_active matches 1.. if score @s wt_trion matches 10.. run scoreboard players remove @s wt_trion 8
execute if score @s wt_active matches 1.. if score @s wt_trion matches 2.. run teleport @s ^ ^1.2 ^6
execute if score @s wt_active matches 1.. if score @s wt_trion matches 2.. run playsound minecraft:entity.breeze.jump player @s ~ ~ ~ 0.8 1.4
