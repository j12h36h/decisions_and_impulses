scoreboard players remove @s wt_trion 4
effect give @s minecraft:resistance 3 2 true
particle minecraft:electric_spark ~ ~1 ~ 0.7 0.9 0.7 0.05 24 force @s
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.7 1.5
execute if score @s wt_trion matches ..0 run function minetrigger:trigger/bailout
