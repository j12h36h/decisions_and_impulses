
scoreboard players set #clock wt_clock 0
execute as @a[scores={wt_trion_max=..999}] run function minetrigger:player/upgrade_trion_1000
execute as @e[tag=wt_training_dummy,tag=!wt_dummy_043] run function minetrigger:world/upgrade_training_dummy
execute as @a[scores={wt_active=1..}] run scoreboard players remove @s wt_trion 1
execute as @a[scores={wt_active=1..,wt_chameleon=1..}] run scoreboard players remove @s wt_trion 2
execute as @a[scores={wt_active=0,wt_trion=..999}] run scoreboard players add @s wt_trion 3
execute as @a if score @s wt_trion > @s wt_trion_max run scoreboard players operation @s wt_trion = @s wt_trion_max
execute as @a[scores={wt_active=1..,wt_trion=..0}] at @s run function minetrigger:trigger/bailout
execute as @a at @s run function minetrigger:hud/actionbar
