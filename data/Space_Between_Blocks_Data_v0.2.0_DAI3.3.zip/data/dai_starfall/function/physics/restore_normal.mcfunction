# Restore the entity's own base attributes by removing only Space Between Blocks modifiers.
attribute @s minecraft:gravity modifier remove dai_starfall:aurod_gravity
attribute @s minecraft:fall_damage_multiplier modifier remove dai_starfall:aurod_fall
tag @s remove ds_aurod_gravity_applied
tag @s remove ds_aurod_gravity
