# Aurod is 0.4g. Use native Minecraft attributes so gravity is authoritative for the player entity.
# Remove first so this function is idempotent and safe for reconnect/recovery paths.
attribute @s minecraft:gravity modifier remove dai_starfall:aurod_gravity
attribute @s minecraft:fall_damage_multiplier modifier remove dai_starfall:aurod_fall
attribute @s minecraft:gravity modifier add dai_starfall:aurod_gravity -0.6 add_multiplied_total
attribute @s minecraft:fall_damage_multiplier modifier add dai_starfall:aurod_fall -0.6 add_multiplied_total
tag @s add ds_aurod_gravity_applied
