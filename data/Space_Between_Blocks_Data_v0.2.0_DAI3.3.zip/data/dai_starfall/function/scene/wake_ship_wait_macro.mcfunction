# Do not place the player into the remote ship until its actual floor chunk exists server-side.
$execute positioned $(ship_x) 67 700 if loaded ~ ~ ~ run function dai_starfall:scene/wake_ship_commit
