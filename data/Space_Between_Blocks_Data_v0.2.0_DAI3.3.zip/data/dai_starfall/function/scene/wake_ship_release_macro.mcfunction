$execute positioned $(ship_x) 67 700 run forceload remove ~-32 ~-48 ~32 ~48
