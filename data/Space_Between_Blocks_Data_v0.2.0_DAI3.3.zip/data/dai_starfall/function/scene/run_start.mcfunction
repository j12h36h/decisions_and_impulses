scoreboard players set @s ds_phase 7
scoreboard players set @s ds_scene 0
effect clear @s minecraft:slowness
effect clear @s minecraft:resistance
title @s times 0 35 5
title @s title {text:"RUN",color:"red",bold:true}
title @s subtitle {text:"EMERGENCY POD // 42m",color:"gold",bold:true}
playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 2 0.5
