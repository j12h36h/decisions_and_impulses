scoreboard players set @s ds_phase 3
function dai_starfall:physics/apply_aurod
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:scene/close_flagship_hatch_macro with storage dai_starfall:ctx
title @s times 5 30 5
title @s title {text:"AUROD",color:"gold",bold:true}
title @s subtitle {text:"T:12942 // steer during descent",color:"light_purple"}
playsound minecraft:entity.elytra.flying master @s ~ ~ ~ 1.2 0.7
