execute positioned ~ 247 -335 run playsound minecraft:entity.generic.explode master @a[distance=..500] ~ ~ ~ 10 0.4
execute positioned ~ 247 -335 run particle minecraft:explosion_emitter ~ ~ ~ 10 6 10 0.12 16 force @a[distance=..500]
execute positioned ~ 247 -335 run particle minecraft:campfire_cosy_smoke ~ ~ ~ 15 8 15 0.08 120 force @a[distance=..500]
function dai_starfall:scene/spawn_hull_2
fill ~-48 232 -369 ~-1 261 -351 minecraft:air
fill ~0 232 -369 ~48 261 -351 minecraft:air
fill ~-48 232 -350 ~-1 261 -332 minecraft:air
fill ~0 232 -350 ~48 261 -332 minecraft:air
fill ~-48 232 -331 ~-1 261 -313 minecraft:air
fill ~0 232 -331 ~48 261 -313 minecraft:air
fill ~-48 232 -312 ~-1 261 -300 minecraft:air
fill ~0 232 -312 ~48 261 -300 minecraft:air
