# Keep only the compact starter-ship neighborhood loaded during the blackout handoff.
$execute positioned $(ship_x) 67 700 run forceload add ~-32 ~-48 ~32 ~48
