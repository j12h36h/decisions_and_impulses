function dai_starfall:physics/restore_normal
kill @e[tag=ds_pod_visual,distance=..100]
kill @e[tag=ds_hull_visual,distance=..500]
effect clear @s minecraft:levitation
scoreboard players set @s ds_phase 9
scoreboard players set @s ds_scene -1
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:scene/wake_ship_forceload_macro with storage dai_starfall:ctx
effect give @s minecraft:resistance 10 255 true
effect give @s minecraft:slow_falling 10 0 true
effect give @s minecraft:darkness 10 0 true
title @s times 10 40 10
title @s title {text:"...",color:"gray"}
