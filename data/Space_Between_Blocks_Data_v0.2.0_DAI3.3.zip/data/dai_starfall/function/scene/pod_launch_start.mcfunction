scoreboard players set @s ds_phase 8
scoreboard players set @s ds_scene 0
effect give @s minecraft:resistance 12 255 true
effect give @s minecraft:levitation 9 4 true
function dai_starfall:scene/spawn_pod_visual
title @s title {text:"EMERGENCY LAUNCH",color:"gold",bold:true}
playsound minecraft:entity.firework_rocket.launch master @s ~ ~ ~ 3 0.6
