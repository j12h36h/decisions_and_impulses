execute if score @s ds_scene matches -1 run function dai_starfall:scene/wake_ship_wait
execute if score @s ds_scene matches 0.. run scoreboard players add @s ds_scene 1
execute if score @s ds_scene matches 10 run function dai_starfall:scene/wake_ship_release
execute if score @s ds_scene matches 30 run tellraw @s [{text:"FLEET NETWORK ........ ",color:"gray"},{text:"OFFLINE",color:"red",bold:true}]
execute if score @s ds_scene matches 50 run tellraw @s [{text:"COMMAND LINK ......... ",color:"gray"},{text:"LOST",color:"red",bold:true}]
execute if score @s ds_scene matches 70 run tellraw @s [{text:"NAVIGATION ........... ",color:"gray"},{text:"1 COORDINATE RECOVERED",color:"gold",bold:true}]
execute if score @s ds_scene matches 90 run title @s title {text:"AUROD // T:16950",color:"gold",bold:true}
execute if score @s ds_scene matches 90 run title @s subtitle {text:"ONLY DESTINATION AVAILABLE",color:"light_purple"}
execute if score @s ds_scene matches 120 run function dai_starfall:scene/wake_ship_finish
