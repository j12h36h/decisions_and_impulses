execute positioned ~ 247 -390 run playsound minecraft:entity.lightning_bolt.thunder master @a[distance=..500] ~ ~ ~ 10 0.5
execute positioned ~ 247 -390 run particle minecraft:explosion_emitter ~ ~ ~ 10 6 10 0.12 16 force @a[distance=..500]
execute positioned ~ 247 -390 run particle minecraft:campfire_cosy_smoke ~ ~ ~ 15 8 15 0.08 120 force @a[distance=..500]
function dai_starfall:scene/spawn_hull_1
fill ~-48 232 -430 ~-1 261 -412 minecraft:air
fill ~0 232 -430 ~48 261 -412 minecraft:air
fill ~-48 232 -411 ~-1 261 -393 minecraft:air
fill ~0 232 -411 ~48 261 -393 minecraft:air
fill ~-48 232 -392 ~-1 261 -374 minecraft:air
fill ~0 232 -392 ~48 261 -374 minecraft:air
fill ~-48 232 -373 ~-1 261 -370 minecraft:air
fill ~0 232 -373 ~48 261 -370 minecraft:air
