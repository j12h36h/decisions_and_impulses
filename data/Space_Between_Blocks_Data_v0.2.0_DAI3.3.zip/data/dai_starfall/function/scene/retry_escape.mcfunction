effect give @s minecraft:resistance 8 255 true
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:scene/retry_escape_macro with storage dai_starfall:ctx
title @s title {text:"IMPACT // RETRY",color:"red",bold:true}
title @s subtitle {text:"Reach the escape pod.",color:"gold"}
