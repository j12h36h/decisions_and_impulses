# Physical touchdown is distinct from entering the surface objective.
# Planetfall protection remains active until a solid block is directly beneath the player.
scoreboard players set @s ds_touchdown 1
effect give @s minecraft:resistance 1 255 true
playsound minecraft:entity.generic.explode master @s ~ ~ ~ 0.7 1.6
particle minecraft:dust_plume ~ ~0.2 ~ 2.5 0.2 2.5 0.2 80 force @s
particle minecraft:cloud ~ ~0.15 ~ 1.5 0.15 1.5 0.05 24 force @s
title @s actionbar [{"text":"TOUCHDOWN // ","color":"gold","bold":true},{"text":"VINEWOOD ","color":"white"},{"score":{"name":"@s","objective":"ds_vines"}},{"text":" / 12","color":"white"}]
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/set_aurod_spawn_macro with storage dai_starfall:ctx
