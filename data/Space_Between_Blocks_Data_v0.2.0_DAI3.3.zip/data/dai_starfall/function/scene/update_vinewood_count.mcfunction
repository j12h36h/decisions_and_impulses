# The tutorial objective is collection-based: count qualifying Aurod Vinewood physically carried right now.
# Querying with maxCount 0 never consumes items; command result is the total matching inventory count.
scoreboard players set @s ds_vines 0
scoreboard players set @s ds_vines_aux 0
execute store result score @s ds_vines run clear @s minecraft:stripped_jungle_wood 0
execute store result score @s ds_vines_aux run clear @s minecraft:mangrove_roots 0
scoreboard players operation @s ds_vines += @s ds_vines_aux

# Independent stack predicates guarantee a full qualifying stack is recognized even if command-result behavior changes.
execute if items entity @s inventory.* minecraft:stripped_jungle_wood[count~{min:12}] run scoreboard players set @s ds_vines 12
execute if items entity @s inventory.* minecraft:mangrove_roots[count~{min:12}] run scoreboard players set @s ds_vines 12

# UI caps at the required amount. Dropping/materially spending Vinewood before completion lowers progress, as a collection quest should.
execute if score @s ds_vines matches 12.. run scoreboard players set @s ds_vines 12

# Give immediate feedback when carried collection increases.
execute if score @s ds_vines > @s ds_vines_seen run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.45 1.7
execute if score @s ds_vines > @s ds_vines_seen run title @s actionbar [{"text":"VINEWOOD COLLECTED // ","color":"gold"},{"score":{"name":"@s","objective":"ds_vines"}},{"text":" / 12","color":"white"}]
execute if score @s ds_vines > @s ds_vines_seen run scoreboard players operation @s ds_vines_seen = @s ds_vines
