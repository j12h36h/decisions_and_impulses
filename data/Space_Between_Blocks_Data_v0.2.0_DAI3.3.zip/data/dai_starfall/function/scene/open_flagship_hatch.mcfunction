scoreboard players set @s ds_phase 2
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:scene/open_flagship_hatch_macro with storage dai_starfall:ctx
effect give @s minecraft:resistance 20 255 true
playsound minecraft:block.iron_door.open master @s ~ ~ ~ 2 0.6
title @s actionbar {text:"DROP BAY // HATCH OPEN — JUMP",color:"gold",bold:true}
