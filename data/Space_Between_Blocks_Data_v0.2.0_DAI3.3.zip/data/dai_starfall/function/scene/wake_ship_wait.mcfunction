execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:scene/wake_ship_wait_macro with storage dai_starfall:ctx
