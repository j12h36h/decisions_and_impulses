execute positioned ~ 247 -245 run playsound minecraft:entity.wither.break_block master @a[distance=..500] ~ ~ ~ 10 0.3
execute positioned ~ 247 -245 run particle minecraft:explosion_emitter ~ ~ ~ 10 6 10 0.12 16 force @a[distance=..500]
execute positioned ~ 247 -245 run particle minecraft:campfire_cosy_smoke ~ ~ ~ 15 8 15 0.08 120 force @a[distance=..500]
function dai_starfall:scene/spawn_hull_3
fill ~-48 232 -299 ~-1 261 -281 minecraft:air
fill ~0 232 -299 ~48 261 -281 minecraft:air
fill ~-48 232 -280 ~-1 261 -262 minecraft:air
fill ~0 232 -280 ~48 261 -262 minecraft:air
fill ~-48 232 -261 ~-1 261 -243 minecraft:air
fill ~0 232 -261 ~48 261 -243 minecraft:air
fill ~-48 232 -242 ~-1 261 -224 minecraft:air
fill ~0 232 -242 ~48 261 -224 minecraft:air
fill ~-48 232 -223 ~-1 261 -205 minecraft:air
fill ~0 232 -223 ~48 261 -205 minecraft:air
fill ~-48 232 -204 ~-1 261 -186 minecraft:air
fill ~0 232 -204 ~48 261 -186 minecraft:air
fill ~-48 232 -185 ~-1 261 -170 minecraft:air
fill ~0 232 -185 ~48 261 -170 minecraft:air
