# Move only debris belonging to this player's distant plot; 2048-block plot spacing prevents cross-player interference.
$execute positioned $(ship_x) 247 -300 as @e[tag=ds_hull_a,distance=..260] at @s run tp @s ~-0.10 ~-0.68 ~0.03
$execute positioned $(ship_x) 247 -300 as @e[tag=ds_hull_b,distance=..260] at @s run tp @s ~0.08 ~-0.82 ~-0.02
$execute positioned $(ship_x) 247 -300 as @e[tag=ds_hull_c,distance=..260] at @s run tp @s ~-0.06 ~-0.95 ~0.06
$execute positioned $(ship_x) 247 -300 as @e[tag=ds_hull_d,distance=..260] at @s run tp @s ~0.12 ~-0.75 ~0.04
$execute positioned $(ship_x) 247 -300 as @e[tag=ds_hull_e,distance=..260] at @s run tp @s ~-0.14 ~-1.02 ~-0.03
$execute positioned $(ship_x) 247 -300 as @e[tag=ds_hull_f,distance=..260] at @s run tp @s ~0.09 ~-0.90 ~0.07
