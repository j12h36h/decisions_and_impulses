scoreboard players set @s ds_phase 10
scoreboard players set @s ds_scene 0
effect clear @s minecraft:darkness
effect clear @s minecraft:resistance
tellraw @s [{text:"OBJECTIVE // ",color:"dark_purple",bold:true},{text:"GO TO AUROD. Use the DROP button in the rear bay, then jump through the hatch.",color:"white"}]
