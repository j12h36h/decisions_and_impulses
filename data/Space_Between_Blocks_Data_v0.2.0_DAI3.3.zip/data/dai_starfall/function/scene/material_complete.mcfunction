scoreboard players set @s ds_phase 5
scoreboard players set @s ds_ui_complete 60
title @s title {text:"COLLECTION COMPLETE",color:"green",bold:true}
title @s subtitle {text:"RETURN TO EXTRACTION BEACON",color:"white"}
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.8 1.25
tellraw @s [{"text":"NAV // ","color":"gold","bold":true},{"text":"Beacon is the lit pad connected to the emergency-pod causeway.","color":"white"}]
tellraw @s [{"text":"✓ OBJECTIVE COMPLETE // ","color":"green","bold":true},{"text":"Return to the extraction beacon.","color":"white"}]
