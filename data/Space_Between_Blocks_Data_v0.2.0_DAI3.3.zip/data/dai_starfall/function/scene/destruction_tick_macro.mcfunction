scoreboard players add @s ds_scene 1
$execute if score @s ds_scene matches 18 positioned $(ship_x) 0 0 run function dai_starfall:scene/hit_1
$execute if score @s ds_scene matches 42 positioned $(ship_x) 0 0 run function dai_starfall:scene/hit_2
$execute if score @s ds_scene matches 68 positioned $(ship_x) 0 0 run function dai_starfall:scene/hit_3
function dai_starfall:scene/move_hull_sections_macro with storage dai_starfall:ctx
$execute if score @s ds_scene matches 88 positioned $(ship_x) 250 -315 run function dai_starfall:scene/spawn_debris
execute if score @s ds_scene matches 105 run function dai_starfall:scene/run_start
