scoreboard players add @s ds_scene 1
particle minecraft:flame ~ ~-1.6 ~ 0.7 0.4 0.7 0.06 18 force @a[distance=..160]
particle minecraft:campfire_cosy_smoke ~ ~-1.8 ~ 0.9 0.5 0.9 0.04 12 force @a[distance=..160]
execute if score @s ds_scene matches 35 run playsound minecraft:entity.generic.explode master @s ~ ~-60 ~ 6 0.5
execute if score @s ds_scene matches 70 run effect give @s minecraft:darkness 3 1 true
execute if score @s ds_scene matches 92 run function dai_starfall:scene/wake_ship
