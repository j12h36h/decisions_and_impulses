$execute positioned $(ship_x) 0 0 run fill ~-3 232 -302 ~3 234 -296 minecraft:iron_block
