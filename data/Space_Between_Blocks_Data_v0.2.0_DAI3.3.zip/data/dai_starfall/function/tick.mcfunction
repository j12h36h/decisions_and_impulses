# Space Between Blocks v0.2.0 / DAI 3.3 runtime.

# Historical shared-terrain migration.
execute if score #aurod_built ds_global matches 1 unless score #terrain_v114 ds_global matches 1 run scoreboard players set #aurod_built ds_global 0
execute unless score #terrain_v114 ds_global matches 1 if entity @a[tag=ds_player,scores={ds_phase=9..}] run scoreboard players set #terrain_v114 ds_global 1

# Do not build the enormous shared post-crash planet during server startup.
execute if entity @a[tag=ds_player,scores={ds_phase=9..}] unless score #aurod_built ds_global matches 1 unless score #aurod_preparing ds_global matches 1 run function dai_starfall:build/prepare_shared_aurod

# Complete shared Aurod only after every remote chunk band is loaded.
execute if score #aurod_preparing ds_global matches 1 if loaded -220 40 99780 if loaded 220 40 99887 if loaded -220 40 99888 if loaded 220 40 99999 if loaded -220 40 100000 if loaded 220 40 100111 if loaded -220 40 100112 if loaded 220 40 100220 run function dai_starfall:build/finish_shared_aurod

# One authoritative player pass replaces the old repeated global @a scans.
execute as @a[tag=ds_player] run function dai_starfall:player/runtime_tick

# Shared Aurod shoreline migration remains global and staged.
execute if score #aurod_built ds_global matches 1 unless score #coast_v116 ds_global matches 0.. run scoreboard players set #coast_v116 ds_global 0
execute if score #aurod_built ds_global matches 1 unless score #coast_wait_v116 ds_global matches 0.. run scoreboard players set #coast_wait_v116 ds_global 0
execute if score #aurod_built ds_global matches 1 if score #coast_v116 ds_global matches ..7 if score #coast_wait_v116 ds_global matches 0 run function dai_starfall:build/patch_shared_coast_v116
execute if score #coast_wait_v116 ds_global matches 1.. run scoreboard players remove #coast_wait_v116 ds_global 1

# Quest bossbars only need 10 Hz viewer synchronization; values remain authoritative.
execute if score #ui_pulse ds_global matches 0 run function dai_starfall:ui/sync_quest_bars
scoreboard players add #ui_pulse ds_global 1
execute if score #ui_pulse ds_global matches 2.. run scoreboard players set #ui_pulse ds_global 0
