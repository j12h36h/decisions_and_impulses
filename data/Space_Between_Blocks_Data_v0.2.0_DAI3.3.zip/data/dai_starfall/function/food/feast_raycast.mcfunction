execute if score @s ds_feast_state matches 0 if block ~ ~ ~ minecraft:cake run function dai_starfall:food/feast_consume_at
execute if score @s ds_feast_state matches 0 unless block ~ ~ ~ minecraft:cake if score @s ds_feast_ray matches ..24 run scoreboard players add @s ds_feast_ray 1
execute if score @s ds_feast_state matches 0 unless block ~ ~ ~ minecraft:cake if score @s ds_feast_ray matches ..24 positioned ^ ^ ^0.20 run function dai_starfall:food/feast_raycast
