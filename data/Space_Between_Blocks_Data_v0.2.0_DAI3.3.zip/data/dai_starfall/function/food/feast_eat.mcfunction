scoreboard players set @s ds_feast_ray 0
scoreboard players set @s ds_feast_state 0
execute anchored eyes positioned ^ ^ ^0.25 run function dai_starfall:food/feast_raycast
