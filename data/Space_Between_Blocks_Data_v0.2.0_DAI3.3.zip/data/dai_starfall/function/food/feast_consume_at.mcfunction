scoreboard players set @s ds_feast_state 0
execute if block ~ ~ ~ minecraft:cake[bites=0] run scoreboard players set @s ds_feast_state 1
execute if block ~ ~ ~ minecraft:cake[bites=1] run scoreboard players set @s ds_feast_state 1
execute if block ~ ~ ~ minecraft:cake[bites=2] run scoreboard players set @s ds_feast_state 2
execute if block ~ ~ ~ minecraft:cake[bites=3] run scoreboard players set @s ds_feast_state 2
execute if block ~ ~ ~ minecraft:cake[bites=4] run scoreboard players set @s ds_feast_state 3
execute if block ~ ~ ~ minecraft:cake[bites=5] run scoreboard players set @s ds_feast_state 3
execute if block ~ ~ ~ minecraft:cake[bites=6] run scoreboard players set @s ds_feast_state 3

effect give @s minecraft:saturation 1 255 true
playsound minecraft:entity.generic.eat player @s ~ ~ ~ 0.8 0.85
playsound minecraft:block.bubble_column.upwards_inside player @s ~ ~ ~ 0.25 1.4
particle minecraft:happy_villager ~ ~1.0 ~ 0.30 0.18 0.30 0.0 5 force @s

execute if score @s ds_feast_state matches 1 run setblock ~ ~ ~ minecraft:cake[bites=2]
execute if score @s ds_feast_state matches 2 run setblock ~ ~ ~ minecraft:cake[bites=4]
execute if score @s ds_feast_state matches 3 run setblock ~ ~ ~ minecraft:air
execute if score @s ds_feast_state matches 1 run title @s actionbar {text:'FOOD FEAST // 2 SERVINGS REMAIN',color:'gold'}
execute if score @s ds_feast_state matches 2 run title @s actionbar {text:'FOOD FEAST // 1 SERVING REMAINS',color:'gold'}
execute if score @s ds_feast_state matches 3 run title @s actionbar {text:'FOOD FEAST // EMPTY',color:'gray'}
