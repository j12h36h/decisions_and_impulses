scoreboard players set @s ds_mt_spin 4
item replace entity @s weapon.mainhand with minecraft:iron_shovel[minecraft:unbreakable={},minecraft:custom_model_data={strings:['spin1']},minecraft:custom_data={dai_starfall:{multitool:1b,mode:'shovel',spinning:1b}},minecraft:custom_name={text:'Imperial Field MultiTool // ROTATING',color:'light_purple',bold:true,italic:false},minecraft:lore=[{text:'Rotary head assembly cycling...',color:'gold',italic:false},{text:'Axe / Pickaxe / Shovel',color:'gray',italic:false}]]
playsound minecraft:block.piston.contract player @s ~ ~ ~ 0.45 1.55
playsound minecraft:item.armor.equip_chain player @s ~ ~ ~ 0.30 1.85
