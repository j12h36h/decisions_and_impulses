execute if items entity @s weapon.mainhand minecraft:iron_axe[minecraft:custom_data~{dai_starfall:{multitool:1b,mode:'axe'}}] run function dai_starfall:item/to_pickaxe
execute if items entity @s weapon.mainhand minecraft:iron_pickaxe[minecraft:custom_data~{dai_starfall:{multitool:1b,mode:'pickaxe'}}] run function dai_starfall:item/to_shovel
execute if items entity @s weapon.mainhand minecraft:iron_shovel[minecraft:custom_data~{dai_starfall:{multitool:1b,mode:'shovel'}}] run function dai_starfall:item/to_axe
