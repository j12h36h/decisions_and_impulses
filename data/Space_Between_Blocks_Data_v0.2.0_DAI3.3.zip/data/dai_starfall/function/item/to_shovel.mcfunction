item replace entity @s weapon.mainhand with minecraft:iron_shovel[minecraft:unbreakable={},minecraft:custom_model_data={strings:['shovel']},minecraft:custom_data={dai_starfall:{multitool:1b,mode:'shovel'}},minecraft:custom_name={text:'Imperial Field MultiTool // SHOVEL',color:'gold',bold:true,italic:false},minecraft:lore=[{text:'Rotary head: Axe / Pickaxe / Shovel',color:'light_purple',italic:false},{text:'Right-click air: rotate head assembly',color:'gray',italic:false},{text:'Infinite durability • Iron-tier field hardware',color:'dark_gray',italic:false}]]
scoreboard players set @s ds_mt_spin 0
playsound minecraft:block.iron_trapdoor.close player @s ~ ~ ~ 0.6 1.70
playsound minecraft:block.copper_bulb.turn_on player @s ~ ~ ~ 0.35 1.88
title @s actionbar {text:"MULTITOOL // SHOVEL LOCKED",color:"gold"}
