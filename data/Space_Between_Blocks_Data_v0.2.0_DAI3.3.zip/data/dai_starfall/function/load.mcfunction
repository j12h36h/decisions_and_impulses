scoreboard objectives add ds_phase dummy
scoreboard objectives add ds_scene dummy
scoreboard objectives add ds_ship dummy
scoreboard objectives add ds_ship_x dummy
scoreboard objectives add ds_vines dummy
scoreboard objectives add ds_vines_aux dummy
scoreboard objectives add ds_vines_inventory dummy
scoreboard objectives add ds_vines_seen dummy
scoreboard objectives add ds_ui_complete dummy
scoreboard objectives add ds_deaths deathCount
scoreboard objectives add ds_seen_deaths dummy
scoreboard objectives add ds_global dummy
scoreboard objectives add ds_init dummy
execute unless score #next_ship ds_global matches -2147483648..2147483647 run scoreboard players set #next_ship ds_global 0
scoreboard players set #ship_spacing ds_global 2048
scoreboard players set #one ds_global 1
scoreboard players set #ui_pulse ds_global 0
scoreboard objectives add ds_patch dummy
scoreboard objectives add ds_y dummy
scoreboard objectives add ds_touchdown dummy
scoreboard objectives add ds_coast dummy
scoreboard objectives add ds_coast_wait dummy

# Persistent multiplayer-safe quest HUD bars are created once per world.
execute unless score #quest_bars ds_global matches 1 run function dai_starfall:ui/init_quest_bars

# Keep collection semantics explicit even when upgrading an existing world with pre-created bossbars.
bossbar set dai_starfall:vinewood_0 name {"text":"AUROD // VINEWOOD COLLECTED 0 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_1 name {"text":"AUROD // VINEWOOD COLLECTED 1 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_2 name {"text":"AUROD // VINEWOOD COLLECTED 2 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_3 name {"text":"AUROD // VINEWOOD COLLECTED 3 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_4 name {"text":"AUROD // VINEWOOD COLLECTED 4 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_5 name {"text":"AUROD // VINEWOOD COLLECTED 5 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_6 name {"text":"AUROD // VINEWOOD COLLECTED 6 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_7 name {"text":"AUROD // VINEWOOD COLLECTED 7 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_8 name {"text":"AUROD // VINEWOOD COLLECTED 8 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_9 name {"text":"AUROD // VINEWOOD COLLECTED 9 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_10 name {"text":"AUROD // VINEWOOD COLLECTED 10 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_11 name {"text":"AUROD // VINEWOOD COLLECTED 11 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_12 name {"text":"AUROD // VINEWOOD COLLECTED 12 / 12","color":"gold","bold":true}

scoreboard objectives add ds_mt_spin dummy
scoreboard objectives add ds_foodkit dummy
scoreboard objectives add ds_feast_ray dummy
scoreboard objectives add ds_feast_state dummy
# DAI 3.3 lifecycle handles normal first join/reconnect. These two lines only
# recover players already online during /reload or legacy development saves.
execute as @a[tag=!ds_player] run function dai_starfall:player/first_join
execute as @a[tag=ds_player] run function dai_starfall:player/join

