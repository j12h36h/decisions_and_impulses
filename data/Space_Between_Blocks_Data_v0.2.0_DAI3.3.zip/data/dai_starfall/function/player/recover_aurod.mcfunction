# Tutorial Aurod checkpoint recovery. Preserve current collection/extraction phase.
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/recover_aurod_macro with storage dai_starfall:ctx
scoreboard players set @s ds_touchdown 1
effect give @s minecraft:resistance 3 255 true
title @s times 5 30 10
title @s title {text:"AUROD CHECKPOINT",color:"gold",bold:true}
title @s subtitle {text:"Surface link restored",color:"white"}
function dai_starfall:ui/sync_quest_bars
