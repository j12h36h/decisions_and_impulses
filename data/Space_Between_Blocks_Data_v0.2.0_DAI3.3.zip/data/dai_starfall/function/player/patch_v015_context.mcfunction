execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/patch_v015_macro with storage dai_starfall:ctx
