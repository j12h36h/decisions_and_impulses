$teleport @s $(ship_x).5 44.0 -250.5 0 0
