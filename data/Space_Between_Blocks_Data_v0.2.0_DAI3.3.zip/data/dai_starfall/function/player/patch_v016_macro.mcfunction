# v0.1.17 staged private shoreline retrofit; one loaded band per tick.
$execute if score @s ds_coast matches 0 if score @s ds_coast_wait matches 0 positioned $(ship_x) 0 0 if loaded ~0 44 -395 run function dai_starfall:build/patch_private_coast_v116_band1
$execute if score @s ds_coast matches 1 if score @s ds_coast_wait matches 0 positioned $(ship_x) 0 0 if loaded ~0 44 -368 run function dai_starfall:build/patch_private_coast_v116_band2
$execute if score @s ds_coast matches 2 if score @s ds_coast_wait matches 0 positioned $(ship_x) 0 0 if loaded ~0 44 -341 run function dai_starfall:build/patch_private_coast_v116_band3
$execute if score @s ds_coast matches 3 if score @s ds_coast_wait matches 0 positioned $(ship_x) 0 0 if loaded ~0 44 -314 run function dai_starfall:build/patch_private_coast_v116_band4
$execute if score @s ds_coast matches 4 if score @s ds_coast_wait matches 0 positioned $(ship_x) 0 0 if loaded ~0 44 -287 run function dai_starfall:build/patch_private_coast_v116_band5
$execute if score @s ds_coast matches 5 if score @s ds_coast_wait matches 0 positioned $(ship_x) 0 0 if loaded ~0 44 -259 run function dai_starfall:build/patch_private_coast_v116_band6
$execute if score @s ds_coast matches 6 if score @s ds_coast_wait matches 0 positioned $(ship_x) 0 0 if loaded ~0 44 -232 run function dai_starfall:build/patch_private_coast_v116_band7
$execute if score @s ds_coast matches 7 if score @s ds_coast_wait matches 0 positioned $(ship_x) 0 0 if loaded ~0 44 -205 run function dai_starfall:build/patch_private_coast_v116_band8
