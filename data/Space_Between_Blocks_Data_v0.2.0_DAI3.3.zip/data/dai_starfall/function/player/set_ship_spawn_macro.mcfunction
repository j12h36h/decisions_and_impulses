$spawnpoint @s $(ship_x) 67 700
