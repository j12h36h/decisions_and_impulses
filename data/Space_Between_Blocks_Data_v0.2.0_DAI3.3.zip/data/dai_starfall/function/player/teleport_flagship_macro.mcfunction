$teleport @s $(ship_x).5 238.0 -390.5 180 0
