# Force-load the player's complete prologue plot and starter escape craft before construction.
# Each rectangle is below vanilla's 256-chunk per-command ceiling.
$execute positioned $(ship_x) 0 0 run forceload add ~-145 -445 ~-1 -150
$execute positioned $(ship_x) 0 0 run forceload add ~0 -445 ~145 -150
$execute positioned $(ship_x) 0 0 run forceload add ~-16 680 ~16 735
