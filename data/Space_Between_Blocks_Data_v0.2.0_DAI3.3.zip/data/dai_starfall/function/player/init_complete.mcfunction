# Construct the real physical flagship/tutorial landscape and starter ship before the player enters the plot.
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/build_plot_macro with storage dai_starfall:ctx
function dai_starfall:player/release_plot_macro with storage dai_starfall:ctx
scoreboard players set @s ds_init 1
scoreboard players set @s ds_phase 1
function dai_starfall:item/give_multitool
function dai_starfall:food/give_starter
function dai_starfall:player/teleport_flagship_macro with storage dai_starfall:ctx
spawnpoint @s 0 80 0
gamemode survival @s
effect give @s minecraft:resistance 6 255 true
title @s times 10 60 20
title @s title {text:"AUROD // T:12942",color:"gold",bold:true}
title @s subtitle {text:"SURFACE COLLECTION DETAIL",color:"gray"}
tellraw @s [{text:"MISSION // ",color:"dark_purple",bold:true},{text:"Proceed through the flagship to the planetary drop bay.",color:"white"}]
