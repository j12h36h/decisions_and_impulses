$execute positioned $(ship_x) 0 0 run function dai_starfall:build/personal_relative
