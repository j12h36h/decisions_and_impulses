$spawnpoint @s $(ship_x) 44 -250
