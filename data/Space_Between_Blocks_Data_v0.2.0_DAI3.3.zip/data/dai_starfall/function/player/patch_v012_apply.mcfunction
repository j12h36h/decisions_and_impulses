# v0.1.12 retrofit: physically connect the existing starter core to its Drop Bay.
fill ~-3 66 708 ~3 66 709 minecraft:polished_blackstone
fill ~-3 71 708 ~3 71 709 minecraft:smooth_quartz
fill ~-3 67 708 ~-3 70 709 minecraft:iron_block
fill ~3 67 708 ~3 70 709 minecraft:iron_block
fill ~-2 67 707 ~2 70 710 minecraft:air
setblock ~0 69 709 minecraft:light[level=15]
setblock ~2 67 697 minecraft:air
setblock ~0 67 711 minecraft:air
setblock ~-7 69 718 minecraft:stone_button[face=wall,facing=east]
setblock ~-6 72 718 minecraft:light[level=15]
scoreboard players set @s ds_patch 112
