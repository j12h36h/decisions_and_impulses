# Flagship deployment button -> real floor hatch
$execute if score @s ds_phase matches 1 positioned $(ship_x) 0 0 if block ~-7 237 -299 minecraft:stone_button[powered=true] run function dai_starfall:scene/open_flagship_hatch
# Once below the real hull, auto-close the hatch; player continues a literal fall to private Aurod.
# phase-2 -> phase-3 is handled in the authoritative main tick using ds_y
# The visible extraction platform is authoritative. While still collecting, standing here forces a fresh carried-inventory validation.
$execute if score @s ds_phase matches 4 positioned $(ship_x) 44 -197 if entity @s[distance=..11] run function dai_starfall:scene/update_vinewood_count
execute if score @s ds_phase matches 4 if score @s ds_vines matches 12.. run function dai_starfall:scene/material_complete
# Once material is complete, the same physical platform starts the destruction sequence immediately; no leave/re-enter is required.
$execute if score @s ds_phase matches 5 positioned $(ship_x) 44 -197 if entity @s[distance=..11] run function dai_starfall:scene/destruction_start
# Cutscene timeline uses this player-specific physical flagship location.
execute if score @s ds_phase matches 6 run function dai_starfall:scene/destruction_tick_macro with storage dai_starfall:ctx
# Physical pod trigger: enter the pod and stand on its plate.
$execute if score @s ds_phase matches 7 positioned $(ship_x) 44 -154 if entity @s[distance=..4] run function dai_starfall:scene/pod_launch_start
# Follow visual shell during actual levitation ascent.
execute if score @s ds_phase matches 8 at @s run tp @e[tag=ds_pod_visual,distance=..12] ~ ~ ~
execute if score @s ds_phase matches 8 run function dai_starfall:scene/pod_launch_tick
# Escape craft Aurod deployment button opens a real hatch.
$execute if score @s ds_phase matches 10 positioned $(ship_x) 0 0 if block ~-7 69 718 minecraft:stone_button[powered=true] run function dai_starfall:travel/open_ship_hatch
# Hidden handoff occurs only after the player physically jumps below the ship.
$execute if score @s ds_phase matches 11 positioned $(ship_x) 62 718 if entity @s[distance=..12] if score #aurod_built ds_global matches 1 run function dai_starfall:travel/to_aurod
$execute if score @s ds_phase matches 11 positioned $(ship_x) 62 718 if entity @s[distance=..12] unless score #aurod_built ds_global matches 1 run effect give @s minecraft:slow_falling 2 0 true
$execute if score @s ds_phase matches 11 positioned $(ship_x) 62 718 if entity @s[distance=..12] unless score #aurod_built ds_global matches 1 run title @s actionbar {text:"NAV // AUROD SURFACE SYNCHRONIZING",color:"gold",bold:true}
