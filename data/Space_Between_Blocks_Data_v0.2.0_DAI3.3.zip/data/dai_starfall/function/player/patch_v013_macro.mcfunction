$execute positioned $(ship_x) 0 0 if loaded ~0 67 700 run function dai_starfall:player/patch_v013_apply
