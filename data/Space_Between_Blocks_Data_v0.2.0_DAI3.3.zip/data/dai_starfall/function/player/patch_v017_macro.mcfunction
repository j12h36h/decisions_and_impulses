$execute positioned $(ship_x) 0 0 if loaded ~0 44 -197 run function dai_starfall:player/patch_v017_apply
