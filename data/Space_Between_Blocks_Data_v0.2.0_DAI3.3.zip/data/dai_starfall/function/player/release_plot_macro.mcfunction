# Release temporary construction tickets after the physical plot exists.
$execute positioned $(ship_x) 0 0 run forceload remove ~-145 -445 ~-1 -150
$execute positioned $(ship_x) 0 0 run forceload remove ~0 -445 ~145 -150
$execute positioned $(ship_x) 0 0 run forceload remove ~-16 680 ~16 735
