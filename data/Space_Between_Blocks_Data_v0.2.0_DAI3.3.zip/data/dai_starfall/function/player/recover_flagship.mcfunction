function dai_starfall:physics/restore_normal
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/teleport_flagship_macro with storage dai_starfall:ctx
effect give @s minecraft:resistance 3 255 true
title @s times 5 30 10
title @s title {text:"FLAGSHIP CHECKPOINT",color:"gold","bold":true}
