# Do not build into unloaded void chunks. Wait until every forced construction region is entity-ticking.
$execute positioned $(ship_x) 0 0 if loaded ~-145 80 -445 if loaded ~-1 80 -150 if loaded ~0 80 -445 if loaded ~145 80 -150 if loaded ~0 80 700 run function dai_starfall:player/init_complete
