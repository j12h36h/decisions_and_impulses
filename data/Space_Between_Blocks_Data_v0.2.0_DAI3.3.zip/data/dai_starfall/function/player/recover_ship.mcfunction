function dai_starfall:physics/restore_normal
effect give @s minecraft:resistance 5 255 true
effect give @s minecraft:slow_falling 3 0 true
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/recover_ship_macro with storage dai_starfall:ctx
tellraw @s {"text":"LIFE SUPPORT // hull-breach recovery engaged","color":"gold"}
