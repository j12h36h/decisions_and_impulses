# DAI 3.3 MAIN-experience reconnect lifecycle.
# Legacy/dev worlds that predate lifecycle metadata are initialized safely here.
execute unless entity @s[tag=ds_player] run function dai_starfall:player/first_join

# Reconcile only state that can be lost outside scoreboard persistence.
execute if score @s ds_phase matches 3..5 unless entity @s[tag=ds_aurod_gravity_applied] run function dai_starfall:physics/apply_aurod
execute if score @s ds_phase matches 12..13 unless entity @s[tag=ds_aurod_gravity_applied] run function dai_starfall:physics/apply_aurod
execute if entity @s[tag=ds_aurod_gravity_applied] if score @s ds_phase matches ..2 run function dai_starfall:physics/restore_normal
execute if entity @s[tag=ds_aurod_gravity_applied] if score @s ds_phase matches 6..11 run function dai_starfall:physics/restore_normal
execute if entity @s[tag=ds_aurod_gravity_applied] if score @s ds_phase matches 14.. run function dai_starfall:physics/restore_normal
