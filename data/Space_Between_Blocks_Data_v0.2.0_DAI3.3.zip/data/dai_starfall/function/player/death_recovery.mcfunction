scoreboard players operation @s ds_seen_deaths = @s ds_deaths
# Never allow immediate-respawn to strand a tutorial player at the global void spawn.
execute if score @s ds_phase matches 1..2 run function dai_starfall:player/recover_flagship
execute if score @s ds_phase matches 3 run function dai_starfall:scene/tutorial_landed
execute if score @s ds_phase matches 3..5 run function dai_starfall:player/recover_aurod
execute if score @s ds_phase matches 7 run function dai_starfall:scene/retry_escape
execute if score @s ds_phase matches 12 run function dai_starfall:travel/return_ship
execute if score @s ds_phase matches 9..10 run function dai_starfall:player/recover_ship
