function dai_starfall:build/extraction_link_relative
scoreboard players set @s ds_patch 17
