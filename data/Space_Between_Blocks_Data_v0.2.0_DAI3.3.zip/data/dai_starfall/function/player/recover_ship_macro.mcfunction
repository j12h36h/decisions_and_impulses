$teleport @s $(ship_x).5 67.0 700.5 0 0
$spawnpoint @s $(ship_x) 67 700
