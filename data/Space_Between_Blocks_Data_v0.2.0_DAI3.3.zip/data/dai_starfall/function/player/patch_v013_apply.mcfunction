# v0.1.13 retrofit: seal the inherited core doorway and finish the starter craft glazing.
fill ~-4 67 693 ~4 73 693 minecraft:tinted_glass
fill ~-7 69 696 ~-7 72 704 minecraft:tinted_glass
fill ~7 69 696 ~7 72 704 minecraft:tinted_glass
# Reinforce the connector floor/roof and rear bay interface.
fill ~-3 66 708 ~3 66 709 minecraft:polished_blackstone
fill ~-3 71 708 ~3 71 709 minecraft:smooth_quartz
fill ~-3 67 708 ~-3 70 709 minecraft:iron_block
fill ~3 67 708 ~3 70 709 minecraft:iron_block
fill ~-2 67 707 ~2 70 710 minecraft:air
setblock ~0 69 709 minecraft:light[level=15]
bossbar set dai_starfall:vinewood_0 name {"text":"AUROD // VINEWOOD COLLECTED 0 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_1 name {"text":"AUROD // VINEWOOD COLLECTED 1 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_2 name {"text":"AUROD // VINEWOOD COLLECTED 2 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_3 name {"text":"AUROD // VINEWOOD COLLECTED 3 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_4 name {"text":"AUROD // VINEWOOD COLLECTED 4 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_5 name {"text":"AUROD // VINEWOOD COLLECTED 5 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_6 name {"text":"AUROD // VINEWOOD COLLECTED 6 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_7 name {"text":"AUROD // VINEWOOD COLLECTED 7 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_8 name {"text":"AUROD // VINEWOOD COLLECTED 8 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_9 name {"text":"AUROD // VINEWOOD COLLECTED 9 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_10 name {"text":"AUROD // VINEWOOD COLLECTED 10 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_11 name {"text":"AUROD // VINEWOOD COLLECTED 11 / 12","color":"gold","bold":true}
bossbar set dai_starfall:vinewood_12 name {"text":"AUROD // VINEWOOD COLLECTED 12 / 12","color":"gold","bold":true}
scoreboard players set @s ds_patch 113
