$execute positioned $(ship_x) 0 0 run fill ~-3 66 715 ~3 66 721 minecraft:air
