function dai_starfall:physics/restore_normal
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:player/teleport_ship_macro with storage dai_starfall:ctx
scoreboard players set @s ds_phase 10
effect give @s minecraft:resistance 2 255 true
title @s title {text:"SHIP LINK RESTORED",color:"gold",bold:true}
title @s subtitle {text:"AUROD REMAINS AVAILABLE",color:"gray"}
