scoreboard players set @s ds_phase 12
effect give @s minecraft:resistance 2 255 true
particle minecraft:dust_plume ~ ~0.2 ~ 2.8 0.2 2.8 0.2 90 force @a[distance=..96]
playsound minecraft:entity.generic.explode master @a[distance=..96] ~ ~ ~ 0.8 1.5
tellraw @s [{text:"OBJECTIVE // ",color:"dark_purple",bold:true},{text:"GO TO SHIP. Reach the extraction beacon when ready.",color:"white"}]
