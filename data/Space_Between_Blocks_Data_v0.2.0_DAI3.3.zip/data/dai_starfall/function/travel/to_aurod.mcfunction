effect clear @s minecraft:slow_falling
function dai_starfall:physics/apply_aurod
effect give @s minecraft:resistance 35 255 true
teleport @s 0.5 270.0 100000.5 0 78
scoreboard players set @s ds_phase 13
execute store result storage dai_starfall:ctx ship_x int 1 run scoreboard players get @s ds_ship_x
function dai_starfall:travel/close_ship_hatch_macro with storage dai_starfall:ctx
title @s times 5 30 5
title @s title {text:"AUROD",color:"gold",bold:true}
title @s subtitle {text:"T:16950 // SHARED",color:"light_purple"}
playsound minecraft:entity.elytra.flying master @s ~ ~ ~ 1.3 0.7
