# 15x7x7 universal transverse corridor module; length east/west
fill ~-7 ~ ~-3 ~7 ~ ~3 minecraft:polished_blackstone
fill ~-7 ~1 ~-3 ~7 ~6 ~-3 minecraft:iron_block
fill ~-7 ~1 ~3 ~7 ~6 ~3 minecraft:iron_block
fill ~-7 ~7 ~-3 ~7 ~7 ~3 minecraft:smooth_quartz
fill ~-7 ~1 ~-2 ~7 ~6 ~2 minecraft:air
setblock ~ ~-1 ~ minecraft:chiseled_deepslate
setblock ~-4 ~5 ~ minecraft:light[level=15]
setblock ~4 ~5 ~ minecraft:light[level=15]
