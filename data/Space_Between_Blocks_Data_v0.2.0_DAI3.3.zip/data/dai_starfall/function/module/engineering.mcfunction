# 15x9x15 engineering module
function dai_starfall:module/core
setblock ~ ~-1 ~ minecraft:blast_furnace[facing=north]
setblock ~-4 ~1 ~-3 minecraft:blast_furnace[facing=east]
setblock ~4 ~1 ~-3 minecraft:smoker[facing=west]
setblock ~-4 ~1 ~3 minecraft:crafter
setblock ~4 ~1 ~3 minecraft:dropper[facing=up]
