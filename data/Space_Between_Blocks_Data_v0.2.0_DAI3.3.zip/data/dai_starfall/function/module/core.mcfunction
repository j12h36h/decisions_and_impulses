# 15x9x15 universal ship core module; origin at floor-center
fill ~-7 ~ ~-7 ~7 ~ ~7 minecraft:polished_blackstone
fill ~-7 ~1 ~-7 ~7 ~8 ~-7 minecraft:iron_block
fill ~-7 ~1 ~7 ~7 ~8 ~7 minecraft:iron_block
fill ~-7 ~1 ~-6 ~-7 ~8 ~6 minecraft:iron_block
fill ~7 ~1 ~-6 ~7 ~8 ~6 minecraft:iron_block
fill ~-7 ~9 ~-7 ~7 ~9 ~7 minecraft:smooth_quartz
fill ~-5 ~1 ~-5 ~5 ~8 ~5 minecraft:air
setblock ~ ~-1 ~ minecraft:lodestone
setblock ~0 ~5 ~-6 minecraft:light[level=15]
setblock ~0 ~5 ~6 minecraft:light[level=15]
setblock ~-6 ~5 ~0 minecraft:light[level=15]
setblock ~6 ~5 ~0 minecraft:light[level=15]
fill ~-2 ~1 ~-7 ~2 ~4 ~-7 minecraft:air
fill ~-2 ~1 ~7 ~2 ~4 ~7 minecraft:air
