# 7x7x15 universal corridor module; length north/south
fill ~-3 ~ ~-7 ~3 ~ ~7 minecraft:polished_blackstone
fill ~-3 ~1 ~-7 ~-3 ~6 ~7 minecraft:iron_block
fill ~3 ~1 ~-7 ~3 ~6 ~7 minecraft:iron_block
fill ~-3 ~7 ~-7 ~3 ~7 ~7 minecraft:smooth_quartz
fill ~-2 ~1 ~-7 ~2 ~6 ~7 minecraft:air
setblock ~ ~-1 ~ minecraft:chiseled_deepslate
setblock ~0 ~5 ~-4 minecraft:light[level=15]
setblock ~0 ~5 ~4 minecraft:light[level=15]
