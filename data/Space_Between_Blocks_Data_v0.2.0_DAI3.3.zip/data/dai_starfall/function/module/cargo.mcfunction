# 15x9x15 cargo module
function dai_starfall:module/core
setblock ~ ~-1 ~ minecraft:barrel
setblock ~-5 ~1 ~-4 minecraft:barrel[facing=up]
setblock ~-5 ~1 ~-2 minecraft:barrel[facing=up]
setblock ~-5 ~1 ~0 minecraft:barrel[facing=up]
setblock ~5 ~1 ~-4 minecraft:barrel[facing=up]
setblock ~5 ~1 ~-2 minecraft:barrel[facing=up]
setblock ~5 ~1 ~0 minecraft:barrel[facing=up]
