# 17x11x17 universal planetary drop bay
fill ~-8 ~ ~-8 ~8 ~ ~8 minecraft:polished_blackstone
fill ~-8 ~1 ~-8 ~8 ~10 ~-8 minecraft:iron_block
fill ~-8 ~1 ~8 ~8 ~10 ~8 minecraft:iron_block
fill ~-8 ~1 ~-7 ~-8 ~10 ~7 minecraft:iron_block
fill ~8 ~1 ~-7 ~8 ~10 ~7 minecraft:iron_block
fill ~-8 ~11 ~-8 ~8 ~11 ~8 minecraft:smooth_quartz
fill ~-6 ~1 ~-6 ~6 ~10 ~6 minecraft:air
setblock ~ ~-1 ~ minecraft:crying_obsidian
fill ~-3 ~ ~-3 ~3 ~ ~3 minecraft:iron_block
setblock ~0 ~4 ~-7 minecraft:light[level=15]
setblock ~0 ~4 ~7 minecraft:light[level=15]
