# One static bossbar per progress value lets multiple players see independent values without dynamic bossbar IDs.
bossbar add dai_starfall:vinewood_0 {"text":"AUROD // VINEWOOD COLLECTED 0 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_1 {"text":"AUROD // VINEWOOD COLLECTED 1 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_2 {"text":"AUROD // VINEWOOD COLLECTED 2 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_3 {"text":"AUROD // VINEWOOD COLLECTED 3 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_4 {"text":"AUROD // VINEWOOD COLLECTED 4 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_5 {"text":"AUROD // VINEWOOD COLLECTED 5 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_6 {"text":"AUROD // VINEWOOD COLLECTED 6 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_7 {"text":"AUROD // VINEWOOD COLLECTED 7 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_8 {"text":"AUROD // VINEWOOD COLLECTED 8 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_9 {"text":"AUROD // VINEWOOD COLLECTED 9 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_10 {"text":"AUROD // VINEWOOD COLLECTED 10 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_11 {"text":"AUROD // VINEWOOD COLLECTED 11 / 12","color":"gold","bold":true}
bossbar add dai_starfall:vinewood_12 {"text":"AUROD // VINEWOOD COLLECTED 12 / 12","color":"yellow","bold":true}
bossbar add dai_starfall:objective_complete {"text":"✓ VINEWOOD COMPLETE // RETURN TO BEACON","color":"green","bold":true}
bossbar set dai_starfall:vinewood_0 max 12
bossbar set dai_starfall:vinewood_1 max 12
bossbar set dai_starfall:vinewood_2 max 12
bossbar set dai_starfall:vinewood_3 max 12
bossbar set dai_starfall:vinewood_4 max 12
bossbar set dai_starfall:vinewood_5 max 12
bossbar set dai_starfall:vinewood_6 max 12
bossbar set dai_starfall:vinewood_7 max 12
bossbar set dai_starfall:vinewood_8 max 12
bossbar set dai_starfall:vinewood_9 max 12
bossbar set dai_starfall:vinewood_10 max 12
bossbar set dai_starfall:vinewood_11 max 12
bossbar set dai_starfall:vinewood_12 max 12
bossbar set dai_starfall:objective_complete max 1
bossbar set dai_starfall:vinewood_0 value 0
bossbar set dai_starfall:vinewood_1 value 1
bossbar set dai_starfall:vinewood_2 value 2
bossbar set dai_starfall:vinewood_3 value 3
bossbar set dai_starfall:vinewood_4 value 4
bossbar set dai_starfall:vinewood_5 value 5
bossbar set dai_starfall:vinewood_6 value 6
bossbar set dai_starfall:vinewood_7 value 7
bossbar set dai_starfall:vinewood_8 value 8
bossbar set dai_starfall:vinewood_9 value 9
bossbar set dai_starfall:vinewood_10 value 10
bossbar set dai_starfall:vinewood_11 value 11
bossbar set dai_starfall:vinewood_12 value 12
bossbar set dai_starfall:objective_complete value 1
bossbar set dai_starfall:vinewood_0 color yellow
bossbar set dai_starfall:vinewood_1 color yellow
bossbar set dai_starfall:vinewood_2 color yellow
bossbar set dai_starfall:vinewood_3 color yellow
bossbar set dai_starfall:vinewood_4 color yellow
bossbar set dai_starfall:vinewood_5 color yellow
bossbar set dai_starfall:vinewood_6 color yellow
bossbar set dai_starfall:vinewood_7 color yellow
bossbar set dai_starfall:vinewood_8 color yellow
bossbar set dai_starfall:vinewood_9 color yellow
bossbar set dai_starfall:vinewood_10 color yellow
bossbar set dai_starfall:vinewood_11 color yellow
bossbar set dai_starfall:vinewood_12 color yellow
bossbar set dai_starfall:objective_complete color green
bossbar set dai_starfall:vinewood_0 style notched_12
bossbar set dai_starfall:vinewood_1 style notched_12
bossbar set dai_starfall:vinewood_2 style notched_12
bossbar set dai_starfall:vinewood_3 style notched_12
bossbar set dai_starfall:vinewood_4 style notched_12
bossbar set dai_starfall:vinewood_5 style notched_12
bossbar set dai_starfall:vinewood_6 style notched_12
bossbar set dai_starfall:vinewood_7 style notched_12
bossbar set dai_starfall:vinewood_8 style notched_12
bossbar set dai_starfall:vinewood_9 style notched_12
bossbar set dai_starfall:vinewood_10 style notched_12
bossbar set dai_starfall:vinewood_11 style notched_12
bossbar set dai_starfall:vinewood_12 style notched_12
bossbar set dai_starfall:objective_complete style progress
bossbar set dai_starfall:vinewood_0 visible true
bossbar set dai_starfall:vinewood_1 visible true
bossbar set dai_starfall:vinewood_2 visible true
bossbar set dai_starfall:vinewood_3 visible true
bossbar set dai_starfall:vinewood_4 visible true
bossbar set dai_starfall:vinewood_5 visible true
bossbar set dai_starfall:vinewood_6 visible true
bossbar set dai_starfall:vinewood_7 visible true
bossbar set dai_starfall:vinewood_8 visible true
bossbar set dai_starfall:vinewood_9 visible true
bossbar set dai_starfall:vinewood_10 visible true
bossbar set dai_starfall:vinewood_11 visible true
bossbar set dai_starfall:vinewood_12 visible true
bossbar set dai_starfall:objective_complete visible true
scoreboard players set #quest_bars ds_global 1
