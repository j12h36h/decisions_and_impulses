# Clear prior viewers first so a player never retains a stale progress bar after their score changes.
bossbar set dai_starfall:vinewood_0 players
bossbar set dai_starfall:vinewood_1 players
bossbar set dai_starfall:vinewood_2 players
bossbar set dai_starfall:vinewood_3 players
bossbar set dai_starfall:vinewood_4 players
bossbar set dai_starfall:vinewood_5 players
bossbar set dai_starfall:vinewood_6 players
bossbar set dai_starfall:vinewood_7 players
bossbar set dai_starfall:vinewood_8 players
bossbar set dai_starfall:vinewood_9 players
bossbar set dai_starfall:vinewood_10 players
bossbar set dai_starfall:vinewood_11 players
bossbar set dai_starfall:vinewood_12 players
bossbar set dai_starfall:objective_complete players

# Assign viewers by their own phase/progress. Players at different counts can coexist safely.
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=0}] run bossbar set dai_starfall:vinewood_0 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=0}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=1}] run bossbar set dai_starfall:vinewood_1 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=1}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=2}] run bossbar set dai_starfall:vinewood_2 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=2}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=3}] run bossbar set dai_starfall:vinewood_3 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=3}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=4}] run bossbar set dai_starfall:vinewood_4 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=4}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=5}] run bossbar set dai_starfall:vinewood_5 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=5}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=6}] run bossbar set dai_starfall:vinewood_6 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=6}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=7}] run bossbar set dai_starfall:vinewood_7 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=7}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=8}] run bossbar set dai_starfall:vinewood_8 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=8}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=9}] run bossbar set dai_starfall:vinewood_9 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=9}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=10}] run bossbar set dai_starfall:vinewood_10 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=10}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=11}] run bossbar set dai_starfall:vinewood_11 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=11}]
execute if entity @a[tag=ds_player,scores={ds_phase=4,ds_vines=12..}] run bossbar set dai_starfall:vinewood_12 players @a[tag=ds_player,scores={ds_phase=4,ds_vines=12..}]
# Completion remains visible for the entire return-to-beacon phase, not merely for a short timer.
execute if entity @a[tag=ds_player,scores={ds_phase=5}] run bossbar set dai_starfall:objective_complete players @a[tag=ds_player,scores={ds_phase=5}]
# Keep the short timer as a transition fallback if another scene changes phase immediately.
execute if entity @a[tag=ds_player,scores={ds_ui_complete=1..}] run bossbar set dai_starfall:objective_complete players @a[tag=ds_player,scores={ds_ui_complete=1..}]
