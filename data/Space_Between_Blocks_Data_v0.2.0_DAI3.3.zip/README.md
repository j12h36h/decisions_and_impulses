# Space Between Blocks — Data v0.2.0

DAI 3.3 MAIN experience.

A science-fiction survival/exploration experience built around a physical flagship tutorial, low-gravity planetary descent, material collection, catastrophic extraction failure, emergency escape, persistent personal ships, and a shared post-crash Aurod world.

The matching Resource Pack uses companion ID `dai_space_experience`.
