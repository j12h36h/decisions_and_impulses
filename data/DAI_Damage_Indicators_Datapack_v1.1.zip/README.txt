DAI Damage Indicators v1.1
Minecraft Java 26.2

Changes in v1.1
- Added a compact living-entity health readout near the crosshair.
- Shows current / maximum health while the player's view ray intersects a living entity.
- Health is displayed at tenth-point precision.
- Floating outgoing-damage numbers now remain visible for ~1.9 seconds (38 ticks).
- Slowed upward drift to suit the longer lifetime.

Commands
/function dai_damage_indicators:enable
/function dai_damage_indicators:disable
/function dai_damage_indicators:toggle

Notes
- Floating damage detection remains based on minecraft.damage_dealt and nearby HurtTime.
- The crosshair health HUD uses a short datapack ray probe and does not require a D.A.I. Java change.
- The resource pack from v1.0 remains compatible with this datapack patch.
