
# Current execution position is either the victim or the attacker's fallback point.
execute positioned ~ ~1.35 ~ summon minecraft:text_display run function dai_damage_indicators:display/setup
