
tag @s add dai_di_display
scoreboard players set @s di_age 0
scoreboard players operation @s di_whole = #whole di_whole
scoreboard players operation @s di_dec = #dec di_dec

data merge entity @s {billboard:'center',shadow:1b,see_through:1b,background:0,alignment:'center',view_range:1.5f,text:{text:'',font:'dai_damage_indicators:damage',color:'#ff5555',bold:true,extra:[{score:{name:'*',objective:'di_whole'}},{text:'.'},{score:{name:'*',objective:'di_dec'}}]}}
