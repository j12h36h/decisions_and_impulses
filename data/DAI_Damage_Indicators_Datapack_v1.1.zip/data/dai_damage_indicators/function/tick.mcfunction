# Initialize new/reloaded players once.
execute as @a[tag=!dai_di_init] run function dai_damage_indicators:player/init

# Read outgoing damage deltas and update the crosshair health HUD for enabled players.
execute as @a[tag=dai_di_init,scores={di_enable=1..}] at @s run function dai_damage_indicators:player/tick

# Float active indicators gently upward for ~1.9 seconds, then clean them up.
scoreboard players add @e[type=minecraft:text_display,tag=dai_di_display] di_age 1
execute as @e[type=minecraft:text_display,tag=dai_di_display,scores={di_age=..37}] at @s run tp @s ~ ~0.020 ~
kill @e[type=minecraft:text_display,tag=dai_di_display,scores={di_age=38..}]
