scoreboard players operation @s di_prev = @s di_dealt
scoreboard players set @s di_delta 0
scoreboard players set @s di_whole 0
scoreboard players set @s di_dec 0
scoreboard players set @s di_enable 1

# Assign this player a lightweight runtime owner id for their crosshair HUD display.
scoreboard players add #next_id di_const 1
scoreboard players operation @s di_id = #next_id di_const

tag @s add dai_di_init
