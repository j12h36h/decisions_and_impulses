
# Minecraft's damage_dealt statistic is stored in tenths of a health point.
# Split the delta into whole + decimal scores so text_display can render X.Y
# without requiring command macros or hard-coded damage buckets.
scoreboard players operation @s di_whole = @s di_delta
scoreboard players operation @s di_whole /= #ten di_const
scoreboard players operation @s di_dec = @s di_delta
scoreboard players operation @s di_dec %= #ten di_const

# Copy this hit into short-lived global scratch scores. Commands execute
# sequentially, and display/spawn immediately copies these scores onto the
# newly-created text_display entity.
scoreboard players operation #whole di_whole = @s di_whole
scoreboard players operation #dec di_dec = @s di_dec

# Don't mistake the attacker for the victim if the attacker was also recently hurt.
tag @s add dai_di_attacker

# Find recently hurt entities in a small combat radius. Entities without HurtTime
# keep di_tmp at zero. This is intentionally best-effort and avoids Java changes.
scoreboard players set @e[distance=..8,tag=!dai_di_attacker] di_tmp 0
execute as @e[distance=..8,tag=!dai_di_attacker,type=!minecraft:text_display] store result score @s di_tmp run data get entity @s HurtTime 1

# Prefer the nearest entity whose HurtTime is currently positive.
execute as @e[distance=..8,tag=!dai_di_attacker,scores={di_tmp=1..},sort=nearest,limit=1] at @s run function dai_damage_indicators:display/spawn

# If no hurt entity can be resolved (for example, a victim died immediately),
# render the same indicator a short distance in front of the attacker instead.
execute unless entity @e[distance=..8,tag=!dai_di_attacker,scores={di_tmp=1..},sort=nearest,limit=1] positioned ^ ^1.15 ^2 run function dai_damage_indicators:display/spawn

tag @s remove dai_di_attacker
