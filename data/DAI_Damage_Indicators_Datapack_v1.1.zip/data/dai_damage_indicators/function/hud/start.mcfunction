# The viewer tag provides a stable reference while the raycast temporarily executes
# as the living entity under the crosshair.
tag @s add dai_di_viewer
scoreboard players set #found di_const 0
scoreboard players set @s di_ray 0

# Make sure this player has a HUD text_display in the current dimension.
scoreboard players set #has_display di_const 0
execute as @e[type=minecraft:text_display,tag=dai_di_health_display] if score @s di_owner = @a[tag=dai_di_viewer,limit=1] di_id run scoreboard players set #has_display di_const 1
execute if score #has_display di_const matches 0 run function dai_damage_indicators:hud/create

# Park the owned display well below the viewer unless this tick resolves a target.
execute positioned ~ ~-64 ~ as @e[type=minecraft:text_display,tag=dai_di_health_display] if score @s di_owner = @a[tag=dai_di_viewer,limit=1] di_id run tp @s ~ ~ ~

# Probe from the player's eyes in 0.25-block increments out to roughly 5.5 blocks.
execute anchored eyes positioned ^ ^ ^0.50 run function dai_damage_indicators:hud/ray

tag @s remove dai_di_viewer
