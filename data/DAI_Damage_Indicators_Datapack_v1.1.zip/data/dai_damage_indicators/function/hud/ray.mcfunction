# Look for a non-player entity at this point. Only entities exposing a Health value
# are accepted, so items/projectiles/displays do not become HUD targets.
execute if score #found di_const matches 0 as @e[distance=..0.42,type=!minecraft:player,type=!minecraft:text_display,sort=nearest] if data entity @s Health run function dai_damage_indicators:hud/found

# Continue forward until a living target is found or the ray reaches its limit.
scoreboard players add @a[tag=dai_di_viewer,limit=1] di_ray 1
execute if score #found di_const matches 0 if score @a[tag=dai_di_viewer,limit=1] di_ray matches ..20 positioned ^ ^ ^0.25 run function dai_damage_indicators:hud/ray
