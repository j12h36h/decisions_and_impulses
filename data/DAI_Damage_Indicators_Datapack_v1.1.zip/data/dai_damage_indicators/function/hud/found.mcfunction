# Only the first living entity intersected by the ray should win this tick.
execute if score #found di_const matches 1.. run return 0
scoreboard players set #found di_const 1

# Capture current and maximum health at tenth-point precision.
execute store result score #hcur di_hcur run data get entity @s Health 10
execute store result score #hmax di_hmax run attribute @s minecraft:max_health get 10

# Split tenths into whole and decimal digits.
scoreboard players operation #hcur_w di_hcur_w = #hcur di_hcur
scoreboard players operation #hcur_w di_hcur_w /= #ten di_const
scoreboard players operation #hcur_d di_hcur_d = #hcur di_hcur
scoreboard players operation #hcur_d di_hcur_d %= #ten di_const
scoreboard players operation #hmax_w di_hmax_w = #hmax di_hmax
scoreboard players operation #hmax_w di_hmax_w /= #ten di_const
scoreboard players operation #hmax_d di_hmax_d = #hmax di_hmax
scoreboard players operation #hmax_d di_hmax_d %= #ten di_const

# Copy the values onto this viewer's display and place it just beneath the crosshair.
execute as @e[type=minecraft:text_display,tag=dai_di_health_display] if score @s di_owner = @a[tag=dai_di_viewer,limit=1] di_id run scoreboard players operation @s di_hcur_w = #hcur_w di_hcur_w
execute as @e[type=minecraft:text_display,tag=dai_di_health_display] if score @s di_owner = @a[tag=dai_di_viewer,limit=1] di_id run scoreboard players operation @s di_hcur_d = #hcur_d di_hcur_d
execute as @e[type=minecraft:text_display,tag=dai_di_health_display] if score @s di_owner = @a[tag=dai_di_viewer,limit=1] di_id run scoreboard players operation @s di_hmax_w = #hmax_w di_hmax_w
execute as @e[type=minecraft:text_display,tag=dai_di_health_display] if score @s di_owner = @a[tag=dai_di_viewer,limit=1] di_id run scoreboard players operation @s di_hmax_d = #hmax_d di_hmax_d

execute as @a[tag=dai_di_viewer,limit=1] anchored eyes positioned ^ ^-0.17 ^1.25 as @e[type=minecraft:text_display,tag=dai_di_health_display] if score @s di_owner = @a[tag=dai_di_viewer,limit=1] di_id run tp @s ~ ~ ~
