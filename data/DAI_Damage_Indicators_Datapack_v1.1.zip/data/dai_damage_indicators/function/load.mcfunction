# DAI Damage Indicators v1.1
# Minecraft Java 26.2 / Data Pack 107.1

scoreboard objectives add di_dealt minecraft.custom:minecraft.damage_dealt
scoreboard objectives add di_prev dummy
scoreboard objectives add di_delta dummy
scoreboard objectives add di_whole dummy
scoreboard objectives add di_dec dummy
scoreboard objectives add di_age dummy
scoreboard objectives add di_tmp dummy
scoreboard objectives add di_enable dummy
scoreboard objectives add di_const dummy

# Crosshair health HUD state.
scoreboard objectives add di_id dummy
scoreboard objectives add di_owner dummy
scoreboard objectives add di_ray dummy
scoreboard objectives add di_hcur dummy
scoreboard objectives add di_hmax dummy
scoreboard objectives add di_hcur_w dummy
scoreboard objectives add di_hcur_d dummy
scoreboard objectives add di_hmax_w dummy
scoreboard objectives add di_hmax_d dummy

scoreboard players set #ten di_const 10
scoreboard players set #next_id di_const 0
scoreboard players set #found di_const 0
scoreboard players set #has_display di_const 0

# Force players to initialize from their CURRENT lifetime stat rather than
# showing all historic damage as one giant number after /reload.
tag @a remove dai_di_init

# Remove stale displays from a previous load/reload.
kill @e[type=minecraft:text_display,tag=dai_di_display]
kill @e[type=minecraft:text_display,tag=dai_di_health_display]

tellraw @a [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'v1.1 loaded.',color:'gray'}]
