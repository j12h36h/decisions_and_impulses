scoreboard players set @s di_enable 0

# Park this player's HUD display out of sight immediately.
tag @s add dai_di_viewer
execute positioned ~ ~-64 ~ as @e[type=minecraft:text_display,tag=dai_di_health_display] if score @s di_owner = @a[tag=dai_di_viewer,limit=1] di_id run tp @s ~ ~ ~
tag @s remove dai_di_viewer

tellraw @s [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'Disabled.',color:'red'}]
