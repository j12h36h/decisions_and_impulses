clear @s
give @s boxhead:combat_knife 1
give @s boxhead:pistol 1
give @s boxhead:light_round 48
