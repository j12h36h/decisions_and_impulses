# Lethal projectile cleanup. Reward/death FX are guaranteed exactly once at the impact point,
# then the dead native carrier is removed from targeting and moved below the arena immediately.
execute if entity @s[type=boxhead:zombie,nbt={Health:0.0f},tag=!bh_death_rewarded] run function boxhead:enemy/death/zombie
execute if entity @s[type=boxhead:mangled,nbt={Health:0.0f},tag=!bh_death_rewarded] run function boxhead:enemy/death/mangled
execute if entity @s[type=boxhead:mutant,nbt={Health:0.0f},tag=!bh_death_rewarded] run function boxhead:enemy/death/mutant
execute if entity @s[type=boxhead:giant,nbt={Health:0.0f},tag=!bh_death_rewarded] run function boxhead:enemy/death/giant
execute if entity @s[nbt={Health:0.0f}] run tag @s remove bh_infected
execute if entity @s[nbt={Health:0.0f}] at @s run tp @s ~ -256 ~
