# Boxhead Village Box v0.3.2 rebuild
# Replaces the leaking fountain / bare block layout with a denser village while
# preserving the four cardinal combat lanes and barrier sockets.
kill @e[type=minecraft:marker,tag=bh_runtime_marker]
scoreboard players set #map_type bh_state 4

# --- Arena foundation -------------------------------------------------------
fill -54 59 -54 54 61 54 minecraft:stone
fill -50 62 -50 50 63 50 minecraft:dirt
fill -48 64 -48 48 64 48 minecraft:grass_block

# Main roads and stone edging. Keep cardinal lanes wide for infected pathing.
fill -48 64 -4 48 64 4 minecraft:dirt_path
fill -4 64 -48 4 64 48 minecraft:dirt_path
fill -48 64 -6 48 64 -5 minecraft:coarse_dirt
fill -48 64 5 48 64 6 minecraft:coarse_dirt
fill -6 64 -48 -5 64 48 minecraft:coarse_dirt
fill 5 64 -48 6 64 48 minecraft:coarse_dirt

# --- Central plaza / contained fountain ------------------------------------
fill -10 64 -10 10 64 10 minecraft:stone_bricks
fill -8 64 -8 8 64 8 minecraft:polished_andesite
fill -6 64 -6 6 64 6 minecraft:smooth_stone

# Proper retaining wall at water level: the old fountain had an exposed 9x9
# water sheet which could flow across the plaza.
fill -4 65 -4 4 65 4 minecraft:stone_bricks
fill -3 65 -3 3 65 3 minecraft:water
fill -1 65 -1 1 65 1 minecraft:chiseled_stone_bricks
setblock 0 66 0 minecraft:stone_brick_wall
setblock 0 67 0 minecraft:sea_lantern
setblock -4 66 -4 minecraft:lantern
setblock 4 66 -4 minecraft:lantern
setblock -4 66 4 minecraft:lantern
setblock 4 66 4 minecraft:lantern

# Plaza seating / planters
setblock -9 65 -7 minecraft:spruce_stairs[facing=east]
setblock -8 65 -7 minecraft:spruce_stairs[facing=west]
setblock 8 65 7 minecraft:spruce_stairs[facing=east]
setblock 9 65 7 minecraft:spruce_stairs[facing=west]
setblock -9 65 7 minecraft:oak_leaves[persistent=true]
setblock 9 65 -7 minecraft:oak_leaves[persistent=true]
setblock -9 66 7 minecraft:flowering_azalea
setblock 9 66 -7 minecraft:azalea

# --- Northwest inn ----------------------------------------------------------
fill -39 64 -36 -21 64 -21 minecraft:stone_bricks
fill -38 65 -35 -22 70 -22 minecraft:oak_planks hollow
fill -38 65 -35 -38 70 -35 minecraft:stripped_spruce_log
fill -22 65 -35 -22 70 -35 minecraft:stripped_spruce_log
fill -38 65 -22 -38 70 -22 minecraft:stripped_spruce_log
fill -22 65 -22 -22 70 -22 minecraft:stripped_spruce_log
fill -40 71 -37 -20 71 -20 minecraft:spruce_planks
fill -38 72 -35 -22 72 -22 minecraft:spruce_slab[type=bottom]
fill -32 65 -22 -29 67 -22 minecraft:air
fill -36 67 -22 -34 68 -22 minecraft:glass_pane
fill -26 67 -22 -24 68 -22 minecraft:glass_pane
setblock -36 65 -25 minecraft:barrel[facing=up]
setblock -35 65 -25 minecraft:barrel[facing=up]
setblock -24 65 -33 minecraft:crafting_table
setblock -23 65 -33 minecraft:chest[facing=west]
fill -39 65 -34 -39 74 -32 minecraft:bricks
setblock -39 75 -33 minecraft:campfire

# --- Northeast smithy / armory ---------------------------------------------
fill 18 64 -35 35 64 -20 minecraft:cobblestone
fill 19 65 -34 34 70 -21 minecraft:stone_bricks hollow
fill 19 65 -34 19 70 -34 minecraft:stripped_dark_oak_log
fill 34 65 -34 34 70 -34 minecraft:stripped_dark_oak_log
fill 19 65 -21 19 70 -21 minecraft:stripped_dark_oak_log
fill 34 65 -21 34 70 -21 minecraft:stripped_dark_oak_log
fill 17 71 -36 36 71 -19 minecraft:dark_oak_planks
fill 20 72 -33 33 72 -22 minecraft:dark_oak_slab[type=bottom]
fill 25 65 -21 28 67 -21 minecraft:air
fill 21 67 -21 23 68 -21 minecraft:iron_bars
fill 31 67 -21 33 68 -21 minecraft:iron_bars
setblock 22 65 -31 minecraft:anvil
setblock 24 65 -31 minecraft:smithing_table
setblock 31 65 -31 minecraft:blast_furnace[facing=south]
setblock 32 65 -31 minecraft:furnace[facing=south]
setblock 33 65 -31 minecraft:grindstone[face=floor,facing=south]
fill 35 65 -33 35 74 -31 minecraft:bricks
setblock 35 75 -32 minecraft:campfire

# --- Southwest store / residence -------------------------------------------
fill -39 64 20 -21 64 35 minecraft:stone_bricks
fill -38 65 21 -22 70 34 minecraft:spruce_planks hollow
fill -38 65 21 -38 70 21 minecraft:stripped_oak_log
fill -22 65 21 -22 70 21 minecraft:stripped_oak_log
fill -38 65 34 -38 70 34 minecraft:stripped_oak_log
fill -22 65 34 -22 70 34 minecraft:stripped_oak_log
fill -40 71 19 -20 71 36 minecraft:spruce_planks
fill -37 72 22 -23 72 33 minecraft:spruce_slab[type=bottom]
fill -32 65 21 -29 67 21 minecraft:air
fill -36 67 21 -34 68 21 minecraft:glass_pane
fill -26 67 21 -24 68 21 minecraft:glass_pane
setblock -36 65 31 minecraft:barrel[facing=up]
setblock -35 65 31 minecraft:barrel[facing=up]
setblock -24 65 31 minecraft:cartography_table
setblock -23 65 31 minecraft:chest[facing=west]

# --- Southeast chapel + graveyard ------------------------------------------
fill 20 64 21 35 64 36 minecraft:stone_bricks
fill 21 65 22 34 71 35 minecraft:calcite hollow
fill 21 65 22 21 71 22 minecraft:stone_bricks
fill 34 65 22 34 71 22 minecraft:stone_bricks
fill 21 65 35 21 71 35 minecraft:stone_bricks
fill 34 65 35 34 71 35 minecraft:stone_bricks
fill 19 72 20 36 72 37 minecraft:deepslate_tiles
fill 22 73 23 33 73 34 minecraft:deepslate_tile_slab[type=bottom]
fill 26 65 22 29 67 22 minecraft:air
fill 23 67 22 25 69 22 minecraft:light_blue_stained_glass_pane
fill 30 67 22 32 69 22 minecraft:light_blue_stained_glass_pane
setblock 27 66 34 minecraft:bell[attachment=floor,facing=north]
# Graveyard behind chapel
fill 38 64 21 47 64 36 minecraft:coarse_dirt
fill 38 65 21 47 65 21 minecraft:cobblestone_wall
fill 38 65 36 47 65 36 minecraft:cobblestone_wall
fill 38 65 21 38 65 36 minecraft:cobblestone_wall
fill 47 65 21 47 65 36 minecraft:cobblestone_wall
fill 42 65 21 43 65 21 minecraft:air
setblock 40 65 25 minecraft:stone_brick_wall
setblock 44 65 25 minecraft:stone_brick_wall
setblock 40 65 31 minecraft:stone_brick_wall
setblock 44 65 31 minecraft:stone_brick_wall
setblock 40 66 25 minecraft:stone_button[face=wall,facing=south]
setblock 44 66 25 minecraft:stone_button[face=wall,facing=south]
setblock 40 66 31 minecraft:stone_button[face=wall,facing=south]
setblock 44 66 31 minecraft:stone_button[face=wall,facing=south]

# --- West market ------------------------------------------------------------
fill -45 64 8 -16 64 17 minecraft:gravel
# Three open stalls, leaving combat movement between them.
fill -43 65 10 -39 65 14 minecraft:oak_planks
fill -43 66 10 -43 68 10 minecraft:oak_fence
fill -39 66 10 -39 68 10 minecraft:oak_fence
fill -43 66 14 -43 68 14 minecraft:oak_fence
fill -39 66 14 -39 68 14 minecraft:oak_fence
fill -44 69 9 -38 69 15 minecraft:red_wool
setblock -41 66 12 minecraft:barrel[facing=up]
fill -34 65 10 -30 65 14 minecraft:oak_planks
fill -34 66 10 -34 68 10 minecraft:oak_fence
fill -30 66 10 -30 68 10 minecraft:oak_fence
fill -34 66 14 -34 68 14 minecraft:oak_fence
fill -30 66 14 -30 68 14 minecraft:oak_fence
fill -35 69 9 -29 69 15 minecraft:white_wool
setblock -32 66 12 minecraft:barrel[facing=up]
fill -25 65 10 -21 65 14 minecraft:oak_planks
fill -25 66 10 -25 68 10 minecraft:oak_fence
fill -21 66 10 -21 68 10 minecraft:oak_fence
fill -25 66 14 -25 68 14 minecraft:oak_fence
fill -21 66 14 -21 68 14 minecraft:oak_fence
fill -26 69 9 -20 69 15 minecraft:yellow_wool
setblock -23 66 12 minecraft:barrel[facing=up]

# --- East farm / garden -----------------------------------------------------
fill 17 64 7 45 64 17 minecraft:oak_planks
fill 18 64 8 44 64 16 minecraft:farmland[moisture=7]
fill 30 64 8 31 64 16 minecraft:water
fill 19 65 9 29 65 10 minecraft:wheat[age=7]
fill 19 65 12 29 65 13 minecraft:carrots[age=7]
fill 19 65 15 29 65 15 minecraft:potatoes[age=7]
fill 32 65 9 43 65 10 minecraft:wheat[age=7]
fill 32 65 12 43 65 13 minecraft:beetroots[age=3]
fill 32 65 15 43 65 15 minecraft:carrots[age=7]
fill 17 65 7 45 65 7 minecraft:oak_fence
fill 17 65 17 45 65 17 minecraft:oak_fence
fill 17 65 7 17 65 17 minecraft:oak_fence
fill 45 65 7 45 65 17 minecraft:oak_fence
fill 28 65 7 34 65 7 minecraft:air
setblock 42 65 5 minecraft:hay_block
setblock 43 65 5 minecraft:hay_block
setblock 42 66 5 minecraft:hay_block

# --- Trees / landscaping ----------------------------------------------------
fill -46 65 -15 -46 69 -15 minecraft:oak_log
fill -48 69 -17 -44 72 -13 minecraft:oak_leaves[persistent=true]
fill 44 65 -9 44 69 -9 minecraft:oak_log
fill 42 69 -11 46 72 -7 minecraft:oak_leaves[persistent=true]
fill -12 65 42 -12 69 42 minecraft:oak_log
fill -14 69 40 -10 72 44 minecraft:oak_leaves[persistent=true]
fill 12 65 -43 12 69 -43 minecraft:oak_log
fill 10 69 -45 14 72 -41 minecraft:oak_leaves[persistent=true]
setblock -14 65 13 minecraft:flowering_azalea
setblock -12 65 15 minecraft:azalea
setblock 13 65 -14 minecraft:flowering_azalea
setblock 15 65 -12 minecraft:azalea
setblock -15 65 -13 minecraft:blue_orchid
setblock 14 65 14 minecraft:poppy

# Street lamps around the plaza / road approaches.
setblock -13 65 -8 minecraft:oak_fence
setblock -13 66 -8 minecraft:oak_fence
setblock -13 67 -8 minecraft:lantern
setblock 13 65 -8 minecraft:oak_fence
setblock 13 66 -8 minecraft:oak_fence
setblock 13 67 -8 minecraft:lantern
setblock -13 65 8 minecraft:oak_fence
setblock -13 66 8 minecraft:oak_fence
setblock -13 67 8 minecraft:lantern
setblock 13 65 8 minecraft:oak_fence
setblock 13 66 8 minecraft:oak_fence
setblock 13 67 8 minecraft:lantern
setblock -8 65 -13 minecraft:oak_fence
setblock -8 66 -13 minecraft:oak_fence
setblock -8 67 -13 minecraft:lantern
setblock 8 65 -13 minecraft:oak_fence
setblock 8 66 -13 minecraft:oak_fence
setblock 8 67 -13 minecraft:lantern
setblock -8 65 13 minecraft:oak_fence
setblock -8 66 13 minecraft:oak_fence
setblock -8 67 13 minecraft:lantern
setblock 8 65 13 minecraft:oak_fence
setblock 8 66 13 minecraft:oak_fence
setblock 8 67 13 minecraft:lantern

# --- Runtime spawn / barrier markers ---------------------------------------
# Infected enter from the four outer cardinal roads.
summon minecraft:marker -45 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 45 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 -45 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 45 {Tags:["bh_runtime_marker","bh_zspawn"]}
# Player spawns sit outside the fountain footprint with clear sight lines.
summon minecraft:marker -11 65 -11 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 11 65 11 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -11 65 11 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 11 65 -11 {Tags:["bh_runtime_marker","bh_player_spawn"]}

summon minecraft:marker -40 65 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 40 65 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 0 65 -40 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
summon minecraft:marker 0 65 40 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_barrier 180
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_bmax 180
fill -40 65 -1 -40 67 1 minecraft:oak_planks
fill 40 65 -1 40 67 1 minecraft:oak_planks
fill -1 65 -40 1 67 -40 minecraft:oak_planks
fill -1 65 40 1 67 40 minecraft:oak_planks

setworldspawn 0 65 12
tp @a 0 65 12
