# BOX TOWN — high-detail urban rebuild
kill @e[type=minecraft:marker,tag=bh_runtime_marker]
scoreboard players set #map_type bh_state 2
# Foundation / grass lots.
fill -62 62 -62 62 62 62 minecraft:stone
fill -60 63 -60 60 63 60 minecraft:grass_block
# Main asphalt cross and sidewalks.
fill -60 63 -8 60 63 8 minecraft:gray_concrete
fill -8 63 -60 8 63 60 minecraft:gray_concrete
fill -60 64 -10 60 64 -9 minecraft:smooth_stone
fill -60 64 9 60 64 10 minecraft:smooth_stone
fill -10 64 -60 -9 64 60 minecraft:smooth_stone
fill 9 64 -60 10 64 60 minecraft:smooth_stone
# Lane markings.
fill -54 64 -1 -49 64 0 minecraft:yellow_concrete
fill -42 64 -1 -37 64 0 minecraft:yellow_concrete
fill -30 64 -1 -25 64 0 minecraft:yellow_concrete
fill -18 64 -1 -13 64 0 minecraft:yellow_concrete
fill -6 64 -1 -1 64 0 minecraft:yellow_concrete
fill 6 64 -1 11 64 0 minecraft:yellow_concrete
fill 18 64 -1 23 64 0 minecraft:yellow_concrete
fill 30 64 -1 35 64 0 minecraft:yellow_concrete
fill 42 64 -1 47 64 0 minecraft:yellow_concrete
fill 54 64 -1 59 64 0 minecraft:yellow_concrete
fill -1 64 -54 0 64 -49 minecraft:yellow_concrete
fill -1 64 -42 0 64 -37 minecraft:yellow_concrete
fill -1 64 -30 0 64 -25 minecraft:yellow_concrete
fill -1 64 -18 0 64 -13 minecraft:yellow_concrete
fill -1 64 -6 0 64 -1 minecraft:yellow_concrete
fill -1 64 6 0 64 11 minecraft:yellow_concrete
fill -1 64 18 0 64 23 minecraft:yellow_concrete
fill -1 64 30 0 64 35 minecraft:yellow_concrete
fill -1 64 42 0 64 47 minecraft:yellow_concrete
fill -1 64 54 0 64 59 minecraft:yellow_concrete
# Central civic plaza with raised planters / memorial.
fill -8 64 -8 8 64 8 minecraft:polished_andesite
fill -5 65 -5 -3 65 -3 minecraft:stone_bricks
fill 3 65 -5 5 65 -3 minecraft:stone_bricks
fill -5 65 3 -3 65 5 minecraft:stone_bricks
fill 3 65 3 5 65 5 minecraft:stone_bricks
setblock -4 66 -4 minecraft:flowering_azalea
setblock 4 66 -4 minecraft:azalea
setblock -4 66 4 minecraft:azalea
setblock 4 66 4 minecraft:flowering_azalea
fill -1 65 -1 1 67 1 minecraft:stone_bricks
setblock 0 68 0 minecraft:lantern
# NW fire / emergency station.
fill -51 64 -49 -22 72 -24 minecraft:red_terracotta hollow
fill -50 64 -48 -23 64 -25 minecraft:smooth_stone
fill -49 73 -47 -24 73 -26 minecraft:white_concrete
fill -44 64 -24 -40 68 -24 air
fill -36 64 -24 -32 68 -24 air
fill -28 64 -24 -24 68 -24 air
fill -44 65 -24 -40 67 -24 minecraft:iron_bars
fill -36 65 -24 -32 67 -24 minecraft:iron_bars
fill -28 65 -24 -24 67 -24 minecraft:iron_bars
fill -48 66 -24 -46 68 -24 minecraft:glass_pane
setblock -47 65 -28 minecraft:bell[attachment=floor,facing=north]
setblock -47 66 -30 minecraft:barrel[facing=up]
# NE office / hardware block.
fill 23 64 -51 51 73 -25 minecraft:light_gray_concrete hollow
fill 24 64 -50 50 64 -26 minecraft:smooth_stone
fill 22 74 -52 52 74 -24 minecraft:polished_andesite
fill 31 64 -25 36 67 -25 air
fill 25 67 -25 29 70 -25 minecraft:cyan_stained_glass_pane
fill 39 67 -25 49 70 -25 minecraft:cyan_stained_glass_pane
fill 25 67 -51 49 70 -51 minecraft:cyan_stained_glass_pane
setblock 47 65 -29 minecraft:barrel[facing=up]
setblock 44 65 -29 minecraft:crafting_table
setblock 41 65 -29 minecraft:anvil
# SW brick apartment / diner block.
fill -52 64 23 -27 75 49 minecraft:bricks hollow
fill -51 64 24 -28 64 48 minecraft:smooth_stone
fill -53 76 22 -26 76 50 minecraft:dark_prismarine
fill -45 64 23 -40 67 23 air
fill -50 67 23 -47 70 23 minecraft:light_blue_stained_glass_pane
fill -38 67 23 -29 70 23 minecraft:light_blue_stained_glass_pane
fill -50 71 23 -44 73 23 minecraft:glass_pane
fill -39 71 23 -29 73 23 minecraft:glass_pane
# Diner awning / seating.
fill -50 64 16 -29 64 21 minecraft:smooth_stone
fill -49 68 18 -30 68 20 minecraft:red_wool
setblock -46 65 19 minecraft:oak_stairs[facing=south,half=bottom,shape=straight]
setblock -42 65 19 minecraft:oak_stairs[facing=south,half=bottom,shape=straight]
setblock -38 65 19 minecraft:oak_stairs[facing=south,half=bottom,shape=straight]
setblock -34 65 19 minecraft:oak_stairs[facing=south,half=bottom,shape=straight]
# SE motel / residence block.
fill 25 64 24 53 73 51 minecraft:spruce_planks hollow
fill 26 64 25 52 64 50 minecraft:smooth_stone
fill 24 74 23 54 74 52 minecraft:dark_oak_planks
fill 37 64 24 42 67 24 air
fill 28 67 24 34 70 24 minecraft:glass_pane
fill 45 67 24 51 70 24 minecraft:glass_pane
# Motel balcony / exterior rail.
fill 27 70 21 51 70 23 minecraft:smooth_stone_slab[type=bottom]
fill 27 71 21 51 71 21 minecraft:iron_bars
# East-side gas station / parking lot.
fill 13 64 14 55 64 20 minecraft:black_concrete
fill 15 65 16 25 65 18 minecraft:white_concrete
fill 29 65 16 39 65 18 minecraft:white_concrete
fill 43 65 16 53 65 18 minecraft:white_concrete
fill 16 69 14 52 69 22 minecraft:white_concrete
fill 17 65 15 17 68 15 minecraft:iron_block
fill 51 65 15 51 68 15 minecraft:iron_block
setblock 23 65 18 minecraft:redstone_lamp[lit=true]
setblock 35 65 18 minecraft:redstone_lamp[lit=true]
setblock 47 65 18 minecraft:redstone_lamp[lit=true]
# West pocket park.
fill -55 64 -19 -17 64 -12 minecraft:grass_block
fill -53 64 -18 -19 64 -17 minecraft:gravel
fill -50 65 -15 -50 69 -15 minecraft:oak_log
fill -52 69 -17 -48 72 -13 minecraft:oak_leaves[persistent=true]
fill -38 65 -15 -38 69 -15 minecraft:oak_log
fill -40 69 -17 -36 72 -13 minecraft:oak_leaves[persistent=true]
fill -26 65 -15 -26 69 -15 minecraft:oak_log
fill -28 69 -17 -24 72 -13 minecraft:oak_leaves[persistent=true]
setblock -45 65 -18 minecraft:oak_stairs[facing=south,half=bottom,shape=straight]
setblock -33 65 -18 minecraft:oak_stairs[facing=south,half=bottom,shape=straight]
# Alley/service details and dumpsters.
fill 14 64 -22 20 64 -12 minecraft:gravel
fill 15 65 -20 17 66 -18 minecraft:green_concrete
setblock 18 65 -20 minecraft:barrel[facing=up]
fill -20 64 24 -13 64 45 minecraft:gravel
fill -18 65 29 -16 66 31 minecraft:green_concrete
setblock -15 65 30 minecraft:barrel[facing=up]
# Street lamps / traffic corners.
setblock -13 65 -13 minecraft:polished_blackstone_wall
setblock -13 66 -13 minecraft:polished_blackstone_wall
setblock -13 67 -13 minecraft:lantern
setblock 13 65 -13 minecraft:polished_blackstone_wall
setblock 13 66 -13 minecraft:polished_blackstone_wall
setblock 13 67 -13 minecraft:lantern
setblock -13 65 13 minecraft:polished_blackstone_wall
setblock -13 66 13 minecraft:polished_blackstone_wall
setblock -13 67 13 minecraft:lantern
setblock 13 65 13 minecraft:polished_blackstone_wall
setblock 13 66 13 minecraft:polished_blackstone_wall
setblock 13 67 13 minecraft:lantern
setblock -35 65 -11 minecraft:polished_blackstone_wall
setblock -35 66 -11 minecraft:polished_blackstone_wall
setblock -35 67 -11 minecraft:lantern
setblock 35 65 -11 minecraft:polished_blackstone_wall
setblock 35 66 -11 minecraft:polished_blackstone_wall
setblock 35 67 -11 minecraft:lantern
setblock -35 65 11 minecraft:polished_blackstone_wall
setblock -35 66 11 minecraft:polished_blackstone_wall
setblock -35 67 11 minecraft:lantern
setblock 35 65 11 minecraft:polished_blackstone_wall
setblock 35 66 11 minecraft:polished_blackstone_wall
setblock 35 67 11 minecraft:lantern
setblock -11 65 -35 minecraft:polished_blackstone_wall
setblock -11 66 -35 minecraft:polished_blackstone_wall
setblock -11 67 -35 minecraft:lantern
setblock 11 65 -35 minecraft:polished_blackstone_wall
setblock 11 66 -35 minecraft:polished_blackstone_wall
setblock 11 67 -35 minecraft:lantern
setblock -11 65 35 minecraft:polished_blackstone_wall
setblock -11 66 35 minecraft:polished_blackstone_wall
setblock -11 67 35 minecraft:lantern
setblock 11 65 35 minecraft:polished_blackstone_wall
setblock 11 66 35 minecraft:polished_blackstone_wall
setblock 11 67 35 minecraft:lantern
setblock -55 65 -11 minecraft:polished_blackstone_wall
setblock -55 66 -11 minecraft:polished_blackstone_wall
setblock -55 67 -11 minecraft:lantern
setblock 55 65 11 minecraft:polished_blackstone_wall
setblock 55 66 11 minecraft:polished_blackstone_wall
setblock 55 67 11 minecraft:lantern
setblock -11 65 55 minecraft:polished_blackstone_wall
setblock -11 66 55 minecraft:polished_blackstone_wall
setblock -11 67 55 minecraft:lantern
setblock 11 65 -55 minecraft:polished_blackstone_wall
setblock 11 66 -55 minecraft:polished_blackstone_wall
setblock 11 67 -55 minecraft:lantern
# Traffic signal poles at central intersection.
fill -12 65 -12 -12 69 -12 minecraft:iron_bars
setblock -12 69 -11 minecraft:redstone_lamp[lit=true]
fill 12 65 12 12 69 12 minecraft:iron_bars
setblock 12 69 11 minecraft:redstone_lamp[lit=true]
# Runtime spawn / barrier markers.
summon minecraft:marker -58 64 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 58 64 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 64 -58 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 64 58 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -15 65 -15 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 15 65 15 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -15 65 15 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 15 65 -15 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -50 64 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 50 64 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 0 64 -50 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
summon minecraft:marker 0 64 50 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_barrier 180
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_bmax 180
fill -50 64 -1 -50 66 1 minecraft:oak_planks
fill 50 64 -1 50 66 1 minecraft:oak_planks
fill -1 64 -50 1 66 -50 minecraft:oak_planks
fill -1 64 50 1 66 50 minecraft:oak_planks
# Spawn safety: clear standing/head space and place players one block above the finished surface.
fill -1 65 13 1 67 15 minecraft:air
fill -16 65 -16 -14 67 -14 minecraft:air
fill 14 65 14 16 67 16 minecraft:air
fill -16 65 14 -14 67 16 minecraft:air
fill 14 65 -16 16 67 -14 minecraft:air
setworldspawn 0 65 14
tp @a 0 65 14
title @a actionbar {"text":"BOX TOWN — dead streets","color":"gold"}
