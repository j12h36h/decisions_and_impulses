# SKY SCRAPER — structural correction / lighting pass
kill @e[type=minecraft:marker,tag=bh_runtime_marker]
scoreboard players set #map_type bh_state 3
# Six sealed tower decks.
fill -34 64 -34 34 64 34 minecraft:smooth_stone
fill -34 72 -34 34 72 34 minecraft:smooth_stone
fill -34 80 -34 34 80 34 minecraft:smooth_stone
fill -34 88 -34 34 88 34 minecraft:smooth_stone
fill -34 96 -34 34 96 34 minecraft:smooth_stone
fill -34 104 -34 34 104 34 minecraft:smooth_stone
fill -34 65 -34 -34 103 34 minecraft:tinted_glass
fill 34 65 -34 34 103 34 minecraft:tinted_glass
fill -33 65 -34 33 103 -34 minecraft:tinted_glass
fill -33 65 34 33 103 34 minecraft:tinted_glass
# Core rooms.
fill -4 65 -4 4 71 4 minecraft:polished_deepslate hollow
fill -1 65 -4 1 68 -4 air
fill -4 73 -4 4 79 4 minecraft:polished_deepslate hollow
fill -1 73 -4 1 76 -4 air
fill -4 81 -4 4 87 4 minecraft:polished_deepslate hollow
fill -1 81 -4 1 84 -4 air
fill -4 89 -4 4 95 4 minecraft:polished_deepslate hollow
fill -1 89 -4 1 92 -4 air
fill -4 97 -4 4 103 4 minecraft:polished_deepslate hollow
fill -1 97 -4 1 100 -4 air
# Ground-floor contained pool: solid base + raised rim, water never replaces the deck.
fill -28 64 -19 -7 64 5 minecraft:polished_diorite
fill -27 65 -18 -8 65 4 minecraft:light_blue_concrete
fill -26 65 -17 -9 65 3 minecraft:water
fill -27 65 -18 -8 65 -18 minecraft:polished_diorite
fill -27 65 4 -8 65 4 minecraft:polished_diorite
fill -27 65 -17 -27 65 3 minecraft:polished_diorite
fill -8 65 -17 -8 65 3 minecraft:polished_diorite
# Lobby / offices.
fill 8 65 -20 28 69 8 minecraft:white_concrete hollow
fill 12 65 -20 16 67 -20 air
fill -28 73 -27 -20 78 -10 minecraft:smooth_quartz hollow
fill -25 73 -10 -23 75 -10 air
fill -14 73 -27 -6 78 -10 minecraft:smooth_quartz hollow
fill -11 73 -10 -9 75 -10 air
fill 8 73 -27 16 78 -10 minecraft:smooth_quartz hollow
fill 11 73 -10 13 75 -10 air
fill 22 73 -27 30 78 -10 minecraft:smooth_quartz hollow
fill 25 73 -10 27 75 -10 air
fill -28 81 -28 28 86 28 minecraft:white_concrete hollow
fill -26 81 -26 26 81 26 minecraft:light_gray_concrete
fill -8 82 -8 8 85 8 minecraft:cyan_stained_glass hollow
setblock 0 82 0 minecraft:beacon
fill -24 82 18 -10 84 24 minecraft:iron_block hollow
fill 10 82 18 24 84 24 minecraft:iron_block hollow
fill -34 89 -34 -20 95 -20 air
fill 20 89 20 34 95 34 air
fill -18 89 -18 18 94 18 minecraft:gray_concrete hollow
fill -26 97 -26 26 102 26 minecraft:quartz_block hollow
fill -3 97 26 3 100 26 air
fill -3 103 -3 3 104 3 air
fill -34 105 -34 34 106 -34 minecraft:iron_bars
fill -34 105 34 34 106 34 minecraft:iron_bars
fill -34 105 -33 -34 106 33 minecraft:iron_bars
fill 34 105 -33 34 106 33 minecraft:iron_bars
# Ceiling lighting grid on every occupied level.
setblock -22 71 -22 minecraft:sea_lantern
setblock -22 71 0 minecraft:sea_lantern
setblock -22 71 22 minecraft:sea_lantern
setblock 0 71 -22 minecraft:sea_lantern
setblock 0 71 22 minecraft:sea_lantern
setblock 22 71 -22 minecraft:sea_lantern
setblock 22 71 0 minecraft:sea_lantern
setblock 22 71 22 minecraft:sea_lantern
setblock 27 71 -10 minecraft:sea_lantern
setblock 33 71 -4 minecraft:sea_lantern
setblock -22 79 -22 minecraft:sea_lantern
setblock -22 79 0 minecraft:sea_lantern
setblock -22 79 22 minecraft:sea_lantern
setblock 0 79 -22 minecraft:sea_lantern
setblock 0 79 22 minecraft:sea_lantern
setblock 22 79 -22 minecraft:sea_lantern
setblock 22 79 0 minecraft:sea_lantern
setblock 22 79 22 minecraft:sea_lantern
setblock 27 79 -10 minecraft:sea_lantern
setblock 33 79 -4 minecraft:sea_lantern
setblock -22 87 -22 minecraft:sea_lantern
setblock -22 87 0 minecraft:sea_lantern
setblock -22 87 22 minecraft:sea_lantern
setblock 0 87 -22 minecraft:sea_lantern
setblock 0 87 22 minecraft:sea_lantern
setblock 22 87 -22 minecraft:sea_lantern
setblock 22 87 0 minecraft:sea_lantern
setblock 22 87 22 minecraft:sea_lantern
setblock 27 87 -10 minecraft:sea_lantern
setblock 33 87 -4 minecraft:sea_lantern
setblock -22 95 -22 minecraft:sea_lantern
setblock -22 95 0 minecraft:sea_lantern
setblock -22 95 22 minecraft:sea_lantern
setblock 0 95 -22 minecraft:sea_lantern
setblock 0 95 22 minecraft:sea_lantern
setblock 22 95 -22 minecraft:sea_lantern
setblock 22 95 0 minecraft:sea_lantern
setblock 22 95 22 minecraft:sea_lantern
setblock 27 95 -10 minecraft:sea_lantern
setblock 33 95 -4 minecraft:sea_lantern
setblock -22 103 -22 minecraft:sea_lantern
setblock -22 103 0 minecraft:sea_lantern
setblock -22 103 22 minecraft:sea_lantern
setblock 0 103 -22 minecraft:sea_lantern
setblock 0 103 22 minecraft:sea_lantern
setblock 22 103 -22 minecraft:sea_lantern
setblock 22 103 0 minecraft:sea_lantern
setblock 22 103 22 minecraft:sea_lantern
setblock 27 103 -10 minecraft:sea_lantern
setblock 33 103 -4 minecraft:sea_lantern
# --- SKY SCRAPER BEAUTIFICATION PASS ---------------------------------------
# Exterior structural spine: dark corner columns and floor bands give the
# glass tower a readable silhouette from every level.
fill -33 65 -33 -33 103 -33 minecraft:polished_blackstone
fill 33 65 -33 33 103 -33 minecraft:polished_blackstone
fill -33 65 33 -33 103 33 minecraft:polished_blackstone
fill 33 65 33 33 103 33 minecraft:polished_blackstone
fill -33 71 -33 33 71 -33 minecraft:polished_blackstone
fill -33 71 33 33 71 33 minecraft:polished_blackstone
fill -33 79 -33 33 79 -33 minecraft:polished_blackstone
fill -33 79 33 33 79 33 minecraft:polished_blackstone
fill -33 87 -33 33 87 -33 minecraft:polished_blackstone
fill -33 87 33 33 87 33 minecraft:polished_blackstone
fill -33 95 -33 33 95 -33 minecraft:polished_blackstone
fill -33 95 33 33 95 33 minecraft:polished_blackstone
fill -33 103 -33 33 103 -33 minecraft:polished_blackstone
fill -33 103 33 33 103 33 minecraft:polished_blackstone
# Vertical facade mullions.
fill -16 65 -34 -16 103 -34 minecraft:iron_bars
fill 0 65 -34 0 103 -34 minecraft:iron_bars
fill 16 65 -34 16 103 -34 minecraft:iron_bars
fill -16 65 34 -16 103 34 minecraft:iron_bars
fill 0 65 34 0 103 34 minecraft:iron_bars
fill 16 65 34 16 103 34 minecraft:iron_bars
fill -34 65 -16 -34 103 -16 minecraft:iron_bars
fill -34 65 0 -34 103 0 minecraft:iron_bars
fill -34 65 16 -34 103 16 minecraft:iron_bars
fill 34 65 -16 34 103 -16 minecraft:iron_bars
fill 34 65 0 34 103 0 minecraft:iron_bars
fill 34 65 16 34 103 16 minecraft:iron_bars

# Ground floor — hotel-style lobby, pool lounge and reception.
fill -5 65 8 26 65 27 minecraft:polished_andesite
fill -3 65 10 24 65 25 minecraft:gray_carpet
fill 14 65 18 24 65 20 minecraft:dark_oak_planks
fill 14 66 18 24 66 18 minecraft:dark_oak_slab[type=bottom]
setblock 16 66 17 minecraft:lantern
setblock 22 66 17 minecraft:lantern
setblock 19 66 19 minecraft:bell[attachment=floor,facing=north]
# Reception back wall and directory lighting.
fill 17 66 22 21 69 22 minecraft:polished_blackstone
fill 18 67 21 20 68 21 minecraft:sea_lantern
# Lobby seating groups.
setblock 2 65 14 minecraft:dark_oak_stairs[facing=east,half=bottom,shape=straight]
setblock 2 65 18 minecraft:dark_oak_stairs[facing=east,half=bottom,shape=straight]
setblock 7 65 14 minecraft:dark_oak_stairs[facing=west,half=bottom,shape=straight]
setblock 7 65 18 minecraft:dark_oak_stairs[facing=west,half=bottom,shape=straight]
fill 4 65 15 5 65 17 minecraft:smooth_quartz_slab[type=bottom]
# Pool deck trim, lighting and loungers.
fill -29 65 -20 -6 65 -19 minecraft:dark_prismarine
fill -29 65 5 -6 65 6 minecraft:dark_prismarine
fill -29 65 -18 -28 65 4 minecraft:dark_prismarine
fill -7 65 -18 -6 65 4 minecraft:dark_prismarine
setblock -24 66 -19 minecraft:sea_lantern
setblock -17 66 -19 minecraft:sea_lantern
setblock -10 66 -19 minecraft:sea_lantern
setblock -24 66 5 minecraft:sea_lantern
setblock -17 66 5 minecraft:sea_lantern
setblock -10 66 5 minecraft:sea_lantern
setblock -24 65 8 minecraft:birch_stairs[facing=south,half=bottom,shape=straight]
setblock -18 65 8 minecraft:birch_stairs[facing=south,half=bottom,shape=straight]
setblock -12 65 8 minecraft:birch_stairs[facing=south,half=bottom,shape=straight]

# Level 2 — corporate offices with glass dividers, desks and records storage.
fill -31 73 8 22 73 29 minecraft:light_gray_carpet
fill -30 74 11 -30 78 27 minecraft:light_blue_stained_glass_pane
fill -17 74 11 -17 78 27 minecraft:light_blue_stained_glass_pane
fill -4 74 11 -4 78 27 minecraft:light_blue_stained_glass_pane
fill 9 74 11 9 78 27 minecraft:light_blue_stained_glass_pane
fill 22 74 11 22 78 27 minecraft:light_blue_stained_glass_pane
# Desk islands.
fill -27 74 14 -22 74 15 minecraft:smooth_stone_slab[type=bottom]
fill -14 74 14 -9 74 15 minecraft:smooth_stone_slab[type=bottom]
fill -1 74 14 4 74 15 minecraft:smooth_stone_slab[type=bottom]
fill 12 74 14 17 74 15 minecraft:smooth_stone_slab[type=bottom]
fill -27 74 22 -22 74 23 minecraft:smooth_stone_slab[type=bottom]
fill -14 74 22 -9 74 23 minecraft:smooth_stone_slab[type=bottom]
fill -1 74 22 4 74 23 minecraft:smooth_stone_slab[type=bottom]
fill 12 74 22 17 74 23 minecraft:smooth_stone_slab[type=bottom]
# Filing / archive walls.
fill 25 74 12 29 77 12 minecraft:bookshelf
fill 25 74 18 29 77 18 minecraft:bookshelf
fill 25 74 24 29 77 24 minecraft:bookshelf
setblock -26 75 14 minecraft:redstone_lamp[lit=true]
setblock -13 75 14 minecraft:redstone_lamp[lit=true]
setblock 0 75 14 minecraft:redstone_lamp[lit=true]
setblock 13 75 14 minecraft:redstone_lamp[lit=true]

# Level 3 — operations / server floor around the illuminated glass core.
fill -26 82 -24 -12 82 -18 minecraft:black_concrete
fill 12 82 -24 26 82 -18 minecraft:black_concrete
fill -26 82 -12 -18 82 12 minecraft:black_concrete
fill 18 82 -12 26 82 12 minecraft:black_concrete
# Server rack banks with live status lamps.
fill -24 83 -23 -21 85 -20 minecraft:polished_blackstone
fill -16 83 -23 -13 85 -20 minecraft:polished_blackstone
fill 13 83 -23 16 85 -20 minecraft:polished_blackstone
fill 21 83 -23 24 85 -20 minecraft:polished_blackstone
setblock -22 84 -19 minecraft:redstone_lamp[lit=true]
setblock -14 84 -19 minecraft:redstone_lamp[lit=true]
setblock 14 84 -19 minecraft:redstone_lamp[lit=true]
setblock 22 84 -19 minecraft:redstone_lamp[lit=true]
# Control desks facing the beacon core.
fill -14 82 12 -5 82 14 minecraft:smooth_quartz_slab[type=bottom]
fill 5 82 12 14 82 14 minecraft:smooth_quartz_slab[type=bottom]
setblock -10 83 12 minecraft:comparator[facing=north]
setblock -7 83 12 minecraft:repeater[facing=north]
setblock 7 83 12 minecraft:repeater[facing=north]
setblock 10 83 12 minecraft:comparator[facing=north]

# Level 4 — staff lounge / cafeteria with a warm material break from the tower.
fill -28 89 8 24 89 28 minecraft:dark_oak_planks
fill -25 90 20 -8 90 24 minecraft:smooth_quartz
fill -23 91 21 -10 91 23 minecraft:smoker[facing=north]
setblock -6 90 22 minecraft:barrel[facing=up]
setblock -3 90 22 minecraft:crafting_table
# Cafe tables and seating.
fill 2 90 12 4 90 14 minecraft:smooth_quartz_slab[type=bottom]
fill 10 90 12 12 90 14 minecraft:smooth_quartz_slab[type=bottom]
fill 18 90 12 20 90 14 minecraft:smooth_quartz_slab[type=bottom]
setblock 1 90 13 minecraft:dark_oak_stairs[facing=east,half=bottom,shape=straight]
setblock 5 90 13 minecraft:dark_oak_stairs[facing=west,half=bottom,shape=straight]
setblock 9 90 13 minecraft:dark_oak_stairs[facing=east,half=bottom,shape=straight]
setblock 13 90 13 minecraft:dark_oak_stairs[facing=west,half=bottom,shape=straight]
setblock 17 90 13 minecraft:dark_oak_stairs[facing=east,half=bottom,shape=straight]
setblock 21 90 13 minecraft:dark_oak_stairs[facing=west,half=bottom,shape=straight]
# Lounge planters and warm lights.
setblock 24 90 22 minecraft:moss_block
setblock 24 91 22 minecraft:flowering_azalea
setblock 24 94 22 minecraft:lantern
setblock -24 94 22 minecraft:lantern

# Level 5 — executive floor / observation suite.
fill -23 97 -22 23 97 23 minecraft:calcite
fill -20 98 -18 -5 102 -6 minecraft:dark_oak_planks hollow
fill 5 98 -18 20 102 -6 minecraft:dark_oak_planks hollow
fill -20 98 7 -5 102 19 minecraft:smooth_quartz hollow
fill 5 98 7 20 102 19 minecraft:smooth_quartz hollow
fill -3 98 -20 3 101 -20 minecraft:light_blue_stained_glass_pane
fill -3 98 20 3 101 20 minecraft:light_blue_stained_glass_pane
# Executive desks / meeting table.
fill -15 98 -12 -9 98 -10 minecraft:dark_oak_slab[type=bottom]
fill 9 98 -12 15 98 -10 minecraft:dark_oak_slab[type=bottom]
fill -7 98 11 7 98 14 minecraft:dark_oak_slab[type=bottom]
setblock -5 99 12 minecraft:lantern
setblock 5 99 12 minecraft:lantern
# Observation lounge along south glass.
setblock -17 98 24 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
setblock -9 98 24 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
setblock 9 98 24 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
setblock 17 98 24 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]

# Rooftop — helipad, warning lights and antenna cluster.
fill -18 105 -18 18 105 18 minecraft:gray_concrete
fill -15 105 -2 15 105 2 minecraft:white_concrete
fill -2 105 -15 2 105 15 minecraft:white_concrete
fill -7 105 -7 -5 105 7 minecraft:yellow_concrete
fill 5 105 -7 7 105 7 minecraft:yellow_concrete
fill -5 105 -2 5 105 2 minecraft:gray_concrete
setblock -18 106 -18 minecraft:redstone_lamp[lit=true]
setblock 18 106 -18 minecraft:redstone_lamp[lit=true]
setblock -18 106 18 minecraft:redstone_lamp[lit=true]
setblock 18 106 18 minecraft:redstone_lamp[lit=true]
fill 0 106 24 0 112 24 minecraft:iron_bars
setblock 0 113 24 minecraft:redstone_torch
fill -4 106 27 -4 109 27 minecraft:lightning_rod[facing=up]
fill 4 106 27 4 109 27 minecraft:lightning_rod[facing=up]
# Service housings / rooftop utility boxes.
fill -28 105 -28 -22 108 -22 minecraft:polished_deepslate hollow
fill 22 105 -28 28 108 -22 minecraft:polished_deepslate hollow
setblock -25 106 -21 minecraft:iron_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock -25 107 -21 minecraft:iron_door[facing=south,half=upper,hinge=left,open=false,powered=false]
setblock 25 106 -21 minecraft:iron_door[facing=south,half=lower,hinge=right,open=false,powered=false]
setblock 25 107 -21 minecraft:iron_door[facing=south,half=upper,hinge=right,open=false,powered=false]

# --- STAIRWELL CORRECTION v0.3.6 ------------------------------------------
# Clear one continuous shaft after all decorative construction so no floor,
# furnishing, or beautification command can block the staircase afterward.
fill 27 65 -9 33 106 -2 minecraft:air
# Side rails and south opening guard. The north edge remains the floor access.
fill 27 65 -9 27 105 -2 minecraft:iron_bars
fill 33 65 -9 33 105 -2 minecraft:iron_bars
# Floor 64 -> 72: two-flight switchback with a full-width landing.
fill 28 65 -8 29 65 -8 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 66 -7 29 66 -7 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 67 -6 29 67 -6 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 68 -5 29 68 -5 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 68 -4 32 68 -2 minecraft:smooth_stone
fill 31 69 -3 32 69 -3 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 70 -4 32 70 -4 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 71 -5 32 71 -5 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 72 -6 32 72 -6 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 28 72 -10 32 72 -7 minecraft:smooth_stone
fill 28 73 -2 32 73 -2 minecraft:iron_bars
setblock 27 69 -3 minecraft:sea_lantern
setblock 33 69 -3 minecraft:sea_lantern
# Floor 72 -> 80: two-flight switchback with a full-width landing.
fill 28 73 -8 29 73 -8 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 74 -7 29 74 -7 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 75 -6 29 75 -6 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 76 -5 29 76 -5 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 76 -4 32 76 -2 minecraft:smooth_stone
fill 31 77 -3 32 77 -3 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 78 -4 32 78 -4 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 79 -5 32 79 -5 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 80 -6 32 80 -6 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 28 80 -10 32 80 -7 minecraft:smooth_stone
fill 28 81 -2 32 81 -2 minecraft:iron_bars
setblock 27 77 -3 minecraft:sea_lantern
setblock 33 77 -3 minecraft:sea_lantern
# Floor 80 -> 88: two-flight switchback with a full-width landing.
fill 28 81 -8 29 81 -8 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 82 -7 29 82 -7 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 83 -6 29 83 -6 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 84 -5 29 84 -5 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 84 -4 32 84 -2 minecraft:smooth_stone
fill 31 85 -3 32 85 -3 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 86 -4 32 86 -4 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 87 -5 32 87 -5 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 88 -6 32 88 -6 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 28 88 -10 32 88 -7 minecraft:smooth_stone
fill 28 89 -2 32 89 -2 minecraft:iron_bars
setblock 27 85 -3 minecraft:sea_lantern
setblock 33 85 -3 minecraft:sea_lantern
# Floor 88 -> 96: two-flight switchback with a full-width landing.
fill 28 89 -8 29 89 -8 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 90 -7 29 90 -7 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 91 -6 29 91 -6 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 92 -5 29 92 -5 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 92 -4 32 92 -2 minecraft:smooth_stone
fill 31 93 -3 32 93 -3 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 94 -4 32 94 -4 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 95 -5 32 95 -5 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 96 -6 32 96 -6 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 28 96 -10 32 96 -7 minecraft:smooth_stone
fill 28 97 -2 32 97 -2 minecraft:iron_bars
setblock 27 93 -3 minecraft:sea_lantern
setblock 33 93 -3 minecraft:sea_lantern
# Floor 96 -> 104: two-flight switchback with a full-width landing.
fill 28 97 -8 29 97 -8 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 98 -7 29 98 -7 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 99 -6 29 99 -6 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 100 -5 29 100 -5 minecraft:quartz_stairs[facing=south,half=bottom,shape=straight]
fill 28 100 -4 32 100 -2 minecraft:smooth_stone
fill 31 101 -3 32 101 -3 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 102 -4 32 102 -4 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 103 -5 32 103 -5 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 31 104 -6 32 104 -6 minecraft:quartz_stairs[facing=north,half=bottom,shape=straight]
fill 28 104 -10 32 104 -7 minecraft:smooth_stone
fill 28 105 -2 32 105 -2 minecraft:iron_bars
setblock 27 101 -3 minecraft:sea_lantern
setblock 33 101 -3 minecraft:sea_lantern
fill 28 64 -10 32 64 -7 minecraft:smooth_stone
fill 28 104 -10 32 104 -7 minecraft:smooth_stone
# Keep the final roof exit clear above the top landing.
fill 28 105 -9 32 107 -7 minecraft:air
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# Runtime markers.
summon minecraft:marker -28 65 -28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 28 73 28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -28 81 28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 28 89 -28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 97 -28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -8 65 20 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 8 65 20 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 0 74 0 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 0 98 0 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -24 65 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 24 73 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 0 81 -24 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
summon minecraft:marker 0 89 24 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_barrier 180
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_bmax 180
fill -24 65 -1 -24 67 1 minecraft:oak_planks
fill 24 73 -1 24 75 1 minecraft:oak_planks
fill -1 81 -24 1 83 -24 minecraft:oak_planks
fill -1 89 24 1 91 24 minecraft:oak_planks
setworldspawn 0 65 22
tp @a 0 65 22
execute as @a run attribute @s minecraft:gravity base set 0.04
title @a actionbar {"text":"SKY SCRAPER — dimensional gravity: 50%","color":"aqua"}
