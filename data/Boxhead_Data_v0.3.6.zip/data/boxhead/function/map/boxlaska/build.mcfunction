# BOXLASKA — frozen frontier detail rebuild
kill @e[type=minecraft:marker,tag=bh_runtime_marker]
scoreboard players set #map_type bh_state 5
# Deep foundation and snow-covered terrain.
fill -54 59 -54 0 61 54 minecraft:stone
fill 1 59 -54 54 61 54 minecraft:stone
fill -50 62 -50 50 63 50 minecraft:dirt
fill -48 64 -48 48 64 48 minecraft:snow_block
# Corner void cuts preserve the arena silhouette.
fill -48 59 -48 -36 64 -36 air
fill 36 59 -48 48 64 -36 air
fill -48 59 36 -36 64 48 air
fill 36 59 36 48 64 48 air
# Packed-ice roads with stone shoulders and snowbanks.
fill -48 64 -4 48 64 4 minecraft:packed_ice
fill -4 64 -48 4 64 48 minecraft:packed_ice
fill -48 64 -6 48 64 -5 minecraft:cobbled_deepslate
fill -48 64 5 48 64 6 minecraft:cobbled_deepslate
fill -6 64 -48 -5 64 48 minecraft:cobbled_deepslate
fill 5 64 -48 6 64 48 minecraft:cobbled_deepslate
fill -46 65 -8 46 65 -7 minecraft:snow_block
fill -46 65 7 46 65 8 minecraft:snow_block
fill -8 65 -46 -7 65 46 minecraft:snow_block
fill 7 65 -46 8 65 46 minecraft:snow_block
# Central frozen pond / meeting circle.
fill -10 64 -10 10 64 10 minecraft:polished_andesite
fill -7 64 -7 7 64 7 minecraft:blue_ice
fill -5 65 -5 5 65 5 minecraft:ice
fill -2 65 -2 2 65 2 minecraft:packed_ice
setblock 0 66 0 minecraft:bell[attachment=floor,facing=north]
# North-west ranger lodge.
fill -40 65 -35 -23 71 -21 minecraft:spruce_planks hollow
fill -41 72 -36 -22 72 -20 minecraft:dark_oak_planks
fill -38 73 -33 -25 73 -23 minecraft:snow_block
fill -33 65 -21 -30 67 -21 air
fill -38 67 -21 -35 69 -21 minecraft:light_blue_stained_glass_pane
fill -28 67 -21 -25 69 -21 minecraft:light_blue_stained_glass_pane
fill -39 65 -34 -38 71 -33 minecraft:stripped_spruce_log
fill -25 65 -34 -24 71 -33 minecraft:stripped_spruce_log
setblock -32 66 -32 minecraft:campfire[lit=true]
setblock -28 66 -31 minecraft:barrel[facing=up]
setblock -36 66 -31 minecraft:barrel[facing=up]
# North-center general store.
fill -14 65 -38 4 71 -24 minecraft:stone_bricks hollow
fill -15 72 -39 5 72 -23 minecraft:deepslate_tiles
fill -10 73 -34 0 73 -28 minecraft:snow_block
fill -7 65 -24 -3 67 -24 air
fill -12 67 -24 -9 69 -24 minecraft:blue_stained_glass_pane
fill 0 67 -24 3 69 -24 minecraft:blue_stained_glass_pane
setblock -11 66 -28 minecraft:barrel[facing=up]
setblock 1 66 -28 minecraft:chest[facing=south,type=single]
# North-east maintenance garage.
fill 18 65 -36 38 71 -21 minecraft:stone_bricks hollow
fill 17 72 -37 39 72 -20 minecraft:deepslate_tiles
fill 22 73 -34 34 73 -24 minecraft:snow_block
fill 23 65 -21 33 68 -21 air
fill 24 65 -21 32 67 -21 minecraft:iron_bars
setblock 35 66 -24 minecraft:blast_furnace[facing=west]
setblock 35 66 -27 minecraft:anvil
# South-west timber cabins.
fill -39 65 20 -27 70 31 minecraft:spruce_planks hollow
fill -40 71 19 -26 71 32 minecraft:dark_oak_planks
fill -36 72 22 -30 72 29 minecraft:snow_block
fill -35 65 20 -32 67 20 air
fill -38 67 20 -36 68 20 minecraft:light_blue_stained_glass_pane
setblock -32 66 27 minecraft:smoker[facing=west]
fill -20 65 24 -9 70 35 minecraft:spruce_planks hollow
fill -21 71 23 -8 71 36 minecraft:dark_oak_planks
fill -18 72 26 -11 72 33 minecraft:snow_block
fill -16 65 24 -13 67 24 air
fill -19 67 24 -17 68 24 minecraft:light_blue_stained_glass_pane
setblock -12 66 32 minecraft:barrel[facing=up]
# South-east rescue station.
fill 13 65 20 34 71 35 minecraft:polished_deepslate hollow
fill 12 72 19 35 72 36 minecraft:deepslate_bricks
fill 18 73 23 29 73 32 minecraft:snow_block
fill 20 65 20 26 68 20 air
fill 15 67 20 18 69 20 minecraft:light_blue_stained_glass_pane
fill 29 67 20 32 69 20 minecraft:light_blue_stained_glass_pane
setblock 30 66 31 minecraft:chest[facing=north,type=single]
setblock 15 66 31 minecraft:brewing_stand
# Frozen creek crossing the south-east field.
fill 9 64 39 42 64 44 minecraft:blue_ice
fill 12 65 40 39 65 43 minecraft:ice
fill 22 65 38 28 65 45 minecraft:spruce_planks
fill 22 66 38 22 66 45 minecraft:spruce_fence
fill 28 66 38 28 66 45 minecraft:spruce_fence
# Lookout tower in the west field.
fill -45 65 7 -45 75 7 minecraft:stripped_spruce_log
fill -40 65 7 -40 75 7 minecraft:stripped_spruce_log
fill -45 65 12 -45 75 12 minecraft:stripped_spruce_log
fill -40 65 12 -40 75 12 minecraft:stripped_spruce_log
fill -46 75 6 -39 75 13 minecraft:spruce_planks
fill -46 76 6 -39 76 6 minecraft:spruce_fence
fill -46 76 13 -39 76 13 minecraft:spruce_fence
fill -46 76 7 -46 76 12 minecraft:spruce_fence
fill -39 76 7 -39 76 12 minecraft:spruce_fence
setblock -42 76 9 minecraft:lantern[hanging=true]
# Camp / supply yard.
fill 17 64 8 39 64 15 minecraft:coarse_dirt
setblock 22 65 11 minecraft:campfire[lit=true]
setblock 29 65 10 minecraft:barrel[facing=up]
setblock 31 65 10 minecraft:barrel[facing=up]
setblock 34 65 12 minecraft:hay_block
setblock 35 65 12 minecraft:hay_block
# Spruce forest clusters and snow-laden trees.
fill -45 65 -14 -45 70 -14 minecraft:spruce_log
fill -47 68 -16 -43 71 -12 minecraft:spruce_leaves[persistent=true]
setblock -45 72 -14 minecraft:snow_block
fill 44 65 -18 44 71 -18 minecraft:spruce_log
fill 42 69 -20 46 72 -16 minecraft:spruce_leaves[persistent=true]
setblock 44 73 -18 minecraft:snow_block
fill 43 65 27 43 70 27 minecraft:spruce_log
fill 41 68 25 45 71 29 minecraft:spruce_leaves[persistent=true]
setblock 43 72 27 minecraft:snow_block
fill -45 65 38 -45 71 38 minecraft:spruce_log
fill -47 69 36 -43 72 40 minecraft:spruce_leaves[persistent=true]
setblock -45 73 38 minecraft:snow_block
fill -18 65 44 -18 70 44 minecraft:spruce_log
fill -20 68 42 -16 71 46 minecraft:spruce_leaves[persistent=true]
setblock -18 72 44 minecraft:snow_block
fill 7 65 44 7 71 44 minecraft:spruce_log
fill 5 69 42 9 72 46 minecraft:spruce_leaves[persistent=true]
setblock 7 73 44 minecraft:snow_block
fill 45 65 8 45 70 8 minecraft:spruce_log
fill 43 68 6 47 71 10 minecraft:spruce_leaves[persistent=true]
setblock 45 72 8 minecraft:snow_block
fill -18 65 -45 -18 71 -45 minecraft:spruce_log
fill -20 69 -47 -16 72 -43 minecraft:spruce_leaves[persistent=true]
setblock -18 73 -45 minecraft:snow_block
fill 12 65 -44 12 70 -44 minecraft:spruce_log
fill 10 68 -46 14 71 -42 minecraft:spruce_leaves[persistent=true]
setblock 12 72 -44 minecraft:snow_block
fill 38 65 -43 38 71 -43 minecraft:spruce_log
fill 36 69 -45 40 72 -41 minecraft:spruce_leaves[persistent=true]
setblock 38 73 -43 minecraft:snow_block
fill -42 65 -42 -42 70 -42 minecraft:spruce_log
fill -44 68 -44 -40 71 -40 minecraft:spruce_leaves[persistent=true]
setblock -42 72 -42 minecraft:snow_block
fill 40 65 40 40 70 40 minecraft:spruce_log
fill 38 68 38 42 71 42 minecraft:spruce_leaves[persistent=true]
setblock 40 72 40 minecraft:snow_block
# Sculpted snowdrifts around roads/buildings.
fill -46 65 -18 -40 65 -14 minecraft:snow_block
fill -45 66 -17 -42 66 -15 minecraft:snow_block
fill 39 65 -10 46 65 -7 minecraft:snow_block
fill 42 66 -9 45 66 -8 minecraft:snow_block
fill -12 65 40 -5 65 46 minecraft:snow_block
fill -10 66 42 -7 66 45 minecraft:snow_block
fill 36 65 34 44 65 38 minecraft:snow_block
# Blue/soul lantern lighting unique to Boxlaska.
setblock -12 65 -8 minecraft:spruce_fence
setblock -12 66 -8 minecraft:spruce_fence
setblock -12 67 -8 minecraft:soul_lantern
setblock 12 65 -8 minecraft:spruce_fence
setblock 12 66 -8 minecraft:spruce_fence
setblock 12 67 -8 minecraft:soul_lantern
setblock -12 65 8 minecraft:spruce_fence
setblock -12 66 8 minecraft:spruce_fence
setblock -12 67 8 minecraft:soul_lantern
setblock 12 65 8 minecraft:spruce_fence
setblock 12 66 8 minecraft:spruce_fence
setblock 12 67 8 minecraft:soul_lantern
setblock -24 65 -6 minecraft:spruce_fence
setblock -24 66 -6 minecraft:spruce_fence
setblock -24 67 -6 minecraft:soul_lantern
setblock 24 65 -6 minecraft:spruce_fence
setblock 24 66 -6 minecraft:spruce_fence
setblock 24 67 -6 minecraft:soul_lantern
setblock -24 65 6 minecraft:spruce_fence
setblock -24 66 6 minecraft:spruce_fence
setblock -24 67 6 minecraft:soul_lantern
setblock 24 65 6 minecraft:spruce_fence
setblock 24 66 6 minecraft:spruce_fence
setblock 24 67 6 minecraft:soul_lantern
setblock -6 65 -24 minecraft:spruce_fence
setblock -6 66 -24 minecraft:spruce_fence
setblock -6 67 -24 minecraft:soul_lantern
setblock 6 65 -24 minecraft:spruce_fence
setblock 6 66 -24 minecraft:spruce_fence
setblock 6 67 -24 minecraft:soul_lantern
setblock -6 65 24 minecraft:spruce_fence
setblock -6 66 24 minecraft:spruce_fence
setblock -6 67 24 minecraft:soul_lantern
setblock 6 65 24 minecraft:spruce_fence
setblock 6 66 24 minecraft:spruce_fence
setblock 6 67 24 minecraft:soul_lantern
setblock -38 65 0 minecraft:spruce_fence
setblock -38 66 0 minecraft:spruce_fence
setblock -38 67 0 minecraft:soul_lantern
setblock 38 65 0 minecraft:spruce_fence
setblock 38 66 0 minecraft:spruce_fence
setblock 38 67 0 minecraft:soul_lantern
setblock 0 65 -38 minecraft:spruce_fence
setblock 0 66 -38 minecraft:spruce_fence
setblock 0 67 -38 minecraft:soul_lantern
setblock 0 65 38 minecraft:spruce_fence
setblock 0 66 38 minecraft:spruce_fence
setblock 0 67 38 minecraft:soul_lantern
# Runtime spawn / barrier markers.
summon minecraft:marker -45 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 45 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 -45 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 45 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -11 65 -11 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 11 65 11 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -11 65 11 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 11 65 -11 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -40 65 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 40 65 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 0 65 -40 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
summon minecraft:marker 0 65 40 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_barrier 180
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_bmax 180
fill -40 65 -1 -40 67 1 minecraft:spruce_planks
fill 40 65 -1 40 67 1 minecraft:spruce_planks
fill -1 65 -40 1 67 -40 minecraft:spruce_planks
fill -1 65 40 1 67 40 minecraft:spruce_planks
setworldspawn 0 65 13
tp @a 0 65 13
title @a actionbar {"text":"BOXLASKA — frozen frontier","color":"aqua"}
