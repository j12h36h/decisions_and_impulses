# Boxhead v0.3.1 — authoritative 20 TPS gameplay clock.
# DAI 3.3 MAIN experience lifecycle owns player initialization through
# experience_first_join / experience_join. /reload performs one recovery pass in load.mcfunction.

# Start/recover the survival director as soon as at least one Boxhead player exists.
execute if entity @a[tag=bh_player] run function boxhead:run/start_if_needed

scoreboard players add #clock bh_state 1
execute if score #clock bh_state matches 20.. run function boxhead:second_tick
function boxhead:player/death_tick
# Last Breath is single-life: eliminated players can never return to playable mode.
execute if score #game_mode bh_state matches 1 as @a[tag=bh_eliminated,gamemode=!spectator] run gamemode spectator @s
scoreboard players remove @a[scores={bh_fire_cd=1..}] bh_fire_cd 1
function boxhead:gun/animation_tick
function boxhead:projectile/tick
function boxhead:wave/tick
function boxhead:boundary/tick
