scoreboard players set #phase bh_state 1
scoreboard players operation #wave bh_state = #checkpoint bh_state
scoreboard players set #intermission bh_state 100
kill @e[type=boxhead:zombie]
kill @e[type=boxhead:mutant]
kill @e[type=boxhead:giant]
kill @e[type=boxhead:mangled]
execute as @a[tag=bh_player] run function boxhead:player/respawn_waiting_force
title @a title {"text":"WAVE FAILED","color":"red","bold":true}
title @a subtitle {"text":"Checkpoint wave restored. Inventory preserved.","color":"white"}
