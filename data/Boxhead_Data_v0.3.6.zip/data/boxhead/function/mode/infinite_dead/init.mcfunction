scoreboard players set #game_mode bh_state 2
gamerule minecraft:keep_inventory true
