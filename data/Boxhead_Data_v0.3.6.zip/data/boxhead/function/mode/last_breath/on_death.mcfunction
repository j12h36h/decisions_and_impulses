tag @s add bh_eliminated
tag @s remove bh_waiting
tag @s remove bh_casual_dead
gamemode spectator @s
title @s title {"text":"LAST BREATH","color":"dark_red","bold":true}
title @s subtitle {"text":"Your run is over. You cannot respawn.","color":"gray"}
