# Last Breath / Last Stand. The world itself is requested as Hardcore by the
# selected dai_worldgen profile; these rules preserve Boxhead's mode semantics.
scoreboard players set #game_mode bh_state 1
difficulty hard
gamerule minecraft:keep_inventory false
gamerule minecraft:immediate_respawn false
tag @a remove bh_eliminated
tellraw @a [{"text":"LAST BREATH / LAST STAND","color":"dark_red","bold":true},{"text":" — Hardcore run. Death is final.","color":"gray"}]
