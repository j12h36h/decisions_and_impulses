tag @s remove bh_purchase_ok
execute if score @s bh_money matches 75.. run tag @s add bh_purchase_ok
execute unless entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Need $75","color":"red"}
execute if entity @s[tag=bh_purchase_ok] run scoreboard players remove @s bh_money 75
execute if entity @s[tag=bh_purchase_ok] run give @s minecraft:bread 6
execute if entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Purchased 6 bread.","color":"green"}
tag @s remove bh_purchase_ok
