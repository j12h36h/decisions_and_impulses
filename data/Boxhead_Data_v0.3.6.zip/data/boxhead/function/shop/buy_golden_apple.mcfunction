tag @s remove bh_purchase_ok
execute if score @s bh_money matches 450.. run tag @s add bh_purchase_ok
execute unless entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Need $450","color":"red"}
execute if entity @s[tag=bh_purchase_ok] run scoreboard players remove @s bh_money 450
execute if entity @s[tag=bh_purchase_ok] run give @s minecraft:golden_apple 1
execute if entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Purchased a golden apple.","color":"green"}
tag @s remove bh_purchase_ok
