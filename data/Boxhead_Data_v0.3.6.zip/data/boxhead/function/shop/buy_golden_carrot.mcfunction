tag @s remove bh_purchase_ok
execute if score @s bh_money matches 200.. run tag @s add bh_purchase_ok
execute unless entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Need $200","color":"red"}
execute if entity @s[tag=bh_purchase_ok] run scoreboard players remove @s bh_money 200
execute if entity @s[tag=bh_purchase_ok] run give @s minecraft:golden_carrot 4
execute if entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Purchased 4 golden carrots.","color":"green"}
tag @s remove bh_purchase_ok
