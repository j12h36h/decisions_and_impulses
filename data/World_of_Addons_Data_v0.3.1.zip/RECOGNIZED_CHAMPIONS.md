# World of Addons — Recognized Champion Registry

World of Addons v0.3.0 is standalone. The built-in **Rift Minion** is always available and is the default pre-lobby selection.

Addon champions are surfaced only when World of Addons explicitly recognizes their DAI content identity. Unknown addons are not inserted into Champion Select automatically.

## Recognized in v0.3.0

| Champion | Recognition check | Optional loadout hook |
|---|---|---|
| Kitty Claws | `blink_daggers:kitty_dagger` + `blink_daggers:kitty_ultimate` | `blink_daggers:give` |
| Echo Anomaly | `dai_time_reverse:temporal_recall` + `dai_time_reverse:reversal_field` | `dai_time_reverse:starter/give` |

The menu uses DAI 3.3 `content_exists` conditions, so absent addons do not create buttons and do not become dependencies. Loadouts are invoked through optional function tags, so missing addon namespaces do not break standalone loading.
