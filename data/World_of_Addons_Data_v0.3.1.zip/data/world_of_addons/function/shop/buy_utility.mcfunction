tag @s remove woa_purchase_ok
execute unless score #phase woa_world matches 3 run title @s actionbar {"text":"Shop unlocks when the match begins.","color":"gray"}
execute if score #phase woa_world matches 3 if score @s woa_gold matches 125.. run tag @s add woa_purchase_ok
execute if score #phase woa_world matches 3 unless score @s woa_gold matches 125.. run title @s actionbar {"text":"Need 125 gold.","color":"red"}
execute if entity @s[tag=woa_purchase_ok] run scoreboard players remove @s woa_gold 125
execute if entity @s[tag=woa_purchase_ok] run give @s minecraft:ender_pearl 2
execute if entity @s[tag=woa_purchase_ok] run give @s minecraft:shield 1
execute if entity @s[tag=woa_purchase_ok] run title @s actionbar [{"text":"Utility Kit purchased: 2 Pearls + Shield. ","color":"green"},{"text":"Gold: ","color":"gray"},{"score":{"name":"@s","objective":"woa_gold"},"color":"gold"}]
tag @s remove woa_purchase_ok
