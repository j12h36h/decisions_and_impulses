scoreboard players set #match woa_world 0
scoreboard players set #phase woa_world 4
kill @e[tag=woa_minion]
title @a title {"text":"MATCH ENDED","color":"gold","bold":true}
