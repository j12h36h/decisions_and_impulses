execute unless score #built woa_world matches 1 run return 0
scoreboard players set #phase woa_world 3
scoreboard players set #match woa_world 1
scoreboard players set #match_tick woa_world 0
scoreboard players set #wave woa_world 0
kill @e[tag=woa_minion]
gamemode adventure @a[tag=woa_participant]
execute as @a[tag=woa_blue,tag=woa_participant] run tp @s -176 66 176 -45 0
execute as @a[tag=woa_red,tag=woa_participant] run tp @s 176 66 -176 135 0
title @a[tag=woa_participant] title {"text":"MATCH STARTED","color":"gold","bold":true}
title @a[tag=woa_participant] subtitle {"text":"First minion wave in 30 seconds","color":"gray"}
