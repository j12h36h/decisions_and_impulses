scoreboard players remove #countdown woa_world 1
execute if score #countdown woa_world matches 80 run title @a[tag=woa_participant] title {"text":"4","color":"gold","bold":true}
execute if score #countdown woa_world matches 60 run title @a[tag=woa_participant] title {"text":"3","color":"gold","bold":true}
execute if score #countdown woa_world matches 40 run title @a[tag=woa_participant] title {"text":"2","color":"gold","bold":true}
execute if score #countdown woa_world matches 20 run title @a[tag=woa_participant] title {"text":"1","color":"gold","bold":true}
execute if score #countdown woa_world matches ..0 run function world_of_addons:match/start
