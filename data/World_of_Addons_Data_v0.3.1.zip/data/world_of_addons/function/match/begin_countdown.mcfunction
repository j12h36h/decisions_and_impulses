scoreboard players set #phase woa_world 2
scoreboard players set #countdown woa_world 100
title @a[tag=woa_participant] title {"text":"5","color":"gold","bold":true}
title @a[tag=woa_participant] subtitle {"text":"All players locked in","color":"gray"}
