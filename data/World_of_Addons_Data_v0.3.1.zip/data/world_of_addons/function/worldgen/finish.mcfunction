bossbar set world_of_addons:generation value 100
scoreboard players set #built woa_world 1
scoreboard players set #phase woa_world 1
scoreboard players set #match woa_world 0
bossbar set world_of_addons:generation visible false
setworldspawn 0 68 0
execute as @a[tag=woa_blue] run tp @s -176 66 176 -45 0
execute as @a[tag=woa_red] run tp @s 176 66 -176 135 0
execute as @a[tag=woa_participant,scores={woa_locked=0}] run function world_of_addons:champion/prepare_lobby
execute as @a[tag=woa_participant] run title @s title {"text":"CHAMPION SELECT","color":"gold","bold":true}
execute as @a[tag=woa_participant] run title @s subtitle [{"text":"Default: ","color":"gray"},{"text":"Rift Minion","color":"green","bold":true},{"text":" • recognized addon champions appear when loaded","color":"aqua"}]
