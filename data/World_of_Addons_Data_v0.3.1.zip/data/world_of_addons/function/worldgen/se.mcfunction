forceload add -15 -15 224 224
function world_of_addons:worldgen/quadrant/se
forceload remove -15 -15 224 224
bossbar set world_of_addons:generation value 95
bossbar set world_of_addons:generation value 74
schedule function world_of_addons:worldgen/v020/mountain_1 1t replace
