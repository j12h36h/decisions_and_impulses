forceload add -224 -15 15 224
function world_of_addons:worldgen/quadrant/sw
forceload remove -224 -15 15 224
bossbar set world_of_addons:generation value 75
schedule function world_of_addons:worldgen/se 1t replace
