forceload add -15 -224 224 15
function world_of_addons:worldgen/quadrant/ne
forceload remove -15 -224 224 15
bossbar set world_of_addons:generation value 50
schedule function world_of_addons:worldgen/sw 1t replace
