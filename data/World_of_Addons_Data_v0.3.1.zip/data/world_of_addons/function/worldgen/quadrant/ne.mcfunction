fill 0 60 -224 55 63 -169 minecraft:stone
fill 0 64 -224 55 64 -169 minecraft:grass_block
fill 0 60 -168 55 63 -113 minecraft:stone
fill 0 64 -168 55 64 -113 minecraft:grass_block
fill 0 60 -112 55 63 -57 minecraft:stone
fill 0 64 -112 55 64 -57 minecraft:grass_block
fill 0 60 -56 55 63 -1 minecraft:stone
fill 0 64 -56 55 64 -1 minecraft:grass_block
fill 56 60 -224 111 63 -169 minecraft:stone
fill 56 64 -224 111 64 -169 minecraft:grass_block
fill 56 60 -168 111 63 -113 minecraft:stone
fill 56 64 -168 111 64 -113 minecraft:grass_block
fill 56 60 -112 111 63 -57 minecraft:stone
fill 56 64 -112 111 64 -57 minecraft:grass_block
fill 56 60 -56 111 63 -1 minecraft:stone
fill 56 64 -56 111 64 -1 minecraft:grass_block
fill 112 60 -224 167 63 -169 minecraft:stone
fill 112 64 -224 167 64 -169 minecraft:grass_block
fill 112 60 -168 167 63 -113 minecraft:stone
fill 112 64 -168 167 64 -113 minecraft:grass_block
fill 112 60 -112 167 63 -57 minecraft:stone
fill 112 64 -112 167 64 -57 minecraft:grass_block
fill 112 60 -56 167 63 -1 minecraft:stone
fill 112 64 -56 167 64 -1 minecraft:grass_block
fill 168 60 -224 223 63 -169 minecraft:stone
fill 168 64 -224 223 64 -169 minecraft:grass_block
fill 168 60 -168 223 63 -113 minecraft:stone
fill 168 64 -168 223 64 -113 minecraft:grass_block
fill 168 60 -112 223 63 -57 minecraft:stone
fill 168 64 -112 223 64 -57 minecraft:grass_block
fill 168 60 -56 223 63 -1 minecraft:stone
fill 168 64 -56 223 64 -1 minecraft:grass_block
fill 224 60 -224 224 63 -169 minecraft:stone
fill 224 64 -224 224 64 -169 minecraft:grass_block
fill 224 60 -168 224 63 -113 minecraft:stone
fill 224 64 -168 224 64 -113 minecraft:grass_block
fill 224 60 -112 224 63 -57 minecraft:stone
fill 224 64 -112 224 64 -57 minecraft:grass_block
fill 224 60 -56 224 63 -1 minecraft:stone
fill 224 64 -56 224 64 -1 minecraft:grass_block
fill -7 64 -201 7 64 -187 minecraft:coarse_dirt
fill -5 64 -199 5 64 -189 minecraft:dirt_path
fill -1 64 -201 13 64 -187 minecraft:coarse_dirt
fill 1 64 -199 11 64 -189 minecraft:dirt_path
fill 5 64 -201 19 64 -187 minecraft:coarse_dirt
fill 7 64 -199 17 64 -189 minecraft:dirt_path
fill 12 64 -201 26 64 -187 minecraft:coarse_dirt
fill 14 64 -199 24 64 -189 minecraft:dirt_path
fill 18 64 -201 32 64 -187 minecraft:coarse_dirt
fill 20 64 -199 30 64 -189 minecraft:dirt_path
fill 24 64 -201 38 64 -187 minecraft:coarse_dirt
fill 26 64 -199 36 64 -189 minecraft:dirt_path
fill 31 64 -200 45 64 -186 minecraft:coarse_dirt
fill 33 64 -198 43 64 -188 minecraft:dirt_path
fill 37 64 -200 51 64 -186 minecraft:coarse_dirt
fill 39 64 -198 49 64 -188 minecraft:dirt_path
fill 43 64 -200 57 64 -186 minecraft:coarse_dirt
fill 45 64 -198 55 64 -188 minecraft:dirt_path
fill 49 64 -199 63 64 -185 minecraft:coarse_dirt
fill 51 64 -197 61 64 -187 minecraft:dirt_path
fill 55 64 -198 69 64 -184 minecraft:coarse_dirt
fill 57 64 -196 67 64 -186 minecraft:dirt_path
fill 61 64 -192 63 64 -190 minecraft:andesite
fill 62 64 -197 76 64 -183 minecraft:coarse_dirt
fill 64 64 -195 74 64 -185 minecraft:dirt_path
fill 68 64 -196 82 64 -182 minecraft:coarse_dirt
fill 70 64 -194 80 64 -184 minecraft:dirt_path
fill 74 64 -190 76 64 -188 minecraft:andesite
fill 74 64 -195 88 64 -181 minecraft:coarse_dirt
fill 76 64 -193 86 64 -183 minecraft:dirt_path
fill 80 64 -194 94 64 -180 minecraft:coarse_dirt
fill 82 64 -192 92 64 -182 minecraft:dirt_path
fill 86 64 -193 100 64 -179 minecraft:coarse_dirt
fill 88 64 -191 98 64 -181 minecraft:dirt_path
fill 92 64 -187 94 64 -185 minecraft:andesite
fill 93 64 -192 107 64 -178 minecraft:coarse_dirt
fill 95 64 -190 105 64 -180 minecraft:dirt_path
fill 99 64 -191 113 64 -177 minecraft:coarse_dirt
fill 101 64 -189 111 64 -179 minecraft:dirt_path
fill 105 64 -185 107 64 -183 minecraft:andesite
fill 105 64 -190 119 64 -176 minecraft:coarse_dirt
fill 107 64 -188 117 64 -178 minecraft:dirt_path
fill 110 64 -187 124 64 -173 minecraft:coarse_dirt
fill 112 64 -185 122 64 -175 minecraft:dirt_path
fill 116 64 -181 118 64 -179 minecraft:andesite
fill 116 64 -185 130 64 -171 minecraft:coarse_dirt
fill 118 64 -183 128 64 -173 minecraft:dirt_path
fill 121 64 -182 135 64 -168 minecraft:coarse_dirt
fill 123 64 -180 133 64 -170 minecraft:dirt_path
fill 127 64 -179 141 64 -165 minecraft:coarse_dirt
fill 129 64 -177 139 64 -167 minecraft:dirt_path
fill 132 64 -176 146 64 -162 minecraft:coarse_dirt
fill 134 64 -174 144 64 -164 minecraft:dirt_path
fill 138 64 -170 140 64 -168 minecraft:andesite
fill 138 64 -174 152 64 -160 minecraft:coarse_dirt
fill 140 64 -172 150 64 -162 minecraft:dirt_path
fill 143 64 -171 157 64 -157 minecraft:coarse_dirt
fill 145 64 -169 155 64 -159 minecraft:dirt_path
fill 148 64 -167 162 64 -153 minecraft:coarse_dirt
fill 150 64 -165 160 64 -155 minecraft:dirt_path
fill 154 64 -162 168 64 -148 minecraft:coarse_dirt
fill 156 64 -160 166 64 -150 minecraft:dirt_path
fill 160 64 -156 162 64 -154 minecraft:andesite
fill 159 64 -158 173 64 -144 minecraft:coarse_dirt
fill 161 64 -156 171 64 -146 minecraft:dirt_path
fill 165 64 -152 167 64 -150 minecraft:andesite
fill -3 64 -11 11 64 3 minecraft:coarse_dirt
fill -1 64 -9 9 64 1 minecraft:dirt_path
fill 3 64 -5 5 64 -3 minecraft:andesite
fill 2 64 -16 16 64 -2 minecraft:coarse_dirt
fill 4 64 -14 14 64 -4 minecraft:dirt_path
fill 8 64 -10 10 64 -8 minecraft:andesite
fill 6 64 -20 20 64 -6 minecraft:coarse_dirt
fill 8 64 -18 18 64 -8 minecraft:dirt_path
fill 12 64 -14 14 64 -12 minecraft:andesite
fill 11 64 -25 25 64 -11 minecraft:coarse_dirt
fill 13 64 -23 23 64 -13 minecraft:dirt_path
fill 17 64 -19 19 64 -17 minecraft:andesite
fill 15 64 -29 29 64 -15 minecraft:coarse_dirt
fill 17 64 -27 27 64 -17 minecraft:dirt_path
fill 21 64 -23 23 64 -21 minecraft:andesite
fill 19 64 -33 33 64 -19 minecraft:coarse_dirt
fill 21 64 -31 31 64 -21 minecraft:dirt_path
fill 25 64 -27 27 64 -25 minecraft:andesite
fill 23 64 -37 37 64 -23 minecraft:coarse_dirt
fill 25 64 -35 35 64 -25 minecraft:dirt_path
fill 29 64 -31 31 64 -29 minecraft:andesite
fill 28 64 -42 42 64 -28 minecraft:coarse_dirt
fill 30 64 -40 40 64 -30 minecraft:dirt_path
fill 34 64 -36 36 64 -34 minecraft:andesite
fill 32 64 -46 46 64 -32 minecraft:coarse_dirt
fill 34 64 -44 44 64 -34 minecraft:dirt_path
fill 38 64 -40 40 64 -38 minecraft:andesite
fill 36 64 -50 50 64 -36 minecraft:coarse_dirt
fill 38 64 -48 48 64 -38 minecraft:dirt_path
fill 42 64 -44 44 64 -42 minecraft:andesite
fill 41 64 -55 55 64 -41 minecraft:coarse_dirt
fill 43 64 -53 53 64 -43 minecraft:dirt_path
fill 47 64 -49 49 64 -47 minecraft:andesite
fill 45 64 -59 59 64 -45 minecraft:coarse_dirt
fill 47 64 -57 57 64 -47 minecraft:dirt_path
fill 51 64 -53 53 64 -51 minecraft:andesite
fill 49 64 -63 63 64 -49 minecraft:coarse_dirt
fill 51 64 -61 61 64 -51 minecraft:dirt_path
fill 55 64 -57 57 64 -55 minecraft:andesite
fill 54 64 -68 68 64 -54 minecraft:coarse_dirt
fill 56 64 -66 66 64 -56 minecraft:dirt_path
fill 60 64 -62 62 64 -60 minecraft:andesite
fill 58 64 -72 72 64 -58 minecraft:coarse_dirt
fill 60 64 -70 70 64 -60 minecraft:dirt_path
fill 64 64 -66 66 64 -64 minecraft:andesite
fill 63 64 -77 77 64 -63 minecraft:coarse_dirt
fill 65 64 -75 75 64 -65 minecraft:dirt_path
fill 69 64 -71 71 64 -69 minecraft:andesite
fill 67 64 -81 81 64 -67 minecraft:coarse_dirt
fill 69 64 -79 79 64 -69 minecraft:dirt_path
fill 73 64 -75 75 64 -73 minecraft:andesite
fill 72 64 -86 86 64 -72 minecraft:coarse_dirt
fill 74 64 -84 84 64 -74 minecraft:dirt_path
fill 78 64 -80 80 64 -78 minecraft:andesite
fill 76 64 -90 90 64 -76 minecraft:coarse_dirt
fill 78 64 -88 88 64 -78 minecraft:dirt_path
fill 82 64 -84 84 64 -82 minecraft:andesite
fill 81 64 -95 95 64 -81 minecraft:coarse_dirt
fill 83 64 -93 93 64 -83 minecraft:dirt_path
fill 87 64 -89 89 64 -87 minecraft:andesite
fill 86 64 -100 100 64 -86 minecraft:coarse_dirt
fill 88 64 -98 98 64 -88 minecraft:dirt_path
fill 92 64 -94 94 64 -92 minecraft:andesite
fill 90 64 -104 104 64 -90 minecraft:coarse_dirt
fill 92 64 -102 102 64 -92 minecraft:dirt_path
fill 96 64 -98 98 64 -96 minecraft:andesite
fill 95 64 -109 109 64 -95 minecraft:coarse_dirt
fill 97 64 -107 107 64 -97 minecraft:dirt_path
fill 101 64 -103 103 64 -101 minecraft:andesite
fill 99 64 -113 113 64 -99 minecraft:coarse_dirt
fill 101 64 -111 111 64 -101 minecraft:dirt_path
fill 105 64 -107 107 64 -105 minecraft:andesite
fill 104 64 -118 118 64 -104 minecraft:coarse_dirt
fill 106 64 -116 116 64 -106 minecraft:dirt_path
fill 110 64 -112 112 64 -110 minecraft:andesite
fill 108 64 -122 122 64 -108 minecraft:coarse_dirt
fill 110 64 -120 120 64 -110 minecraft:dirt_path
fill 114 64 -116 116 64 -114 minecraft:andesite
fill 113 64 -127 127 64 -113 minecraft:coarse_dirt
fill 115 64 -125 125 64 -115 minecraft:dirt_path
fill 119 64 -121 121 64 -119 minecraft:andesite
fill 117 64 -131 131 64 -117 minecraft:coarse_dirt
fill 119 64 -129 129 64 -119 minecraft:dirt_path
fill 123 64 -125 125 64 -123 minecraft:andesite
fill 122 64 -136 136 64 -122 minecraft:coarse_dirt
fill 124 64 -134 134 64 -124 minecraft:dirt_path
fill 128 64 -130 130 64 -128 minecraft:andesite
fill 126 64 -140 140 64 -126 minecraft:coarse_dirt
fill 128 64 -138 138 64 -128 minecraft:dirt_path
fill 132 64 -134 134 64 -132 minecraft:andesite
fill 130 64 -144 144 64 -130 minecraft:coarse_dirt
fill 132 64 -142 142 64 -132 minecraft:dirt_path
fill 136 64 -138 138 64 -136 minecraft:andesite
fill 134 64 -148 148 64 -134 minecraft:coarse_dirt
fill 136 64 -146 146 64 -136 minecraft:dirt_path
fill 140 64 -142 142 64 -140 minecraft:andesite
fill 139 64 -153 153 64 -139 minecraft:coarse_dirt
fill 141 64 -151 151 64 -141 minecraft:dirt_path
fill 145 64 -147 147 64 -145 minecraft:andesite
fill 143 64 -157 157 64 -143 minecraft:coarse_dirt
fill 145 64 -155 155 64 -145 minecraft:dirt_path
fill 149 64 -151 151 64 -149 minecraft:andesite
fill 148 64 -162 162 64 -148 minecraft:coarse_dirt
fill 150 64 -160 160 64 -150 minecraft:dirt_path
fill 154 64 -156 156 64 -154 minecraft:andesite
fill 154 64 -168 168 64 -154 minecraft:coarse_dirt
fill 156 64 -166 166 64 -156 minecraft:dirt_path
fill 160 64 -162 162 64 -160 minecraft:andesite
fill 159 64 -173 173 64 -159 minecraft:coarse_dirt
fill 161 64 -171 171 64 -161 minecraft:dirt_path
fill 165 64 -167 167 64 -165 minecraft:andesite
fill 187 64 -13 201 64 1 minecraft:coarse_dirt
fill 189 64 -11 199 64 -1 minecraft:dirt_path
fill 187 64 -19 201 64 -5 minecraft:coarse_dirt
fill 189 64 -17 199 64 -7 minecraft:dirt_path
fill 187 64 -26 201 64 -12 minecraft:coarse_dirt
fill 189 64 -24 199 64 -14 minecraft:dirt_path
fill 187 64 -32 201 64 -18 minecraft:coarse_dirt
fill 189 64 -30 199 64 -20 minecraft:dirt_path
fill 187 64 -38 201 64 -24 minecraft:coarse_dirt
fill 189 64 -36 199 64 -26 minecraft:dirt_path
fill 186 64 -45 200 64 -31 minecraft:coarse_dirt
fill 188 64 -43 198 64 -33 minecraft:dirt_path
fill 186 64 -51 200 64 -37 minecraft:coarse_dirt
fill 188 64 -49 198 64 -39 minecraft:dirt_path
fill 186 64 -57 200 64 -43 minecraft:coarse_dirt
fill 188 64 -55 198 64 -45 minecraft:dirt_path
fill 185 64 -63 199 64 -49 minecraft:coarse_dirt
fill 187 64 -61 197 64 -51 minecraft:dirt_path
fill 184 64 -69 198 64 -55 minecraft:coarse_dirt
fill 186 64 -67 196 64 -57 minecraft:dirt_path
fill 190 64 -63 192 64 -61 minecraft:andesite
fill 183 64 -76 197 64 -62 minecraft:coarse_dirt
fill 185 64 -74 195 64 -64 minecraft:dirt_path
fill 182 64 -82 196 64 -68 minecraft:coarse_dirt
fill 184 64 -80 194 64 -70 minecraft:dirt_path
fill 188 64 -76 190 64 -74 minecraft:andesite
fill 181 64 -88 195 64 -74 minecraft:coarse_dirt
fill 183 64 -86 193 64 -76 minecraft:dirt_path
fill 180 64 -94 194 64 -80 minecraft:coarse_dirt
fill 182 64 -92 192 64 -82 minecraft:dirt_path
fill 179 64 -100 193 64 -86 minecraft:coarse_dirt
fill 181 64 -98 191 64 -88 minecraft:dirt_path
fill 185 64 -94 187 64 -92 minecraft:andesite
fill 178 64 -107 192 64 -93 minecraft:coarse_dirt
fill 180 64 -105 190 64 -95 minecraft:dirt_path
fill 177 64 -113 191 64 -99 minecraft:coarse_dirt
fill 179 64 -111 189 64 -101 minecraft:dirt_path
fill 183 64 -107 185 64 -105 minecraft:andesite
fill 176 64 -119 190 64 -105 minecraft:coarse_dirt
fill 178 64 -117 188 64 -107 minecraft:dirt_path
fill 173 64 -124 187 64 -110 minecraft:coarse_dirt
fill 175 64 -122 185 64 -112 minecraft:dirt_path
fill 179 64 -118 181 64 -116 minecraft:andesite
fill 171 64 -130 185 64 -116 minecraft:coarse_dirt
fill 173 64 -128 183 64 -118 minecraft:dirt_path
fill 168 64 -135 182 64 -121 minecraft:coarse_dirt
fill 170 64 -133 180 64 -123 minecraft:dirt_path
fill 165 64 -141 179 64 -127 minecraft:coarse_dirt
fill 167 64 -139 177 64 -129 minecraft:dirt_path
fill 162 64 -146 176 64 -132 minecraft:coarse_dirt
fill 164 64 -144 174 64 -134 minecraft:dirt_path
fill 168 64 -140 170 64 -138 minecraft:andesite
fill 160 64 -152 174 64 -138 minecraft:coarse_dirt
fill 162 64 -150 172 64 -140 minecraft:dirt_path
fill 157 64 -157 171 64 -143 minecraft:coarse_dirt
fill 159 64 -155 169 64 -145 minecraft:dirt_path
fill 153 64 -162 167 64 -148 minecraft:coarse_dirt
fill 155 64 -160 165 64 -150 minecraft:dirt_path
fill 148 64 -168 162 64 -154 minecraft:coarse_dirt
fill 150 64 -166 160 64 -156 minecraft:dirt_path
fill 154 64 -162 156 64 -160 minecraft:andesite
fill 144 64 -173 158 64 -159 minecraft:coarse_dirt
fill 146 64 -171 156 64 -161 minecraft:dirt_path
fill 150 64 -167 152 64 -165 minecraft:andesite
fill 148 64 -204 204 64 -148 minecraft:polished_andesite
fill 155 64 -197 197 64 -155 minecraft:red_nether_bricks
fill 168 64 -184 184 64 -168 minecraft:redstone_block
fill 184 64 -198 198 64 -184 minecraft:smooth_quartz
fill 117 64 -99 131 64 -85 minecraft:podzol
summon minecraft:armor_stand 124 65 -92 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Sentinel","color":"aqua"}',CustomNameVisible:1b}
fill 147 64 -79 161 64 -65 minecraft:podzol
summon minecraft:armor_stand 154 65 -72 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Gromp","color":"green"}',CustomNameVisible:1b}
fill 89 64 -55 103 64 -41 minecraft:podzol
summon minecraft:armor_stand 96 65 -48 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Wolves","color":"gray"}',CustomNameVisible:1b}
fill 41 64 -111 55 64 -97 minecraft:podzol
summon minecraft:armor_stand 48 65 -104 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Raptors","color":"red"}',CustomNameVisible:1b}
fill 5 64 -139 19 64 -125 minecraft:podzol
summon minecraft:armor_stand 12 65 -132 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Brambleback","color":"red"}',CustomNameVisible:1b}
fill 47 64 -171 61 64 -157 minecraft:podzol
summon minecraft:armor_stand 54 65 -164 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Krugs","color":"gold"}',CustomNameVisible:1b}
fill 139 65 -86 167 69 -80 minecraft:mossy_cobblestone
fill 106 65 -68 134 69 -62 minecraft:mossy_cobblestone
fill 76 65 -111 84 69 -78 minecraft:mossy_cobblestone
fill 29 65 -155 37 69 -120 minecraft:mossy_cobblestone
fill 111 65 -125 145 69 -119 minecraft:mossy_cobblestone
fill 82 65 -151 110 69 -145 minecraft:mossy_cobblestone
fill 57 65 -181 63 69 -154 minecraft:mossy_cobblestone
fill 103 65 -35 128 69 -29 minecraft:mossy_cobblestone
fill 42 65 -43 70 69 -37 minecraft:mossy_cobblestone
fill 19 65 -95 25 69 -67 minecraft:mossy_cobblestone
fill 149 65 -62 155 69 -38 minecraft:mossy_cobblestone
fill 66 65 -117 92 69 -111 minecraft:mossy_cobblestone
fill 20 65 -22 42 69 -16 minecraft:mossy_cobblestone
fill -4 65 -101 18 69 -95 minecraft:mossy_cobblestone
fill 80 65 -175 103 69 -169 minecraft:mossy_cobblestone
execute positioned 165 65 -84 run function world_of_addons:worldgen/features/tree
execute positioned 87 65 -170 run function world_of_addons:worldgen/features/tree
execute positioned 104 65 -58 run function world_of_addons:worldgen/features/tree
execute positioned 68 65 -19 run function world_of_addons:worldgen/features/tree
execute positioned 104 65 -35 run function world_of_addons:worldgen/features/tree
execute positioned 82 65 -15 run function world_of_addons:worldgen/features/tree
execute positioned 43 65 -174 run function world_of_addons:worldgen/features/tree
execute positioned 139 65 -15 run function world_of_addons:worldgen/features/tree
execute positioned 77 65 -132 run function world_of_addons:worldgen/features/tree
execute positioned 179 65 -11 run function world_of_addons:worldgen/features/tree
execute positioned 134 65 -4 run function world_of_addons:worldgen/features/tree
execute positioned 93 65 -204 run function world_of_addons:worldgen/features/tree
execute positioned 51 65 -24 run function world_of_addons:worldgen/features/tree
execute positioned 83 65 -10 run function world_of_addons:worldgen/features/tree
execute positioned 104 65 -26 run function world_of_addons:worldgen/features/tree
execute positioned 103 65 -163 run function world_of_addons:worldgen/features/tree
execute positioned 3 65 -108 run function world_of_addons:worldgen/features/tree
execute positioned 131 65 -71 run function world_of_addons:worldgen/features/tree
execute positioned 63 65 -30 run function world_of_addons:worldgen/features/tree
execute positioned 20 65 -166 run function world_of_addons:worldgen/features/tree
execute positioned 154 65 -130 run function world_of_addons:worldgen/features/tree
execute positioned 176 65 -77 run function world_of_addons:worldgen/features/tree
fill 30 65 -185 40 65 -175 minecraft:short_grass replace minecraft:air
fill 107 65 -173 117 65 -163 minecraft:short_grass replace minecraft:air
fill 170 65 -40 180 65 -30 minecraft:short_grass replace minecraft:air
fill 31 65 -79 41 65 -69 minecraft:short_grass replace minecraft:air
fill 77 65 -25 87 65 -15 minecraft:short_grass replace minecraft:air
summon minecraft:armor_stand 187 65 -48 {Tags:["woa_static","woa_tower","woa_red","woa_top","woa_inner","woa_red_top_inner"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Top Inner Turret","color":"red"}'}
scoreboard players set @e[tag=woa_red_top_inner,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_red_top_inner,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display 187 65 -48 {Tags:["woa_static","woa_tower_visual","woa_red_top_inner"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 187 65 -48 {Tags:["woa_static","woa_tower_visual","woa_red_top_inner"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 187 65 -48 {Tags:["woa_static","woa_tower_visual","woa_red_top_inner"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 187 65 -48 {Tags:["woa_static","woa_tower_visual","woa_red_top_inner"],block_state:{Name:"minecraft:shroomlight"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 164 65 -124 {Tags:["woa_static","woa_tower","woa_red","woa_top","woa_inhibitor","woa_red_top_inhibitor"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Top Inhibitor Turret","color":"red"}'}
scoreboard players set @e[tag=woa_red_top_inhibitor,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_red_top_inhibitor,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display 164 65 -124 {Tags:["woa_static","woa_tower_visual","woa_red_top_inhibitor"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 164 65 -124 {Tags:["woa_static","woa_tower_visual","woa_red_top_inhibitor"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 164 65 -124 {Tags:["woa_static","woa_tower_visual","woa_red_top_inhibitor"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 164 65 -124 {Tags:["woa_static","woa_tower_visual","woa_red_top_inhibitor"],block_state:{Name:"minecraft:shroomlight"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 62 65 -62 {Tags:["woa_static","woa_tower","woa_red","woa_mid","woa_outer","woa_red_mid_outer"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Mid Outer Turret","color":"red"}'}
scoreboard players set @e[tag=woa_red_mid_outer,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_red_mid_outer,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display 62 65 -62 {Tags:["woa_static","woa_tower_visual","woa_red_mid_outer"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 62 65 -62 {Tags:["woa_static","woa_tower_visual","woa_red_mid_outer"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 62 65 -62 {Tags:["woa_static","woa_tower_visual","woa_red_mid_outer"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 62 65 -62 {Tags:["woa_static","woa_tower_visual","woa_red_mid_outer"],block_state:{Name:"minecraft:shroomlight"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 105 65 -105 {Tags:["woa_static","woa_tower","woa_red","woa_mid","woa_inner","woa_red_mid_inner"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Mid Inner Turret","color":"red"}'}
scoreboard players set @e[tag=woa_red_mid_inner,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_red_mid_inner,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display 105 65 -105 {Tags:["woa_static","woa_tower_visual","woa_red_mid_inner"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 105 65 -105 {Tags:["woa_static","woa_tower_visual","woa_red_mid_inner"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 105 65 -105 {Tags:["woa_static","woa_tower_visual","woa_red_mid_inner"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 105 65 -105 {Tags:["woa_static","woa_tower_visual","woa_red_mid_inner"],block_state:{Name:"minecraft:shroomlight"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 143 65 -143 {Tags:["woa_static","woa_tower","woa_red","woa_mid","woa_inhibitor","woa_red_mid_inhibitor"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Mid Inhibitor Turret","color":"red"}'}
scoreboard players set @e[tag=woa_red_mid_inhibitor,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_red_mid_inhibitor,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display 143 65 -143 {Tags:["woa_static","woa_tower_visual","woa_red_mid_inhibitor"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 143 65 -143 {Tags:["woa_static","woa_tower_visual","woa_red_mid_inhibitor"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 143 65 -143 {Tags:["woa_static","woa_tower_visual","woa_red_mid_inhibitor"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 143 65 -143 {Tags:["woa_static","woa_tower_visual","woa_red_mid_inhibitor"],block_state:{Name:"minecraft:shroomlight"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 48 65 -187 {Tags:["woa_static","woa_tower","woa_red","woa_bot","woa_inner","woa_red_bot_inner"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Bot Inner Turret","color":"red"}'}
scoreboard players set @e[tag=woa_red_bot_inner,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_red_bot_inner,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display 48 65 -187 {Tags:["woa_static","woa_tower_visual","woa_red_bot_inner"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 48 65 -187 {Tags:["woa_static","woa_tower_visual","woa_red_bot_inner"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 48 65 -187 {Tags:["woa_static","woa_tower_visual","woa_red_bot_inner"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 48 65 -187 {Tags:["woa_static","woa_tower_visual","woa_red_bot_inner"],block_state:{Name:"minecraft:shroomlight"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 124 65 -164 {Tags:["woa_static","woa_tower","woa_red","woa_bot","woa_inhibitor","woa_red_bot_inhibitor"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Bot Inhibitor Turret","color":"red"}'}
scoreboard players set @e[tag=woa_red_bot_inhibitor,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_red_bot_inhibitor,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display 124 65 -164 {Tags:["woa_static","woa_tower_visual","woa_red_bot_inhibitor"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 124 65 -164 {Tags:["woa_static","woa_tower_visual","woa_red_bot_inhibitor"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 124 65 -164 {Tags:["woa_static","woa_tower_visual","woa_red_bot_inhibitor"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 124 65 -164 {Tags:["woa_static","woa_tower_visual","woa_red_bot_inhibitor"],block_state:{Name:"minecraft:shroomlight"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 166 65 -154 {Tags:["woa_static","woa_tower","woa_red","woa_nexus","woa_nexus_a","woa_red_nexus_nexus_a"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Nexus Turret","color":"red"}'}
scoreboard players set @e[tag=woa_red_nexus_nexus_a,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_red_nexus_nexus_a,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display 166 65 -154 {Tags:["woa_static","woa_tower_visual","woa_red_nexus_nexus_a"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 166 65 -154 {Tags:["woa_static","woa_tower_visual","woa_red_nexus_nexus_a"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 166 65 -154 {Tags:["woa_static","woa_tower_visual","woa_red_nexus_nexus_a"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 166 65 -154 {Tags:["woa_static","woa_tower_visual","woa_red_nexus_nexus_a"],block_state:{Name:"minecraft:shroomlight"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 154 65 -166 {Tags:["woa_static","woa_tower","woa_red","woa_nexus","woa_nexus_b","woa_red_nexus_nexus_b"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Nexus Turret","color":"red"}'}
scoreboard players set @e[tag=woa_red_nexus_nexus_b,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_red_nexus_nexus_b,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display 154 65 -166 {Tags:["woa_static","woa_tower_visual","woa_red_nexus_nexus_b"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 154 65 -166 {Tags:["woa_static","woa_tower_visual","woa_red_nexus_nexus_b"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 154 65 -166 {Tags:["woa_static","woa_tower_visual","woa_red_nexus_nexus_b"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 154 65 -166 {Tags:["woa_static","woa_tower_visual","woa_red_nexus_nexus_b"],block_state:{Name:"minecraft:shroomlight"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 157 65 -137 {Tags:["woa_static","woa_inhibitor","woa_red","woa_red_inhibitor_157_137"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Top Inhibitor","color":"red"}'}
summon minecraft:block_display 157 65 -137 {Tags:["woa_static","woa_inhibitor_visual","woa_red_inhibitor_157_137"],block_state:{Name:"minecraft:polished_blackstone_bricks"},view_range:1.5f,transformation:{translation:[-1.3f,0f,-1.3f],left_rotation:[0f,0f,0f,1f],scale:[2.6f,0.6f,2.6f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 157 65 -137 {Tags:["woa_static","woa_inhibitor_visual","woa_red_inhibitor_157_137"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-0.7150000000000001f,0.6f,-0.7150000000000001f],left_rotation:[0f,0f,0f,1f],scale:[1.4300000000000002f,2.0f,1.4300000000000002f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 157 65 -137 {Tags:["woa_static","woa_inhibitor_visual","woa_red_inhibitor_157_137"],block_state:{Name:"minecraft:beacon"},view_range:1.5f,transformation:{translation:[-0.5f,2.6f,-0.5f],left_rotation:[0f,0f,0f,1f],scale:[1.0f,1.0f,1.0f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 137 65 -157 {Tags:["woa_static","woa_inhibitor","woa_red","woa_red_inhibitor_137_157"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Bot Inhibitor","color":"red"}'}
summon minecraft:block_display 137 65 -157 {Tags:["woa_static","woa_inhibitor_visual","woa_red_inhibitor_137_157"],block_state:{Name:"minecraft:polished_blackstone_bricks"},view_range:1.5f,transformation:{translation:[-1.3f,0f,-1.3f],left_rotation:[0f,0f,0f,1f],scale:[2.6f,0.6f,2.6f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 137 65 -157 {Tags:["woa_static","woa_inhibitor_visual","woa_red_inhibitor_137_157"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-0.7150000000000001f,0.6f,-0.7150000000000001f],left_rotation:[0f,0f,0f,1f],scale:[1.4300000000000002f,2.0f,1.4300000000000002f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 137 65 -157 {Tags:["woa_static","woa_inhibitor_visual","woa_red_inhibitor_137_157"],block_state:{Name:"minecraft:beacon"},view_range:1.5f,transformation:{translation:[-0.5f,2.6f,-0.5f],left_rotation:[0f,0f,0f,1f],scale:[1.0f,1.0f,1.0f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 151 65 -151 {Tags:["woa_static","woa_inhibitor","woa_red","woa_red_inhibitor_151_151"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Mid Inhibitor","color":"red"}'}
summon minecraft:block_display 151 65 -151 {Tags:["woa_static","woa_inhibitor_visual","woa_red_inhibitor_151_151"],block_state:{Name:"minecraft:polished_blackstone_bricks"},view_range:1.5f,transformation:{translation:[-1.3f,0f,-1.3f],left_rotation:[0f,0f,0f,1f],scale:[2.6f,0.6f,2.6f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 151 65 -151 {Tags:["woa_static","woa_inhibitor_visual","woa_red_inhibitor_151_151"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-0.7150000000000001f,0.6f,-0.7150000000000001f],left_rotation:[0f,0f,0f,1f],scale:[1.4300000000000002f,2.0f,1.4300000000000002f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 151 65 -151 {Tags:["woa_static","woa_inhibitor_visual","woa_red_inhibitor_151_151"],block_state:{Name:"minecraft:beacon"},view_range:1.5f,transformation:{translation:[-0.5f,2.6f,-0.5f],left_rotation:[0f,0f,0f,1f],scale:[1.0f,1.0f,1.0f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand 176 65 -176 {Tags:["woa_static","woa_nexus","woa_red","woa_red_nexus_176_176"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Nexus","color":"red"}'}
summon minecraft:block_display 176 65 -176 {Tags:["woa_static","woa_nexus_visual","woa_red_nexus_176_176"],block_state:{Name:"minecraft:polished_blackstone_bricks"},view_range:1.5f,transformation:{translation:[-2.1f,0f,-2.1f],left_rotation:[0f,0f,0f,1f],scale:[4.2f,0.6f,4.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 176 65 -176 {Tags:["woa_static","woa_nexus_visual","woa_red_nexus_176_176"],block_state:{Name:"minecraft:redstone_block"},view_range:1.5f,transformation:{translation:[-1.1550000000000002f,0.6f,-1.1550000000000002f],left_rotation:[0f,0f,0f,1f],scale:[2.3100000000000005f,3.2f,2.3100000000000005f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display 176 65 -176 {Tags:["woa_static","woa_nexus_visual","woa_red_nexus_176_176"],block_state:{Name:"minecraft:beacon"},view_range:1.5f,transformation:{translation:[-0.5f,3.8f,-0.5f],left_rotation:[0f,0f,0f,1f],scale:[1.0f,1.0f,1.0f],right_rotation:[0f,0f,0f,1f]}}
