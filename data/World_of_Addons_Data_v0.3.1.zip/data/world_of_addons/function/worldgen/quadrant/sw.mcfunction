fill -224 60 0 -169 63 55 minecraft:stone
fill -224 64 0 -169 64 55 minecraft:grass_block
fill -224 60 56 -169 63 111 minecraft:stone
fill -224 64 56 -169 64 111 minecraft:grass_block
fill -224 60 112 -169 63 167 minecraft:stone
fill -224 64 112 -169 64 167 minecraft:grass_block
fill -224 60 168 -169 63 223 minecraft:stone
fill -224 64 168 -169 64 223 minecraft:grass_block
fill -224 60 224 -169 63 224 minecraft:stone
fill -224 64 224 -169 64 224 minecraft:grass_block
fill -168 60 0 -113 63 55 minecraft:stone
fill -168 64 0 -113 64 55 minecraft:grass_block
fill -168 60 56 -113 63 111 minecraft:stone
fill -168 64 56 -113 64 111 minecraft:grass_block
fill -168 60 112 -113 63 167 minecraft:stone
fill -168 64 112 -113 64 167 minecraft:grass_block
fill -168 60 168 -113 63 223 minecraft:stone
fill -168 64 168 -113 64 223 minecraft:grass_block
fill -168 60 224 -113 63 224 minecraft:stone
fill -168 64 224 -113 64 224 minecraft:grass_block
fill -112 60 0 -57 63 55 minecraft:stone
fill -112 64 0 -57 64 55 minecraft:grass_block
fill -112 60 56 -57 63 111 minecraft:stone
fill -112 64 56 -57 64 111 minecraft:grass_block
fill -112 60 112 -57 63 167 minecraft:stone
fill -112 64 112 -57 64 167 minecraft:grass_block
fill -112 60 168 -57 63 223 minecraft:stone
fill -112 64 168 -57 64 223 minecraft:grass_block
fill -112 60 224 -57 63 224 minecraft:stone
fill -112 64 224 -57 64 224 minecraft:grass_block
fill -56 60 0 -1 63 55 minecraft:stone
fill -56 64 0 -1 64 55 minecraft:grass_block
fill -56 60 56 -1 63 111 minecraft:stone
fill -56 64 56 -1 64 111 minecraft:grass_block
fill -56 60 112 -1 63 167 minecraft:stone
fill -56 64 112 -1 64 167 minecraft:grass_block
fill -56 60 168 -1 63 223 minecraft:stone
fill -56 64 168 -1 64 223 minecraft:grass_block
fill -56 60 224 -1 63 224 minecraft:stone
fill -56 64 224 -1 64 224 minecraft:grass_block
fill -164 64 138 -150 64 152 minecraft:coarse_dirt
fill -162 64 140 -152 64 150 minecraft:dirt_path
fill -158 64 144 -156 64 146 minecraft:andesite
fill -168 64 133 -154 64 147 minecraft:coarse_dirt
fill -166 64 135 -156 64 145 minecraft:dirt_path
fill -162 64 139 -160 64 141 minecraft:andesite
fill -172 64 127 -158 64 141 minecraft:coarse_dirt
fill -170 64 129 -160 64 139 minecraft:dirt_path
fill -176 64 121 -162 64 135 minecraft:coarse_dirt
fill -174 64 123 -164 64 133 minecraft:dirt_path
fill -180 64 116 -166 64 130 minecraft:coarse_dirt
fill -178 64 118 -168 64 128 minecraft:dirt_path
fill -184 64 111 -170 64 125 minecraft:coarse_dirt
fill -182 64 113 -172 64 123 minecraft:dirt_path
fill -188 64 105 -174 64 119 minecraft:coarse_dirt
fill -186 64 107 -176 64 117 minecraft:dirt_path
fill -182 64 111 -180 64 113 minecraft:andesite
fill -189 64 99 -175 64 113 minecraft:coarse_dirt
fill -187 64 101 -177 64 111 minecraft:dirt_path
fill -191 64 93 -177 64 107 minecraft:coarse_dirt
fill -189 64 95 -179 64 105 minecraft:dirt_path
fill -185 64 99 -183 64 101 minecraft:andesite
fill -192 64 87 -178 64 101 minecraft:coarse_dirt
fill -190 64 89 -180 64 99 minecraft:dirt_path
fill -193 64 81 -179 64 95 minecraft:coarse_dirt
fill -191 64 83 -181 64 93 minecraft:dirt_path
fill -195 64 75 -181 64 89 minecraft:coarse_dirt
fill -193 64 77 -183 64 87 minecraft:dirt_path
fill -196 64 69 -182 64 83 minecraft:coarse_dirt
fill -194 64 71 -184 64 81 minecraft:dirt_path
fill -197 64 63 -183 64 77 minecraft:coarse_dirt
fill -195 64 65 -185 64 75 minecraft:dirt_path
fill -191 64 69 -189 64 71 minecraft:andesite
fill -199 64 57 -185 64 71 minecraft:coarse_dirt
fill -197 64 59 -187 64 69 minecraft:dirt_path
fill -200 64 51 -186 64 65 minecraft:coarse_dirt
fill -198 64 53 -188 64 63 minecraft:dirt_path
fill -194 64 57 -192 64 59 minecraft:andesite
fill -200 64 45 -186 64 59 minecraft:coarse_dirt
fill -198 64 47 -188 64 57 minecraft:dirt_path
fill -194 64 51 -192 64 53 minecraft:andesite
fill -200 64 38 -186 64 52 minecraft:coarse_dirt
fill -198 64 40 -188 64 50 minecraft:dirt_path
fill -201 64 32 -187 64 46 minecraft:coarse_dirt
fill -199 64 34 -189 64 44 minecraft:dirt_path
fill -201 64 25 -187 64 39 minecraft:coarse_dirt
fill -199 64 27 -189 64 37 minecraft:dirt_path
fill -195 64 31 -193 64 33 minecraft:andesite
fill -201 64 19 -187 64 33 minecraft:coarse_dirt
fill -199 64 21 -189 64 31 minecraft:dirt_path
fill -195 64 25 -193 64 27 minecraft:andesite
fill -201 64 12 -187 64 26 minecraft:coarse_dirt
fill -199 64 14 -189 64 24 minecraft:dirt_path
fill -202 64 6 -188 64 20 minecraft:coarse_dirt
fill -200 64 8 -190 64 18 minecraft:dirt_path
fill -202 64 -1 -188 64 13 minecraft:coarse_dirt
fill -200 64 1 -190 64 11 minecraft:dirt_path
fill -196 64 5 -194 64 7 minecraft:andesite
fill -202 64 -7 -188 64 7 minecraft:coarse_dirt
fill -200 64 -5 -190 64 5 minecraft:dirt_path
fill -196 64 -1 -194 64 1 minecraft:andesite
fill -157 64 143 -143 64 157 minecraft:coarse_dirt
fill -155 64 145 -145 64 155 minecraft:dirt_path
fill -151 64 149 -149 64 151 minecraft:andesite
fill -153 64 139 -139 64 153 minecraft:coarse_dirt
fill -151 64 141 -141 64 151 minecraft:dirt_path
fill -147 64 145 -145 64 147 minecraft:andesite
fill -148 64 134 -134 64 148 minecraft:coarse_dirt
fill -146 64 136 -136 64 146 minecraft:dirt_path
fill -142 64 140 -140 64 142 minecraft:andesite
fill -144 64 130 -130 64 144 minecraft:coarse_dirt
fill -142 64 132 -132 64 142 minecraft:dirt_path
fill -138 64 136 -136 64 138 minecraft:andesite
fill -140 64 126 -126 64 140 minecraft:coarse_dirt
fill -138 64 128 -128 64 138 minecraft:dirt_path
fill -134 64 132 -132 64 134 minecraft:andesite
fill -136 64 122 -122 64 136 minecraft:coarse_dirt
fill -134 64 124 -124 64 134 minecraft:dirt_path
fill -130 64 128 -128 64 130 minecraft:andesite
fill -131 64 117 -117 64 131 minecraft:coarse_dirt
fill -129 64 119 -119 64 129 minecraft:dirt_path
fill -125 64 123 -123 64 125 minecraft:andesite
fill -127 64 113 -113 64 127 minecraft:coarse_dirt
fill -125 64 115 -115 64 125 minecraft:dirt_path
fill -121 64 119 -119 64 121 minecraft:andesite
fill -122 64 108 -108 64 122 minecraft:coarse_dirt
fill -120 64 110 -110 64 120 minecraft:dirt_path
fill -116 64 114 -114 64 116 minecraft:andesite
fill -118 64 104 -104 64 118 minecraft:coarse_dirt
fill -116 64 106 -106 64 116 minecraft:dirt_path
fill -112 64 110 -110 64 112 minecraft:andesite
fill -113 64 99 -99 64 113 minecraft:coarse_dirt
fill -111 64 101 -101 64 111 minecraft:dirt_path
fill -107 64 105 -105 64 107 minecraft:andesite
fill -109 64 95 -95 64 109 minecraft:coarse_dirt
fill -107 64 97 -97 64 107 minecraft:dirt_path
fill -103 64 101 -101 64 103 minecraft:andesite
fill -104 64 90 -90 64 104 minecraft:coarse_dirt
fill -102 64 92 -92 64 102 minecraft:dirt_path
fill -98 64 96 -96 64 98 minecraft:andesite
fill -100 64 86 -86 64 100 minecraft:coarse_dirt
fill -98 64 88 -88 64 98 minecraft:dirt_path
fill -94 64 92 -92 64 94 minecraft:andesite
fill -95 64 81 -81 64 95 minecraft:coarse_dirt
fill -93 64 83 -83 64 93 minecraft:dirt_path
fill -89 64 87 -87 64 89 minecraft:andesite
fill -90 64 76 -76 64 90 minecraft:coarse_dirt
fill -88 64 78 -78 64 88 minecraft:dirt_path
fill -84 64 82 -82 64 84 minecraft:andesite
fill -86 64 72 -72 64 86 minecraft:coarse_dirt
fill -84 64 74 -74 64 84 minecraft:dirt_path
fill -80 64 78 -78 64 80 minecraft:andesite
fill -81 64 67 -67 64 81 minecraft:coarse_dirt
fill -79 64 69 -69 64 79 minecraft:dirt_path
fill -75 64 73 -73 64 75 minecraft:andesite
fill -77 64 63 -63 64 77 minecraft:coarse_dirt
fill -75 64 65 -65 64 75 minecraft:dirt_path
fill -71 64 69 -69 64 71 minecraft:andesite
fill -72 64 58 -58 64 72 minecraft:coarse_dirt
fill -70 64 60 -60 64 70 minecraft:dirt_path
fill -66 64 64 -64 64 66 minecraft:andesite
fill -68 64 54 -54 64 68 minecraft:coarse_dirt
fill -66 64 56 -56 64 66 minecraft:dirt_path
fill -62 64 60 -60 64 62 minecraft:andesite
fill -63 64 49 -49 64 63 minecraft:coarse_dirt
fill -61 64 51 -51 64 61 minecraft:dirt_path
fill -57 64 55 -55 64 57 minecraft:andesite
fill -59 64 45 -45 64 59 minecraft:coarse_dirt
fill -57 64 47 -47 64 57 minecraft:dirt_path
fill -53 64 51 -51 64 53 minecraft:andesite
fill -55 64 41 -41 64 55 minecraft:coarse_dirt
fill -53 64 43 -43 64 53 minecraft:dirt_path
fill -49 64 47 -47 64 49 minecraft:andesite
fill -50 64 36 -36 64 50 minecraft:coarse_dirt
fill -48 64 38 -38 64 48 minecraft:dirt_path
fill -44 64 42 -42 64 44 minecraft:andesite
fill -46 64 32 -32 64 46 minecraft:coarse_dirt
fill -44 64 34 -34 64 44 minecraft:dirt_path
fill -40 64 38 -38 64 40 minecraft:andesite
fill -42 64 28 -28 64 42 minecraft:coarse_dirt
fill -40 64 30 -30 64 40 minecraft:dirt_path
fill -36 64 34 -34 64 36 minecraft:andesite
fill -37 64 23 -23 64 37 minecraft:coarse_dirt
fill -35 64 25 -25 64 35 minecraft:dirt_path
fill -31 64 29 -29 64 31 minecraft:andesite
fill -33 64 19 -19 64 33 minecraft:coarse_dirt
fill -31 64 21 -21 64 31 minecraft:dirt_path
fill -27 64 25 -25 64 27 minecraft:andesite
fill -29 64 15 -15 64 29 minecraft:coarse_dirt
fill -27 64 17 -17 64 27 minecraft:dirt_path
fill -23 64 21 -21 64 23 minecraft:andesite
fill -25 64 11 -11 64 25 minecraft:coarse_dirt
fill -23 64 13 -13 64 23 minecraft:dirt_path
fill -19 64 17 -17 64 19 minecraft:andesite
fill -20 64 6 -6 64 20 minecraft:coarse_dirt
fill -18 64 8 -8 64 18 minecraft:dirt_path
fill -14 64 12 -12 64 14 minecraft:andesite
fill -16 64 2 -2 64 16 minecraft:coarse_dirt
fill -14 64 4 -4 64 14 minecraft:dirt_path
fill -10 64 8 -8 64 10 minecraft:andesite
fill -11 64 -3 3 64 11 minecraft:coarse_dirt
fill -9 64 -1 1 64 9 minecraft:dirt_path
fill -5 64 3 -3 64 5 minecraft:andesite
fill -152 64 150 -138 64 164 minecraft:coarse_dirt
fill -150 64 152 -140 64 162 minecraft:dirt_path
fill -146 64 156 -144 64 158 minecraft:andesite
fill -147 64 154 -133 64 168 minecraft:coarse_dirt
fill -145 64 156 -135 64 166 minecraft:dirt_path
fill -141 64 160 -139 64 162 minecraft:andesite
fill -141 64 158 -127 64 172 minecraft:coarse_dirt
fill -139 64 160 -129 64 170 minecraft:dirt_path
fill -135 64 162 -121 64 176 minecraft:coarse_dirt
fill -133 64 164 -123 64 174 minecraft:dirt_path
fill -130 64 166 -116 64 180 minecraft:coarse_dirt
fill -128 64 168 -118 64 178 minecraft:dirt_path
fill -125 64 170 -111 64 184 minecraft:coarse_dirt
fill -123 64 172 -113 64 182 minecraft:dirt_path
fill -119 64 174 -105 64 188 minecraft:coarse_dirt
fill -117 64 176 -107 64 186 minecraft:dirt_path
fill -113 64 180 -111 64 182 minecraft:andesite
fill -113 64 175 -99 64 189 minecraft:coarse_dirt
fill -111 64 177 -101 64 187 minecraft:dirt_path
fill -107 64 177 -93 64 191 minecraft:coarse_dirt
fill -105 64 179 -95 64 189 minecraft:dirt_path
fill -101 64 183 -99 64 185 minecraft:andesite
fill -101 64 178 -87 64 192 minecraft:coarse_dirt
fill -99 64 180 -89 64 190 minecraft:dirt_path
fill -95 64 179 -81 64 193 minecraft:coarse_dirt
fill -93 64 181 -83 64 191 minecraft:dirt_path
fill -89 64 181 -75 64 195 minecraft:coarse_dirt
fill -87 64 183 -77 64 193 minecraft:dirt_path
fill -83 64 182 -69 64 196 minecraft:coarse_dirt
fill -81 64 184 -71 64 194 minecraft:dirt_path
fill -77 64 183 -63 64 197 minecraft:coarse_dirt
fill -75 64 185 -65 64 195 minecraft:dirt_path
fill -71 64 189 -69 64 191 minecraft:andesite
fill -71 64 185 -57 64 199 minecraft:coarse_dirt
fill -69 64 187 -59 64 197 minecraft:dirt_path
fill -65 64 186 -51 64 200 minecraft:coarse_dirt
fill -63 64 188 -53 64 198 minecraft:dirt_path
fill -59 64 192 -57 64 194 minecraft:andesite
fill -59 64 186 -45 64 200 minecraft:coarse_dirt
fill -57 64 188 -47 64 198 minecraft:dirt_path
fill -53 64 192 -51 64 194 minecraft:andesite
fill -52 64 186 -38 64 200 minecraft:coarse_dirt
fill -50 64 188 -40 64 198 minecraft:dirt_path
fill -46 64 187 -32 64 201 minecraft:coarse_dirt
fill -44 64 189 -34 64 199 minecraft:dirt_path
fill -39 64 187 -25 64 201 minecraft:coarse_dirt
fill -37 64 189 -27 64 199 minecraft:dirt_path
fill -33 64 193 -31 64 195 minecraft:andesite
fill -33 64 187 -19 64 201 minecraft:coarse_dirt
fill -31 64 189 -21 64 199 minecraft:dirt_path
fill -27 64 193 -25 64 195 minecraft:andesite
fill -26 64 187 -12 64 201 minecraft:coarse_dirt
fill -24 64 189 -14 64 199 minecraft:dirt_path
fill -20 64 188 -6 64 202 minecraft:coarse_dirt
fill -18 64 190 -8 64 200 minecraft:dirt_path
fill -13 64 188 1 64 202 minecraft:coarse_dirt
fill -11 64 190 -1 64 200 minecraft:dirt_path
fill -7 64 194 -5 64 196 minecraft:andesite
fill -204 64 148 -148 64 204 minecraft:polished_andesite
fill -197 64 155 -155 64 197 minecraft:prismarine_bricks
fill -184 64 168 -168 64 184 minecraft:lapis_block
fill -198 64 184 -184 64 198 minecraft:smooth_quartz
fill -131 64 85 -117 64 99 minecraft:podzol
summon minecraft:armor_stand -124 65 92 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Sentinel","color":"aqua"}',CustomNameVisible:1b}
fill -161 64 65 -147 64 79 minecraft:podzol
summon minecraft:armor_stand -154 65 72 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Gromp","color":"green"}',CustomNameVisible:1b}
fill -103 64 41 -89 64 55 minecraft:podzol
summon minecraft:armor_stand -96 65 48 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Wolves","color":"gray"}',CustomNameVisible:1b}
fill -55 64 97 -41 64 111 minecraft:podzol
summon minecraft:armor_stand -48 65 104 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Raptors","color":"red"}',CustomNameVisible:1b}
fill -19 64 125 -5 64 139 minecraft:podzol
summon minecraft:armor_stand -12 65 132 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Red Brambleback","color":"red"}',CustomNameVisible:1b}
fill -61 64 157 -47 64 171 minecraft:podzol
summon minecraft:armor_stand -54 65 164 {Tags:["woa_static","woa_camp"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Krugs","color":"gold"}',CustomNameVisible:1b}
fill -167 65 80 -139 69 86 minecraft:mossy_cobblestone
fill -134 65 62 -106 69 68 minecraft:mossy_cobblestone
fill -84 65 78 -76 69 111 minecraft:mossy_cobblestone
fill -37 65 120 -29 69 155 minecraft:mossy_cobblestone
fill -145 65 119 -111 69 125 minecraft:mossy_cobblestone
fill -110 65 145 -82 69 151 minecraft:mossy_cobblestone
fill -63 65 154 -57 69 181 minecraft:mossy_cobblestone
fill -128 65 29 -103 69 35 minecraft:mossy_cobblestone
fill -70 65 37 -42 69 43 minecraft:mossy_cobblestone
fill -25 65 67 -19 69 95 minecraft:mossy_cobblestone
fill -155 65 38 -149 69 62 minecraft:mossy_cobblestone
fill -92 65 111 -66 69 117 minecraft:mossy_cobblestone
fill -42 65 16 -20 69 22 minecraft:mossy_cobblestone
fill -18 65 95 4 69 101 minecraft:mossy_cobblestone
fill -103 65 169 -80 69 175 minecraft:mossy_cobblestone
execute positioned -114 65 72 run function world_of_addons:worldgen/features/tree
execute positioned -4 65 163 run function world_of_addons:worldgen/features/tree
execute positioned -57 65 139 run function world_of_addons:worldgen/features/tree
execute positioned -83 65 40 run function world_of_addons:worldgen/features/tree
execute positioned -68 65 137 run function world_of_addons:worldgen/features/tree
execute positioned -55 65 142 run function world_of_addons:worldgen/features/tree
execute positioned -106 65 141 run function world_of_addons:worldgen/features/tree
execute positioned -66 65 21 run function world_of_addons:worldgen/features/tree
execute positioned -127 65 193 run function world_of_addons:worldgen/features/tree
execute positioned -106 65 138 run function world_of_addons:worldgen/features/tree
execute positioned -38 65 170 run function world_of_addons:worldgen/features/tree
execute positioned -156 65 104 run function world_of_addons:worldgen/features/tree
execute positioned -118 65 21 run function world_of_addons:worldgen/features/tree
execute positioned -155 65 50 run function world_of_addons:worldgen/features/tree
execute positioned -9 65 170 run function world_of_addons:worldgen/features/tree
execute positioned -134 65 186 run function world_of_addons:worldgen/features/tree
execute positioned -143 65 37 run function world_of_addons:worldgen/features/tree
execute positioned -73 65 34 run function world_of_addons:worldgen/features/tree
execute positioned -99 65 17 run function world_of_addons:worldgen/features/tree
execute positioned -147 65 13 run function world_of_addons:worldgen/features/tree
execute positioned -19 65 117 run function world_of_addons:worldgen/features/tree
execute positioned -18 65 143 run function world_of_addons:worldgen/features/tree
fill -180 65 30 -170 65 40 minecraft:short_grass replace minecraft:air
fill -40 65 175 -30 65 185 minecraft:short_grass replace minecraft:air
fill -117 65 163 -107 65 173 minecraft:short_grass replace minecraft:air
fill -41 65 69 -31 65 79 minecraft:short_grass replace minecraft:air
fill -87 65 15 -77 65 25 minecraft:short_grass replace minecraft:air
summon minecraft:armor_stand -187 65 48 {Tags:["woa_static","woa_tower","woa_blue","woa_top","woa_inner","woa_blue_top_inner"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Top Inner Turret","color":"blue"}'}
scoreboard players set @e[tag=woa_blue_top_inner,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_blue_top_inner,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display -187 65 48 {Tags:["woa_static","woa_tower_visual","woa_blue_top_inner"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -187 65 48 {Tags:["woa_static","woa_tower_visual","woa_blue_top_inner"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -187 65 48 {Tags:["woa_static","woa_tower_visual","woa_blue_top_inner"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -187 65 48 {Tags:["woa_static","woa_tower_visual","woa_blue_top_inner"],block_state:{Name:"minecraft:sea_lantern"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -164 65 124 {Tags:["woa_static","woa_tower","woa_blue","woa_top","woa_inhibitor","woa_blue_top_inhibitor"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Top Inhibitor Turret","color":"blue"}'}
scoreboard players set @e[tag=woa_blue_top_inhibitor,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_blue_top_inhibitor,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display -164 65 124 {Tags:["woa_static","woa_tower_visual","woa_blue_top_inhibitor"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -164 65 124 {Tags:["woa_static","woa_tower_visual","woa_blue_top_inhibitor"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -164 65 124 {Tags:["woa_static","woa_tower_visual","woa_blue_top_inhibitor"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -164 65 124 {Tags:["woa_static","woa_tower_visual","woa_blue_top_inhibitor"],block_state:{Name:"minecraft:sea_lantern"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -62 65 62 {Tags:["woa_static","woa_tower","woa_blue","woa_mid","woa_outer","woa_blue_mid_outer"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Mid Outer Turret","color":"blue"}'}
scoreboard players set @e[tag=woa_blue_mid_outer,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_blue_mid_outer,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display -62 65 62 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_outer"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -62 65 62 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_outer"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -62 65 62 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_outer"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -62 65 62 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_outer"],block_state:{Name:"minecraft:sea_lantern"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -105 65 105 {Tags:["woa_static","woa_tower","woa_blue","woa_mid","woa_inner","woa_blue_mid_inner"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Mid Inner Turret","color":"blue"}'}
scoreboard players set @e[tag=woa_blue_mid_inner,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_blue_mid_inner,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display -105 65 105 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_inner"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -105 65 105 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_inner"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -105 65 105 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_inner"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -105 65 105 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_inner"],block_state:{Name:"minecraft:sea_lantern"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -143 65 143 {Tags:["woa_static","woa_tower","woa_blue","woa_mid","woa_inhibitor","woa_blue_mid_inhibitor"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Mid Inhibitor Turret","color":"blue"}'}
scoreboard players set @e[tag=woa_blue_mid_inhibitor,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_blue_mid_inhibitor,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display -143 65 143 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_inhibitor"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -143 65 143 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_inhibitor"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -143 65 143 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_inhibitor"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -143 65 143 {Tags:["woa_static","woa_tower_visual","woa_blue_mid_inhibitor"],block_state:{Name:"minecraft:sea_lantern"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -48 65 187 {Tags:["woa_static","woa_tower","woa_blue","woa_bot","woa_inner","woa_blue_bot_inner"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Bot Inner Turret","color":"blue"}'}
scoreboard players set @e[tag=woa_blue_bot_inner,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_blue_bot_inner,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display -48 65 187 {Tags:["woa_static","woa_tower_visual","woa_blue_bot_inner"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -48 65 187 {Tags:["woa_static","woa_tower_visual","woa_blue_bot_inner"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -48 65 187 {Tags:["woa_static","woa_tower_visual","woa_blue_bot_inner"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -48 65 187 {Tags:["woa_static","woa_tower_visual","woa_blue_bot_inner"],block_state:{Name:"minecraft:sea_lantern"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -124 65 164 {Tags:["woa_static","woa_tower","woa_blue","woa_bot","woa_inhibitor","woa_blue_bot_inhibitor"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Bot Inhibitor Turret","color":"blue"}'}
scoreboard players set @e[tag=woa_blue_bot_inhibitor,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_blue_bot_inhibitor,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display -124 65 164 {Tags:["woa_static","woa_tower_visual","woa_blue_bot_inhibitor"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -124 65 164 {Tags:["woa_static","woa_tower_visual","woa_blue_bot_inhibitor"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -124 65 164 {Tags:["woa_static","woa_tower_visual","woa_blue_bot_inhibitor"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -124 65 164 {Tags:["woa_static","woa_tower_visual","woa_blue_bot_inhibitor"],block_state:{Name:"minecraft:sea_lantern"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -166 65 154 {Tags:["woa_static","woa_tower","woa_blue","woa_nexus","woa_nexus_a","woa_blue_nexus_nexus_a"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Nexus Turret","color":"blue"}'}
scoreboard players set @e[tag=woa_blue_nexus_nexus_a,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_blue_nexus_nexus_a,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display -166 65 154 {Tags:["woa_static","woa_tower_visual","woa_blue_nexus_nexus_a"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -166 65 154 {Tags:["woa_static","woa_tower_visual","woa_blue_nexus_nexus_a"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -166 65 154 {Tags:["woa_static","woa_tower_visual","woa_blue_nexus_nexus_a"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -166 65 154 {Tags:["woa_static","woa_tower_visual","woa_blue_nexus_nexus_a"],block_state:{Name:"minecraft:sea_lantern"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -154 65 166 {Tags:["woa_static","woa_tower","woa_blue","woa_nexus","woa_nexus_b","woa_blue_nexus_nexus_b"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Nexus Turret","color":"blue"}'}
scoreboard players set @e[tag=woa_blue_nexus_nexus_b,distance=..2,sort=nearest,limit=1] woa_hp 1200
scoreboard players set @e[tag=woa_blue_nexus_nexus_b,distance=..2,sort=nearest,limit=1] woa_tower_cd 0
summon minecraft:block_display -154 65 166 {Tags:["woa_static","woa_tower_visual","woa_blue_nexus_nexus_b"],block_state:{Name:"minecraft:polished_deepslate"},view_range:1.5f,transformation:{translation:[-1.6f,0f,-1.6f],left_rotation:[0f,0f,0f,1f],scale:[3.2f,0.8f,3.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -154 65 166 {Tags:["woa_static","woa_tower_visual","woa_blue_nexus_nexus_b"],block_state:{Name:"minecraft:stone_bricks"},view_range:1.5f,transformation:{translation:[-0.9f,0.8f,-0.9f],left_rotation:[0f,0f,0f,1f],scale:[1.8f,4.2f,1.8f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -154 65 166 {Tags:["woa_static","woa_tower_visual","woa_blue_nexus_nexus_b"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1f,5.0f,-1.1f],left_rotation:[0f,0f,0f,1f],scale:[2.2f,0.9f,2.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -154 65 166 {Tags:["woa_static","woa_tower_visual","woa_blue_nexus_nexus_b"],block_state:{Name:"minecraft:sea_lantern"},view_range:1.5f,transformation:{translation:[-0.55f,5.9f,-0.55f],left_rotation:[0f,0f,0f,1f],scale:[1.1f,1.1f,1.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -157 65 137 {Tags:["woa_static","woa_inhibitor","woa_blue","woa_blue_inhibitor_157_137"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Top Inhibitor","color":"blue"}'}
summon minecraft:block_display -157 65 137 {Tags:["woa_static","woa_inhibitor_visual","woa_blue_inhibitor_157_137"],block_state:{Name:"minecraft:polished_blackstone_bricks"},view_range:1.5f,transformation:{translation:[-1.3f,0f,-1.3f],left_rotation:[0f,0f,0f,1f],scale:[2.6f,0.6f,2.6f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -157 65 137 {Tags:["woa_static","woa_inhibitor_visual","woa_blue_inhibitor_157_137"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-0.7150000000000001f,0.6f,-0.7150000000000001f],left_rotation:[0f,0f,0f,1f],scale:[1.4300000000000002f,2.0f,1.4300000000000002f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -157 65 137 {Tags:["woa_static","woa_inhibitor_visual","woa_blue_inhibitor_157_137"],block_state:{Name:"minecraft:beacon"},view_range:1.5f,transformation:{translation:[-0.5f,2.6f,-0.5f],left_rotation:[0f,0f,0f,1f],scale:[1.0f,1.0f,1.0f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -137 65 157 {Tags:["woa_static","woa_inhibitor","woa_blue","woa_blue_inhibitor_137_157"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Bot Inhibitor","color":"blue"}'}
summon minecraft:block_display -137 65 157 {Tags:["woa_static","woa_inhibitor_visual","woa_blue_inhibitor_137_157"],block_state:{Name:"minecraft:polished_blackstone_bricks"},view_range:1.5f,transformation:{translation:[-1.3f,0f,-1.3f],left_rotation:[0f,0f,0f,1f],scale:[2.6f,0.6f,2.6f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -137 65 157 {Tags:["woa_static","woa_inhibitor_visual","woa_blue_inhibitor_137_157"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-0.7150000000000001f,0.6f,-0.7150000000000001f],left_rotation:[0f,0f,0f,1f],scale:[1.4300000000000002f,2.0f,1.4300000000000002f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -137 65 157 {Tags:["woa_static","woa_inhibitor_visual","woa_blue_inhibitor_137_157"],block_state:{Name:"minecraft:beacon"},view_range:1.5f,transformation:{translation:[-0.5f,2.6f,-0.5f],left_rotation:[0f,0f,0f,1f],scale:[1.0f,1.0f,1.0f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -151 65 151 {Tags:["woa_static","woa_inhibitor","woa_blue","woa_blue_inhibitor_151_151"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Mid Inhibitor","color":"blue"}'}
summon minecraft:block_display -151 65 151 {Tags:["woa_static","woa_inhibitor_visual","woa_blue_inhibitor_151_151"],block_state:{Name:"minecraft:polished_blackstone_bricks"},view_range:1.5f,transformation:{translation:[-1.3f,0f,-1.3f],left_rotation:[0f,0f,0f,1f],scale:[2.6f,0.6f,2.6f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -151 65 151 {Tags:["woa_static","woa_inhibitor_visual","woa_blue_inhibitor_151_151"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-0.7150000000000001f,0.6f,-0.7150000000000001f],left_rotation:[0f,0f,0f,1f],scale:[1.4300000000000002f,2.0f,1.4300000000000002f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -151 65 151 {Tags:["woa_static","woa_inhibitor_visual","woa_blue_inhibitor_151_151"],block_state:{Name:"minecraft:beacon"},view_range:1.5f,transformation:{translation:[-0.5f,2.6f,-0.5f],left_rotation:[0f,0f,0f,1f],scale:[1.0f,1.0f,1.0f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:armor_stand -176 65 176 {Tags:["woa_static","woa_nexus","woa_blue","woa_blue_nexus_176_176"],Invisible:1b,Marker:1b,NoGravity:1b,CustomName:'{"text":"Blue Nexus","color":"blue"}'}
summon minecraft:block_display -176 65 176 {Tags:["woa_static","woa_nexus_visual","woa_blue_nexus_176_176"],block_state:{Name:"minecraft:polished_blackstone_bricks"},view_range:1.5f,transformation:{translation:[-2.1f,0f,-2.1f],left_rotation:[0f,0f,0f,1f],scale:[4.2f,0.6f,4.2f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -176 65 176 {Tags:["woa_static","woa_nexus_visual","woa_blue_nexus_176_176"],block_state:{Name:"minecraft:lapis_block"},view_range:1.5f,transformation:{translation:[-1.1550000000000002f,0.6f,-1.1550000000000002f],left_rotation:[0f,0f,0f,1f],scale:[2.3100000000000005f,3.2f,2.3100000000000005f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display -176 65 176 {Tags:["woa_static","woa_nexus_visual","woa_blue_nexus_176_176"],block_state:{Name:"minecraft:beacon"},view_range:1.5f,transformation:{translation:[-0.5f,3.8f,-0.5f],left_rotation:[0f,0f,0f,1f],scale:[1.0f,1.0f,1.0f],right_rotation:[0f,0f,0f,1f]}}
