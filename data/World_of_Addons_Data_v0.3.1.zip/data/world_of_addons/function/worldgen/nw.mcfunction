forceload add -224 -224 15 15
function world_of_addons:worldgen/quadrant/nw
forceload remove -224 -224 15 15
bossbar set world_of_addons:generation value 25
schedule function world_of_addons:worldgen/ne 1t replace
