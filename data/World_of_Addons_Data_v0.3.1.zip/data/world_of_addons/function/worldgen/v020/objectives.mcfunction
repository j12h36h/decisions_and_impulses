# Ecosystem objective zones. Text uses proper JSON components rather than literal {text} placeholders.
kill @e[tag=woa_objective]
summon minecraft:text_display -72 74 -64 {Tags:["woa_static","woa_objective","woa_mammal_ecosystem"],text:'{"text":"MAMMAL ECOSYSTEM","color":"green","bold":true}',billboard:"center",see_through:1b,background:0,view_range:1.5f,shadow:1b}
summon minecraft:text_display -72 72.8 -64 {Tags:["woa_static","woa_objective","woa_mammal_ecosystem"],text:'{"text":"ALPINE HABITAT","color":"gray","italic":true}',billboard:"center",see_through:1b,background:0,view_range:1.5f}
summon minecraft:text_display 72 63 64 {Tags:["woa_static","woa_objective","woa_reptilian_habitat"],text:'{"text":"REPTILIAN HABITAT","color":"dark_green","bold":true}',billboard:"center",see_through:1b,background:0,view_range:1.5f,shadow:1b}
summon minecraft:text_display 72 61.8 64 {Tags:["woa_static","woa_objective","woa_reptilian_habitat"],text:'{"text":"EVERGLADES BASIN","color":"gold","italic":true}',billboard:"center",see_through:1b,background:0,view_range:1.5f}
bossbar set world_of_addons:generation value 95
schedule function world_of_addons:worldgen/v020/village 1t replace
