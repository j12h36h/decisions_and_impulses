fill ~-4 ~-3 ~-3 ~-4 ~ ~-3 minecraft:mangrove_log
fill ~4 ~-3 ~-3 ~4 ~ ~-3 minecraft:mangrove_log
fill ~-4 ~-3 ~3 ~-4 ~ ~3 minecraft:mangrove_log
fill ~4 ~-3 ~3 ~4 ~ ~3 minecraft:mangrove_log
fill ~-4 ~ ~-3 ~4 ~ ~3 minecraft:mangrove_planks
fill ~-4 ~1 ~-3 ~4 ~4 ~3 minecraft:mangrove_planks hollow
fill ~-5 ~5 ~-4 ~5 ~5 ~4 minecraft:mangrove_slab[type=top]
fill ~-1 ~1 ~-3 ~1 ~3 ~-3 minecraft:air
setblock ~ ~1 ~-3 minecraft:mangrove_door[facing=north,half=lower]
setblock ~ ~2 ~-3 minecraft:mangrove_door[facing=north,half=upper]
setblock ~-3 ~2 ~3 minecraft:lantern
setblock ~3 ~2 ~3 minecraft:lantern
