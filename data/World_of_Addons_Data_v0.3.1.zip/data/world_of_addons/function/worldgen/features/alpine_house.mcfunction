fill ~-4 ~ ~-3 ~4 ~4 ~3 minecraft:spruce_planks hollow
fill ~-5 ~4 ~-4 ~5 ~4 ~4 minecraft:stone_bricks
fill ~-4 ~5 ~-3 ~4 ~5 ~3 minecraft:spruce_slab[type=top]
fill ~-3 ~1 ~-3 ~3 ~2 ~-3 minecraft:glass_pane
fill ~-1 ~ ~-3 ~1 ~2 ~-3 minecraft:air
setblock ~ ~ ~-3 minecraft:spruce_door[facing=north,half=lower]
setblock ~ ~1 ~-3 minecraft:spruce_door[facing=north,half=upper]
setblock ~-3 ~1 ~3 minecraft:lantern
setblock ~3 ~1 ~3 minecraft:lantern
