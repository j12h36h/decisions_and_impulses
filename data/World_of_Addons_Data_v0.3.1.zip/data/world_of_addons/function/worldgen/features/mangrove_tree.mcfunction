setblock ~ ~ ~ minecraft:mangrove_roots
setblock ~1 ~ ~ minecraft:mangrove_roots
setblock ~-1 ~ ~ minecraft:mangrove_roots
setblock ~ ~ ~1 minecraft:mangrove_roots
fill ~ ~1 ~ ~ ~6 ~ minecraft:mangrove_log
fill ~-2 ~4 ~-2 ~2 ~5 ~2 minecraft:mangrove_leaves[persistent=true]
fill ~-3 ~5 ~-2 ~3 ~6 ~2 minecraft:mangrove_leaves[persistent=true]
fill ~-2 ~6 ~-3 ~2 ~7 ~3 minecraft:mangrove_leaves[persistent=true]
setblock ~ ~7 ~ minecraft:mangrove_leaves[persistent=true]
