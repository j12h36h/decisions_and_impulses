fill ~-1 ~ ~-1 ~1 ~3 ~1 minecraft:oak_log
fill ~-3 ~3 ~-3 ~3 ~5 ~3 minecraft:oak_leaves[persistent=true]
fill ~-2 ~6 ~-2 ~2 ~6 ~2 minecraft:oak_leaves[persistent=true]
setblock ~ ~7 ~ minecraft:oak_leaves[persistent=true]
