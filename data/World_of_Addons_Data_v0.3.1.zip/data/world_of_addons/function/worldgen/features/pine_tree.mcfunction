fill ~ ~ ~ ~ ~8 ~ minecraft:spruce_log
fill ~-2 ~5 ~-2 ~2 ~5 ~2 minecraft:spruce_leaves[persistent=true]
fill ~-3 ~6 ~-3 ~3 ~6 ~3 minecraft:spruce_leaves[persistent=true]
fill ~-2 ~7 ~-2 ~2 ~7 ~2 minecraft:spruce_leaves[persistent=true]
fill ~-1 ~8 ~-1 ~1 ~9 ~1 minecraft:spruce_leaves[persistent=true]
setblock ~ ~10 ~ minecraft:spruce_leaves[persistent=true]
