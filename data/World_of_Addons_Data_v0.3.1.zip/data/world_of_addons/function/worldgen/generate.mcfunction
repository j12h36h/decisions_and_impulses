kill @e[tag=woa_static]
kill @e[tag=woa_minion]
scoreboard players set #built woa_world 0
scoreboard players set #match woa_world 0
scoreboard players set #match_tick woa_world 0
scoreboard players set #wave woa_world 0
bossbar set world_of_addons:generation value 0
bossbar set world_of_addons:generation visible true
forceload add -16 -16 16 16
fill -16 60 -16 16 63 16 minecraft:stone
fill -16 64 -16 16 64 16 minecraft:grass_block
fill -5 65 -5 5 65 5 minecraft:smooth_stone
forceload remove -16 -16 16 16
schedule function world_of_addons:worldgen/nw 1t replace
