# World of Addons v0.3.0 — DAI 3.3 standalone experience bootstrap.
scoreboard objectives add woa_world dummy
scoreboard objectives add woa_team dummy
scoreboard objectives add woa_gold dummy
scoreboard objectives add woa_hp dummy
scoreboard objectives add woa_lane dummy
scoreboard objectives add woa_step dummy
scoreboard objectives add woa_age dummy
scoreboard objectives add woa_attack dummy
scoreboard objectives add woa_tower_cd dummy
scoreboard objectives add woa_char dummy
scoreboard objectives add woa_locked dummy
scoreboard objectives add woa_rune dummy
team add woa_blue {"text":"Blue Team","color":"blue"}
team add woa_red {"text":"Red Team","color":"red"}
team modify woa_blue color blue
team modify woa_red color red
team modify woa_blue friendlyFire false
team modify woa_red friendlyFire false
bossbar add world_of_addons:generation {"text":"Building World of Addons","color":"aqua"}
bossbar set world_of_addons:generation max 100
bossbar set world_of_addons:generation visible false
scoreboard players set #three woa_world 3
execute unless score #team_next woa_world matches 0..1 run scoreboard players set #team_next woa_world 0
execute unless score #built woa_world matches 0..1 run scoreboard players set #built woa_world 0
execute unless score #phase woa_world matches 0..4 run scoreboard players set #phase woa_world 0
# Shared recognized-character hook. Optional addon registrations run only when the addon contributes them.
function #world_of_addons:characters/register
