execute if score #phase woa_world matches 0 run title @s actionbar {"text":"Rift generation / lobby setup","color":"gray"}
execute if score #phase woa_world matches 1 run title @s actionbar [{"text":"CHAMPION SELECT  •  ","color":"gold","bold":true},{"text":"Lock in to ready up","color":"gray"}]
execute if score #phase woa_world matches 2 run title @s actionbar {"text":"All players ready — match countdown active","color":"gold"}
execute if score #phase woa_world matches 3 run title @s actionbar [{"text":"MATCH ACTIVE  •  Wave ","color":"green","bold":true},{"score":{"name":"#wave","objective":"woa_world"},"color":"white"},{"text":"  •  Gold ","color":"gray"},{"score":{"name":"@s","objective":"woa_gold"},"color":"gold"}]
execute if score #phase woa_world matches 4 run title @s actionbar {"text":"Match ended","color":"gold"}
