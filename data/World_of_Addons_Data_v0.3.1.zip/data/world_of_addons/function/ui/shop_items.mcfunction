execute unless score #phase woa_world matches 3 run title @s actionbar {"text":"Shop unlocks when the match begins.","color":"gray"}
execute if score #phase woa_world matches 3 run title @s actionbar [{"text":"ITEMS","color":"green","bold":true},{"text":" catalog foundation — purchasing is coming in the economy pass.","color":"gray"}]
