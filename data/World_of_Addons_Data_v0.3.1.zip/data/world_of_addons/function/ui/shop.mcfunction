execute unless score #phase woa_world matches 3 run title @s actionbar {"text":"Shop unlocks after Champion Select and match start.","color":"gray"}
execute if score #phase woa_world matches 3 run title @s actionbar [{"text":"SHOP  •  Gold ","color":"gold","bold":true},{"score":{"name":"@s","objective":"woa_gold"},"color":"yellow"}]
