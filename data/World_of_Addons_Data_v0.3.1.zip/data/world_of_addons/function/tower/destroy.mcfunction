particle minecraft:explosion_emitter ~ ~3 ~ 0 0 0 0 1 force
playsound minecraft:entity.generic.explode master @a[distance=..40] ~ ~ ~ 0.9 0.8
kill @e[tag=woa_tower_visual,distance=..5]
kill @s
