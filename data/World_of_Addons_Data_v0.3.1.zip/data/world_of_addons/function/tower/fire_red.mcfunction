damage @e[tag=woa_minion,tag=woa_blue,distance=..18,sort=nearest,limit=1] 12 minecraft:magic
particle minecraft:electric_spark ~ ~5 ~ 0.45 0.7 0.45 0.03 12 force
playsound minecraft:block.beacon.power_select master @a[distance=..24] ~ ~ ~ 0.35 0.75
scoreboard players set @s woa_tower_cd 20
