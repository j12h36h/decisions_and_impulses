# Alternating team assignment, then wait for native D.A.I. Champion Select unless a match is already active.
scoreboard players operation #assign woa_world = #team_next woa_world
execute if score #assign woa_world matches 0 run team join woa_blue @s
execute if score #assign woa_world matches 0 run tag @s add woa_blue
execute if score #assign woa_world matches 0 run scoreboard players set @s woa_team 1
execute if score #assign woa_world matches 0 run spawnpoint @s -176 66 176
execute if score #assign woa_world matches 1 run team join woa_red @s
execute if score #assign woa_world matches 1 run tag @s add woa_red
execute if score #assign woa_world matches 1 run scoreboard players set @s woa_team 2
execute if score #assign woa_world matches 1 run spawnpoint @s 176 66 -176
scoreboard players add #team_next woa_world 1
execute if score #team_next woa_world matches 2.. run scoreboard players set #team_next woa_world 0
scoreboard players set @s woa_gold 500
scoreboard players set @s woa_char 0
scoreboard players set @s woa_locked 0
scoreboard players set @s woa_rune 0
tag @s add woa_char_rift_minion
tag @s remove woa_char_kitty_claws
tag @s remove woa_char_echo_anomaly
tag @s add woa_joined

# Active-match joins wait instead of changing the ready gate.
execute if score #phase woa_world matches 3.. run tag @s add woa_waiting
execute if score #phase woa_world matches 3.. run gamemode spectator @s
execute if score #phase woa_world matches 3.. run title @s actionbar {"text":"Match already active — waiting as spectator","color":"gray"}
execute unless score #phase woa_world matches 3.. run tag @s add woa_participant
execute unless score #phase woa_world matches 3.. if score #built woa_world matches 1 run title @s title {"text":"CHAMPION SELECT","color":"gold","bold":true}
execute unless score #phase woa_world matches 3.. if score #built woa_world matches 1 run title @s subtitle [{"text":"Default: ","color":"gray"},{"text":"Rift Minion","color":"green","bold":true},{"text":" • recognized addon champions appear automatically","color":"aqua"}]
