spawnpoint @s 176 66 -176
