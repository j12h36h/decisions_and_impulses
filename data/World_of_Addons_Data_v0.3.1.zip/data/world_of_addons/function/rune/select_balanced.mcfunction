scoreboard players set @s woa_rune 0
title @s actionbar [{"text":"Rune selected: ","color":"gray"},{"text":"BALANCED","color":"gray","bold":true},{"text":" — No passive stat modifier.","color":"gray"}]
