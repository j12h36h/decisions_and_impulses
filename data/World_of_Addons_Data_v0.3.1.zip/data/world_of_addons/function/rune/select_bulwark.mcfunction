scoreboard players set @s woa_rune 2
title @s actionbar [{"text":"Rune selected: ","color":"gray"},{"text":"BULWARK","color":"aqua","bold":true},{"text":" — Resistance I while participating.","color":"gray"}]
