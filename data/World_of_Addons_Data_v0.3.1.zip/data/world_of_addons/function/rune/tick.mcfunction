# Refresh selected rune passives at 2 Hz (called from the existing ten-tick runtime).
execute as @a[tag=woa_participant,scores={woa_rune=1}] run effect give @s minecraft:strength 2 0 true
execute as @a[tag=woa_participant,scores={woa_rune=2}] run effect give @s minecraft:resistance 2 0 true
execute as @a[tag=woa_participant,scores={woa_rune=3}] run effect give @s minecraft:speed 2 0 true
