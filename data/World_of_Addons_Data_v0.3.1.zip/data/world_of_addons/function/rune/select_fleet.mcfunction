scoreboard players set @s woa_rune 3
title @s actionbar [{"text":"Rune selected: ","color":"gray"},{"text":"FLEET","color":"green","bold":true},{"text":" — Speed I while participating.","color":"gray"}]
