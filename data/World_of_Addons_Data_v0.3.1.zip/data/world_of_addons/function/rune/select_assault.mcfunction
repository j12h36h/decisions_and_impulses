scoreboard players set @s woa_rune 1
title @s actionbar [{"text":"Rune selected: ","color":"gray"},{"text":"ASSAULT","color":"red","bold":true},{"text":" — Strength I while participating.","color":"gray"}]
