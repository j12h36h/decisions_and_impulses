function world_of_addons:rune/tick
function world_of_addons:ui/hud
scoreboard players remove @e[tag=woa_tower,scores={woa_tower_cd=1..}] woa_tower_cd 10
execute as @e[tag=woa_tower,tag=woa_blue,scores={woa_tower_cd=..0}] at @s if entity @e[tag=woa_minion,tag=woa_red,distance=..18,limit=1] run function world_of_addons:tower/fire_blue
execute as @e[tag=woa_tower,tag=woa_red,scores={woa_tower_cd=..0}] at @s if entity @e[tag=woa_minion,tag=woa_blue,distance=..18,limit=1] run function world_of_addons:tower/fire_red
execute as @e[tag=woa_tower,scores={woa_hp=..0}] at @s run function world_of_addons:tower/destroy
