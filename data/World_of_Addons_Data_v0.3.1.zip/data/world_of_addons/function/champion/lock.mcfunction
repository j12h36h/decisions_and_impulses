# Standalone-safe Champion Select lock-in.
execute unless score #phase woa_world matches 1 run title @s actionbar {"text":"Champion Select is closed.","color":"red"}
execute if score #phase woa_world matches 1 if score @s woa_locked matches 1.. run title @s actionbar {"text":"Already locked in.","color":"gray"}

# Character 0 is the built-in Rift Minion and is the default selection.
execute if score #phase woa_world matches 1 if score @s woa_locked matches 0 if score @s woa_char matches 0 run function world_of_addons:champion/apply_rift_minion

# Recognized addon loadouts are called through optional function tags. Missing addons simply contribute nothing.
execute if score #phase woa_world matches 1 if score @s woa_locked matches 0 if score @s woa_char matches 1 run function #world_of_addons:characters/kitty_claws/apply_loadout
execute if score #phase woa_world matches 1 if score @s woa_locked matches 0 if score @s woa_char matches 2 run function #world_of_addons:characters/echo_anomaly/apply_loadout

execute if score #phase woa_world matches 1 if score @s woa_locked matches 0 run scoreboard players set @s woa_locked 1
execute if score #phase woa_world matches 1 if score @s woa_locked matches 1 if score @s woa_char matches 0 run title @s actionbar {"text":"LOCKED IN — RIFT MINION","color":"green","bold":true}
execute if score #phase woa_world matches 1 if score @s woa_locked matches 1 if score @s woa_char matches 1 run title @s actionbar {"text":"LOCKED IN — KITTY CLAWS","color":"light_purple","bold":true}
execute if score #phase woa_world matches 1 if score @s woa_locked matches 1 if score @s woa_char matches 2 run title @s actionbar {"text":"LOCKED IN — ECHO ANOMALY","color":"aqua","bold":true}
