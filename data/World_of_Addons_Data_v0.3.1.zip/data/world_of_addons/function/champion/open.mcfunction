title @s title {"text":"CHAMPION SELECT","color":"gold","bold":true}
title @s subtitle [{"text":"Rift Minion is always available","color":"green"},{"text":" • recognized addon champions appear automatically","color":"aqua"}]
