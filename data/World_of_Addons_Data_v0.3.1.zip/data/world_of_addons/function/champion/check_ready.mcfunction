# Online active participants are the ready gate; disconnected players automatically stop counting.
execute if entity @a[tag=woa_participant] unless entity @a[tag=woa_participant,scores={woa_locked=0}] run function world_of_addons:match/begin_countdown
