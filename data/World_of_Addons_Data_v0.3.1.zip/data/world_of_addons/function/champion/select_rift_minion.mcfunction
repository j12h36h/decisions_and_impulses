# Built-in standalone fallback character. Always available.
execute unless score #phase woa_world matches 1 run title @s actionbar {"text":"Champion Select is closed.","color":"red"}
execute if score #phase woa_world matches 1 if score @s woa_locked matches 1.. run title @s actionbar {"text":"You are already locked in.","color":"red"}
execute if score #phase woa_world matches 1 if score @s woa_locked matches 0 run scoreboard players set @s woa_char 0
execute if score #phase woa_world matches 1 if score @s woa_locked matches 0 run tag @s add woa_char_rift_minion
execute if score #phase woa_world matches 1 if score @s woa_locked matches 0 run tag @s remove woa_char_kitty_claws
execute if score #phase woa_world matches 1 if score @s woa_locked matches 0 run tag @s remove woa_char_echo_anomaly
execute if score #phase woa_world matches 1 if score @s woa_locked matches 0 run title @s actionbar [{"text":"Selected: ","color":"gray"},{"text":"Rift Minion","color":"green","bold":true},{"text":" — standalone fallback; choose LOCK IN when ready.","color":"gray"}]
