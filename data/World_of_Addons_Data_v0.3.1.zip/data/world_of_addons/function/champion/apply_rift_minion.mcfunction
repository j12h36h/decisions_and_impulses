# Resource-pack-free built-in fallback loadout.
give @s minecraft:iron_sword 1
give @s minecraft:shield 1
give @s minecraft:cooked_beef 16
