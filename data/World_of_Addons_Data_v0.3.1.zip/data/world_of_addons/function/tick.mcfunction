# World of Addons v0.2.1 global tick.
scoreboard players add #tick woa_world 1
execute as @a[tag=!woa_joined] run function world_of_addons:player/first_join

# All League/Champion/Shop navigation is native D.A.I. menu UI. No chat triggers are polled here.
execute if score #built woa_world matches 0 as @a run title @s actionbar {"text":"Building World of Addons map…","color":"aqua"}
execute if score #built woa_world matches 1 if score #tick woa_world matches 10.. run function world_of_addons:runtime/ten_tick
execute if score #phase woa_world matches 1 run function world_of_addons:champion/check_ready
execute if score #phase woa_world matches 2 run function world_of_addons:match/countdown_tick
execute if score #phase woa_world matches 3 run function world_of_addons:match/tick
execute if score #tick woa_world matches 10.. run scoreboard players set #tick woa_world 0
