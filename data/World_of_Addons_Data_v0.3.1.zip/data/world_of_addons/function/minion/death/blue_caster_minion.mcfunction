# Award lane gold only to the opposing player who dealt the killing blow.
execute as @a[tag=dai_entity_killer_context,tag=woa_red] run scoreboard players add @s woa_gold 25
execute as @a[tag=dai_entity_killer_context,tag=woa_red] run title @s actionbar [{"text":"+25G ","color":"gold","bold":true},{"text":"Caster Minion","color":"gray"}]
