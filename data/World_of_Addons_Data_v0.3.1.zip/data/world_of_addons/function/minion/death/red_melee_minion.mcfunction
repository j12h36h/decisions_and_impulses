# Award lane gold only to the opposing player who dealt the killing blow.
execute as @a[tag=dai_entity_killer_context,tag=woa_blue] run scoreboard players add @s woa_gold 20
execute as @a[tag=dai_entity_killer_context,tag=woa_blue] run title @s actionbar [{"text":"+20G ","color":"gold","bold":true},{"text":"Melee Minion","color":"gray"}]
