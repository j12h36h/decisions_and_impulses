execute if score @s woa_step matches 0 positioned -166 65 166 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 0 run tp @s ~ ~ ~ facing -166 65 166
execute if score @s woa_step matches 1 positioned -150 65 150 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 1 run tp @s ~ ~ ~ facing -150 65 150
execute if score @s woa_step matches 2 positioned -120 65 120 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 2 run tp @s ~ ~ ~ facing -120 65 120
execute if score @s woa_step matches 3 positioned -88 65 88 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 3 run tp @s ~ ~ ~ facing -88 65 88
execute if score @s woa_step matches 4 positioned -56 65 56 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 4 run tp @s ~ ~ ~ facing -56 65 56
execute if score @s woa_step matches 5 positioned -22 65 22 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 5 run tp @s ~ ~ ~ facing -22 65 22
execute if score @s woa_step matches 6 positioned 0 65 0 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 6 run tp @s ~ ~ ~ facing 0 65 0
execute if score @s woa_step matches 7 positioned 22 65 -22 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 7 run tp @s ~ ~ ~ facing 22 65 -22
execute if score @s woa_step matches 8 positioned 56 65 -56 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 8 run tp @s ~ ~ ~ facing 56 65 -56
execute if score @s woa_step matches 9 positioned 88 65 -88 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 9 run tp @s ~ ~ ~ facing 88 65 -88
execute if score @s woa_step matches 10 positioned 120 65 -120 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 10 run tp @s ~ ~ ~ facing 120 65 -120
execute if score @s woa_step matches 11 positioned 150 65 -150 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 11 run tp @s ~ ~ ~ facing 150 65 -150
execute if score @s woa_step matches 12.. run kill @s
execute if score @s woa_step matches ..11 run tp @s ^ ^ ^0.28
