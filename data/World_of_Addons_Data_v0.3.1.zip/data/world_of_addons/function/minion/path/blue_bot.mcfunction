execute if score @s woa_step matches 0 positioned -145 65 157 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 0 run tp @s ~ ~ ~ facing -145 65 157
execute if score @s woa_step matches 1 positioned -112 65 181 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 1 run tp @s ~ ~ ~ facing -112 65 181
execute if score @s woa_step matches 2 positioned -58 65 193 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 2 run tp @s ~ ~ ~ facing -58 65 193
execute if score @s woa_step matches 3 positioned 0 65 195 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 3 run tp @s ~ ~ ~ facing 0 65 195
execute if score @s woa_step matches 4 positioned 76 65 191 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 4 run tp @s ~ ~ ~ facing 76 65 191
execute if score @s woa_step matches 5 positioned 132 65 176 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 5 run tp @s ~ ~ ~ facing 132 65 176
execute if score @s woa_step matches 6 positioned 169 65 145 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 6 run tp @s ~ ~ ~ facing 169 65 145
execute if score @s woa_step matches 7 positioned 188 65 92 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 7 run tp @s ~ ~ ~ facing 188 65 92
execute if score @s woa_step matches 8 positioned 195 65 25 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 8 run tp @s ~ ~ ~ facing 195 65 25
execute if score @s woa_step matches 9 positioned 193 65 -50 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 9 run tp @s ~ ~ ~ facing 193 65 -50
execute if score @s woa_step matches 10 positioned 183 65 -112 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 10 run tp @s ~ ~ ~ facing 183 65 -112
execute if score @s woa_step matches 11 positioned 164 65 -150 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 11 run tp @s ~ ~ ~ facing 164 65 -150
execute if score @s woa_step matches 12 positioned 151 65 -166 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 12 run tp @s ~ ~ ~ facing 151 65 -166
execute if score @s woa_step matches 13.. run kill @s
execute if score @s woa_step matches ..12 run tp @s ^ ^ ^0.28
