execute if score @s woa_step matches 0 positioned -157 65 145 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 0 run tp @s ~ ~ ~ facing -157 65 145
execute if score @s woa_step matches 1 positioned -181 65 112 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 1 run tp @s ~ ~ ~ facing -181 65 112
execute if score @s woa_step matches 2 positioned -193 65 58 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 2 run tp @s ~ ~ ~ facing -193 65 58
execute if score @s woa_step matches 3 positioned -195 65 0 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 3 run tp @s ~ ~ ~ facing -195 65 0
execute if score @s woa_step matches 4 positioned -191 65 -76 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 4 run tp @s ~ ~ ~ facing -191 65 -76
execute if score @s woa_step matches 5 positioned -176 65 -132 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 5 run tp @s ~ ~ ~ facing -176 65 -132
execute if score @s woa_step matches 6 positioned -145 65 -169 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 6 run tp @s ~ ~ ~ facing -145 65 -169
execute if score @s woa_step matches 7 positioned -92 65 -188 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 7 run tp @s ~ ~ ~ facing -92 65 -188
execute if score @s woa_step matches 8 positioned -25 65 -195 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 8 run tp @s ~ ~ ~ facing -25 65 -195
execute if score @s woa_step matches 9 positioned 50 65 -193 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 9 run tp @s ~ ~ ~ facing 50 65 -193
execute if score @s woa_step matches 10 positioned 112 65 -183 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 10 run tp @s ~ ~ ~ facing 112 65 -183
execute if score @s woa_step matches 11 positioned 150 65 -164 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 11 run tp @s ~ ~ ~ facing 150 65 -164
execute if score @s woa_step matches 12 positioned 166 65 -151 if entity @s[distance=..2.5] run scoreboard players add @s woa_step 1
execute if score @s woa_step matches 12 run tp @s ~ ~ ~ facing 166 65 -151
execute if score @s woa_step matches 13.. run kill @s
execute if score @s woa_step matches ..12 run tp @s ^ ^ ^0.28
