scoreboard players set #match_tick woa_world 0
scoreboard players add #wave woa_world 1
scoreboard players operation #cannon woa_world = #wave woa_world
scoreboard players operation #cannon woa_world %= #three woa_world
function world_of_addons:minion/spawn/blue_top
function world_of_addons:minion/spawn/blue_mid
function world_of_addons:minion/spawn/blue_bot
function world_of_addons:minion/spawn/red_top
function world_of_addons:minion/spawn/red_mid
function world_of_addons:minion/spawn/red_bot
playsound minecraft:block.bell.use master @a ~ ~ ~ 0.4 1.3
title @a actionbar [{"text":"Minion wave ","color":"gray"},{"score":{"name":"#wave","objective":"woa_world"},"color":"white"},{"text":" deployed.","color":"gray"}]
