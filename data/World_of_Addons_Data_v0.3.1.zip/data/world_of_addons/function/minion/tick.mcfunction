scoreboard players add @e[tag=woa_minion] woa_age 1
scoreboard players remove @e[tag=woa_minion,scores={woa_attack=1..}] woa_attack 1
kill @e[tag=woa_minion,scores={woa_age=4200..}]
# Blue combat.
execute as @e[tag=woa_minion,tag=woa_blue,tag=woa_melee,scores={woa_attack=..0}] at @s if entity @e[tag=woa_minion,tag=woa_red,distance=..2.4,limit=1] run function world_of_addons:minion/combat/blue_melee
execute as @e[tag=woa_minion,tag=woa_blue,tag=woa_caster,scores={woa_attack=..0}] at @s if entity @e[tag=woa_minion,tag=woa_red,distance=..7,limit=1] run function world_of_addons:minion/combat/blue_caster
execute as @e[tag=woa_minion,tag=woa_blue,tag=woa_siege,scores={woa_attack=..0}] at @s if entity @e[tag=woa_minion,tag=woa_red,distance=..6,limit=1] run function world_of_addons:minion/combat/blue_siege
execute as @e[tag=woa_minion,tag=woa_blue,scores={woa_attack=..0}] at @s unless entity @e[tag=woa_minion,tag=woa_red,distance=..7,limit=1] if entity @e[tag=woa_tower,tag=woa_red,distance=..7,limit=1] run function world_of_addons:minion/combat/blue_tower
# Red combat.
execute as @e[tag=woa_minion,tag=woa_red,tag=woa_melee,scores={woa_attack=..0}] at @s if entity @e[tag=woa_minion,tag=woa_blue,distance=..2.4,limit=1] run function world_of_addons:minion/combat/red_melee
execute as @e[tag=woa_minion,tag=woa_red,tag=woa_caster,scores={woa_attack=..0}] at @s if entity @e[tag=woa_minion,tag=woa_blue,distance=..7,limit=1] run function world_of_addons:minion/combat/red_caster
execute as @e[tag=woa_minion,tag=woa_red,tag=woa_siege,scores={woa_attack=..0}] at @s if entity @e[tag=woa_minion,tag=woa_blue,distance=..6,limit=1] run function world_of_addons:minion/combat/red_siege
execute as @e[tag=woa_minion,tag=woa_red,scores={woa_attack=..0}] at @s unless entity @e[tag=woa_minion,tag=woa_blue,distance=..7,limit=1] if entity @e[tag=woa_tower,tag=woa_blue,distance=..7,limit=1] run function world_of_addons:minion/combat/red_tower
# Movement only while no nearby opposing minion or tower.
execute as @e[tag=woa_minion,tag=woa_blue,tag=woa_top] at @s unless entity @e[tag=woa_minion,tag=woa_red,distance=..7,limit=1] unless entity @e[tag=woa_tower,tag=woa_red,distance=..7,limit=1] run function world_of_addons:minion/path/blue_top
execute as @e[tag=woa_minion,tag=woa_blue,tag=woa_mid] at @s unless entity @e[tag=woa_minion,tag=woa_red,distance=..7,limit=1] unless entity @e[tag=woa_tower,tag=woa_red,distance=..7,limit=1] run function world_of_addons:minion/path/blue_mid
execute as @e[tag=woa_minion,tag=woa_blue,tag=woa_bot] at @s unless entity @e[tag=woa_minion,tag=woa_red,distance=..7,limit=1] unless entity @e[tag=woa_tower,tag=woa_red,distance=..7,limit=1] run function world_of_addons:minion/path/blue_bot
execute as @e[tag=woa_minion,tag=woa_red,tag=woa_top] at @s unless entity @e[tag=woa_minion,tag=woa_blue,distance=..7,limit=1] unless entity @e[tag=woa_tower,tag=woa_blue,distance=..7,limit=1] run function world_of_addons:minion/path/red_top
execute as @e[tag=woa_minion,tag=woa_red,tag=woa_mid] at @s unless entity @e[tag=woa_minion,tag=woa_blue,distance=..7,limit=1] unless entity @e[tag=woa_tower,tag=woa_blue,distance=..7,limit=1] run function world_of_addons:minion/path/red_mid
execute as @e[tag=woa_minion,tag=woa_red,tag=woa_bot] at @s unless entity @e[tag=woa_minion,tag=woa_blue,distance=..7,limit=1] unless entity @e[tag=woa_tower,tag=woa_blue,distance=..7,limit=1] run function world_of_addons:minion/path/red_bot
