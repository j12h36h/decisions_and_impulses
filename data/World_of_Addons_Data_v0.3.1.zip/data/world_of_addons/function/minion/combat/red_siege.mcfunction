damage @e[tag=woa_minion,tag=woa_blue,distance=..6,sort=nearest,limit=1] 7 minecraft:explosion
particle minecraft:smoke ~ ~1 ~ 0.3 0.3 0.3 0.02 5 force
scoreboard players set @s woa_attack 32
