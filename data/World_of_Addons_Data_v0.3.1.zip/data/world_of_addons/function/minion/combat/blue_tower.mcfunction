scoreboard players remove @e[tag=woa_tower,tag=woa_red,distance=..7,sort=nearest,limit=1] woa_hp 7
particle minecraft:crit ~ ~1 ~ 0.2 0.2 0.2 0.02 4 force
scoreboard players set @s woa_attack 20
