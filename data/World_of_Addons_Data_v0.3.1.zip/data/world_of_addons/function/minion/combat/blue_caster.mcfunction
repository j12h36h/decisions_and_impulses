damage @e[tag=woa_minion,tag=woa_red,distance=..7,sort=nearest,limit=1] 4 minecraft:magic
particle minecraft:enchanted_hit ~ ~1 ~ 0.2 0.2 0.2 0.02 4 force
scoreboard players set @s woa_attack 26
