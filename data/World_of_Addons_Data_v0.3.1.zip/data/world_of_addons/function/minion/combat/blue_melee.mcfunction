damage @e[tag=woa_minion,tag=woa_red,distance=..2.4,sort=nearest,limit=1] 5 minecraft:mob_attack
particle minecraft:crit ~ ~1 ~ 0.2 0.2 0.2 0.02 4 force
scoreboard players set @s woa_attack 20
