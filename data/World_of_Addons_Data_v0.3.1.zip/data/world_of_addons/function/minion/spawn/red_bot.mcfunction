summon world_of_addons:red_melee_minion 155.5 65 -145.0 {Tags:["woa_new","woa_minion","woa_red","woa_bot","woa_melee"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Melee Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_melee_minion 157.0 65 -145.0 {Tags:["woa_new","woa_minion","woa_red","woa_bot","woa_melee"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Melee Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_melee_minion 158.5 65 -145.0 {Tags:["woa_new","woa_minion","woa_red","woa_bot","woa_melee"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Melee Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_caster_minion 155.5 65 -147.2 {Tags:["woa_new","woa_minion","woa_red","woa_bot","woa_caster"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Caster Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_caster_minion 157.0 65 -147.2 {Tags:["woa_new","woa_minion","woa_red","woa_bot","woa_caster"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Caster Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_caster_minion 158.5 65 -147.2 {Tags:["woa_new","woa_minion","woa_red","woa_bot","woa_caster"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Caster Minion","color":"red"}',CustomNameVisible:1b}
execute if score #cannon woa_world matches 0 run summon world_of_addons:red_siege_minion 157.0 65 -149.0 {Tags:["woa_new","woa_minion","woa_red","woa_bot","woa_siege"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Siege Minion","color":"red"}',CustomNameVisible:1b}
team join woa_red @e[tag=woa_new]
scoreboard players set @e[tag=woa_new] woa_step 0
scoreboard players set @e[tag=woa_new] woa_age 0
scoreboard players set @e[tag=woa_new] woa_attack 0
tag @e[tag=woa_new] remove woa_new
