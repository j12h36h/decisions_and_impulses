summon world_of_addons:red_melee_minion 143.5 65 -157.0 {Tags:["woa_new","woa_minion","woa_red","woa_top","woa_melee"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Melee Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_melee_minion 145.0 65 -157.0 {Tags:["woa_new","woa_minion","woa_red","woa_top","woa_melee"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Melee Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_melee_minion 146.5 65 -157.0 {Tags:["woa_new","woa_minion","woa_red","woa_top","woa_melee"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Melee Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_caster_minion 143.5 65 -159.2 {Tags:["woa_new","woa_minion","woa_red","woa_top","woa_caster"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Caster Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_caster_minion 145.0 65 -159.2 {Tags:["woa_new","woa_minion","woa_red","woa_top","woa_caster"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Caster Minion","color":"red"}',CustomNameVisible:1b}
summon world_of_addons:red_caster_minion 146.5 65 -159.2 {Tags:["woa_new","woa_minion","woa_red","woa_top","woa_caster"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Caster Minion","color":"red"}',CustomNameVisible:1b}
execute if score #cannon woa_world matches 0 run summon world_of_addons:red_siege_minion 145.0 65 -161.0 {Tags:["woa_new","woa_minion","woa_red","woa_top","woa_siege"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Red Siege Minion","color":"red"}',CustomNameVisible:1b}
team join woa_red @e[tag=woa_new]
scoreboard players set @e[tag=woa_new] woa_step 0
scoreboard players set @e[tag=woa_new] woa_age 0
scoreboard players set @e[tag=woa_new] woa_attack 0
tag @e[tag=woa_new] remove woa_new
