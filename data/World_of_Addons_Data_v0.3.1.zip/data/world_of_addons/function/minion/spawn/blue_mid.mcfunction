summon world_of_addons:blue_melee_minion -151.5 65 150.0 {Tags:["woa_new","woa_minion","woa_blue","woa_mid","woa_melee"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Blue Melee Minion","color":"blue"}',CustomNameVisible:1b}
summon world_of_addons:blue_melee_minion -150.0 65 150.0 {Tags:["woa_new","woa_minion","woa_blue","woa_mid","woa_melee"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Blue Melee Minion","color":"blue"}',CustomNameVisible:1b}
summon world_of_addons:blue_melee_minion -148.5 65 150.0 {Tags:["woa_new","woa_minion","woa_blue","woa_mid","woa_melee"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Blue Melee Minion","color":"blue"}',CustomNameVisible:1b}
summon world_of_addons:blue_caster_minion -151.5 65 152.2 {Tags:["woa_new","woa_minion","woa_blue","woa_mid","woa_caster"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Blue Caster Minion","color":"blue"}',CustomNameVisible:1b}
summon world_of_addons:blue_caster_minion -150.0 65 152.2 {Tags:["woa_new","woa_minion","woa_blue","woa_mid","woa_caster"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Blue Caster Minion","color":"blue"}',CustomNameVisible:1b}
summon world_of_addons:blue_caster_minion -148.5 65 152.2 {Tags:["woa_new","woa_minion","woa_blue","woa_mid","woa_caster"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Blue Caster Minion","color":"blue"}',CustomNameVisible:1b}
execute if score #cannon woa_world matches 0 run summon world_of_addons:blue_siege_minion -150.0 65 154.0 {Tags:["woa_new","woa_minion","woa_blue","woa_mid","woa_siege"],NoAI:1b,NoGravity:1b,Silent:1b,PersistenceRequired:1b,CustomName:'{"text":"Blue Siege Minion","color":"blue"}',CustomNameVisible:1b}
team join woa_blue @e[tag=woa_new]
scoreboard players set @e[tag=woa_new] woa_step 0
scoreboard players set @e[tag=woa_new] woa_age 0
scoreboard players set @e[tag=woa_new] woa_attack 0
tag @e[tag=woa_new] remove woa_new
