# World of Addons v0.3.0

## Standalone Champion Select
- Made World of Addons fully standalone-capable with no Resource Pack or other DAI datapack required.
- Added the built-in **Rift Minion** as a resource-pack-free playable fallback character.
- Rift Minion is now the default pre-lobby character selection.
- Players can lock in and begin a complete match even when no champion addons are installed.

## Recognized Addon Roster
- Reworked Champion Select into an explicit recognized-addon roster.
- Unknown addons no longer appear automatically.
- Added DAI 3.3 `content_exists` conditions so a champion button is added only when its recognized content is actually loaded.
- Kitty Claws is recognized from the Blink Daggers content set.
- Echo Anomaly is recognized from the DAI Time Reverse content set.

## Dependency Safety
- Removed direct external item-ID references from pre-lobby preparation.
- Removed hard external function calls from the lock-in path.
- Added character-specific optional function-tag loadout bridges for recognized champions.
- Removed the old global all-character loadout tag from match start.
- Pre-lobby inventory is now normalized so standalone/demo kits cannot leak into another character selection.
- Missing recognized addons now contribute nothing instead of causing a hard datapack dependency.

## Pre-Lobby
- Added explicit Rift Minion selection state and character tag.
- Updated selection feedback to distinguish the standalone fallback from recognized addon champions.
- Updated first-join messaging to explain that recognized champions appear automatically.

## DAI 3.3
- Updated MAIN experience metadata and branding for DAI 3.3.
- Added a documented recognized-champion registry for future supported addons.
- Preserved the existing Rift world, ecosystems, lane systems, towers, ready gate, countdown, HUD and match flow.
