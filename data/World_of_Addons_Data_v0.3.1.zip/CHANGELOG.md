# World of Addons v0.3.1

## League Menu
- Fixed the grave/backtick (`) key by switching World of Addons to DAI 3.3 targeted menu routing.
- Backtick now opens the World of Addons League Menu directly and closes it when pressed again.
- Rebuilt the League Menu with exactly three primary buttons: Character Selection, Rune Selection, and Inventory / Shop.

## Character Selection
- Preserved the built-in Rift Minion fallback and default selection.
- Preserved whitelist/recognition-driven addon champions.
- Kitty Claws and Echo Anomaly only appear when their specifically recognized addon content exists.
- Unknown addons remain excluded from the character roster.

## Rune Selection
- Added a fully functional Rune Selection menu.
- Added Balanced (no passive), Assault (Strength I), Bulwark (Resistance I), and Fleet (Speed I).
- Rune state is stored per player and refreshed through the existing 10-tick runtime.

## Inventory / Shop
- Replaced the placeholder shop catalog with real purchases using `woa_gold`.
- Added Iron Blade, Ranged Kit, Sustain Pack, Armor Kit, and Utility Kit purchases.
- Added a live gold/status action.
- Native minion death hooks now reward the opposing player who lands the killing blow: 20G melee, 25G caster, 40G siege.

## Title Screen
- Fixed the missing texture on the second title-screen button.
- Replaced the animated/indexed Recovery Compass icon with the direct-texture-safe vanilla Compass icon.

## Standalone Compatibility
- Still requires no Resource Pack and no other DAI datapack.
- All new menus, runes, shop items, and fallback character content use only World of Addons + vanilla Minecraft content.

# World of Addons v0.3.0

## Standalone Champion Select
- Made World of Addons fully standalone-capable with no Resource Pack or other DAI datapack required.
- Added the built-in **Rift Minion** as a resource-pack-free playable fallback character.
- Rift Minion is now the default pre-lobby character selection.
- Players can lock in and begin a complete match even when no champion addons are installed.

## Recognized Addon Roster
- Reworked Champion Select into an explicit recognized-addon roster.
- Unknown addons no longer appear automatically.
- Added DAI 3.3 `content_exists` conditions so a champion button is added only when its recognized content is actually loaded.
- Kitty Claws is recognized from the Blink Daggers content set.
- Echo Anomaly is recognized from the DAI Time Reverse content set.

## Dependency Safety
- Removed direct external item-ID references from pre-lobby preparation.
- Removed hard external function calls from the lock-in path.
- Added character-specific optional function-tag loadout bridges for recognized champions.
- Removed the old global all-character loadout tag from match start.
- Pre-lobby inventory is now normalized so standalone/demo kits cannot leak into another character selection.
- Missing recognized addons now contribute nothing instead of causing a hard datapack dependency.

## Pre-Lobby
- Added explicit Rift Minion selection state and character tag.
- Updated selection feedback to distinguish the standalone fallback from recognized addon champions.
- Updated first-join messaging to explain that recognized champions appear automatically.

## DAI 3.3
- Updated MAIN experience metadata and branding for DAI 3.3.
- Added a documented recognized-champion registry for future supported addons.
- Preserved the existing Rift world, ecosystems, lane systems, towers, ready gate, countdown, HUD and match flow.

# World of Addons v0.2.2

## Native D.A.I. Menu Hotfix

- Replaced the legacy chat + `/trigger` Champion Select prototype with native D.A.I. menus.
- Added **LEAGUE OF ADDONS** to the D.A.I. system menu opened by grave/backtick (`).
- Added native **CHAMPION SELECT**, **SHOP**, and **MATCH STATUS** pages.
- Added **Kitty Claws**, **Echo Anomaly**, and **LOCK IN** as native Champion Select controls.
- Removed `woa_shop`, `woa_select`, and `woa_lock` trigger objectives and per-tick trigger polling.
- Replaced menu/status tellraw output with titles/actionbar feedback.
- Preserved the v0.2.0 terrain, ecosystems, towers, Champion Select ready gate, and post-lock minion timing.
- No resource pack required.

# World of Addons v0.2.0

## Added
- Champion Select match gate with Kitty Claws and Echo Anomaly starter roster.
- Shared character-addon registration/loadout function tags.
- Five-second all-players-ready match countdown.
- Alpine Mammal Ecosystem terrain and pine forest identity.
- Everglades-style Reptilian Habitat with mangroves and swamp lowlands.
- Climbable top-to-mid waterfall terraces.
- Swampy mid-to-bot river descent.
- Collisionless walk-through leaf brush volumes.
- Scenic alpine village and Everglades stilt settlement.

## Changed
- First minion wave now starts 30 seconds after Champion Select completes and the match starts.
- Top-side interior terrain is smoothly banded/elevated instead of surrounded by giant retaining walls.
- Bottom-side interior is gradually de-elevated into a basin.
- Baron Pit renamed Mammal Ecosystem.
- Dragon Pit renamed Reptilian Habitat.
- Objective labels now use proper colored JSON text components.
- Shop trigger demoted to debug/fallback while D.A.I. grave/backtick native menu remains the primary interface foundation.

## Fixed
- Unsupported Stray, Husk and Magma Cube D.A.I. minion carriers replaced with supported Skeleton, Zombie and Slime carriers.
- Minecraft 26.2 gamerule IDs updated for mob drops, time advancement and weather advancement.
- Removed collision-heavy leaf walls and giant stone/deepslate perimeter walls from v0.1.x.


## v0.2.2 — Native Menu Routing Hotfix

- Backtick no longer opens the generic D.A.I. root for World of Addons.
- The Experience now routes grave/backtick directly to `world_of_addons:menu_open_root`.
- Champion Select auto-opens after first-join startup.
- Removed the unnecessary replacement of D.A.I.'s `default` SYSTEM menu.
- Pre-match lobby strips standalone Kitty Claws / Echo Anomaly starter kits.
- LOCK IN grants only the selected character kit.
