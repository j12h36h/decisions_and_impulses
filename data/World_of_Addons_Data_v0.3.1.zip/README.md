# World of Addons — Data v0.3.1

Standalone **D.A.I. 3.3 MAIN Experience** for Minecraft **26.2**. **No Resource Pack and no other DAI datapack are required.**

## Standalone Champion Select

- **Rift Minion** is built into World of Addons and is always available.
- New players default to Rift Minion during the pre-match lobby.
- If no recognized champion addon is loaded, Champion Select remains fully functional with Rift Minion + LOCK IN.
- World of Addons only incorporates addon champions it explicitly recognizes. Unknown addons do not appear automatically.
- Recognized champion buttons use DAI 3.3 `content_exists` conditions and disappear completely when their addon content is absent.
- Recognized addon loadouts are called through character-specific optional function tags, preventing missing addon namespaces from becoming hard datapack dependencies.
- Pre-lobby inventory is normalized before lock-in so standalone/demo kits cannot leak across character choices.

## Recognized v0.3.1 champions

- **Kitty Claws** — recognized from the Blink Daggers content set.
- **Echo Anomaly** — recognized from the DAI Time Reverse content set.

See `RECOGNIZED_CHAMPIONS.md` for the exact recognition contract.

## League Menu

- Backtick / grave (`) now opens the World of Addons League Menu directly.
- The League Menu contains exactly three routes: **Character Selection**, **Rune Selection**, and **Inventory / Shop**.
- Pressing backtick again closes the DAI menu and recaptures the mouse.
- Rune Selection provides Balanced, Assault, Bulwark, and Fleet passives.
- Inventory / Shop now contains real gold purchases instead of catalog placeholders.
- Native minion deaths award killer gold to keep the shop economy active.

## Core Experience

World of Addons still provides its Rift map, three lanes, Blue/Red teams, lane minions, towers, Champion Select ready gate, five-second match countdown, 30-second first wave timing, shop foundation, HUD, alpine Mammal Ecosystem, Everglades Reptilian Habitat, waterfalls, brush volumes and scenic settlements entirely from this datapack.

Future champion addons can be added to the recognized registry without making them required dependencies.
