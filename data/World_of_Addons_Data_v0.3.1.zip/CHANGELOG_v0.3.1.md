# World of Addons v0.3.1

## League Menu
- Fixed the grave/backtick (`) key by switching World of Addons to DAI 3.3 targeted menu routing.
- Backtick now opens the World of Addons League Menu directly and closes it when pressed again.
- Rebuilt the League Menu with exactly three primary buttons: Character Selection, Rune Selection, and Inventory / Shop.

## Character Selection
- Preserved the built-in Rift Minion fallback and default selection.
- Preserved whitelist/recognition-driven addon champions.
- Kitty Claws and Echo Anomaly only appear when their specifically recognized addon content exists.
- Unknown addons remain excluded from the character roster.

## Rune Selection
- Added a fully functional Rune Selection menu.
- Added Balanced (no passive), Assault (Strength I), Bulwark (Resistance I), and Fleet (Speed I).
- Rune state is stored per player and refreshed through the existing 10-tick runtime.

## Inventory / Shop
- Replaced the placeholder shop catalog with real purchases using `woa_gold`.
- Added Iron Blade, Ranged Kit, Sustain Pack, Armor Kit, and Utility Kit purchases.
- Added a live gold/status action.
- Native minion death hooks now reward the opposing player who lands the killing blow: 20G melee, 25G caster, 40G siege.

## Title Screen
- Fixed the missing texture on the second title-screen button.
- Replaced the animated/indexed Recovery Compass icon with the direct-texture-safe vanilla Compass icon.

## Standalone Compatibility
- Still requires no Resource Pack and no other DAI datapack.
- All new menus, runes, shop items, and fallback character content use only World of Addons + vanilla Minecraft content.

