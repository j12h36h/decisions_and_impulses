# AutoCraft MineShaft v2.4.5 — Compact Pause Layout

- Resizes the AutoCraft pause screen to a compact 420×260 layout so it fits at smaller GUI scales.
- Reflows the existing pause actions into two columns and keeps the full-screen mine background.
- Retains the centered entry animation and removes fixed-canvas background text from menu/loading scenes.
- Remains a standalone vanilla datapack with no Resource Pack or custom image assets.
