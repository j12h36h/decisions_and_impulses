# AutoCraft MineShaft v2.4.3 — Complete Pause Actions

- Replaces both DAI Engine and vanilla pause entry screens with the AutoCraft pause screen.
- Restores Resume, Vanilla Pause / Options, DAI Creator, Settings, Return to Title and Field Guide actions.
- Keeps the mine background scene and custom AutoCraft styling.
- DAI 4.2 does not expose its engine shutdown action to datapack screens, so Quit Game cannot be added to this menu without an engine-side action.
- Remains a standalone vanilla datapack with no Resource Pack or custom image assets.
