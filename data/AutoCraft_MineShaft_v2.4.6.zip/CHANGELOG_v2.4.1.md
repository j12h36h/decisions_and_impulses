# AutoCraft MineShaft v2.4.1 — Cinematic and Pause Screen Fixes

- Re-centers the first-entry animation using DAI 4.2’s canvas-centered 2D coordinates.
- Replaces the generic pause presentation with an AutoCraft screen using the canonical `pause` screen and vanilla-scene identifiers.
- Adds a dedicated mine-themed background scene and Field Guide button to the pause screen.
- Remains a standalone datapack with no Resource Pack or custom image assets.
