# AutoCraft MineShaft v2.4.2 — Pause Stage Routing

- Routes the DAI shell `pause` stage directly to the AutoCraft datapack pause screen and mine background scene.
- Retains the centered first-entry animation and custom pause layout from v2.4.1.
- Remains a standalone vanilla datapack with no Resource Pack or custom image assets.
