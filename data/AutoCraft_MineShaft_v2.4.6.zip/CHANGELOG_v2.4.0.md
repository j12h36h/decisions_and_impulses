# AutoCraft MineShaft v2.4.0 — Experience-Owned Screens

- Adds a WOA-style launcher presentation route and AutoCraft title screen for DAI 4.2, taking ownership of the launcher title stage.
- Adds AutoCraft-owned pause and field-menu screens for the active MineShaft world.
- Uses DAI 4.2 shell presentation ownership and in-world screen ownership fields.
- Adds loading, launch and title scenes assembled from vanilla block models, gradients and text.
- Remains a standalone datapack. No Resource Pack, custom texture, image or companion is required.
- Preserves the existing worldgen, save identity, progression and gameplay functions.
