# AutoCraft MineShaft v2.3.0 — DAI 4.2 Experience Flow

- Adds the experience-owned loading screen and world-loading status treatment using colors and progress only.
- Adds a resource-independent first-descent cinematic built from DAI 2D primitives.
- Runs the existing first-join and resume functions through the DAI 4.2 server-function action.
- Preserves all MineShaft gameplay, world generation, progression, and the existing title screen.
- Remains a standalone datapack: no resource pack, texture, or companion pack is required.
