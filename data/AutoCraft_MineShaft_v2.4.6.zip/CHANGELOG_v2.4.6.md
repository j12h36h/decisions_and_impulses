# AutoCraft MineShaft v2.4.6 — Experimental Settings Skin

- Adds a DAI screen skin for the experimental world settings confirmation.
- Replaces the static DAI header with AutoCraft MineShaft world setup branding and a gold framed banner.
- Keeps DAI's original experimental warning, screen instance, navigation, and Continue/Back button callbacks intact.
- Uses datapack scene data only; no Resource Pack or image assets.
