# AutoCraft MineShaft v2.4.4 — Background Text Alignment

- Removes fixed-canvas screen-space text from menu and world-entry background scenes so labels no longer drift at different GUI sizes.
- Keeps title, pause and loading copy in their own UI layers, where DAI lays them out against the live screen.
- Retains the custom pause controls, screen overrides and centered first-entry animation.
- Remains a standalone vanilla datapack with no Resource Pack or custom image assets.
