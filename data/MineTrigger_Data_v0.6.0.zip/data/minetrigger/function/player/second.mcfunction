# Per-player 1 TPS Trion economy / HUD maintenance.
execute if score @s wt_trion_max matches ..999 run function minetrigger:player/upgrade_trion_1000
execute if score @s wt_active matches 1.. run scoreboard players remove @s wt_trion 1
execute if score @s wt_active matches 1.. if score @s wt_chameleon matches 1.. run scoreboard players remove @s wt_trion 2
execute if score @s wt_active matches 0 if score @s wt_trion matches ..999 run scoreboard players add @s wt_trion 3
execute if score @s wt_trion > @s wt_trion_max run scoreboard players operation @s wt_trion = @s wt_trion_max
execute if score @s wt_active matches 1.. if score @s wt_trion matches ..0 at @s run function minetrigger:trigger/bailout
function minetrigger:hud/actionbar
