MineTrigger - Border Training v0.6.0
=====================================
Requires: Decisions & Impulses (D.A.I.) 3.3+
Recommended companion: MineTrigger Resource Pack v0.6.0
Namespace: minetrigger
DAI role: MAIN
Managed pack ID: minetrigger

CURRENT SYSTEMS
---------------
- Registry-backed minetrigger:* Trigger equipment and projectile identities.
- Registry-backed DAI Training Trion Soldier entity.
- DAI JSON void world generation.
- Start New / Continue Training title screen and save browser.
- Trigger Body On/Off and Bail Out flow.
- Attacker, Shooter, Sniper, and All-Rounder loadouts.
- 1000-point Trion resource economy and Trigger ability costs.
- Mobility, stealth, radar, melee reactions, and loadout restoration.
- Direct ` MineTrigger dashboard / Border Wheel interface.
- Automatic companion resource-pack enablement.
- Visible Asteroid, Hound, and Egret Trion projectile presentation.
- DAI 3.3 structured projectile-physics profiles for ranged Trigger definitions.

INSTALL
-------
1. Install D.A.I. 3.3+.
2. Put the datapack ZIP in the instance-level /datapacks folder.
3. Put the matching resource-pack ZIP in /resourcepacks.
4. Restart Minecraft. DAI automatically enables the MineTrigger companion RP.
5. Choose START NEW TRAINING or CONTINUE TRAINING.

Press ` in-game to open the MineTrigger dashboard directly.

v0.6.0 DAI 3.3 CAPABILITY + EFFICIENCY PASS
-------------------------------------------
- Removed the redundant every-tick player initialization scan. DAI MAIN-experience join callbacks and load-time initialization already cover first join, reconnect, and /reload.
- Collapsed three global projectile scans (Asteroid / Hound / Egret) into one mt_projectile scan with local type dispatch.
- Consolidated once-per-second Trion economy and HUD work into one global player pass.
- Removed the permanent once-per-second legacy training-dummy migration scan; existing worlds are repaired by the v0.5.0 migration and new dummies already spawn current.
- Added structured DAI 3.3 projectile profiles to Asteroid, Hound, and Egret definitions while preserving the existing visible projectile gameplay path.
- Preserved the 1000 Trion economy, Trigger On/Off controls, loadouts, training-sector recovery, projectile damage/ranges, and training dummies.

v0.5.0 RECOVERY / INTEGRITY PASS
--------------------------------
- Added in-place training-sector integrity rails without changing the existing arena layout.
- Added physical-position recovery for players who fall below the training world.
- Existing 1000 Trion balance, Trigger On/Off controls, loadouts, projectiles, and training dummies remained intact.
