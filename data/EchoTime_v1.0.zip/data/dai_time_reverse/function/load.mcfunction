# EchoTime v1.0 release
# Minecraft Java 26.2 / Data Pack 107.1 / DAI 1.9.9
#
# This hotfix deliberately bounds temporal history work. The previous v0.2.0
# implementation performed multiple dimension-wide entity/marker sweeps every
# server tick. On integrated clients that could create severe command/entity
# pressure before any ability was even activated.

scoreboard objectives add tr_id dummy
scoreboard objectives add tr_eid dummy
scoreboard objectives add tr_owner dummy
scoreboard objectives add tr_age dummy
scoreboard objectives add tr_mode dummy
scoreboard objectives add tr_ticks dummy
scoreboard objectives add tr_rticks dummy
scoreboard objectives add tr_hp dummy
scoreboard objectives add tr_resumehp dummy
scoreboard objectives add tr_invul dummy
scoreboard objectives add tr_nograv dummy
scoreboard objectives add tr_noai dummy
scoreboard objectives add tr_tmp dummy
scoreboard objectives add tr_loop dummy
scoreboard objectives add tr_cdemg dummy
scoreboard objectives add tr_cdfull dummy
scoreboard objectives add tr_cdarea dummy
scoreboard objectives add tr_recstamp dummy
scoreboard objectives add tr_agestamp dummy
scoreboard objectives add tr_playstamp dummy
scoreboard objectives add tr_hold dummy
scoreboard objectives add tr_dry dummy
scoreboard objectives add tr_freeze dummy
scoreboard objectives add tr_freeze_noai dummy
scoreboard objectives add tr_freeze_nograv dummy
scoreboard objectives add tr_freeze_hasnoai dummy
scoreboard objectives add tr_emergency trigger
scoreboard objectives add tr_full trigger
scoreboard objectives add tr_area trigger

scoreboard players add #next_player tr_tmp 0
scoreboard players add #next_entity tr_tmp 0
scoreboard players set #sample tr_tmp 0
scoreboard players set #epoch tr_tmp 0

# A reload must never strand an entity in temporary rewind/freeze state.
execute as @e[tag=tr_chrono_frozen] at @s run function dai_time_reverse:freeze/stop
execute as @a[scores={tr_mode=1..}] at @s run function dai_time_reverse:player/stop
execute as @a at @s as @e[tag=tr_area_rewinding,distance=..96] at @s run function dai_time_reverse:entity/stop

# Purge old runtime history from the unsafe recorder. This is intentionally a
# one-time load operation rather than a per-tick dimension sweep.
execute as @a at @s run kill @e[type=minecraft:marker,tag=tr_snapshot,distance=..128]
execute as @a at @s run kill @e[type=minecraft:marker,tag=tr_resume_frame,distance=..128]
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=tr_snapshot]
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=tr_resume_frame]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=tr_snapshot]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=tr_resume_frame]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=tr_snapshot]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=tr_resume_frame]

# Clean obsolete v0.2.0 dedup tags. No global tag-clearing sweep is used now.
tag @e[tag=tr_area_rewinding] remove tr_processed_tick
tag @e[tag=tr_recorded_tick] remove tr_recorded_tick

# Force one clean migration pass for the bounded recorder.
tag @a remove tr_init_perfhotfix
tag @a remove tr_init_v021
tag @a remove tr_items_v022
tag @a remove tr_items_v024

tellraw @a [{"text":"[EchoTime] ","color":"aqua","bold":true},{"text":"v1.0 loaded. ","color":"green","bold":false},{"text":"Temporal abilities ready. Temporal Recall now renders as an enchanted Ender Eye.","color":"gray"}]
