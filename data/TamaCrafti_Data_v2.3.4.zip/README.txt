TamaCrafti Datapack v2.3.2 - Journey HUD Layout Update

Updated against the newer D.A.I. Java experience/worldgen/condition architecture.
Built to pair with TamaCrafti Resource Pack v2.0.4 HD.

Modern DAI integration:
- Save-browser empty-state and delete-confirmation copy are now authored by TamaCrafti instead of inheriting engine/ACMS wording.
- Explicitly selects the normal gradient title theme so Journey save pages inherit TamaCrafti title colors rather than MineShaft scenery.
- Explicitly declares this datapack as the DAI MAIN experience.
- Uses DAI native world_type = void instead of generating a flat world and erasing large regions with /fill.
- Keeps the original Y=200 spawn, Y=199 stone-brick starter platform, world border, gamerules, Nether, and End access.
- Adds the current DAI experience-owned Journey save browser to the custom title screen.
- Retains the responsive title implementation; DAI can compact the save browser on smaller screens.
- Explicitly declares the new experience automation-control ceiling with permissive values, preserving previous behavior.
- Existing DAI boolean logic conditions now explicitly declare operator = is_true for the centralized condition evaluator.
- Grave/backtick custom HUD ownership remains handled by TamaCrafti's open/close actions and tc_left_frame anchor.
- server_run_function handoffs remain native; no return to privileged command bridges.

Journey HUD update:
- Reworked the lower-left status layout so Hunger, Happy, Clean, Energy, Health, and Trust are wider, more legible, aligned, and kept inside the status frame.
- The persistent bottom-right Actions control is now Main Menu.
- Removed the redundant invisible Main Menu hitbox from the top/header of Feed, Play, Clean, Sleep, and Stats panels.
- Right-side panel headers are now presentation-only; navigation back to Main Menu is always available from the persistent button.

Gameplay intentionally unchanged:
- Care, hunger, happiness, cleanliness, energy, health, trust, growth, requests, rewards, farming, and home construction are unchanged.
- Pet sprite-sheet timing and all UI artwork are unchanged.
- Existing save recovery remains supported by DAI's legacy/pre-marker compatibility path.

Useful authoritative test functions:
/function tamacrafti:journey/init
/function tamacrafti:journey/resume
/function tamacrafti:debug/rebuild_home
/function tamacrafti:debug/journey_reset_player
