scoreboard players set @s tc_aclk 0
scoreboard players add @s tc_age 1
function tamacrafti:state/health_check
function tamacrafti:state/sync
