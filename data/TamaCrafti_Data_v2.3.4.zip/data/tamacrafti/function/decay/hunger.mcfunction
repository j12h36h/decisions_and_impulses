scoreboard players set @s tc_hclk 0
scoreboard players remove @s tc_hunger 1
function tamacrafti:state/clamp
function tamacrafti:state/health_check
function tamacrafti:state/sync
