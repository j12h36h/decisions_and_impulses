scoreboard players set @s tc_pclk 0
scoreboard players remove @s tc_happy 1
function tamacrafti:state/clamp
function tamacrafti:state/health_check
function tamacrafti:state/sync
