scoreboard players set @s tc_eclk 0
scoreboard players remove @s tc_energy 1
function tamacrafti:state/clamp
function tamacrafti:state/health_check
function tamacrafti:state/sync
