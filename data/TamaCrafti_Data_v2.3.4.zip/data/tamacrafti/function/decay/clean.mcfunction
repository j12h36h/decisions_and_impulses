scoreboard players set @s tc_cclk 0
scoreboard players remove @s tc_clean 1
function tamacrafti:state/clamp
function tamacrafti:state/health_check
function tamacrafti:state/sync
