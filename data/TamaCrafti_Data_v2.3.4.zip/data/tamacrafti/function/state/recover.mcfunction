
scoreboard players set @s tc_healclk 0
execute if score @s tc_hunger matches 3.. if score @s tc_happy matches 3.. if score @s tc_clean matches 3.. if score @s tc_energy matches 3.. if score @s tc_health matches ..4 run scoreboard players add @s tc_health 1
function tamacrafti:state/clamp
function tamacrafti:state/sync
