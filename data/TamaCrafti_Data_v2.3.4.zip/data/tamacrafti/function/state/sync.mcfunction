function tamacrafti:state/clamp
function tamacrafti:state/clear_flags
execute if score @s tc_hunger matches 0 run advancement grant @s only tamacrafti:state/hunger_0
execute if score @s tc_hunger matches 1 run advancement grant @s only tamacrafti:state/hunger_1
execute if score @s tc_hunger matches 2 run advancement grant @s only tamacrafti:state/hunger_2
execute if score @s tc_hunger matches 3 run advancement grant @s only tamacrafti:state/hunger_3
execute if score @s tc_hunger matches 4 run advancement grant @s only tamacrafti:state/hunger_4
execute if score @s tc_hunger matches 5 run advancement grant @s only tamacrafti:state/hunger_5
execute if score @s tc_happy matches 0 run advancement grant @s only tamacrafti:state/happy_0
execute if score @s tc_happy matches 1 run advancement grant @s only tamacrafti:state/happy_1
execute if score @s tc_happy matches 2 run advancement grant @s only tamacrafti:state/happy_2
execute if score @s tc_happy matches 3 run advancement grant @s only tamacrafti:state/happy_3
execute if score @s tc_happy matches 4 run advancement grant @s only tamacrafti:state/happy_4
execute if score @s tc_happy matches 5 run advancement grant @s only tamacrafti:state/happy_5
execute if score @s tc_clean matches 0 run advancement grant @s only tamacrafti:state/clean_0
execute if score @s tc_clean matches 1 run advancement grant @s only tamacrafti:state/clean_1
execute if score @s tc_clean matches 2 run advancement grant @s only tamacrafti:state/clean_2
execute if score @s tc_clean matches 3 run advancement grant @s only tamacrafti:state/clean_3
execute if score @s tc_clean matches 4 run advancement grant @s only tamacrafti:state/clean_4
execute if score @s tc_clean matches 5 run advancement grant @s only tamacrafti:state/clean_5
execute if score @s tc_energy matches 0 run advancement grant @s only tamacrafti:state/energy_0
execute if score @s tc_energy matches 1 run advancement grant @s only tamacrafti:state/energy_1
execute if score @s tc_energy matches 2 run advancement grant @s only tamacrafti:state/energy_2
execute if score @s tc_energy matches 3 run advancement grant @s only tamacrafti:state/energy_3
execute if score @s tc_energy matches 4 run advancement grant @s only tamacrafti:state/energy_4
execute if score @s tc_energy matches 5 run advancement grant @s only tamacrafti:state/energy_5
execute if score @s tc_health matches 0 run advancement grant @s only tamacrafti:state/health_0
execute if score @s tc_health matches 1 run advancement grant @s only tamacrafti:state/health_1
execute if score @s tc_health matches 2 run advancement grant @s only tamacrafti:state/health_2
execute if score @s tc_health matches 3 run advancement grant @s only tamacrafti:state/health_3
execute if score @s tc_health matches 4 run advancement grant @s only tamacrafti:state/health_4
execute if score @s tc_health matches 5 run advancement grant @s only tamacrafti:state/health_5
execute if score @s tc_trust matches 0 run advancement grant @s only tamacrafti:state/trust_0
execute if score @s tc_trust matches 1 run advancement grant @s only tamacrafti:state/trust_1
execute if score @s tc_trust matches 2 run advancement grant @s only tamacrafti:state/trust_2
execute if score @s tc_trust matches 3 run advancement grant @s only tamacrafti:state/trust_3
execute if score @s tc_trust matches 4 run advancement grant @s only tamacrafti:state/trust_4
execute if score @s tc_trust matches 5 run advancement grant @s only tamacrafti:state/trust_5
scoreboard players set @s tc_stage 0
execute if score @s tc_age matches 5.. run scoreboard players set @s tc_stage 1
execute if score @s tc_age matches 15.. run scoreboard players set @s tc_stage 2
execute if score @s tc_stage matches 0 run advancement grant @s only tamacrafti:state/stage_0
execute if score @s tc_stage matches 1 run advancement grant @s only tamacrafti:state/stage_1
execute if score @s tc_stage matches 2 run advancement grant @s only tamacrafti:state/stage_2
execute if score @s tc_age matches ..4 run advancement grant @s only tamacrafti:state/growth_0
execute if score @s tc_age matches 5..9 run advancement grant @s only tamacrafti:state/growth_1
execute if score @s tc_age matches 10..14 run advancement grant @s only tamacrafti:state/growth_2
execute if score @s tc_age matches 15.. run advancement grant @s only tamacrafti:state/growth_3
scoreboard players set @s tc_mood 0
execute if score @s tc_happy matches ..1 run scoreboard players set @s tc_mood 4
execute if score @s tc_energy matches ..1 run scoreboard players set @s tc_mood 3
execute if score @s tc_clean matches ..1 run scoreboard players set @s tc_mood 2
execute if score @s tc_hunger matches ..1 run scoreboard players set @s tc_mood 1
execute if score @s tc_sleeping matches 1 run scoreboard players set @s tc_mood 3
execute if score @s tc_health matches ..1 run scoreboard players set @s tc_mood 5
execute if score @s tc_mood matches 0 run advancement grant @s only tamacrafti:state/mood_happy
execute if score @s tc_mood matches 1 run advancement grant @s only tamacrafti:state/mood_hungry
execute if score @s tc_mood matches 2 run advancement grant @s only tamacrafti:state/mood_dirty
execute if score @s tc_mood matches 3 run advancement grant @s only tamacrafti:state/mood_sleepy
execute if score @s tc_mood matches 4 run advancement grant @s only tamacrafti:state/mood_sad
execute if score @s tc_mood matches 5 run advancement grant @s only tamacrafti:state/mood_sick

# v1.2 action availability and inventory flags
execute if score @s tc_sleeping matches 1 run advancement grant @s only tamacrafti:state/sleeping
execute if score @s tc_sleeping matches 0 if score @s tc_cdfeed matches 0 run advancement grant @s only tamacrafti:state/ready_feed
execute if score @s tc_sleeping matches 0 if score @s tc_cdplay matches 0 if score @s tc_energy matches 1.. run advancement grant @s only tamacrafti:state/ready_play
execute if score @s tc_sleeping matches 0 if score @s tc_cdclean matches 0 if score @s tc_clean matches ..4 run advancement grant @s only tamacrafti:state/ready_clean
execute if score @s tc_sleeping matches 0 if score @s tc_cdsleep matches 0 if score @s tc_energy matches ..4 run advancement grant @s only tamacrafti:state/ready_sleep
execute store result score @s tc_tmp run clear @s minecraft:carrot 0
execute if score @s tc_tmp matches 1.. run advancement grant @s only tamacrafti:state/has_carrot
execute store result score @s tc_tmp run clear @s minecraft:apple 0
execute if score @s tc_tmp matches 1.. run advancement grant @s only tamacrafti:state/has_apple
execute store result score @s tc_tmp run clear @s minecraft:baked_potato 0
execute if score @s tc_tmp matches 1.. run advancement grant @s only tamacrafti:state/has_potato
execute store result score @s tc_tmp run clear @s minecraft:cookie 0
execute if score @s tc_tmp matches 1.. run advancement grant @s only tamacrafti:state/has_cookie
execute if score @s tc_request matches 0 run advancement grant @s only tamacrafti:state/request_none
execute if score @s tc_request matches 1 run advancement grant @s only tamacrafti:state/request_carrot
execute if score @s tc_request matches 2 run advancement grant @s only tamacrafti:state/request_play
execute if score @s tc_request matches 3 run advancement grant @s only tamacrafti:state/request_clean
execute if score @s tc_request matches 4 run advancement grant @s only tamacrafti:state/request_sleep
