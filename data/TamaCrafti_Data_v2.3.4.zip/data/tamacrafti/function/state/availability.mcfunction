
scoreboard players set @s tc_avclk 0
execute if score @s tc_sleeping matches 1 run advancement grant @s only tamacrafti:state/sleeping
execute if score @s tc_sleeping matches 0 run advancement revoke @s only tamacrafti:state/sleeping
execute if score @s tc_sleeping matches 0 if score @s tc_cdfeed matches 0 run advancement grant @s only tamacrafti:state/ready_feed
execute unless score @s tc_sleeping matches 0 run advancement revoke @s only tamacrafti:state/ready_feed
execute unless score @s tc_cdfeed matches 0 run advancement revoke @s only tamacrafti:state/ready_feed
execute if score @s tc_sleeping matches 0 if score @s tc_cdplay matches 0 if score @s tc_energy matches 1.. run advancement grant @s only tamacrafti:state/ready_play
execute unless score @s tc_sleeping matches 0 run advancement revoke @s only tamacrafti:state/ready_play
execute unless score @s tc_cdplay matches 0 run advancement revoke @s only tamacrafti:state/ready_play
execute if score @s tc_energy matches 0 run advancement revoke @s only tamacrafti:state/ready_play
execute if score @s tc_sleeping matches 0 if score @s tc_cdclean matches 0 if score @s tc_clean matches ..4 run advancement grant @s only tamacrafti:state/ready_clean
execute unless score @s tc_sleeping matches 0 run advancement revoke @s only tamacrafti:state/ready_clean
execute unless score @s tc_cdclean matches 0 run advancement revoke @s only tamacrafti:state/ready_clean
execute if score @s tc_clean matches 5 run advancement revoke @s only tamacrafti:state/ready_clean
execute if score @s tc_sleeping matches 0 if score @s tc_cdsleep matches 0 if score @s tc_energy matches ..4 run advancement grant @s only tamacrafti:state/ready_sleep
execute unless score @s tc_sleeping matches 0 run advancement revoke @s only tamacrafti:state/ready_sleep
execute unless score @s tc_cdsleep matches 0 run advancement revoke @s only tamacrafti:state/ready_sleep
execute if score @s tc_energy matches 5 run advancement revoke @s only tamacrafti:state/ready_sleep
execute store result score @s tc_tmp run clear @s minecraft:carrot 0
execute if score @s tc_tmp matches 1.. run advancement grant @s only tamacrafti:state/has_carrot
execute if score @s tc_tmp matches 0 run advancement revoke @s only tamacrafti:state/has_carrot
execute store result score @s tc_tmp run clear @s minecraft:apple 0
execute if score @s tc_tmp matches 1.. run advancement grant @s only tamacrafti:state/has_apple
execute if score @s tc_tmp matches 0 run advancement revoke @s only tamacrafti:state/has_apple
execute store result score @s tc_tmp run clear @s minecraft:potato 0
execute if score @s tc_tmp matches 1.. run advancement grant @s only tamacrafti:state/has_potato
execute if score @s tc_tmp matches 0 run advancement revoke @s only tamacrafti:state/has_potato
execute store result score @s tc_tmp run clear @s minecraft:cookie 0
execute if score @s tc_tmp matches 1.. run advancement grant @s only tamacrafti:state/has_cookie
execute if score @s tc_tmp matches 0 run advancement revoke @s only tamacrafti:state/has_cookie


# Journey/home flags mirrored as impossible advancements for DAI conditions.
execute if score @s tc_journey matches 1 run advancement grant @s only tamacrafti:state/journey_active
execute unless score @s tc_journey matches 1 run advancement revoke @s only tamacrafti:state/journey_active
execute if score #home tc_home_active matches 1 run advancement grant @s only tamacrafti:state/home_building
execute unless score #home tc_home_active matches 1 run advancement revoke @s only tamacrafti:state/home_building
execute if score #home tc_home_complete matches 1 run advancement grant @s only tamacrafti:state/home_complete
execute unless score #home tc_home_complete matches 1 run advancement revoke @s only tamacrafti:state/home_complete
