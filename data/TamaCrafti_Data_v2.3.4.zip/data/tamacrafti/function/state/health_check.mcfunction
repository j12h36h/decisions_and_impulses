
scoreboard players set @s tc_tmp 0
execute if score @s tc_hunger matches 0 run scoreboard players add @s tc_tmp 1
execute if score @s tc_happy matches 0 run scoreboard players add @s tc_tmp 1
execute if score @s tc_clean matches 0 run scoreboard players add @s tc_tmp 1
execute if score @s tc_energy matches 0 run scoreboard players add @s tc_tmp 1
execute if score @s tc_tmp matches 2.. run scoreboard players remove @s tc_health 1
function tamacrafti:state/clamp
