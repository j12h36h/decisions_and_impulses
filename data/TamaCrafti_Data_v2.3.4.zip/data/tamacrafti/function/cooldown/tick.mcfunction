
execute if score @s tc_cdfeed matches 1.. run scoreboard players remove @s tc_cdfeed 1
execute if score @s tc_cdplay matches 1.. run scoreboard players remove @s tc_cdplay 1
execute if score @s tc_cdclean matches 1.. run scoreboard players remove @s tc_cdclean 1
execute if score @s tc_cdsleep matches 1.. run scoreboard players remove @s tc_cdsleep 1
