# Runtime-only Journey state bootstrap.
# World shape, gamerules, border, weather, time, and the starter platform are
# owned by data/tamacrafti/dai_worldgen/journey.json so a version-sensitive
# command can fail safely without invalidating this entire function at reload.
scoreboard players set #world tc_world_init 1
scoreboard players set #home tc_home_step 0
scoreboard players set #home tc_home_clock -40
scoreboard players set #home tc_home_active 1
scoreboard players set #home tc_home_complete 0
advancement grant @a only tamacrafti:state/home_building
advancement revoke @a only tamacrafti:state/home_complete
