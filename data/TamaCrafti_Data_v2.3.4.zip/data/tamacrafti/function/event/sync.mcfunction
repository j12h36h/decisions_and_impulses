advancement revoke @s only tamacrafti:state/event_success
advancement revoke @s only tamacrafti:state/event_fail
execute if score @s tc_event matches 1 run advancement grant @s only tamacrafti:state/event_success
execute if score @s tc_event matches 2 run advancement grant @s only tamacrafti:state/event_fail
