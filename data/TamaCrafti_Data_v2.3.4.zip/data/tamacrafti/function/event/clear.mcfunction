scoreboard players set @s tc_event 0
advancement revoke @s only tamacrafti:state/event_success
advancement revoke @s only tamacrafti:state/event_fail
