
scoreboard players add #home tc_home_clock 1
execute if score #home tc_home_clock matches 3.. run function tamacrafti:home/step
execute if score #home tc_home_clock matches 3.. run scoreboard players set #home tc_home_clock 0
