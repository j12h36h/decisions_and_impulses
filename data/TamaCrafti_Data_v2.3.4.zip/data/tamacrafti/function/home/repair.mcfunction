
scoreboard players set #home tc_home_step 0
scoreboard players set #home tc_home_clock 0
scoreboard players set #home tc_home_active 1
scoreboard players set #home tc_home_complete 0
advancement grant @a only tamacrafti:state/home_building
advancement revoke @a only tamacrafti:state/home_complete
