
scoreboard players set #home tc_home_active 0
scoreboard players set #home tc_home_complete 1
advancement revoke @a only tamacrafti:state/home_building
advancement grant @a only tamacrafti:state/home_complete
playsound minecraft:ui.toast.challenge_complete master @a 0 200 0 0.65 1.25
title @a times 10 55 20
title @a title {"text":"Home Sweet Home!","color":"light_purple","bold":true}
title @a subtitle {"text":"Your TamaCrafti journey can begin.","color":"green"}
tellraw @a [{"text":"[TamaCrafti] ","color":"light_purple","bold":true},{"text":"The garden is ready. Care milestones will unlock more farming rewards.","color":"white"}]
