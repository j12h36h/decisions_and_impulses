
advancement revoke @s only tamacrafti:world/slept_in_bed
scoreboard players add @s tc_energy 2
scoreboard players add @s tc_happy 1
scoreboard players add @s tc_trust 1
execute if score @s tc_request matches 4 run function tamacrafti:request/complete
function tamacrafti:state/clamp
function tamacrafti:state/sync
