
advancement revoke @s only tamacrafti:world/enter_end
execute if score @s tc_endseen matches 0 run scoreboard players add @s tc_happy 2
execute if score @s tc_endseen matches 0 run scoreboard players add @s tc_trust 1
scoreboard players set @s tc_endseen 1
function tamacrafti:state/clamp
function tamacrafti:state/sync
