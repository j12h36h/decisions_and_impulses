
advancement revoke @s only tamacrafti:world/enter_nether
execute if score @s tc_netherseen matches 0 run scoreboard players add @s tc_happy 1
execute if score @s tc_netherseen matches 0 run scoreboard players add @s tc_trust 1
scoreboard players set @s tc_netherseen 1
function tamacrafti:state/clamp
function tamacrafti:state/sync
