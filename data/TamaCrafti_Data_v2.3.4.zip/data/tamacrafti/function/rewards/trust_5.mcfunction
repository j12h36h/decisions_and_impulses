
scoreboard players set @s tc_reward5 1
give @s minecraft:pumpkin_seeds 4
give @s minecraft:cookie 3
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.6 1.25
tellraw @s [{"text":"TamaCrafti Trust 5: ","color":"light_purple","bold":true},{"text":"Pumpkin seeds and special treats unlocked.","color":"white"}]
