
scoreboard players set @s tc_reward4 1
give @s minecraft:melon_seeds 4
give @s minecraft:apple 2
playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.55 1.7
tellraw @s [{"text":"TamaCrafti Trust 4: ","color":"aqua","bold":true},{"text":"Melon seeds and apples unlocked.","color":"white"}]
