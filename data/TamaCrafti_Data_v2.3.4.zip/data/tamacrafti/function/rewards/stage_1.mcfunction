
scoreboard players set @s tc_rewardstage1 1
give @s minecraft:sweet_berries 6
give @s minecraft:glow_berries 4
playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.55 1.85
tellraw @s [{"text":"TamaCrafti Growth: ","color":"green","bold":true},{"text":"Berry growing unlocked.","color":"white"}]
