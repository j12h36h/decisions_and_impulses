
scoreboard players set @s tc_reward3 1
give @s minecraft:beetroot_seeds 6
playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.55 1.6
tellraw @s [{"text":"TamaCrafti Trust 3: ","color":"aqua","bold":true},{"text":"Beetroot seeds unlocked for the home garden.","color":"white"}]
