
execute if score @s tc_trust matches 3.. unless score @s tc_reward3 matches 1 run function tamacrafti:rewards/trust_3
execute if score @s tc_trust matches 4.. unless score @s tc_reward4 matches 1 run function tamacrafti:rewards/trust_4
execute if score @s tc_trust matches 5.. unless score @s tc_reward5 matches 1 run function tamacrafti:rewards/trust_5
execute if score @s tc_stage matches 1.. unless score @s tc_rewardstage1 matches 1 run function tamacrafti:rewards/stage_1
