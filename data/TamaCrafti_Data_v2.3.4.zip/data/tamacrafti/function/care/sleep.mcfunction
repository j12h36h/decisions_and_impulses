
scoreboard players set @s tc_event 2
scoreboard players set @s tc_tmp 0
execute if score @s tc_sleeping matches 0 if score @s tc_cdsleep matches 0 if score @s tc_energy matches ..4 run scoreboard players set @s tc_tmp 1
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_event 1
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_action 9
execute if score @s tc_tmp matches 1 run function tamacrafti:care/repeat
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_sleeping 1
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_sleepclk 0
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_cdsleep 1200
execute if score @s tc_tmp matches 1 if score @s tc_repeat matches ..1 run scoreboard players add @s tc_trust 1
execute if score @s tc_tmp matches 1 run scoreboard players add @s tc_sleep 1
execute if score @s tc_tmp matches 1 if score @s tc_request matches 4 run function tamacrafti:request/complete
execute if score @s tc_tmp matches 1 run playsound minecraft:block.note_block.bell player @s ~ ~ ~ 0.6 0.8
function tamacrafti:state/clamp
function tamacrafti:state/sync
function tamacrafti:event/sync
