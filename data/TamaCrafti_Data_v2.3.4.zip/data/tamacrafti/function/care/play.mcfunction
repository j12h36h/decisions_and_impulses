function tamacrafti:care/play_ball
