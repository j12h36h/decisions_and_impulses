scoreboard players set @s tc_event 2
scoreboard players set @s tc_tmp 0
execute if score @s tc_sleeping matches 0 if score @s tc_cdplay matches 0 if score @s tc_trust matches 3.. run scoreboard players set @s tc_tmp 1
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_event 1
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_action 6
execute if score @s tc_tmp matches 1 run function tamacrafti:care/repeat
execute if score @s tc_tmp matches 1 run scoreboard players add @s tc_happy 3
execute if score @s tc_tmp matches 1 run scoreboard players remove @s tc_energy 2
execute if score @s tc_tmp matches 1 if score @s tc_repeat matches 2.. if score @s tc_happy matches 1.. run scoreboard players remove @s tc_happy 1
execute if score @s tc_tmp matches 1 if score @s tc_repeat matches ..1 run scoreboard players add @s tc_trust 1
execute if score @s tc_tmp matches 1 run scoreboard players add @s tc_play 1
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_cdplay 160
execute if score @s tc_tmp matches 1 if score @s tc_request matches 2 run function tamacrafti:request/complete
execute if score @s tc_tmp matches 1 run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.7 1.25
function tamacrafti:state/clamp
function tamacrafti:state/health_check
function tamacrafti:state/sync
function tamacrafti:event/sync
