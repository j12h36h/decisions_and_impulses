
execute if score @s tc_last = @s tc_action run scoreboard players add @s tc_repeat 1
execute unless score @s tc_last = @s tc_action run scoreboard players set @s tc_repeat 0
scoreboard players operation @s tc_last = @s tc_action
