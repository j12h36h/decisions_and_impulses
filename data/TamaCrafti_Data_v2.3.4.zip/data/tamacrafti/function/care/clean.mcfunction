
scoreboard players set @s tc_event 2
scoreboard players set @s tc_tmp 0
execute if score @s tc_sleeping matches 0 if score @s tc_cdclean matches 0 if score @s tc_clean matches ..4 run scoreboard players set @s tc_tmp 1
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_event 1
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_action 8
execute if score @s tc_tmp matches 1 run function tamacrafti:care/repeat
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_clean 5
execute if score @s tc_tmp matches 1 run scoreboard players add @s tc_happy 1
execute if score @s tc_tmp matches 1 if score @s tc_repeat matches ..1 run scoreboard players add @s tc_trust 1
execute if score @s tc_tmp matches 1 run scoreboard players add @s tc_wash 1
execute if score @s tc_tmp matches 1 run scoreboard players set @s tc_cdclean 200
execute if score @s tc_tmp matches 1 if score @s tc_request matches 3 run function tamacrafti:request/complete
execute if score @s tc_tmp matches 1 run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 0.7 1.5
function tamacrafti:state/clamp
function tamacrafti:state/health_check
function tamacrafti:state/sync
function tamacrafti:event/sync
