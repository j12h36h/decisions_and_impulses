scoreboard players set @s tc_event 2
scoreboard players set @s tc_tmp 0
execute if score @s tc_sleeping matches 0 if score @s tc_cdfeed matches 0 store result score @s tc_tmp run clear @s minecraft:cookie 1
execute if score @s tc_tmp matches 1.. run scoreboard players set @s tc_event 1
execute if score @s tc_tmp matches 1.. run scoreboard players set @s tc_action 4
execute if score @s tc_tmp matches 1.. run function tamacrafti:care/repeat
execute if score @s tc_tmp matches 1.. run scoreboard players add @s tc_hunger 1
execute if score @s tc_tmp matches 1.. run scoreboard players add @s tc_happy 3
execute if score @s tc_tmp matches 1.. if score @s tc_repeat matches 2.. if score @s tc_happy matches 1.. run scoreboard players remove @s tc_happy 1
execute if score @s tc_tmp matches 1.. if score @s tc_repeat matches ..1 run scoreboard players add @s tc_trust 1
execute if score @s tc_tmp matches 1.. run scoreboard players add @s tc_feed 1
execute if score @s tc_tmp matches 1.. run scoreboard players set @s tc_cdfeed 80
execute if score @s tc_tmp matches 1.. if score @s tc_repeat matches 2.. if score @s tc_health matches 1.. run scoreboard players remove @s tc_health 1
execute if score @s tc_tmp matches 1.. run playsound minecraft:entity.generic.eat player @s ~ ~ ~ 0.7 1.45
function tamacrafti:state/clamp
function tamacrafti:state/health_check
function tamacrafti:state/sync
function tamacrafti:event/sync
