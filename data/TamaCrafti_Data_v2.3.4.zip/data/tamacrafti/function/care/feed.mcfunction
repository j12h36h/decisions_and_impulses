function tamacrafti:care/feed_carrot
