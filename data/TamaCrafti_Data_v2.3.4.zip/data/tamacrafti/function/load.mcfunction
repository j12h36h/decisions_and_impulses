# TamaCrafti v1.2 — no Java changes required
scoreboard objectives add tc_init dummy
scoreboard objectives add tc_hunger dummy
scoreboard objectives add tc_happy dummy
scoreboard objectives add tc_clean dummy
scoreboard objectives add tc_energy dummy
scoreboard objectives add tc_health dummy
scoreboard objectives add tc_trust dummy
scoreboard objectives add tc_age dummy
scoreboard objectives add tc_stage dummy
scoreboard objectives add tc_mood dummy
scoreboard objectives add tc_event dummy
scoreboard objectives add tc_tmp dummy
scoreboard objectives add tc_hclk dummy
scoreboard objectives add tc_pclk dummy
scoreboard objectives add tc_cclk dummy
scoreboard objectives add tc_eclk dummy
scoreboard objectives add tc_aclk dummy
scoreboard objectives add tc_feed dummy
scoreboard objectives add tc_play dummy
scoreboard objectives add tc_wash dummy
scoreboard objectives add tc_sleep dummy
execute as @a unless score @s tc_init matches 1 run function tamacrafti:player/init
scoreboard objectives add tc_sleeping dummy
scoreboard objectives add tc_sleepclk dummy
scoreboard objectives add tc_cdfeed dummy
scoreboard objectives add tc_cdplay dummy
scoreboard objectives add tc_cdclean dummy
scoreboard objectives add tc_cdsleep dummy
scoreboard objectives add tc_last dummy
scoreboard objectives add tc_action dummy
scoreboard objectives add tc_repeat dummy
scoreboard objectives add tc_request dummy
scoreboard objectives add tc_reqnext dummy
scoreboard objectives add tc_reqclk dummy
scoreboard objectives add tc_reqdone dummy
scoreboard objectives add tc_reqmiss dummy
scoreboard objectives add tc_healclk dummy
scoreboard objectives add tc_netherseen dummy
scoreboard objectives add tc_endseen dummy

# v1.2 migration: create zero values for existing pets without resetting them.
scoreboard players add @a tc_sleeping 0
scoreboard players add @a tc_sleepclk 0
scoreboard players add @a tc_cdfeed 0
scoreboard players add @a tc_cdplay 0
scoreboard players add @a tc_cdclean 0
scoreboard players add @a tc_cdsleep 0
scoreboard players add @a tc_last 0
scoreboard players add @a tc_action 0
scoreboard players add @a tc_repeat 0
scoreboard players add @a tc_request 0
scoreboard players add @a tc_reqnext 0
scoreboard players add @a tc_reqclk 0
scoreboard players add @a tc_reqdone 0
scoreboard players add @a tc_reqmiss 0
scoreboard players add @a tc_healclk 0
scoreboard players add @a tc_netherseen 0
scoreboard players add @a tc_endseen 0
scoreboard objectives add tc_avclk dummy
scoreboard players add @a tc_avclk 0

# v2.0 Journey Alpha
scoreboard objectives add tc_journey dummy
scoreboard objectives add tc_home_step dummy
scoreboard objectives add tc_home_clock dummy
scoreboard objectives add tc_home_active dummy
scoreboard objectives add tc_home_complete dummy
scoreboard objectives add tc_world_init dummy
scoreboard objectives add tc_recipeclk dummy
scoreboard objectives add tc_reward3 dummy
scoreboard objectives add tc_reward4 dummy
scoreboard objectives add tc_reward5 dummy
scoreboard objectives add tc_rewardstage1 dummy
scoreboard objectives add tc_journeykit dummy

# Migration-safe zero initialization.
scoreboard players add @a tc_journey 0
scoreboard players add @a tc_recipeclk 0
scoreboard players add @a tc_reward3 0
scoreboard players add @a tc_reward4 0
scoreboard players add @a tc_reward5 0
scoreboard players add @a tc_rewardstage1 0
scoreboard players add @a tc_journeykit 0
scoreboard players add #world tc_world_init 0
scoreboard players add #home tc_home_step 0
scoreboard players add #home tc_home_clock 0
scoreboard players add #home tc_home_active 0
scoreboard players add #home tc_home_complete 0
