function tamacrafti:state/clear_flags
function tamacrafti:event/clear
scoreboard players set @s tc_init 0
function tamacrafti:player/init
