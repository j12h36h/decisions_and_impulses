
scoreboard players add @s tc_sleepclk 1
execute if score @s tc_sleepclk matches 200 run scoreboard players add @s tc_energy 1
execute if score @s tc_sleepclk matches 200 run function tamacrafti:state/sync
execute if score @s tc_sleepclk matches 400 run scoreboard players add @s tc_energy 1
execute if score @s tc_sleepclk matches 400 run function tamacrafti:state/sync
execute if score @s tc_sleepclk matches 600 run scoreboard players add @s tc_energy 1
execute if score @s tc_sleepclk matches 600 run function tamacrafti:state/sync
execute if score @s tc_sleepclk matches 800 run scoreboard players add @s tc_energy 1
execute if score @s tc_sleepclk matches 800 run function tamacrafti:state/sync
execute if score @s tc_sleepclk matches 1000 run scoreboard players add @s tc_energy 1
execute if score @s tc_sleepclk matches 1000 run function tamacrafti:state/sync
execute if score @s tc_sleepclk matches 1200.. run function tamacrafti:sleep/end
function tamacrafti:state/clamp
