
scoreboard players set @s tc_sleeping 0
scoreboard players set @s tc_sleepclk 0
execute if score @s tc_hunger matches 1.. run scoreboard players remove @s tc_hunger 1
scoreboard players add @s tc_happy 1
function tamacrafti:state/health_check
function tamacrafti:state/sync
