
scoreboard players add @s tc_reqclk 1
execute if score @s tc_request matches 0 if score @s tc_reqclk matches 3600.. run function tamacrafti:request/new
execute if score @s tc_request matches 1.. if score @s tc_reqclk matches 2400.. run function tamacrafti:request/expire
