
scoreboard players add @s tc_reqdone 1
scoreboard players set @s tc_request 0
scoreboard players set @s tc_reqclk 0
scoreboard players add @s tc_trust 1
playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.55 1.8
