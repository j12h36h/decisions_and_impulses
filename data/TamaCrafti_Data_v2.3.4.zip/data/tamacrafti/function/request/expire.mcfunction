
scoreboard players add @s tc_reqmiss 1
scoreboard players set @s tc_request 0
scoreboard players set @s tc_reqclk 0
execute if score @s tc_happy matches 1.. run scoreboard players remove @s tc_happy 1
function tamacrafti:state/sync
