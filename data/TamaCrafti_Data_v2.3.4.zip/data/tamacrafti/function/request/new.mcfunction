
scoreboard players add @s tc_reqnext 1
execute if score @s tc_reqnext matches 5.. run scoreboard players set @s tc_reqnext 1
scoreboard players operation @s tc_request = @s tc_reqnext
scoreboard players set @s tc_reqclk 0
function tamacrafti:state/sync
