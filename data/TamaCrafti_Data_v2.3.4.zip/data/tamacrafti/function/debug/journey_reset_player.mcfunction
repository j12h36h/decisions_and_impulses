# Destructive Journey player reset for testing.
scoreboard players set @s tc_journey 0
scoreboard players set @s tc_reward3 0
scoreboard players set @s tc_reward4 0
scoreboard players set @s tc_reward5 0
scoreboard players set @s tc_rewardstage1 0
advancement revoke @s only tamacrafti:state/journey_active
function tamacrafti:journey/init
