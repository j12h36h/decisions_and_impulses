scoreboard players set @s tc_age 5
function tamacrafti:state/sync
