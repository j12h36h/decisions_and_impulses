scoreboard players set @s tc_age 0
function tamacrafti:state/sync
