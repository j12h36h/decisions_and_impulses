give @s minecraft:carrot 8
give @s minecraft:apple 8
give @s minecraft:baked_potato 8
give @s minecraft:cookie 8
