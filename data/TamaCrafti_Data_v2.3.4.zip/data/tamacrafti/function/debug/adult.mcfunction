scoreboard players set @s tc_age 15
function tamacrafti:state/sync
