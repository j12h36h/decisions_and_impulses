scoreboard players set @s tc_hunger 1
scoreboard players set @s tc_happy 1
scoreboard players set @s tc_clean 1
scoreboard players set @s tc_energy 1
function tamacrafti:state/sync
