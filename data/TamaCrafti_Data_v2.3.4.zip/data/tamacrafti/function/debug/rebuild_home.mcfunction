
function tamacrafti:home/repair
tellraw @s {"text":"TamaCrafti home repair/rebuild pass started.","color":"yellow"}
