# DAI Comic Effects Data — v1.4.0 → v1.5.0

## DAI 3.3 Modernization
- Updated the addon for DAI 3.3.
- Updated managed ADDON metadata to v1.5.0.
- Preserved the stable `dai_comic_fx` addon identity.
- Preserved DAI-native `player_attack_entity` reactions for POW and WHAM instead of replacing them with tick polling.

## World-Space FX Efficiency
- Reworked active comic `text_display` processing.
- Age, vertical movement, and expiry are now handled in one local display function.
- Reduced active comic-display processing from three global entity scans every tick to one global selection followed by local execution.
- Preserved the existing 20 TPS sprite movement and 16-tick lifetime.
- Visual movement speed and effect timing remain unchanged.

## Creeper BOOM Timing Fix
- Corrected creeper fuse accounting after v1.4.0 reduced environmental recognition to 10 Hz.
- Creeper countdown progress now advances by two game ticks per environmental sample.
- Restores real-time BOOM timing instead of effectively running the internal comic fuse at half speed.
- Manual and natural creeper detonation handling remain supported.

## Repeatable CRASH Events
- Separated CRASH state from the generic BOOM/ZAP one-shot event tag.
- Living entities can now trigger CRASH again after a later qualifying hard fall.
- CRASH no longer risks interfering with a creeper's later BOOM cue.
- Falling-block CRASH remains one-shot for the lifetime of the falling entity.

## Environmental Recognition
- Preserved the v1.4.0 10 Hz nearby environmental scan cadence.
- Preserved overlapping-player deduplication.
- Preserved automatic detection for:
  - Significant living-entity falls
  - Water-entry SPLASH events
  - Falling-block impacts
  - Lightning ZAP events
  - Primed TNT BOOM events
  - Creeper BOOM events
- No environmental detection radius was reduced.

## Existing Comic Interface
- Preserved POW, BAM, WHAM, KAPOW, WHACK, BOOM, ZAP, SPLASH, and CRASH presentation.
- Preserved layered POW and animated KAPOW test effects.
- Preserved the shared DAI Automation/Actions menu contribution.
- No progression or save migration is required.

## Performance Summary
- Active comic `text_display` world scans: **3 per tick → 1 per tick**
- Environmental recognition: **remains 10 Hz**
- Combat POW/WHAM: **remains event-driven**
- Creeper fuse timing: **corrected to real game-tick time**
