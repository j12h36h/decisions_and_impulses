# DAI Comic Effects v1.5.0 runtime state
scoreboard objectives add dai_cfx_fall dummy
scoreboard objectives add dai_cfx_age dummy
scoreboard objectives add dai_cfx_creep dummy
scoreboard objectives add dai_cfx_fuse dummy
scoreboard objectives add dai_cfx_clock dummy
scoreboard players set #scan dai_cfx_clock 0
kill @e[type=minecraft:text_display,tag=dai_cfx_effect]
tag @e[tag=dai_cfx_scanned] remove dai_cfx_scanned
tag @e[tag=dai_cfx_crash_seen] remove dai_cfx_crash_seen
