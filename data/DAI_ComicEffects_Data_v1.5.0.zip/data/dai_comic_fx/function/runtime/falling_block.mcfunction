# A falling block disappears as soon as it becomes a placed block, so fire CRASH immediately
# before contact when the block underneath is no longer air/fluid.
execute unless entity @s[tag=dai_cfx_crash_seen] unless block ~ ~-1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:cave_air unless block ~ ~-1 ~ minecraft:void_air unless block ~ ~-1 ~ minecraft:water unless block ~ ~-1 ~ minecraft:lava run function dai_comic_fx:event/crash
