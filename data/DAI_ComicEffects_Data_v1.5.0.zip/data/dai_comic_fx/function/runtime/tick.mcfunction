# DAI Comic Effects v1.5.0
# Active world-space comic sprites use one local display pass per tick.
# Environmental recognition remains sampled at 10 Hz to preserve v1.4.0's lower idle cost.
execute as @e[type=minecraft:text_display,tag=dai_cfx_effect] at @s run function dai_comic_fx:runtime/display_tick

scoreboard players add #scan dai_cfx_clock 1
execute if score #scan dai_cfx_clock matches 2.. run tag @e[tag=dai_cfx_scanned] remove dai_cfx_scanned
execute if score #scan dai_cfx_clock matches 2.. as @a at @s run function dai_comic_fx:runtime/scan_nearby
execute if score #scan dai_cfx_clock matches 2.. run scoreboard players set #scan dai_cfx_clock 0
