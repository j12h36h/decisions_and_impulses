# One selected comic text_display: age, rise, then expire.
scoreboard players add @s dai_cfx_age 1
tp @s ~ ~0.025 ~
execute if score @s dai_cfx_age matches 16.. run kill @s
