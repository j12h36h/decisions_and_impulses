# Capture fall distance at 0.1-block precision.
execute store result score @s dai_cfx_fall run data get entity @s FallDistance 10

# Any airborne living entity can make a SPLASH when it enters water.
execute if data entity @s {OnGround:0b} unless block ~ ~ ~ minecraft:water run tag @s add dai_cfx_airborne
execute if entity @s[tag=dai_cfx_airborne] if block ~ ~ ~ minecraft:water run function dai_comic_fx:event/splash

# Only meaningful falls become CRASH events; normal hops stay quiet.
execute if score @s dai_cfx_fall matches 30.. run tag @s add dai_cfx_hard_fall
execute if entity @s[tag=dai_cfx_hard_fall,tag=!dai_cfx_crash_seen] if data entity @s {OnGround:1b} run function dai_comic_fx:event/crash

# Rearm after ordinary landings / swimming transitions.
execute if data entity @s {OnGround:1b} run tag @s remove dai_cfx_airborne
execute if data entity @s {OnGround:1b} run tag @s remove dai_cfx_hard_fall
execute if data entity @s {OnGround:1b} run tag @s remove dai_cfx_crash_seen
execute if block ~ ~ ~ minecraft:water run tag @s remove dai_cfx_hard_fall
execute if block ~ ~ ~ minecraft:water run tag @s remove dai_cfx_crash_seen
