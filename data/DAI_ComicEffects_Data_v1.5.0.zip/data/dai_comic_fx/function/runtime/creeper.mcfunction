# DAI Comic Effects v1.5.0
# The environmental scan runs at 10 Hz, so fuse progress advances by two game ticks per sample.
execute unless entity @s[tag=dai_cfx_creeper_init] run function dai_comic_fx:runtime/creeper_init

# Manually ignited creepers always count down. Natural creepers count down while a
# survival/adventure player is in their normal detonation radius.
execute if data entity @s {ignited:1b} run scoreboard players add @s dai_cfx_creep 2
execute unless data entity @s {ignited:1b} if entity @a[distance=..3,gamemode=!creative,gamemode=!spectator] run scoreboard players add @s dai_cfx_creep 2
execute unless data entity @s {ignited:1b} unless entity @a[distance=..3,gamemode=!creative,gamemode=!spectator] run scoreboard players set @s dai_cfx_creep 0
execute unless data entity @s {ignited:1b} unless entity @a[distance=..3,gamemode=!creative,gamemode=!spectator] run tag @s remove dai_cfx_event_seen

execute if score @s dai_cfx_creep >= @s dai_cfx_fuse unless entity @s[tag=dai_cfx_event_seen] run function dai_comic_fx:event/boom
