DAI Survival Interface v0.4.0
For Minecraft 26.2 + DAI 3.3
Role: ADDON
DAI ID: dai_survival_interface

Purpose
- True screen-space survival/target interface.
- No floating text_display entities.
- No damage-number logic.
- Designed to stack with Damage Indicators and other DAI addons.

Target UI
- Appears before combat when you aim at a living entity.
- Shows target name.
- Native health progress bar.
- Shows current / maximum HP.
- Shows approximate range.
- 2.5 second target-lock grace window prevents flicker on brief ray misses.
- Sixteen isolated HUD lanes are included for local/LAN multiplayer use.

Commands
/function survival_interface:toggle
/function survival_interface:enable
/function survival_interface:disable

v0.4.0 / DAI 3.3 capability + efficiency pass
- Updated managed addon metadata and release text for DAI 3.3.
- Preserves native living-entity Health/max-health reads, including DAI native entities.
- Expensive recursive target acquisition now runs at 10 TPS per player instead of 20 TPS.
- Multiplayer aim scans are split across alternating phases to distribute command load between ticks.
- The 2.5 second target-lock timer still advances at 20 TPS for unchanged grace-window timing.
- Bossbar hide operations now run only on visibility transitions.
- Each player's dedicated bossbar lane is claimed during initialization instead of reassigning the lane every target refresh.
- Removed the repeated global temporary-target cleanup from every target scan; load-time cleanup remains as a stale-state safeguard.
- Existing enabled/disabled preferences remain persistent.

v0.3.0
- Expanded isolated bossbar HUD lanes from 8 to 16 concurrent players.
- Kept each player's target/health/range display isolated from every other player's target.
- Existing preferences persisted; slot assignment wraps across 16 lanes.

Important
Remove the old DAI_Damage_Indicators_HUD v0.x addon when installing this pack.
That older addon is a separate pack and will continue spawning its world-space
text displays if it remains enabled.

HUD implementation
Survival Interface uses Minecraft's native bossbar HUD for dynamic target text,
health values, and progress. It does not create world-space HUD entities.
