# Lightweight 20 TPS state maintenance; expensive aim acquisition is staggered at 10 TPS per player.
execute as @a[tag=!si_init] run function survival_interface:player/init

# Target-lock grace remains real-time at 20 TPS even though acquisition is sampled at 10 TPS.
execute as @a[tag=si_init,scores={si_enable=1..,si_lock=1..}] run scoreboard players remove @s si_lock 1

# Split players across two alternating phases so multiplayer ray work is distributed between ticks.
execute as @a[tag=si_init,scores={si_enable=1..}] at @s if score @s si_phase = #pulse si_const run function survival_interface:target/start

# Hide only on a visibility transition instead of rewriting bossbar state every tick.
execute as @a[tag=si_init,tag=si_hud_visible,scores={si_enable=1..,si_lock=..0}] run function survival_interface:ui/hide
execute as @a[tag=si_init,tag=si_hud_visible,scores={si_enable=..0}] run function survival_interface:ui/hide

scoreboard players add #pulse si_const 1
execute if score #pulse si_const matches 2.. run scoreboard players set #pulse si_const 0
