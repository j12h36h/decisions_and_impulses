scoreboard players add #next_slot si_const 1
execute if score #next_slot si_const matches 17.. run scoreboard players set #next_slot si_const 1
scoreboard players operation @s si_slot = #next_slot si_const

# Alternate player scan phases by lane so multiplayer raycasts are staggered across server ticks.
scoreboard players operation @s si_phase = @s si_slot
scoreboard players operation @s si_phase %= #two si_const

# Preserve an existing preference; only players without a score default to Enabled.
execute unless score @s si_enable = @s si_enable run scoreboard players set @s si_enable 1
scoreboard players set @s si_lock 0
scoreboard players set @s si_ray 0
tag @s add si_init
function survival_interface:ui/claim
function survival_interface:ui/hide
