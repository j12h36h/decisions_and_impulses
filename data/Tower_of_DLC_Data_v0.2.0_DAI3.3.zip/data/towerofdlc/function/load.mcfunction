# Tower of DLC persistent systems
scoreboard objectives add td_init dummy
scoreboard objectives add td_clock dummy
scoreboard objectives add td_faction dummy
scoreboard objectives add td_disc_cd dummy
scoreboard objectives add td_dash_cd dummy
scoreboard objectives add td_bike_active dummy
scoreboard objectives add td_proj_age dummy
scoreboard objectives add td_kills playerKillCount
scoreboard objectives add td_deaths deathCount
scoreboard objectives add td_data dummy
scoreboard objectives add td_tech dummy
scoreboard objectives add td_capture dummy
scoreboard objectives add td_owner dummy
scoreboard players add #clock td_clock 0
scoreboard players add #cyan td_data 0
scoreboard players add #orange td_data 0
scoreboard players add #cyan td_tech 0
scoreboard players add #orange td_tech 0
scoreboard players add #cyan td_capture 0
scoreboard players add #orange td_capture 0
scoreboard players add #owner td_owner 0
scoreboard players add #v013 td_init 0
scoreboard players add #v014 td_init 0
team add td_cyan
team modify td_cyan color aqua
team modify td_cyan friendlyFire false
team modify td_cyan collisionRule pushOtherTeams
team add td_orange
team modify td_orange color gold
team modify td_orange friendlyFire false
team modify td_orange collisionRule pushOtherTeams
execute as @a unless score @s td_init matches 1 run function towerofdlc:player/init
