scoreboard players set #owner td_owner 1
scoreboard players set #cyan td_capture 0
scoreboard players set #orange td_capture 0
scoreboard players add #cyan td_data 25
function towerofdlc:tower/eye_cyan
title @a title {"text":"CYAN CONTROLS THE SYSTEM EYE","color":"aqua","bold":true}
title @a subtitle {"text":"The Grid is routing Data west","color":"white"}
playsound minecraft:block.beacon.activate master @a 0 70 0 1.0 1.5
