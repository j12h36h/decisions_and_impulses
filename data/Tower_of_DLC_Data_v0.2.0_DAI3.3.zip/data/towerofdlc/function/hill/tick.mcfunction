# Only one faction in the top capture volume advances the hill.
execute if entity @a[team=td_cyan,x=-9,y=64,z=-9,dx=18,dy=8,dz=18] unless entity @a[team=td_orange,x=-9,y=64,z=-9,dx=18,dy=8,dz=18] run scoreboard players add #cyan td_capture 1
execute if entity @a[team=td_orange,x=-9,y=64,z=-9,dx=18,dy=8,dz=18] unless entity @a[team=td_cyan,x=-9,y=64,z=-9,dx=18,dy=8,dz=18] run scoreboard players add #orange td_capture 1
execute if entity @a[team=td_cyan,x=-9,y=64,z=-9,dx=18,dy=8,dz=18] unless entity @a[team=td_orange,x=-9,y=64,z=-9,dx=18,dy=8,dz=18] run scoreboard players set #orange td_capture 0
execute if entity @a[team=td_orange,x=-9,y=64,z=-9,dx=18,dy=8,dz=18] unless entity @a[team=td_cyan,x=-9,y=64,z=-9,dx=18,dy=8,dz=18] run scoreboard players set #cyan td_capture 0
execute if score #cyan td_capture matches 20.. run function towerofdlc:hill/capture_cyan
execute if score #orange td_capture matches 20.. run function towerofdlc:hill/capture_orange
execute if score #owner td_owner matches 1 run scoreboard players add #cyan td_data 1
execute if score #owner td_owner matches 2 run scoreboard players add #orange td_data 1
execute if score #owner td_owner matches 1 positioned 0 78 0 run particle minecraft:electric_spark ~ ~ ~ 4 5 4 0.05 18 force @a[distance=..160]
execute if score #owner td_owner matches 2 positioned 0 78 0 run particle minecraft:flame ~ ~ ~ 4 5 4 0.01 12 force @a[distance=..160]
