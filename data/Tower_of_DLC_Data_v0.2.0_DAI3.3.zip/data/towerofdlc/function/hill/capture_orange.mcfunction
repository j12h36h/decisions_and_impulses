scoreboard players set #owner td_owner 2
scoreboard players set #cyan td_capture 0
scoreboard players set #orange td_capture 0
scoreboard players add #orange td_data 25
function towerofdlc:tower/eye_orange
title @a title {"text":"ORANGE CONTROLS THE SYSTEM EYE","color":"gold","bold":true}
title @a subtitle {"text":"The Grid is routing Data east","color":"white"}
playsound minecraft:block.beacon.activate master @a 0 70 0 1.0 0.8
