# Tower of DLC v0.1.4 world compiler
function towerofdlc:world/grid
function towerofdlc:world/city
function towerofdlc:world/bases
function towerofdlc:world/tower
function towerofdlc:world/bridges
function towerofdlc:tower/eye_neutral
function towerofdlc:world/lighting
setworldspawn 0 -60 100
scoreboard players set #owner td_owner 0
scoreboard players set #cyan td_capture 0
scoreboard players set #orange td_capture 0
scoreboard players set #v013 td_init 1
scoreboard players set #v014 td_init 1
