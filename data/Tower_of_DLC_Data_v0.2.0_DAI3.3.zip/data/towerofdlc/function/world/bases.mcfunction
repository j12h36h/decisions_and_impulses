fill -104 -61 -20 -72 -61 20 minecraft:polished_deepslate
fill -104 6 -20 -72 6 20 minecraft:polished_deepslate
fill -104 -60 -20 -104 5 20 minecraft:cyan_concrete
fill -72 -60 -20 -72 5 20 minecraft:polished_deepslate
fill -103 -60 -20 -73 5 -20 minecraft:polished_deepslate
fill -103 -60 20 -73 5 20 minecraft:polished_deepslate
fill -72 -60 -4 -72 -54 4 minecraft:air
fill -101 -60 -15 -76 -60 15 minecraft:black_concrete
fill -98 -60 -12 -80 -60 12 minecraft:cyan_concrete outline
fill -96 -59 -10 -82 -59 10 minecraft:gray_concrete
setblock -90 -59 0 towerofdlc:cyan_grid_lamp
fill 72 -61 -20 104 -61 20 minecraft:polished_deepslate
fill 72 6 -20 104 6 20 minecraft:polished_deepslate
fill 104 -60 -20 104 5 20 minecraft:orange_concrete
fill 72 -60 -20 72 5 20 minecraft:polished_deepslate
fill 73 -60 -20 103 5 -20 minecraft:polished_deepslate
fill 73 -60 20 103 5 20 minecraft:polished_deepslate
fill 72 -60 -4 72 -54 4 minecraft:air
fill 76 -60 -15 101 -60 15 minecraft:black_concrete
fill 80 -60 -12 98 -60 12 minecraft:orange_concrete outline
fill 82 -59 -10 96 -59 10 minecraft:gray_concrete
setblock 90 -59 0 towerofdlc:orange_grid_lamp
