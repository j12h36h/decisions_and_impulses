# Tower of DLC v0.1.4 one-time lighting migration for existing worlds.
# Adds native faction Grid Lamps + invisible light cells without rebuilding player-facing geometry.
function towerofdlc:world/lighting
scoreboard players set #v014 td_init 1
