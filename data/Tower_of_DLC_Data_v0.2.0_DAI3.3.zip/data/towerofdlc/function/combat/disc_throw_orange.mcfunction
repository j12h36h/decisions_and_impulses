execute unless score @s td_faction matches 2 run return 0
execute if score @s td_disc_cd matches 1.. run playsound minecraft:block.note_block.hat player @s ~ ~ ~ 0.4 0.7
execute unless score @s td_disc_cd matches 1.. anchored eyes positioned ^ ^ ^1.5 run summon minecraft:item_display ~ ~ ~ {Tags:["td_disc_projectile","td_orange_disc","td_new"],billboard:"center",view_range:1.4f,shadow_radius:0.0f,item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.32f,0.32f,0.32f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]},item:{id:"towerofdlc:orange_disc",count:1}}
execute unless score @s td_disc_cd matches 1.. run data modify entity @e[type=minecraft:item_display,tag=td_new,tag=td_orange_disc,limit=1,sort=nearest,distance=..4] Rotation set from entity @s Rotation
execute unless score @s td_disc_cd matches 1.. run scoreboard players set @e[type=minecraft:item_display,tag=td_new,tag=td_orange_disc,limit=1,sort=nearest,distance=..4] td_proj_age 0
execute unless score @s td_disc_cd matches 1.. run tag @e[type=minecraft:item_display,tag=td_new,tag=td_orange_disc,limit=1,sort=nearest,distance=..4] remove td_new
execute unless score @s td_disc_cd matches 1.. run scoreboard players set @s td_disc_cd 18
execute if score @s td_disc_cd matches 18 run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.7 1.3
