tellraw @s [{"text":"=== TOWER OF DLC // WAR STATUS ===","color":"aqua","bold":true}]
tellraw @s [{"text":"CYAN Data: ","color":"aqua"},{"score":{"name":"#cyan","objective":"td_data"}},{"text":"  Tech: ","color":"gray"},{"score":{"name":"#cyan","objective":"td_tech"}}]
tellraw @s [{"text":"ORANGE Data: ","color":"gold"},{"score":{"name":"#orange","objective":"td_data"}},{"text":"  Tech: ","color":"gray"},{"score":{"name":"#orange","objective":"td_tech"}}]
tellraw @s [{"text":"Eye Owner: 0 Neutral // 1 Cyan // 2 Orange = ","color":"white"},{"score":{"name":"#owner","objective":"td_owner"}}]
