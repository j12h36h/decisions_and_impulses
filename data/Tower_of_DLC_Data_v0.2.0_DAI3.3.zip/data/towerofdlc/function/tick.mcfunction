# Tower of DLC v0.2.0 — DAI 3.3 runtime dispatcher
# Player initialization is owned by the DAI MAIN-experience first-join/join lifecycle; /reload recovery remains in load.mcfunction.
execute unless score #v013 td_init matches 1 run function towerofdlc:world/upgrade_013
execute unless score #v014 td_init matches 1 run function towerofdlc:world/upgrade_014
scoreboard players add #clock td_clock 1
scoreboard players remove @a[scores={td_disc_cd=1..}] td_disc_cd 1
scoreboard players remove @a[scores={td_dash_cd=1..}] td_dash_cd 1

# One projectile world scan; faction-specific behavior dispatches locally.
execute as @e[type=minecraft:item_display,tag=td_disc_projectile] at @s run function towerofdlc:projectile/tick

execute if score #clock td_clock matches 20.. run function towerofdlc:second

# Native DAI Light Cycles now own their 20 TPS drive + passenger cleanup through entity gameplay events.
