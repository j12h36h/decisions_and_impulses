execute as @a[team=td_cyan,scores={td_kills=1..}] run scoreboard players add #cyan td_data 5
execute as @a[team=td_orange,scores={td_kills=1..}] run scoreboard players add #orange td_data 5
scoreboard players set @a[scores={td_kills=1..}] td_kills 0
