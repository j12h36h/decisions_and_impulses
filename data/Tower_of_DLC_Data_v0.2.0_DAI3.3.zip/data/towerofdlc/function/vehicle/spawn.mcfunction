# Tower of DLC v0.1.3 — spawn the faction-specific native DAI Light Cycle.
# No vanilla carrier or item-display visual is used.
execute on vehicle if entity @s[tag=td_bike] run tag @s add td_bike_cleanup
ride @s dismount
kill @e[tag=td_bike_cleanup]
execute at @s run kill @e[tag=td_bike,sort=nearest,limit=1,distance=..3]
execute if score @s td_faction matches 1 at @s run summon towerofdlc:cyan_light_cycle ~ ~0.10 ~ {Tags:["td_bike","td_cyan_bike","td_new_bike"],Silent:1b,Invulnerable:1b}
execute if score @s td_faction matches 2 at @s run summon towerofdlc:orange_light_cycle ~ ~0.10 ~ {Tags:["td_bike","td_orange_bike","td_new_bike"],Silent:1b,Invulnerable:1b}
execute at @s run tp @e[tag=td_new_bike,sort=nearest,limit=1,distance=..4] ~ ~ ~ ~ 0
execute at @s run tag @e[tag=td_new_bike,sort=nearest,limit=1,distance=..4] remove td_new_bike
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 0.65 1.65
