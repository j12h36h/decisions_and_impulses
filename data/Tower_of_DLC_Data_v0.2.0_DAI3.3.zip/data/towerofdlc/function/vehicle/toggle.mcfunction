# Bike Toggle: second use dismisses; first use deploys the native DAI cycle.
execute if score @s td_faction matches 0 run tellraw @s [{"text":"[GRID] ","color":"aqua","bold":true},{"text":"Choose a faction before deploying a Light Cycle.","color":"white"}]
execute if score @s td_faction matches 0 run return 0
execute if score @s td_bike_active matches 1 run return run function towerofdlc:vehicle/dismount
function towerofdlc:vehicle/spawn
function towerofdlc:vehicle/mount
