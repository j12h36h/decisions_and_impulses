# Dismiss the player's current native Light Cycle.
execute on vehicle if entity @s[tag=td_bike] run tag @s add td_bike_cleanup
ride @s dismount
kill @e[tag=td_bike_cleanup]
scoreboard players set @s td_bike_active 0
playsound minecraft:block.beacon.deactivate player @s ~ ~ ~ 0.55 1.25
