# DAI 3.3 entity gameplay tick. Runs as the native Light Cycle.
# The mounted player remains the steering authority; rider_tick preserves the original continuous camera-yaw drive behavior.
execute on passengers if entity @s[type=minecraft:player] at @s run function towerofdlc:vehicle/rider_tick
