# DAI 3.3 native passenger_removed event. Runs as the Light Cycle at dismount time.
# Clear the rider's active-cycle state and remove the non-persistent cycle immediately.
scoreboard players set @a[distance=..4,scores={td_bike_active=1},limit=1,sort=nearest] td_bike_active 0
kill @s
