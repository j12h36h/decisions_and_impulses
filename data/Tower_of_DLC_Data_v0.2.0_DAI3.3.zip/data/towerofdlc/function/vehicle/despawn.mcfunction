function towerofdlc:vehicle/dismount
