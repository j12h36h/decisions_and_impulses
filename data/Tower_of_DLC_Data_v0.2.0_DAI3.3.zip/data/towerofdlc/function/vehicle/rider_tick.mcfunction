# Runs as the rider while Bike Toggle is active. The native DAI cycle auto-drives forward and uses rider yaw as steering.
# Normal forward move when the next half-block is clear.
execute at @s rotated ~ 0 run execute on vehicle positioned as @s if entity @s[tag=td_bike] if block ^ ^0.10 ^0.62 air run return run tp @s ^ ^ ^0.46 ~ 0
# Step a one-block rise (the Tower spiral uses gradual one-block road rises).
execute at @s rotated ~ 0 run execute on vehicle positioned as @s if entity @s[tag=td_bike] unless block ^ ^0.10 ^0.62 air if block ^ ^1.10 ^0.62 air run return run tp @s ^ ^1 ^0.38 ~ 0
