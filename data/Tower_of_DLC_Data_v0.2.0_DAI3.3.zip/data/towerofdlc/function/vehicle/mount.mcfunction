execute at @s run ride @s mount @e[tag=td_bike,sort=nearest,limit=1,distance=..5]
scoreboard players set @s td_bike_active 1
tellraw @s [{"text":"[LIGHT CYCLE] ","color":"aqua","bold":true},{"text":"NATIVE ENTITY ONLINE — the cycle drives continuously; steer with your camera. Use Bike Toggle again to dismiss.","color":"white"}]
