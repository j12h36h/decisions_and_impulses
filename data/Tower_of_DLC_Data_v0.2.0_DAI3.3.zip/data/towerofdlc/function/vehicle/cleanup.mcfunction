# Compatibility cleanup for a detached Light Cycle.
execute at @s run kill @e[tag=td_bike,sort=nearest,limit=1,distance=..4]
scoreboard players set @s td_bike_active 0
