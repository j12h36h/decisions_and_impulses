# v0.1.3: obsolete — Light Cycles are rendered directly by the DAI native mesh renderer.
