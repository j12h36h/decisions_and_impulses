team join td_cyan @s
scoreboard players set @s td_faction 1
clear @s
function towerofdlc:faction/loadout_cyan
spawnpoint @s -90 -59 0
tp @s -90 -59 0 90 0
title @s title {"text":"CYAN LINK ESTABLISHED","color":"aqua","bold":true}
title @s subtitle {"text":"Reach the System Eye at the top of the Tower","color":"white"}
tellraw @a [{"text":"[GRID] ","color":"dark_aqua","bold":true},{"selector":"@s"},{"text":" synchronized with CYAN.","color":"aqua"}]
