clear @s towerofdlc:cyan_disc
item replace entity @s hotbar.0 with towerofdlc:orange_disc
item replace entity @s hotbar.1 with towerofdlc:overclock
item replace entity @s hotbar.2 with towerofdlc:bike_toggle
