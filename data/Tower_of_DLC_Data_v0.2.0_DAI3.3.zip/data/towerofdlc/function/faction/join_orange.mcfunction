team join td_orange @s
scoreboard players set @s td_faction 2
clear @s
function towerofdlc:faction/loadout_orange
spawnpoint @s 90 -59 0
tp @s 90 -59 0 -90 0
title @s title {"text":"ORANGE LINK ESTABLISHED","color":"gold","bold":true}
title @s subtitle {"text":"Reach the System Eye at the top of the Tower","color":"white"}
tellraw @a [{"text":"[GRID] ","color":"dark_aqua","bold":true},{"selector":"@s"},{"text":" synchronized with ORANGE.","color":"gold"}]
