execute if score @s td_dash_cd matches 1.. run playsound minecraft:block.note_block.hat player @s ~ ~ ~ 0.3 0.6
execute unless score @s td_dash_cd matches 1.. run tp @s ^ ^0.15 ^5.5
execute unless score @s td_dash_cd matches 1.. run effect give @s minecraft:speed 2 2 true
execute unless score @s td_dash_cd matches 1.. run scoreboard players set @s td_dash_cd 45
execute if score @s td_dash_cd matches 45 run playsound minecraft:entity.breeze.jump player @s ~ ~ ~ 0.7 1.4
