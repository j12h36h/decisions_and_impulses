execute if score #cyan td_data matches 25.. run scoreboard players set #cyan td_tech 1
execute if score #cyan td_data matches 75.. run scoreboard players set #cyan td_tech 2
execute if score #cyan td_data matches 150.. run scoreboard players set #cyan td_tech 3
execute if score #orange td_data matches 25.. run scoreboard players set #orange td_tech 1
execute if score #orange td_data matches 75.. run scoreboard players set #orange td_tech 2
execute if score #orange td_data matches 150.. run scoreboard players set #orange td_tech 3
execute if score #cyan td_tech matches 1.. run effect give @a[team=td_cyan] minecraft:speed 3 0 true
execute if score #cyan td_tech matches 2.. run effect give @a[team=td_cyan] minecraft:resistance 3 0 true
execute if score #cyan td_tech matches 3.. run effect give @a[team=td_cyan] minecraft:regeneration 3 0 true
execute if score #orange td_tech matches 1.. run effect give @a[team=td_orange] minecraft:speed 3 0 true
execute if score #orange td_tech matches 2.. run effect give @a[team=td_orange] minecraft:resistance 3 0 true
execute if score #orange td_tech matches 3.. run effect give @a[team=td_orange] minecraft:regeneration 3 0 true
