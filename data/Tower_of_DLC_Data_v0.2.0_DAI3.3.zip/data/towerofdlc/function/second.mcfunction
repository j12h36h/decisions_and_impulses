scoreboard players set #clock td_clock 0
function towerofdlc:hill/tick
function towerofdlc:tech/tick
function towerofdlc:score/kills
execute as @a run function towerofdlc:hud/actionbar
