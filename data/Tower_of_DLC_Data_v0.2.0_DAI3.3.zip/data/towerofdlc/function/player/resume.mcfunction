gamemode adventure @s
execute if score @s td_faction matches 0 run tp @s 0 -60 100 180 0
execute if score @s td_faction matches 1 run function towerofdlc:faction/loadout_cyan
execute if score @s td_faction matches 2 run function towerofdlc:faction/loadout_orange
