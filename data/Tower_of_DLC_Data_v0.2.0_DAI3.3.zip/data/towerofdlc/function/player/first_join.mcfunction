function towerofdlc:player/init
tp @s 0 -60 100 180 0
