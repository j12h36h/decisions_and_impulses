execute if score @s td_faction matches 1 run tp @s -90 -59 0 90 0
execute if score @s td_faction matches 2 run tp @s 90 -59 0 -90 0
execute if score @s td_faction matches 0 run tp @s 0 -60 100 180 0
