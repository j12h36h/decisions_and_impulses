scoreboard players set @s td_init 1
scoreboard players set @s td_faction 0
scoreboard players set @s td_disc_cd 0
scoreboard players set @s td_dash_cd 0
scoreboard players set @s td_bike_active 0
gamemode adventure @s
clear @s towerofdlc:cyan_access
clear @s towerofdlc:orange_access
item replace entity @s hotbar.3 with towerofdlc:cyan_access
item replace entity @s hotbar.5 with towerofdlc:orange_access
tellraw @s [{"text":"[TOWER OF DLC] ","color":"aqua","bold":true},{"text":"Choose a faction: CYAN in slot 4 or ORANGE in slot 6. Right-click the Access key.","color":"white"}]
