scoreboard players add @s td_proj_age 1
particle minecraft:electric_spark ~ ~ ~ 0.08 0.08 0.08 0.02 3 force @a[distance=..72]
execute if entity @a[team=td_orange,distance=..1.4,limit=1,sort=nearest] run function towerofdlc:projectile/cyan_hit
execute unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run tag @s add td_proj_dead
execute if score @s td_proj_age matches 34.. run tag @s add td_proj_dead
execute unless entity @s[tag=td_proj_dead] run tp @s ^ ^ ^1.25
execute if entity @s[tag=td_proj_dead] run kill @s
