damage @a[team=td_cyan,distance=..1.4,limit=1,sort=nearest] 6 minecraft:magic
particle minecraft:enchanted_hit ~ ~ ~ 0.18 0.18 0.18 0.04 12 force @a[distance=..64]
playsound minecraft:block.amethyst_block.break player @a[distance=..32] ~ ~ ~ 0.6 1.1
tag @s add td_proj_dead
