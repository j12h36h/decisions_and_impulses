# Runs as one selected Identity Disc projectile.
execute if entity @s[tag=td_cyan_disc] run return run function towerofdlc:projectile/cyan_tick
execute if entity @s[tag=td_orange_disc] run return run function towerofdlc:projectile/orange_tick
tag @s add td_proj_dead
kill @s
