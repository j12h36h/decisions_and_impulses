fill -1 72 -11 1 82 11 minecraft:white_stained_glass
fill -1 75 -6 1 79 6 minecraft:air
fill -1 76 -2 1 78 2 minecraft:sea_lantern
