Tower of DLC Data v0.2.0 // DAI 3.3

MAIN DAI Experience datapack.
Two persistent factions fight through a dense dark-grid city, race native Light Cycles through the spiral Core Spire, and hold the System Eye.
DAI 3.3 moves Light Cycle driving/cleanup into native entity lifecycle events and consolidates Identity Disc projectile processing while preserving the authored combat and world layout.
Install beside the matching Tower of DLC Resource Pack and DAI 3.3.
