# Minecraft's damage_dealt statistic is cumulative and stored in tenths of a
# health point. Split this tick's delta into a stable one-decimal value.
scoreboard players operation @s di_whole = @s di_delta
scoreboard players operation @s di_whole /= #ten di_const
scoreboard players operation @s di_dec = @s di_delta
scoreboard players operation @s di_dec %= #ten di_const

# Freeze the value into macro storage before the display is created. This keeps
# the floating number independent of later scoreboard changes and avoids the
# wildcard score-component behavior that could render as 0.0.
execute store result storage dai_damage_indicators:runtime whole int 1 run scoreboard players get @s di_whole
execute store result storage dai_damage_indicators:runtime dec int 1 run scoreboard players get @s di_dec

# Don't mistake the attacker for the victim if the attacker was also recently hurt.
tag @s add dai_di_attacker

# Find recently hurt entities in a small combat radius. Entities without HurtTime
# keep di_tmp at zero. This remains best-effort and requires no Java changes.
scoreboard players set @e[distance=..8,tag=!dai_di_attacker] di_tmp 0
execute as @e[distance=..8,tag=!dai_di_attacker,type=!minecraft:text_display] store result score @s di_tmp run data get entity @s HurtTime 1

# Prefer the nearest entity whose HurtTime is currently positive.
execute as @e[distance=..8,tag=!dai_di_attacker,scores={di_tmp=1..},sort=nearest,limit=1] at @s run function dai_damage_indicators:display/spawn with storage dai_damage_indicators:runtime

# If no hurt entity can be resolved (for example, a victim died immediately),
# render the same indicator a short distance in front of the attacker instead.
execute unless entity @e[distance=..8,tag=!dai_di_attacker,scores={di_tmp=1..},sort=nearest,limit=1] positioned ^ ^1.15 ^2 run function dai_damage_indicators:display/spawn with storage dai_damage_indicators:runtime

tag @s remove dai_di_attacker
