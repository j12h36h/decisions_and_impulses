tag @s remove dai_di_disabled
scoreboard players set @s di_enable 1
scoreboard players operation @s di_prev = @s di_dealt
tellraw @s [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'Enabled.',color:'green'}]
