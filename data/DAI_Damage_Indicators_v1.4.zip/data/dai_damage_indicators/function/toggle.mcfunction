
scoreboard players operation #toggle di_const = @s di_enable
execute if score #toggle di_const matches 1.. run function dai_damage_indicators:disable
execute unless score #toggle di_const matches 1.. run function dai_damage_indicators:enable
