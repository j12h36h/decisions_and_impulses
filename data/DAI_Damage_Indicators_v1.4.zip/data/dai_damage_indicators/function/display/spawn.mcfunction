# Current execution position is either the victim or the attacker's fallback point.
# Spawn above the body so the number stays readable in melee range.
execute positioned ~ ~1.55 ~ summon minecraft:text_display run function dai_damage_indicators:display/setup with storage dai_damage_indicators:runtime
