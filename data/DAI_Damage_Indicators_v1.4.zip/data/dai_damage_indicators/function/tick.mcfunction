# Initialize new/reloaded players once.
execute as @a[tag=!dai_di_init] run function dai_damage_indicators:player/init

# Read outgoing damage deltas for enabled players.
execute as @a[tag=dai_di_init,scores={di_enable=1..}] at @s run function dai_damage_indicators:player/tick

# Float active indicators gently upward for ~3.5 seconds, then clean them up.
scoreboard players add @e[type=minecraft:text_display,tag=dai_di_display] di_age 1
execute as @e[type=minecraft:text_display,tag=dai_di_display,scores={di_age=..69}] at @s run tp @s ~ ~0.014 ~
kill @e[type=minecraft:text_display,tag=dai_di_display,scores={di_age=70..}]
