# damage_dealt is cumulative. Subtract the previous sample to isolate this tick.
scoreboard players operation @s di_delta = @s di_dealt
scoreboard players operation @s di_delta -= @s di_prev

# A positive delta means the player dealt damage since the previous tick.
execute if score @s di_delta matches 1.. run function dai_damage_indicators:hit

# Always resynchronize so statistic resets or other external changes recover cleanly.
scoreboard players operation @s di_prev = @s di_dealt
