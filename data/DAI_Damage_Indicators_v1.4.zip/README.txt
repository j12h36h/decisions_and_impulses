DAI Damage Indicators v1.4
For Minecraft 26.2 + DAI 1.9.9
Role: ADDON

Purpose
- Floating combat damage numbers only.
- No target HUD, health panel, range panel, or survival interface logic.
- Designed to stack with DAI main experiences and other DAI addons.

DAI 1.9.9 Integration
- Explicit addon role metadata.
- Stable pack identity: dai_damage_indicators.
- Managed pack version: 1.4.
- Compatible with DAI 1.9.9 global addon discovery/version synchronization.

Behavior
- Resource-pack independent.
- Large readable damage values.
- ~3.5 second lifetime with gentle upward movement.
- Enable/disable preference now survives /reload and reconnects.
- Existing v1.3 users remain enabled by default unless they disable the addon.

Commands
/function dai_damage_indicators:toggle
/function dai_damage_indicators:enable
/function dai_damage_indicators:disable
