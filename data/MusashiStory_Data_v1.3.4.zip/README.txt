Musashi Story Data v1.3.2
DAI 3.1 idle blade stance refinement release.
- Existing worlds migrate in place.
- Adds the v1.3.2 modernization marker.
- Companion resource pack updates selected idle sword presentation.
