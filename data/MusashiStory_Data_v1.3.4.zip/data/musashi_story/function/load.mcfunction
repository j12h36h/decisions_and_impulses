# Musashi Story v1.3.3 load — DAI 3.1 idle sword stance micro-adjustment migration.
function musashi_story:bootstrap/ensure

# Reset transient runtime clocks on reload without touching player/world progression.
scoreboard players set #tick ms_world 0
scoreboard players set #anim ms_world 0
scoreboard players set #player_clock ms_world 0
scoreboard players set #resolve_clock ms_world 0
scoreboard players set #hud_clock ms_world 0
scoreboard players set #visual_clock ms_world 0
scoreboard players set #ensure_clock ms_world 0
scoreboard players set #safety_clock ms_world 0
scoreboard players set #spawn_clock ms_world 0
scoreboard players set #gen_cadence ms_world 0

# Existing-world migrations run once on load, never as permanent per-tick checks.
execute if score #built ms_world matches 1 unless score #quality_v050 ms_world matches 1 run function musashi_story:worldgen/quality_pass
execute if score #built ms_world matches 1 unless score #modern_v120 ms_world matches 1 run function musashi_story:worldgen/repair/v120
execute if score #built ms_world matches 1 unless score #modern_v130 ms_world matches 1 run function musashi_story:worldgen/repair/v130
execute if score #built ms_world matches 1 unless score #modern_v131 ms_world matches 1 run function musashi_story:worldgen/repair/v131
execute if score #built ms_world matches 1 unless score #modern_v132 ms_world matches 1 run function musashi_story:worldgen/repair/v132
execute if score #built ms_world matches 1 unless score #modern_v133 ms_world matches 1 run function musashi_story:worldgen/repair/v133
execute if score #built ms_world matches 1 unless score #modern_v134 ms_world matches 1 run function musashi_story:worldgen/repair/v134
