# Musashi Story global tick — v1.3.1 DAI 3.1 polished runtime.
scoreboard players add #tick ms_world 1
scoreboard players add #anim ms_world 1
scoreboard players add #player_clock ms_world 1
scoreboard players add #resolve_clock ms_world 1
scoreboard players add #hud_clock ms_world 1
scoreboard players add #visual_clock ms_world 1
scoreboard players add #ensure_clock ms_world 1
scoreboard players add #safety_clock ms_world 1
scoreboard players add #spawn_clock ms_world 1
scoreboard players add #gen_cadence ms_world 1

execute if score #region_cd ms_world matches 1.. run scoreboard players remove #region_cd ms_world 1
execute if score #anim ms_world matches 20.. run scoreboard players set #anim ms_world 0

# First-world province construction: one optimized batch every two ticks to reduce chunk/save spikes.
execute if score #gen_active ms_world matches 1 if score #gen_cadence ms_world matches 2.. run function musashi_story:worldgen/base/pulse
execute if score #gen_cadence ms_world matches 2.. run scoreboard players set #gen_cadence ms_world 0

# Responsive gameplay and exact DeathTime reward capture.
execute if score #built ms_world matches 1 run function musashi_story:enemy/death_scan
# visual_animate is edge-triggered internally: two transformation keyframes per second, not repeated per-tick merges.
execute if score #built ms_world matches 1 run function musashi_story:enemy/visual_animate

# Player proximity/rank work: 4 TPS. Void recovery shares this cadence.
execute if score #built ms_world matches 1 if score #player_clock ms_world matches 5.. as @a[tag=ms_player] at @s run function musashi_story:player/tick
execute if score #built ms_world matches 1 if score #player_clock ms_world matches 5.. as @a[tag=ms_player,y=-128,dy=64] run function musashi_story:journey/recover
execute if score #player_clock ms_world matches 5.. run scoreboard players set #player_clock ms_world 0

# Resolve regeneration: true 2 TPS cadence instead of the old threshold leaking into every later tick.
execute if score #built ms_world matches 1 if score #resolve_clock ms_world matches 10.. as @a[tag=ms_player] if score @s ms_resolve matches ..99 run scoreboard players add @s ms_resolve 1
execute if score #resolve_clock ms_world matches 10.. run scoreboard players set #resolve_clock ms_world 0

# HUD + lazy region discovery: 1 TPS.
execute if score #built ms_world matches 1 if score #hud_clock ms_world matches 20.. as @a[tag=ms_player] run function musashi_story:player/hud
execute if score #built ms_world matches 1 if score #hud_clock ms_world matches 20.. as @a[tag=ms_player] at @s run function musashi_story:worldgen/regions/pulse
execute if score #hud_clock ms_world matches 20.. run scoreboard players set #hud_clock ms_world 0

# Enemy maintenance uses staggered cadences; only interpolation/animation stays responsive.
execute if score #built ms_world matches 1 if score #safety_clock ms_world matches 10.. run function musashi_story:enemy/safety
execute if score #safety_clock ms_world matches 10.. run scoreboard players set #safety_clock ms_world 0
execute if score #built ms_world matches 1 if score #visual_clock ms_world matches 2.. run function musashi_story:enemy/visual_follow
execute if score #visual_clock ms_world matches 2.. run scoreboard players set #visual_clock ms_world 0
execute if score #built ms_world matches 1 if score #ensure_clock ms_world matches 20.. run function musashi_story:enemy/visual_ensure
execute if score #built ms_world matches 1 if score #ensure_clock ms_world matches 20.. run function musashi_story:enemy/visual_cleanup
execute if score #ensure_clock ms_world matches 20.. run scoreboard players set #ensure_clock ms_world 0

# Spawn maintenance: 0.2 TPS / every five seconds.
execute if score #built ms_world matches 1 if score #spawn_clock ms_world matches 100.. run function musashi_story:enemy/spawn_cycle
execute if score #spawn_clock ms_world matches 100.. run scoreboard players set #spawn_clock ms_world 0

# Keep legacy #tick bounded for functions/debug output that inspect it.
execute if score #tick ms_world matches 100.. run scoreboard players set #tick ms_world 0
