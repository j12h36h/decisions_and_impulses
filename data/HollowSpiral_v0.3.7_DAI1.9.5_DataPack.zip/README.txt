HOLLOW SPIRAL v0.3.7

Endless survival room-grid experience for DAI 1.9.5 / Minecraft 26.2.

DAI 1.9.5 INTEGRATION
- Declares Hollow Spiral explicitly as the MAIN DAI experience.
- New expeditions use DAI 1.9.5 high-level world_type = void generation instead of the generic Minecraft flat preset.
- The companion HollowSpire resource pack can now be discovered and auto-managed through its stable hollow_spire companion identity.
- Existing Hollow Spiral saves keep their original save_id and persistent dungeon state.

GAMEPLAY RETAINED
This revision keeps the v0.3.6 vertical stair fixes, Ocean pressure-shell protection, structural Coral Grotto, Castle defender rolls, stable Fungal Bogs, Smithery containment, structural Flooded Ruins, floor-is-lava Volcano traversal, Tiny Villages and siege-damaged masonry Ruins.

Hollow Spiral intentionally remains in VANILLA MOB MODE. Room encounters use ordinary minecraft:* entities; DAI 1.9.5 native custom entities are not forced into this experience.

Use with HollowSpire v0.1.2 DAI 1.9.5 ResourcePack for the current visual stage.
