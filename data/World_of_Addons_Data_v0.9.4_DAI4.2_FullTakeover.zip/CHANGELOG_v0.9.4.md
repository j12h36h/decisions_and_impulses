# World of Addons Data v0.9.4 — DAI 4.2

- Corrected the full-takeover pause-menu navigation hierarchy.
- Renamed **RETURN TO DAI UNIVERSE** to **RETURN TO TITLE SCREEN**.
- The button now uses DAI 4.2 `return_to_experience_title`.
- Saving/disconnect returns to the World of Addons title shell while preserving WoA shell ownership.
- Returning to DAI Universe remains a separate action intended for the World of Addons title shell, not the gameplay pause menu.
- Removed the old kick/close-screen workaround completely.
- Existing gameplay, worldgen, champion state, authority rules, presentation takeover and resource identifiers are unchanged.
