# World of Addons — Recognized Champion Registry

World of Addons v0.5.0 is standalone. The built-in **Rift Minion** is always available and is the default pre-lobby selection.

Addon champions are surfaced only when World of Addons explicitly recognizes their stable DAI content identity. Unknown addons are not inserted into Champion Select automatically.

## Recognized in v0.5.0

| Champion | Recognition check | Optional loadout hook |
|---|---|---|
| Kitty Claws | `blink_daggers:kitty_dagger` + `blink_daggers:kitty_ultimate` | `blink_daggers:give` |
| Echo Anomaly | `dai_time_reverse:temporal_recall` + `dai_time_reverse:reversal_field` | `dai_time_reverse:starter/give` |

The menu uses DAI 4.1 `content_exists` conditions, so absent addons do not create buttons and do not become dependencies. Loadouts are invoked through optional function tags, so missing addon namespaces do not break standalone loading.

Kitty's Dagger v0.8.0 and EchoTime v1.4.0 preserve these stable content/function identities, so their DAI 4.1 compatibility passes remain compatible with this registry without version-specific checks.
