# World of Addons v0.5.0 — Experience UI + Rift Structure Cleanup

## Experience-owned UI loop
- Replaced the active grave-key DAI menu path with a World of Addons-owned `dai_screens` League Menu.
- Added custom Champion Select, Rune Loadout, Shop, Match Status and Rift Pause screens.
- First-join Champion Select now routes into the custom screen automatically.
- Added DAI 4.0 `screen_overrides` for both `DAI_GameMenuScreen` and vanilla `PauseScreen` while the World of Addons datapack is active.
- Added a custom Return to DAI Universe path from the Rift pause screen.
- Preserved DAI title/loading ownership and safe Engine fallbacks outside the active Experience.
- Preserved legacy menu IDs as compatibility entry points; their actions now route into the custom screens.
- Added `content_exists` gates directly to Kitty Claws and Echo Anomaly selection actions so custom-screen buttons cannot select missing addon kits.

## Resource-pack lifecycle contract
- Added explicit `branding.companion_id: world_of_addons` to the Experience.
- Keeps the stable companion identity used by DAI 4.0's pre-world live resource-pack activation barrier.

## Map cleanup
- Rebuilt the Mammal Ecosystem rectangle into an alpine sanctuary ruin with an irregular spring, broken arcade, side fragments and stepping stones.
- Rebuilt the Reptilian Habitat rectangle into a drowned Everglades ruin with mud shelves, open gate fragments, water court and rubble.
- Replaced thirty long 5-block-high mossy wall cuboids with thin traversable ruins containing gaps, gates, broken heights and collapsed stone.
- Added `worldgen/v050/repair` as a one-time in-place migration for existing worlds.
- New world generation runs the same v0.5 cleanup stage immediately before finish.
- Added `#map_rev` migration guarding so the repair has zero recurring tick cost.

## Preserved
- Stable Experience/worldgen/save IDs.
- Three-lane match layout and bases.
- Native minions/towers, economy, runes and recognized addon roster.
- v0.4 DAI 4.0 runtime efficiency improvements.
- Standalone datapack operation without a Resource Pack.
