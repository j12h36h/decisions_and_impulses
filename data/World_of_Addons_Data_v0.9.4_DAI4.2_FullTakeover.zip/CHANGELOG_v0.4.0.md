# World of Addons v0.4.0 — DAI 4.0 Compatibility + Capability / Efficiency Pass

## DAI 4.0
- Updated MAIN Experience metadata, branding, documentation, and visible versioning for **DAI Engine 4.0**.
- Preserved the stable Experience identity `world_of_addons:world_of_addons`, worldgen identity, save ownership, title-screen definition, and all existing World of Addons function/content IDs.
- Preserved DAI-owned custom loading presentation, title-screen save browser, and direct grave-key League Menu routing.
- Preserved standalone operation with no Resource Pack and no required champion addon.
- Preserved the explicit recognized-addon roster model rather than making arbitrary installed addons playable automatically.
- Verified the existing Kitty Claws and Echo Anomaly recognition contracts against the stable DAI 4.0 content/function identities retained by Kitty's Dagger and EchoTime.

## Runtime Efficiency
- Replaced the 20 TPS Champion Select ready-gate poll with an immediate lock-in check plus a 10-tick disconnect/reconnect fallback.
- Moved the repeated map-building actionbar refresh from 20 TPS to the shared 10-tick cadence.
- Consolidated tower cooldown, target/fire, and destruction maintenance behind one `@e[tag=woa_tower]` selection per 10-tick pass using `runtime/tower_tick`.
- Skips the active minion dispatcher when no `woa_minion` entities exist, while preserving full 20 TPS minion simulation whenever minions are present.
- Kept match countdown timing, active minion movement/combat, wave timing, rune refresh cadence, shop behavior, and HUD behavior intact.

## Compatibility
- Existing v0.3.x worlds require no reset.
- Existing teams, scoreboards, character tags, gold, rune state, match state, native minion definitions, optional function tags, and stable addon hooks remain unchanged.
- Data Pack format remains 107.1 for Minecraft 26.2.

