# World of Addons v0.5.0 — Rift Layout

## Core orientation

- Blue Base / Nexus: southwest near `(-176, 176)`
- Red Base / Nexus: northeast near `(176, -176)`
- Mid / river transition: `(0, 0)`
- Mammal Ecosystem: northwest/top-side objective region near `(-72, -64)`
- Reptilian Habitat: southeast/bottom-side objective region near `(72, 64)`
- World border: 500 blocks

## Vertical ecology

**Top / Mammal side:** naturally banded mountain terrain reaching roughly Y 70–88, spruce/pine forest, exposed stone/podzol, scenic alpine village, and climbable waterfall terraces descending into Mid.

**Mid:** neutral elevation anchor around Y 64–68 and the ecosystem transition.

**Bottom / Reptilian side:** gradually lowered Y 58–63 basin with mud/clay, shallow swamp channels, mangrove trees/roots, and Everglades-style lowland scenery.

## Brush

Brush is represented by collisionless vanilla-leaf `block_display` clusters rather than solid leaf blocks. Players can physically walk into the volume. Vision concealment logic is intentionally reserved for a later gameplay pass.

## Match flow

World generation → Champion Select → all active players lock → 5-second countdown → fountain spawn/loadout hooks → active match → 30-second first-wave timer.


## v0.5 ruin cleanup

The old broad filled-wall placeholders have been retired.

- The Mammal Ecosystem at roughly `(-72, -64)` is now a broken alpine sanctuary around a spring rather than a square platform with a solid wall.
- The Reptilian Habitat at roughly `(72, 64)` is now a drowned Everglades ruin with an open gate, water court and collapsed stone.
- Jungle lane separators are thin fragmented ruins with deliberate walk-through gaps and gate openings instead of 5-block-high solid cuboids.
- Existing v0.4.x worlds receive the same geometry in place through the guarded `worldgen/v050/repair` migration.
