# World of Addons — Data v0.9.4

Standalone **D.A.I. Engine 4.2 MAIN Experience** for Minecraft **26.2**. The datapack remains playable without a Resource Pack; the companion pack adds the full visual treatment.

World of Addons is a League-inspired DAI Experience with a generated Rift, Blue/Red teams, three lanes, native minions and towers, Champion Select, runes, shop economy, HUD, recognized addon champions, custom DAI screens and Experience-owned navigation.

## DAI 4.2 Experience UI

v0.5.0 moves the active match loop away from generic DAI menus and into World of Addons-owned screens:

- The grave/backtick key opens the **World of Addons League Menu** directly through `grave_open_action`.
- First-join Champion Select now opens as a custom `dai_screens` interface.
- Champion Select, Runes, Shop, Match Status and the in-world pause loop are World of Addons screens.
- The DAI and vanilla pause surfaces are replaced while this Experience is active.
- `ESC` opens the Rift pause screen, with Resume, League Menu, Champion, Rune, Shop, Status and Return-to-DAI controls.
- The existing DAI 4.2 loading/title Experience ownership remains intact.
- The resource companion supplies scene art for these screens; datapack gradient fallbacks keep every screen usable without it.

The UI loop is fully data-driven through DAI 4.2 `dai_screens`, `screen_overrides`, `scene_environments` and normal logic actions. Screen style is now authored explicitly in JSON instead of relying on the Engine fallback panel/frame defaults.

## Champion / Addon Loop

- **Rift Minion** remains the built-in champion and is always available.
- **Kitty Claws** recognizes Kitty's Dagger using the stable `blink_daggers:kitty_dagger` and `blink_daggers:kitty_ultimate` content IDs.
- **Echo Anomaly** recognizes EchoTime using `dai_time_reverse:temporal_recall` and `dai_time_reverse:reversal_field`.
- Addon champion actions now carry the same `content_exists` gates as the legacy menu buttons, preventing absent kits from being selected through the custom screen.
- Stable optional loadout hooks remain unchanged.

## Rift Map v0.5 Cleanup

The old large filled wall cuboids have been removed from the intended ruin zones.

- The Mammal Ecosystem and Reptilian Habitat rectangles are rebuilt as traversable ruined sanctuaries with water courts, broken facades, pillars, openings and stepping stones.
- Thirty long jungle wall cuboids are converted into thin fragmented ruins with gates, collapsed sections and rubble rather than solid 5-block-high barriers.
- Existing v0.4.x worlds migrate in place once through `worldgen/v050/repair`; a world reset is not required.
- New worlds run the same repair/build stage immediately before worldgen finishes, keeping old worldgen IDs and save compatibility.
- The migration is guarded by `#map_rev woa_world = 5`, so it does not repeat every load.

## Runtime Efficiency

The v0.4.0 runtime efficiency work remains intact:

- Ready-state fallback checks run at 10-tick cadence instead of every tick.
- Map-building actionbar refresh runs at 2 Hz.
- Tower maintenance uses the consolidated tower dispatcher.
- Minion dispatch is skipped when there are no active lane minions.
- Match-critical countdown and active minion simulation remain full-rate.

The v0.5 map repair is a one-time world migration and adds no recurring match-tick cost.

## DAI 4.2 Companion Identity

The Experience now explicitly advertises `branding.companion_id: world_of_addons`, matching the Resource Pack `dai.companion_id`. DAI can therefore activate the companion before entering the Rift and remove it after unloading the Experience.

## Compatibility

- Minecraft Java 26.2
- DAI Engine 4.2
- Data Pack format 107.1
- DAI role: `main`
- Stable Experience ID: `world_of_addons:world_of_addons`
- Stable save/worldgen identities preserved
- Existing v0.3.x / v0.4.x saves migrate without reset
- Resource Pack optional for gameplay; recommended for full UI/visual presentation

## v0.7.1 3D Experience Scenes

World of Addons now owns the complete presentation handoff when used with the DAI 4.2 scene/presentation runtime. The title, launch transition, world loading, first-entry fly-in, resume handoff and core UI surfaces all use World of Addons scene environments. Model-backed scenes use Minecraft block/item models after DAI's registry safety boundary; during unsafe registry bootstrap the Experience keeps its own resource-independent branded fallback instead of exposing the generic DAI universe.


## v0.8.0 — DAI 4.2 Compatibility

- Updated stable pack metadata to the DAI 4.2 `pack_id` + `version` convention while retaining the existing `world_of_addons` identity.
- Keeps the v0.7.1 server-authority capability declarations for player-triggered server functions.
- Explicitly authors each World of Addons data-screen frame/title/panel style in JSON so the Experience does not depend on an unreplaceable Engine visual default.
- Compatible with DAI 4.2 dedicated-server presentation synchronization for screens, screen overrides, scenes, logics and title definitions.
- Existing saves, teams, scoreboard state, worldgen state and champion integration IDs remain unchanged.


## v0.9.0 — Full Experience Replacement

World of Addons now owns the complete presentation loop after the Experience is selected: an authored Rift title screen, pack-owned safe/world-loading art, a first-entry splash cinematic, fullscreen Rift handoffs, custom League menus, custom pause flow, and the existing scene-driven Champion/Runes/Shop/Status surfaces. The global DAI shell remains untouched until World of Addons is selected, so installing WoA cannot visually hijack unrelated experiences.


## v0.9.2 — Full DAI 4.2 Shell Takeover

World of Addons now publishes a high-priority `dai_shell_presentations` definition. When installed as a DAI MAIN Experience, the DAI 4.2 boot shell resolves directly to the World of Addons Rift presentation instead of the generic DAI Engine universe title.

The takeover remains data-driven: the shell title, loading style, launch/world-loading scenes and return-to-shell route are all declared by JSON in this datapack.


## v0.9.2
Explicit shell-owner binding for the DAI 4.2 early-presentation hotfix.


## v0.9.3 — DAI 4.2 Universe Return

The Rift pause screen now uses the DAI 4.2 `return_to_dai_universe` client action.
It no longer attempts to kick the integrated-server player and then close the menu.

`RETURN TO DAI UNIVERSE` now performs a real world/session detach, temporarily
suspends World of Addons shell ownership, restores DAI's built-in Universe shell,
and removes the Experience-owned resource context during unload. Selecting World
of Addons again explicitly restores its full shell takeover.


## v0.9.4 — Correct Experience Return Hierarchy

The in-game pause menu now uses **RETURN TO TITLE SCREEN** and calls DAI 4.2 `return_to_experience_title`. This saves/leaves the active world and returns to the World of Addons title while keeping WoA's full-shell ownership active. Returning to DAI Universe is a separate higher-level navigation action.
