# Per-tower 10-tick maintenance. Executed as/at one woa_tower.
execute if score @s woa_tower_cd matches 1.. run scoreboard players remove @s woa_tower_cd 10
execute if entity @s[tag=woa_blue] if score @s woa_tower_cd matches ..0 if entity @e[tag=woa_minion,tag=woa_red,distance=..18,limit=1] run function world_of_addons:tower/fire_blue
execute if entity @s[tag=woa_red] if score @s woa_tower_cd matches ..0 if entity @e[tag=woa_minion,tag=woa_blue,distance=..18,limit=1] run function world_of_addons:tower/fire_red
execute if score @s woa_hp matches ..0 run function world_of_addons:tower/destroy
