# World of Addons v0.5.0 — shared 10-tick maintenance.

# Event-driven lock-in checks happen immediately from champion/lock; this is the
# disconnect/reconnect/state-correction fallback while Champion Select is active.
execute if score #phase woa_world matches 1 run function world_of_addons:champion/check_ready

function world_of_addons:rune/tick
function world_of_addons:ui/hud

# One tower selection replaces the previous cooldown/fire/destroy world scans.
execute as @e[tag=woa_tower] at @s run function world_of_addons:runtime/tower_tick
