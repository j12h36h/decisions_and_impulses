# World of Addons v0.5.0 pre-lobby preparation.
# The MAIN experience owns the match loadout: clear standalone/demo starter inventory first.
execute if score @s woa_locked matches 0 run clear @s
# Recognized addons may contribute optional state cleanup without becoming required dependencies.
execute if score @s woa_locked matches 0 run function #world_of_addons:characters/prepare_lobby
