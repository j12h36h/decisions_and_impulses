# Compatibility stub — DAI Engine 4.2+
# The pause-menu action is client-owned and now uses
# world_of_addons:leave_rift -> return_to_experience_title.
# No server-side world-exit command or close_screen fallback is used.
