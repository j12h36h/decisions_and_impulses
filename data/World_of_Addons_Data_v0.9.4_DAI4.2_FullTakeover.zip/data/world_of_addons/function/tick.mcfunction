# World of Addons v0.9.0 global tick — DAI 4.1.
scoreboard players add #tick woa_world 1

# New-player admission remains immediate.
execute as @a[tag=!woa_joined] run function world_of_addons:player/first_join

# Low-frequency presentation/runtime maintenance.
execute if score #tick woa_world matches 10.. if score #built woa_world matches 0 as @a run title @s actionbar {"text":"Building World of Addons map…","color":"aqua"}
execute if score #tick woa_world matches 10.. if score #built woa_world matches 1 run function world_of_addons:runtime/ten_tick

# Match-critical timing remains full-rate.
execute if score #phase woa_world matches 2 run function world_of_addons:match/countdown_tick
execute if score #phase woa_world matches 3 run function world_of_addons:match/tick

execute if score #tick woa_world matches 10.. run scoreboard players set #tick woa_world 0
