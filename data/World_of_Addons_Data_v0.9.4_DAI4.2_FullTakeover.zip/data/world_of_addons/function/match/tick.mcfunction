scoreboard players add #match_tick woa_world 1
execute if score #match_tick woa_world matches 600.. run function world_of_addons:minion/wave
execute if entity @e[tag=woa_minion,limit=1] run function world_of_addons:minion/tick
