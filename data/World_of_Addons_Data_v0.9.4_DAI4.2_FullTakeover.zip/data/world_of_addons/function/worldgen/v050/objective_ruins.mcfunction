# World of Addons v0.5.0 — rebuild the two objective rectangles as actual traversable ruins.

# Mammal Ecosystem / alpine sanctuary (-72,-64). Remove the old 37x37 slab + filled north wall.
fill -90 64 -82 -54 69 -46 minecraft:air
fill -90 64 -82 -54 64 -46 minecraft:grass_block
# Irregular moss apron and spring.
fill -85 64 -77 -59 64 -51 minecraft:moss_block
fill -82 63 -74 -62 63 -54 minecraft:gravel
fill -82 64 -74 -62 64 -54 minecraft:water
fill -77 64 -68 -67 64 -60 minecraft:mossy_cobblestone
fill -75 65 -67 -69 65 -61 minecraft:stone_bricks
# Broken north arcade.
fill -88 65 -80 -80 67 -79 minecraft:mossy_stone_bricks
fill -88 65 -81 -87 69 -79 minecraft:stone_bricks
fill -76 65 -80 -72 66 -79 minecraft:cracked_stone_bricks
fill -68 65 -80 -62 68 -79 minecraft:mossy_stone_bricks
fill -58 65 -80 -56 66 -79 minecraft:cracked_stone_bricks
# Side fragments and fallen blocks.
fill -87 65 -76 -86 68 -69 minecraft:stone_bricks
fill -87 65 -60 -86 66 -54 minecraft:mossy_stone_bricks
fill -58 65 -72 -57 67 -65 minecraft:cracked_stone_bricks
setblock -83 65 -65 minecraft:mossy_cobblestone
setblock -82 65 -64 minecraft:cracked_stone_bricks
setblock -61 65 -59 minecraft:mossy_cobblestone
setblock -64 65 -76 minecraft:stone_bricks
# Open stepping stones through the spring.
setblock -79 64 -64 minecraft:stone_bricks
setblock -75 64 -64 minecraft:mossy_stone_bricks
setblock -71 64 -64 minecraft:cracked_stone_bricks
setblock -67 64 -64 minecraft:mossy_stone_bricks

# Reptilian Habitat / Everglades ruin (72,64). Remove the old slab + filled wall.
fill 54 64 46 90 69 82 minecraft:air
fill 54 64 46 90 64 82 minecraft:grass_block
# Mud/moss shelves around a shallow drowned court.
fill 58 64 50 86 64 78 minecraft:moss_block
fill 62 63 54 82 63 74 minecraft:mud
fill 62 64 54 82 64 74 minecraft:water
fill 67 64 59 77 64 69 minecraft:mossy_cobblestone
# Broken south-facing facade with a real central entrance.
fill 56 65 48 64 67 49 minecraft:mossy_stone_bricks
fill 56 65 48 57 69 50 minecraft:stone_bricks
fill 68 65 48 70 66 49 minecraft:cracked_stone_bricks
fill 76 65 48 84 68 49 minecraft:mossy_stone_bricks
fill 88 65 48 89 66 49 minecraft:cracked_stone_bricks
# Gate pillars + broken lintel.
fill 70 65 48 71 68 50 minecraft:stone_bricks
fill 75 65 48 76 68 50 minecraft:mossy_stone_bricks
fill 70 69 49 73 69 49 minecraft:cracked_stone_bricks
fill 75 69 49 76 69 49 minecraft:cracked_stone_bricks
# Side ruin fragments/rubble.
fill 58 65 53 59 67 61 minecraft:mossy_stone_bricks
fill 85 65 60 86 68 68 minecraft:stone_bricks
fill 58 65 71 59 66 76 minecraft:cracked_stone_bricks
setblock 64 65 53 minecraft:mossy_cobblestone
setblock 66 65 75 minecraft:cracked_stone_bricks
setblock 82 65 55 minecraft:mossy_cobblestone
setblock 84 65 72 minecraft:stone_bricks
# Stepping stones across the drowned court.
setblock 66 64 64 minecraft:mossy_stone_bricks
setblock 70 64 64 minecraft:cracked_stone_bricks
setblock 74 64 64 minecraft:mossy_stone_bricks
setblock 78 64 64 minecraft:stone_bricks
