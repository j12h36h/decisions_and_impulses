# World of Addons v0.5.0 — convert the old filled jungle wall cuboids into traversable ruined structures.
# Every old obstacle is cleared first, then rebuilt as thin broken stonework with gates, gaps and rubble.
# Ruin 1: replace solid X wall 139..167, -86..-80
fill 139 65 -86 167 69 -80 minecraft:air
fill 139 65 -84 146 65 -82 minecraft:mossy_cobblestone
fill 139 66 -83 146 67 -83 minecraft:mossy_stone_bricks
fill 140 68 -83 145 68 -83 minecraft:cracked_stone_bricks
fill 139 66 -84 140 67 -82 minecraft:stone_bricks
fill 160 65 -84 167 65 -82 minecraft:mossy_cobblestone
fill 160 66 -83 167 68 -83 minecraft:stone_bricks
fill 161 69 -83 166 69 -83 minecraft:cracked_stone_bricks
fill 160 66 -84 161 67 -82 minecraft:stone_bricks
fill 150 65 -84 150 68 -82 minecraft:mossy_stone_bricks
fill 150 69 -83 150 69 -83 minecraft:cracked_stone_bricks
fill 156 65 -84 156 68 -82 minecraft:mossy_stone_bricks
fill 156 69 -83 156 69 -83 minecraft:cracked_stone_bricks
fill 150 69 -83 156 69 -83 minecraft:stone_bricks
fill 151 65 -84 155 68 -82 minecraft:air
setblock 148 65 -85 minecraft:mossy_cobblestone
setblock 148 66 -85 minecraft:stone_bricks
setblock 150 65 -81 minecraft:cracked_stone_bricks
setblock 158 65 -81 minecraft:mossy_cobblestone
setblock 158 66 -81 minecraft:stone_bricks
setblock 156 65 -85 minecraft:cracked_stone_bricks
setblock 153 65 -82 minecraft:mossy_cobblestone

# Ruin 2: replace solid X wall 106..134, -68..-62
fill 106 65 -68 134 69 -62 minecraft:air
fill 106 65 -66 111 65 -64 minecraft:mossy_cobblestone
fill 106 66 -65 111 68 -65 minecraft:stone_bricks
fill 107 69 -65 110 69 -65 minecraft:cracked_stone_bricks
fill 106 66 -66 107 67 -64 minecraft:stone_bricks
fill 115 65 -66 120 65 -64 minecraft:mossy_cobblestone
fill 115 66 -65 120 66 -65 minecraft:mossy_stone_bricks
fill 115 66 -66 116 66 -64 minecraft:stone_bricks
fill 129 65 -66 134 65 -64 minecraft:mossy_cobblestone
fill 129 66 -65 134 67 -65 minecraft:stone_bricks
fill 130 68 -65 133 68 -65 minecraft:cracked_stone_bricks
fill 129 66 -66 130 67 -64 minecraft:stone_bricks
setblock 115 65 -67 minecraft:mossy_cobblestone
setblock 115 66 -67 minecraft:stone_bricks
setblock 117 65 -63 minecraft:cracked_stone_bricks
setblock 125 65 -63 minecraft:mossy_cobblestone
setblock 125 66 -63 minecraft:stone_bricks
setblock 123 65 -67 minecraft:cracked_stone_bricks
setblock 120 65 -64 minecraft:mossy_cobblestone

# Ruin 3: replace solid Z wall 76..84, -111..-78
fill 76 65 -111 84 69 -78 minecraft:air
fill 79 65 -111 81 65 -100 minecraft:mossy_cobblestone
fill 80 66 -111 80 68 -100 minecraft:mossy_stone_bricks
fill 80 69 -110 80 69 -101 minecraft:cracked_stone_bricks
fill 79 66 -111 81 67 -110 minecraft:stone_bricks
fill 79 65 -89 81 65 -78 minecraft:mossy_cobblestone
fill 80 66 -89 80 67 -78 minecraft:stone_bricks
fill 80 68 -88 80 68 -79 minecraft:cracked_stone_bricks
fill 79 66 -89 81 67 -88 minecraft:stone_bricks
fill 79 65 -92 81 68 -92 minecraft:mossy_stone_bricks
fill 80 69 -92 80 69 -92 minecraft:cracked_stone_bricks
fill 79 65 -86 81 68 -86 minecraft:mossy_stone_bricks
fill 80 69 -86 80 69 -86 minecraft:cracked_stone_bricks
fill 80 69 -92 80 69 -86 minecraft:stone_bricks
fill 79 65 -91 81 68 -87 minecraft:air
setblock 78 65 -100 minecraft:mossy_cobblestone
setblock 78 66 -100 minecraft:stone_bricks
setblock 82 65 -98 minecraft:cracked_stone_bricks
setblock 82 65 -89 minecraft:mossy_cobblestone
setblock 82 66 -89 minecraft:stone_bricks
setblock 78 65 -91 minecraft:cracked_stone_bricks
setblock 81 65 -94 minecraft:mossy_cobblestone

# Ruin 4: replace solid Z wall 29..37, -155..-120
fill 29 65 -155 37 69 -120 minecraft:air
fill 32 65 -155 34 65 -146 minecraft:mossy_cobblestone
fill 33 66 -155 33 67 -146 minecraft:stone_bricks
fill 33 68 -154 33 68 -147 minecraft:cracked_stone_bricks
fill 32 66 -155 34 67 -154 minecraft:stone_bricks
fill 32 65 -129 34 65 -120 minecraft:mossy_cobblestone
fill 33 66 -129 33 68 -120 minecraft:mossy_stone_bricks
fill 33 69 -128 33 69 -121 minecraft:cracked_stone_bricks
fill 32 66 -129 34 67 -128 minecraft:stone_bricks
fill 32 65 -140 34 68 -140 minecraft:mossy_stone_bricks
fill 33 69 -140 33 69 -140 minecraft:cracked_stone_bricks
fill 32 65 -134 34 68 -134 minecraft:mossy_stone_bricks
fill 33 69 -134 33 69 -134 minecraft:cracked_stone_bricks
fill 33 69 -140 33 69 -134 minecraft:stone_bricks
fill 32 65 -139 34 68 -135 minecraft:air
setblock 31 65 -143 minecraft:mossy_cobblestone
setblock 31 66 -143 minecraft:stone_bricks
setblock 35 65 -141 minecraft:cracked_stone_bricks
setblock 35 65 -131 minecraft:mossy_cobblestone
setblock 35 66 -131 minecraft:stone_bricks
setblock 31 65 -133 minecraft:cracked_stone_bricks
setblock 34 65 -137 minecraft:mossy_cobblestone

# Ruin 5: replace solid X wall 111..145, -125..-119
fill 111 65 -125 145 69 -119 minecraft:air
fill 111 65 -123 118 65 -121 minecraft:mossy_cobblestone
fill 111 66 -122 118 68 -122 minecraft:mossy_stone_bricks
fill 112 69 -122 117 69 -122 minecraft:cracked_stone_bricks
fill 111 66 -123 112 67 -121 minecraft:stone_bricks
fill 122 65 -123 129 65 -121 minecraft:mossy_cobblestone
fill 122 66 -122 129 66 -122 minecraft:stone_bricks
fill 122 66 -123 123 66 -121 minecraft:stone_bricks
fill 138 65 -123 145 65 -121 minecraft:mossy_cobblestone
fill 138 66 -122 145 67 -122 minecraft:mossy_stone_bricks
fill 139 68 -122 144 68 -122 minecraft:cracked_stone_bricks
fill 138 66 -123 139 67 -121 minecraft:stone_bricks
setblock 122 65 -124 minecraft:mossy_cobblestone
setblock 122 66 -124 minecraft:stone_bricks
setblock 124 65 -120 minecraft:cracked_stone_bricks
setblock 134 65 -120 minecraft:mossy_cobblestone
setblock 134 66 -120 minecraft:stone_bricks
setblock 132 65 -124 minecraft:cracked_stone_bricks
setblock 128 65 -121 minecraft:mossy_cobblestone

# Ruin 6: replace solid X wall 82..110, -151..-145
fill 82 65 -151 110 69 -145 minecraft:air
fill 82 65 -149 91 65 -147 minecraft:mossy_cobblestone
fill 82 66 -148 91 68 -148 minecraft:stone_bricks
fill 83 69 -148 90 69 -148 minecraft:cracked_stone_bricks
fill 82 66 -149 83 67 -147 minecraft:stone_bricks
fill 101 65 -149 110 65 -147 minecraft:mossy_cobblestone
fill 101 66 -148 110 67 -148 minecraft:mossy_stone_bricks
fill 102 68 -148 109 68 -148 minecraft:cracked_stone_bricks
fill 101 66 -149 102 67 -147 minecraft:stone_bricks
fill 98 65 -149 98 68 -147 minecraft:mossy_stone_bricks
fill 98 69 -148 98 69 -148 minecraft:cracked_stone_bricks
fill 104 65 -149 104 68 -147 minecraft:mossy_stone_bricks
fill 104 69 -148 104 69 -148 minecraft:cracked_stone_bricks
fill 98 69 -148 104 69 -148 minecraft:stone_bricks
fill 99 65 -149 103 68 -147 minecraft:air
setblock 91 65 -150 minecraft:mossy_cobblestone
setblock 91 66 -150 minecraft:stone_bricks
setblock 93 65 -146 minecraft:cracked_stone_bricks
setblock 101 65 -146 minecraft:mossy_cobblestone
setblock 101 66 -146 minecraft:stone_bricks
setblock 99 65 -150 minecraft:cracked_stone_bricks
setblock 96 65 -147 minecraft:mossy_cobblestone

# Ruin 7: replace solid Z wall 57..63, -181..-154
fill 57 65 -181 63 69 -154 minecraft:air
fill 59 65 -181 61 65 -174 minecraft:mossy_cobblestone
fill 60 66 -181 60 67 -174 minecraft:mossy_stone_bricks
fill 60 68 -180 60 68 -175 minecraft:cracked_stone_bricks
fill 59 66 -181 61 67 -180 minecraft:stone_bricks
fill 59 65 -161 61 65 -154 minecraft:mossy_cobblestone
fill 60 66 -161 60 68 -154 minecraft:stone_bricks
fill 60 69 -160 60 69 -155 minecraft:cracked_stone_bricks
fill 59 66 -161 61 67 -160 minecraft:stone_bricks
fill 59 65 -170 61 68 -170 minecraft:mossy_stone_bricks
fill 60 69 -170 60 69 -170 minecraft:cracked_stone_bricks
fill 59 65 -164 61 68 -164 minecraft:mossy_stone_bricks
fill 60 69 -164 60 69 -164 minecraft:cracked_stone_bricks
fill 60 69 -170 60 69 -164 minecraft:stone_bricks
fill 59 65 -169 61 68 -165 minecraft:air
setblock 58 65 -172 minecraft:mossy_cobblestone
setblock 58 66 -172 minecraft:stone_bricks
setblock 62 65 -170 minecraft:cracked_stone_bricks
setblock 62 65 -163 minecraft:mossy_cobblestone
setblock 62 66 -163 minecraft:stone_bricks
setblock 58 65 -165 minecraft:cracked_stone_bricks
setblock 61 65 -167 minecraft:mossy_cobblestone

# Ruin 8: replace solid X wall 103..128, -35..-29
fill 103 65 -35 128 69 -29 minecraft:air
fill 103 65 -33 108 65 -31 minecraft:mossy_cobblestone
fill 103 66 -32 108 68 -32 minecraft:stone_bricks
fill 104 69 -32 107 69 -32 minecraft:cracked_stone_bricks
fill 103 66 -33 104 67 -31 minecraft:stone_bricks
fill 111 65 -33 116 65 -31 minecraft:mossy_cobblestone
fill 111 66 -32 116 66 -32 minecraft:mossy_stone_bricks
fill 111 66 -33 112 66 -31 minecraft:stone_bricks
fill 123 65 -33 128 65 -31 minecraft:mossy_cobblestone
fill 123 66 -32 128 67 -32 minecraft:stone_bricks
fill 124 68 -32 127 68 -32 minecraft:cracked_stone_bricks
fill 123 66 -33 124 67 -31 minecraft:stone_bricks
setblock 111 65 -34 minecraft:mossy_cobblestone
setblock 111 66 -34 minecraft:stone_bricks
setblock 113 65 -30 minecraft:cracked_stone_bricks
setblock 120 65 -30 minecraft:mossy_cobblestone
setblock 120 66 -30 minecraft:stone_bricks
setblock 118 65 -34 minecraft:cracked_stone_bricks
setblock 116 65 -31 minecraft:mossy_cobblestone

# Ruin 9: replace solid X wall 42..70, -43..-37
fill 42 65 -43 70 69 -37 minecraft:air
fill 42 65 -41 51 65 -39 minecraft:mossy_cobblestone
fill 42 66 -40 51 68 -40 minecraft:mossy_stone_bricks
fill 43 69 -40 50 69 -40 minecraft:cracked_stone_bricks
fill 42 66 -41 43 67 -39 minecraft:stone_bricks
fill 61 65 -41 70 65 -39 minecraft:mossy_cobblestone
fill 61 66 -40 70 67 -40 minecraft:stone_bricks
fill 62 68 -40 69 68 -40 minecraft:cracked_stone_bricks
fill 61 66 -41 62 67 -39 minecraft:stone_bricks
fill 58 65 -41 58 68 -39 minecraft:mossy_stone_bricks
fill 58 69 -40 58 69 -40 minecraft:cracked_stone_bricks
fill 64 65 -41 64 68 -39 minecraft:mossy_stone_bricks
fill 64 69 -40 64 69 -40 minecraft:cracked_stone_bricks
fill 58 69 -40 64 69 -40 minecraft:stone_bricks
fill 59 65 -41 63 68 -39 minecraft:air
setblock 51 65 -42 minecraft:mossy_cobblestone
setblock 51 66 -42 minecraft:stone_bricks
setblock 53 65 -38 minecraft:cracked_stone_bricks
setblock 61 65 -38 minecraft:mossy_cobblestone
setblock 61 66 -38 minecraft:stone_bricks
setblock 59 65 -42 minecraft:cracked_stone_bricks
setblock 56 65 -39 minecraft:mossy_cobblestone

# Ruin 10: replace solid Z wall 19..25, -95..-67
fill 19 65 -95 25 69 -67 minecraft:air
fill 21 65 -95 23 65 -88 minecraft:mossy_cobblestone
fill 22 66 -95 22 67 -88 minecraft:stone_bricks
fill 22 68 -94 22 68 -89 minecraft:cracked_stone_bricks
fill 21 66 -95 23 67 -94 minecraft:stone_bricks
fill 21 65 -74 23 65 -67 minecraft:mossy_cobblestone
fill 22 66 -74 22 68 -67 minecraft:mossy_stone_bricks
fill 22 69 -73 22 69 -68 minecraft:cracked_stone_bricks
fill 21 66 -74 23 67 -73 minecraft:stone_bricks
fill 21 65 -84 23 68 -84 minecraft:mossy_stone_bricks
fill 22 69 -84 22 69 -84 minecraft:cracked_stone_bricks
fill 21 65 -78 23 68 -78 minecraft:mossy_stone_bricks
fill 22 69 -78 22 69 -78 minecraft:cracked_stone_bricks
fill 22 69 -84 22 69 -78 minecraft:stone_bricks
fill 21 65 -83 23 68 -79 minecraft:air
setblock 20 65 -86 minecraft:mossy_cobblestone
setblock 20 66 -86 minecraft:stone_bricks
setblock 24 65 -84 minecraft:cracked_stone_bricks
setblock 24 65 -76 minecraft:mossy_cobblestone
setblock 24 66 -76 minecraft:stone_bricks
setblock 20 65 -78 minecraft:cracked_stone_bricks
setblock 23 65 -81 minecraft:mossy_cobblestone

# Ruin 11: replace solid Z wall 149..155, -62..-38
fill 149 65 -62 155 69 -38 minecraft:air
fill 151 65 -62 153 65 -57 minecraft:mossy_cobblestone
fill 152 66 -62 152 68 -57 minecraft:mossy_stone_bricks
fill 152 69 -61 152 69 -58 minecraft:cracked_stone_bricks
fill 151 66 -62 153 67 -61 minecraft:stone_bricks
fill 151 65 -54 153 65 -49 minecraft:mossy_cobblestone
fill 152 66 -54 152 66 -49 minecraft:stone_bricks
fill 151 66 -54 153 66 -53 minecraft:stone_bricks
fill 151 65 -43 153 65 -38 minecraft:mossy_cobblestone
fill 152 66 -43 152 67 -38 minecraft:mossy_stone_bricks
fill 152 68 -42 152 68 -39 minecraft:cracked_stone_bricks
fill 151 66 -43 153 67 -42 minecraft:stone_bricks
setblock 150 65 -54 minecraft:mossy_cobblestone
setblock 150 66 -54 minecraft:stone_bricks
setblock 154 65 -52 minecraft:cracked_stone_bricks
setblock 154 65 -46 minecraft:mossy_cobblestone
setblock 154 66 -46 minecraft:stone_bricks
setblock 150 65 -48 minecraft:cracked_stone_bricks
setblock 153 65 -50 minecraft:mossy_cobblestone

# Ruin 12: replace solid X wall 66..92, -117..-111
fill 66 65 -117 92 69 -111 minecraft:air
fill 66 65 -115 75 65 -113 minecraft:mossy_cobblestone
fill 66 66 -114 75 68 -114 minecraft:stone_bricks
fill 67 69 -114 74 69 -114 minecraft:cracked_stone_bricks
fill 66 66 -115 67 67 -113 minecraft:stone_bricks
fill 83 65 -115 92 65 -113 minecraft:mossy_cobblestone
fill 83 66 -114 92 67 -114 minecraft:mossy_stone_bricks
fill 84 68 -114 91 68 -114 minecraft:cracked_stone_bricks
fill 83 66 -115 84 67 -113 minecraft:stone_bricks
fill 81 65 -115 81 68 -113 minecraft:mossy_stone_bricks
fill 81 69 -114 81 69 -114 minecraft:cracked_stone_bricks
fill 87 65 -115 87 68 -113 minecraft:mossy_stone_bricks
fill 87 69 -114 87 69 -114 minecraft:cracked_stone_bricks
fill 81 69 -114 87 69 -114 minecraft:stone_bricks
fill 82 65 -115 86 68 -113 minecraft:air
setblock 75 65 -116 minecraft:mossy_cobblestone
setblock 75 66 -116 minecraft:stone_bricks
setblock 77 65 -112 minecraft:cracked_stone_bricks
setblock 84 65 -112 minecraft:mossy_cobblestone
setblock 84 66 -112 minecraft:stone_bricks
setblock 82 65 -116 minecraft:cracked_stone_bricks
setblock 79 65 -113 minecraft:mossy_cobblestone

# Ruin 13: replace solid X wall 20..42, -22..-16
fill 20 65 -22 42 69 -16 minecraft:air
fill 20 65 -20 25 65 -18 minecraft:mossy_cobblestone
fill 20 66 -19 25 67 -19 minecraft:mossy_stone_bricks
fill 21 68 -19 24 68 -19 minecraft:cracked_stone_bricks
fill 20 66 -20 21 67 -18 minecraft:stone_bricks
fill 36 65 -20 42 65 -18 minecraft:mossy_cobblestone
fill 36 66 -19 42 68 -19 minecraft:stone_bricks
fill 37 69 -19 41 69 -19 minecraft:cracked_stone_bricks
fill 36 66 -20 37 67 -18 minecraft:stone_bricks
fill 28 65 -20 28 68 -18 minecraft:mossy_stone_bricks
fill 28 69 -19 28 69 -19 minecraft:cracked_stone_bricks
fill 34 65 -20 34 68 -18 minecraft:mossy_stone_bricks
fill 34 69 -19 34 69 -19 minecraft:cracked_stone_bricks
fill 28 69 -19 34 69 -19 minecraft:stone_bricks
fill 29 65 -20 33 68 -18 minecraft:air
setblock 27 65 -21 minecraft:mossy_cobblestone
setblock 27 66 -21 minecraft:stone_bricks
setblock 29 65 -17 minecraft:cracked_stone_bricks
setblock 35 65 -17 minecraft:mossy_cobblestone
setblock 35 66 -17 minecraft:stone_bricks
setblock 33 65 -21 minecraft:cracked_stone_bricks

# Ruin 14: replace solid X wall -4..18, -101..-95
fill -4 65 -101 18 69 -95 minecraft:air
fill -4 65 -99 0 65 -97 minecraft:mossy_cobblestone
fill -4 66 -98 0 68 -98 minecraft:stone_bricks
fill -3 69 -98 -1 69 -98 minecraft:cracked_stone_bricks
fill -4 66 -99 -3 67 -97 minecraft:stone_bricks
fill 3 65 -99 7 65 -97 minecraft:mossy_cobblestone
fill 3 66 -98 7 66 -98 minecraft:mossy_stone_bricks
fill 3 66 -99 4 66 -97 minecraft:stone_bricks
fill 13 65 -99 18 65 -97 minecraft:mossy_cobblestone
fill 13 66 -98 18 67 -98 minecraft:stone_bricks
fill 14 68 -98 17 68 -98 minecraft:cracked_stone_bricks
fill 13 66 -99 14 67 -97 minecraft:stone_bricks
setblock 3 65 -100 minecraft:mossy_cobblestone
setblock 3 66 -100 minecraft:stone_bricks
setblock 5 65 -96 minecraft:cracked_stone_bricks
setblock 11 65 -96 minecraft:mossy_cobblestone
setblock 11 66 -96 minecraft:stone_bricks
setblock 9 65 -100 minecraft:cracked_stone_bricks

# Ruin 15: replace solid X wall 80..103, -175..-169
fill 80 65 -175 103 69 -169 minecraft:air
fill 80 65 -173 88 65 -171 minecraft:mossy_cobblestone
fill 80 66 -172 88 68 -172 minecraft:mossy_stone_bricks
fill 81 69 -172 87 69 -172 minecraft:cracked_stone_bricks
fill 80 66 -173 81 67 -171 minecraft:stone_bricks
fill 95 65 -173 103 65 -171 minecraft:mossy_cobblestone
fill 95 66 -172 103 67 -172 minecraft:stone_bricks
fill 96 68 -172 102 68 -172 minecraft:cracked_stone_bricks
fill 95 66 -173 96 67 -171 minecraft:stone_bricks
fill 93 65 -173 93 68 -171 minecraft:mossy_stone_bricks
fill 93 69 -172 93 69 -172 minecraft:cracked_stone_bricks
fill 99 65 -173 99 68 -171 minecraft:mossy_stone_bricks
fill 99 69 -172 99 69 -172 minecraft:cracked_stone_bricks
fill 93 69 -172 99 69 -172 minecraft:stone_bricks
fill 94 65 -173 98 68 -171 minecraft:air
setblock 88 65 -174 minecraft:mossy_cobblestone
setblock 88 66 -174 minecraft:stone_bricks
setblock 90 65 -170 minecraft:cracked_stone_bricks
setblock 96 65 -170 minecraft:mossy_cobblestone
setblock 96 66 -170 minecraft:stone_bricks
setblock 94 65 -174 minecraft:cracked_stone_bricks
setblock 92 65 -171 minecraft:mossy_cobblestone

# Ruin 16: replace solid X wall -167..-139, 80..86
fill -167 65 80 -139 69 86 minecraft:air
fill -167 65 82 -160 65 84 minecraft:mossy_cobblestone
fill -167 66 83 -160 67 83 minecraft:stone_bricks
fill -166 68 83 -161 68 83 minecraft:cracked_stone_bricks
fill -167 66 82 -166 67 84 minecraft:stone_bricks
fill -146 65 82 -139 65 84 minecraft:mossy_cobblestone
fill -146 66 83 -139 68 83 minecraft:mossy_stone_bricks
fill -145 69 83 -140 69 83 minecraft:cracked_stone_bricks
fill -146 66 82 -145 67 84 minecraft:stone_bricks
fill -156 65 82 -156 68 84 minecraft:mossy_stone_bricks
fill -156 69 83 -156 69 83 minecraft:cracked_stone_bricks
fill -150 65 82 -150 68 84 minecraft:mossy_stone_bricks
fill -150 69 83 -150 69 83 minecraft:cracked_stone_bricks
fill -156 69 83 -150 69 83 minecraft:stone_bricks
fill -155 65 82 -151 68 84 minecraft:air
setblock -158 65 81 minecraft:mossy_cobblestone
setblock -158 66 81 minecraft:stone_bricks
setblock -156 65 85 minecraft:cracked_stone_bricks
setblock -148 65 85 minecraft:mossy_cobblestone
setblock -148 66 85 minecraft:stone_bricks
setblock -150 65 81 minecraft:cracked_stone_bricks
setblock -153 65 84 minecraft:mossy_cobblestone

# Ruin 17: replace solid X wall -134..-106, 62..68
fill -134 65 62 -106 69 68 minecraft:air
fill -134 65 64 -129 65 66 minecraft:mossy_cobblestone
fill -134 66 65 -129 68 65 minecraft:mossy_stone_bricks
fill -133 69 65 -130 69 65 minecraft:cracked_stone_bricks
fill -134 66 64 -133 67 66 minecraft:stone_bricks
fill -125 65 64 -120 65 66 minecraft:mossy_cobblestone
fill -125 66 65 -120 66 65 minecraft:stone_bricks
fill -125 66 64 -124 66 66 minecraft:stone_bricks
fill -111 65 64 -106 65 66 minecraft:mossy_cobblestone
fill -111 66 65 -106 67 65 minecraft:mossy_stone_bricks
fill -110 68 65 -107 68 65 minecraft:cracked_stone_bricks
fill -111 66 64 -110 67 66 minecraft:stone_bricks
setblock -125 65 63 minecraft:mossy_cobblestone
setblock -125 66 63 minecraft:stone_bricks
setblock -123 65 67 minecraft:cracked_stone_bricks
setblock -115 65 67 minecraft:mossy_cobblestone
setblock -115 66 67 minecraft:stone_bricks
setblock -117 65 63 minecraft:cracked_stone_bricks
setblock -120 65 66 minecraft:mossy_cobblestone

# Ruin 18: replace solid Z wall -84..-76, 78..111
fill -84 65 78 -76 69 111 minecraft:air
fill -81 65 78 -79 65 89 minecraft:mossy_cobblestone
fill -80 66 78 -80 68 89 minecraft:stone_bricks
fill -80 69 79 -80 69 88 minecraft:cracked_stone_bricks
fill -81 66 78 -79 67 79 minecraft:stone_bricks
fill -81 65 100 -79 65 111 minecraft:mossy_cobblestone
fill -80 66 100 -80 67 111 minecraft:mossy_stone_bricks
fill -80 68 101 -80 68 110 minecraft:cracked_stone_bricks
fill -81 66 100 -79 67 101 minecraft:stone_bricks
fill -81 65 97 -79 68 97 minecraft:mossy_stone_bricks
fill -80 69 97 -80 69 97 minecraft:cracked_stone_bricks
fill -81 65 103 -79 68 103 minecraft:mossy_stone_bricks
fill -80 69 103 -80 69 103 minecraft:cracked_stone_bricks
fill -80 69 97 -80 69 103 minecraft:stone_bricks
fill -81 65 98 -79 68 102 minecraft:air
setblock -82 65 89 minecraft:mossy_cobblestone
setblock -82 66 89 minecraft:stone_bricks
setblock -78 65 91 minecraft:cracked_stone_bricks
setblock -78 65 100 minecraft:mossy_cobblestone
setblock -78 66 100 minecraft:stone_bricks
setblock -82 65 98 minecraft:cracked_stone_bricks
setblock -79 65 95 minecraft:mossy_cobblestone

# Ruin 19: replace solid Z wall -37..-29, 120..155
fill -37 65 120 -29 69 155 minecraft:air
fill -34 65 120 -32 65 129 minecraft:mossy_cobblestone
fill -33 66 120 -33 67 129 minecraft:mossy_stone_bricks
fill -33 68 121 -33 68 128 minecraft:cracked_stone_bricks
fill -34 66 120 -32 67 121 minecraft:stone_bricks
fill -34 65 146 -32 65 155 minecraft:mossy_cobblestone
fill -33 66 146 -33 68 155 minecraft:stone_bricks
fill -33 69 147 -33 69 154 minecraft:cracked_stone_bricks
fill -34 66 146 -32 67 147 minecraft:stone_bricks
fill -34 65 135 -32 68 135 minecraft:mossy_stone_bricks
fill -33 69 135 -33 69 135 minecraft:cracked_stone_bricks
fill -34 65 141 -32 68 141 minecraft:mossy_stone_bricks
fill -33 69 141 -33 69 141 minecraft:cracked_stone_bricks
fill -33 69 135 -33 69 141 minecraft:stone_bricks
fill -34 65 136 -32 68 140 minecraft:air
setblock -35 65 132 minecraft:mossy_cobblestone
setblock -35 66 132 minecraft:stone_bricks
setblock -31 65 134 minecraft:cracked_stone_bricks
setblock -31 65 144 minecraft:mossy_cobblestone
setblock -31 66 144 minecraft:stone_bricks
setblock -35 65 142 minecraft:cracked_stone_bricks
setblock -32 65 138 minecraft:mossy_cobblestone

# Ruin 20: replace solid X wall -145..-111, 119..125
fill -145 65 119 -111 69 125 minecraft:air
fill -145 65 121 -138 65 123 minecraft:mossy_cobblestone
fill -145 66 122 -138 68 122 minecraft:stone_bricks
fill -144 69 122 -139 69 122 minecraft:cracked_stone_bricks
fill -145 66 121 -144 67 123 minecraft:stone_bricks
fill -134 65 121 -127 65 123 minecraft:mossy_cobblestone
fill -134 66 122 -127 66 122 minecraft:mossy_stone_bricks
fill -134 66 121 -133 66 123 minecraft:stone_bricks
fill -118 65 121 -111 65 123 minecraft:mossy_cobblestone
fill -118 66 122 -111 67 122 minecraft:stone_bricks
fill -117 68 122 -112 68 122 minecraft:cracked_stone_bricks
fill -118 66 121 -117 67 123 minecraft:stone_bricks
setblock -134 65 120 minecraft:mossy_cobblestone
setblock -134 66 120 minecraft:stone_bricks
setblock -132 65 124 minecraft:cracked_stone_bricks
setblock -122 65 124 minecraft:mossy_cobblestone
setblock -122 66 124 minecraft:stone_bricks
setblock -124 65 120 minecraft:cracked_stone_bricks
setblock -128 65 123 minecraft:mossy_cobblestone

# Ruin 21: replace solid X wall -110..-82, 145..151
fill -110 65 145 -82 69 151 minecraft:air
fill -110 65 147 -101 65 149 minecraft:mossy_cobblestone
fill -110 66 148 -101 68 148 minecraft:mossy_stone_bricks
fill -109 69 148 -102 69 148 minecraft:cracked_stone_bricks
fill -110 66 147 -109 67 149 minecraft:stone_bricks
fill -91 65 147 -82 65 149 minecraft:mossy_cobblestone
fill -91 66 148 -82 67 148 minecraft:stone_bricks
fill -90 68 148 -83 68 148 minecraft:cracked_stone_bricks
fill -91 66 147 -90 67 149 minecraft:stone_bricks
fill -94 65 147 -94 68 149 minecraft:mossy_stone_bricks
fill -94 69 148 -94 69 148 minecraft:cracked_stone_bricks
fill -88 65 147 -88 68 149 minecraft:mossy_stone_bricks
fill -88 69 148 -88 69 148 minecraft:cracked_stone_bricks
fill -94 69 148 -88 69 148 minecraft:stone_bricks
fill -93 65 147 -89 68 149 minecraft:air
setblock -101 65 146 minecraft:mossy_cobblestone
setblock -101 66 146 minecraft:stone_bricks
setblock -99 65 150 minecraft:cracked_stone_bricks
setblock -91 65 150 minecraft:mossy_cobblestone
setblock -91 66 150 minecraft:stone_bricks
setblock -93 65 146 minecraft:cracked_stone_bricks
setblock -96 65 149 minecraft:mossy_cobblestone

# Ruin 22: replace solid Z wall -63..-57, 154..181
fill -63 65 154 -57 69 181 minecraft:air
fill -61 65 154 -59 65 161 minecraft:mossy_cobblestone
fill -60 66 154 -60 67 161 minecraft:stone_bricks
fill -60 68 155 -60 68 160 minecraft:cracked_stone_bricks
fill -61 66 154 -59 67 155 minecraft:stone_bricks
fill -61 65 174 -59 65 181 minecraft:mossy_cobblestone
fill -60 66 174 -60 68 181 minecraft:mossy_stone_bricks
fill -60 69 175 -60 69 180 minecraft:cracked_stone_bricks
fill -61 66 174 -59 67 175 minecraft:stone_bricks
fill -61 65 165 -59 68 165 minecraft:mossy_stone_bricks
fill -60 69 165 -60 69 165 minecraft:cracked_stone_bricks
fill -61 65 171 -59 68 171 minecraft:mossy_stone_bricks
fill -60 69 171 -60 69 171 minecraft:cracked_stone_bricks
fill -60 69 165 -60 69 171 minecraft:stone_bricks
fill -61 65 166 -59 68 170 minecraft:air
setblock -62 65 163 minecraft:mossy_cobblestone
setblock -62 66 163 minecraft:stone_bricks
setblock -58 65 165 minecraft:cracked_stone_bricks
setblock -58 65 172 minecraft:mossy_cobblestone
setblock -58 66 172 minecraft:stone_bricks
setblock -62 65 170 minecraft:cracked_stone_bricks
setblock -59 65 168 minecraft:mossy_cobblestone

# Ruin 23: replace solid X wall -128..-103, 29..35
fill -128 65 29 -103 69 35 minecraft:air
fill -128 65 31 -123 65 33 minecraft:mossy_cobblestone
fill -128 66 32 -123 68 32 minecraft:mossy_stone_bricks
fill -127 69 32 -124 69 32 minecraft:cracked_stone_bricks
fill -128 66 31 -127 67 33 minecraft:stone_bricks
fill -120 65 31 -115 65 33 minecraft:mossy_cobblestone
fill -120 66 32 -115 66 32 minecraft:stone_bricks
fill -120 66 31 -119 66 33 minecraft:stone_bricks
fill -108 65 31 -103 65 33 minecraft:mossy_cobblestone
fill -108 66 32 -103 67 32 minecraft:mossy_stone_bricks
fill -107 68 32 -104 68 32 minecraft:cracked_stone_bricks
fill -108 66 31 -107 67 33 minecraft:stone_bricks
setblock -120 65 30 minecraft:mossy_cobblestone
setblock -120 66 30 minecraft:stone_bricks
setblock -118 65 34 minecraft:cracked_stone_bricks
setblock -111 65 34 minecraft:mossy_cobblestone
setblock -111 66 34 minecraft:stone_bricks
setblock -113 65 30 minecraft:cracked_stone_bricks
setblock -115 65 33 minecraft:mossy_cobblestone

# Ruin 24: replace solid X wall -70..-42, 37..43
fill -70 65 37 -42 69 43 minecraft:air
fill -70 65 39 -61 65 41 minecraft:mossy_cobblestone
fill -70 66 40 -61 68 40 minecraft:stone_bricks
fill -69 69 40 -62 69 40 minecraft:cracked_stone_bricks
fill -70 66 39 -69 67 41 minecraft:stone_bricks
fill -51 65 39 -42 65 41 minecraft:mossy_cobblestone
fill -51 66 40 -42 67 40 minecraft:mossy_stone_bricks
fill -50 68 40 -43 68 40 minecraft:cracked_stone_bricks
fill -51 66 39 -50 67 41 minecraft:stone_bricks
fill -54 65 39 -54 68 41 minecraft:mossy_stone_bricks
fill -54 69 40 -54 69 40 minecraft:cracked_stone_bricks
fill -48 65 39 -48 68 41 minecraft:mossy_stone_bricks
fill -48 69 40 -48 69 40 minecraft:cracked_stone_bricks
fill -54 69 40 -48 69 40 minecraft:stone_bricks
fill -53 65 39 -49 68 41 minecraft:air
setblock -61 65 38 minecraft:mossy_cobblestone
setblock -61 66 38 minecraft:stone_bricks
setblock -59 65 42 minecraft:cracked_stone_bricks
setblock -51 65 42 minecraft:mossy_cobblestone
setblock -51 66 42 minecraft:stone_bricks
setblock -53 65 38 minecraft:cracked_stone_bricks
setblock -56 65 41 minecraft:mossy_cobblestone

# Ruin 25: replace solid Z wall -25..-19, 67..95
fill -25 65 67 -19 69 95 minecraft:air
fill -23 65 67 -21 65 74 minecraft:mossy_cobblestone
fill -22 66 67 -22 67 74 minecraft:mossy_stone_bricks
fill -22 68 68 -22 68 73 minecraft:cracked_stone_bricks
fill -23 66 67 -21 67 68 minecraft:stone_bricks
fill -23 65 88 -21 65 95 minecraft:mossy_cobblestone
fill -22 66 88 -22 68 95 minecraft:stone_bricks
fill -22 69 89 -22 69 94 minecraft:cracked_stone_bricks
fill -23 66 88 -21 67 89 minecraft:stone_bricks
fill -23 65 78 -21 68 78 minecraft:mossy_stone_bricks
fill -22 69 78 -22 69 78 minecraft:cracked_stone_bricks
fill -23 65 84 -21 68 84 minecraft:mossy_stone_bricks
fill -22 69 84 -22 69 84 minecraft:cracked_stone_bricks
fill -22 69 78 -22 69 84 minecraft:stone_bricks
fill -23 65 79 -21 68 83 minecraft:air
setblock -24 65 76 minecraft:mossy_cobblestone
setblock -24 66 76 minecraft:stone_bricks
setblock -20 65 78 minecraft:cracked_stone_bricks
setblock -20 65 86 minecraft:mossy_cobblestone
setblock -20 66 86 minecraft:stone_bricks
setblock -24 65 84 minecraft:cracked_stone_bricks
setblock -21 65 81 minecraft:mossy_cobblestone

# Ruin 26: replace solid Z wall -155..-149, 38..62
fill -155 65 38 -149 69 62 minecraft:air
fill -153 65 38 -151 65 43 minecraft:mossy_cobblestone
fill -152 66 38 -152 68 43 minecraft:stone_bricks
fill -152 69 39 -152 69 42 minecraft:cracked_stone_bricks
fill -153 66 38 -151 67 39 minecraft:stone_bricks
fill -153 65 46 -151 65 51 minecraft:mossy_cobblestone
fill -152 66 46 -152 66 51 minecraft:mossy_stone_bricks
fill -153 66 46 -151 66 47 minecraft:stone_bricks
fill -153 65 57 -151 65 62 minecraft:mossy_cobblestone
fill -152 66 57 -152 67 62 minecraft:stone_bricks
fill -152 68 58 -152 68 61 minecraft:cracked_stone_bricks
fill -153 66 57 -151 67 58 minecraft:stone_bricks
setblock -154 65 46 minecraft:mossy_cobblestone
setblock -154 66 46 minecraft:stone_bricks
setblock -150 65 48 minecraft:cracked_stone_bricks
setblock -150 65 54 minecraft:mossy_cobblestone
setblock -150 66 54 minecraft:stone_bricks
setblock -154 65 52 minecraft:cracked_stone_bricks
setblock -151 65 50 minecraft:mossy_cobblestone

# Ruin 27: replace solid X wall -92..-66, 111..117
fill -92 65 111 -66 69 117 minecraft:air
fill -92 65 113 -83 65 115 minecraft:mossy_cobblestone
fill -92 66 114 -83 68 114 minecraft:mossy_stone_bricks
fill -91 69 114 -84 69 114 minecraft:cracked_stone_bricks
fill -92 66 113 -91 67 115 minecraft:stone_bricks
fill -75 65 113 -66 65 115 minecraft:mossy_cobblestone
fill -75 66 114 -66 67 114 minecraft:stone_bricks
fill -74 68 114 -67 68 114 minecraft:cracked_stone_bricks
fill -75 66 113 -74 67 115 minecraft:stone_bricks
fill -77 65 113 -77 68 115 minecraft:mossy_stone_bricks
fill -77 69 114 -77 69 114 minecraft:cracked_stone_bricks
fill -71 65 113 -71 68 115 minecraft:mossy_stone_bricks
fill -71 69 114 -71 69 114 minecraft:cracked_stone_bricks
fill -77 69 114 -71 69 114 minecraft:stone_bricks
fill -76 65 113 -72 68 115 minecraft:air
setblock -83 65 112 minecraft:mossy_cobblestone
setblock -83 66 112 minecraft:stone_bricks
setblock -81 65 116 minecraft:cracked_stone_bricks
setblock -74 65 116 minecraft:mossy_cobblestone
setblock -74 66 116 minecraft:stone_bricks
setblock -76 65 112 minecraft:cracked_stone_bricks
setblock -79 65 115 minecraft:mossy_cobblestone

# Ruin 28: replace solid X wall -42..-20, 16..22
fill -42 65 16 -20 69 22 minecraft:air
fill -42 65 18 -37 65 20 minecraft:mossy_cobblestone
fill -42 66 19 -37 67 19 minecraft:stone_bricks
fill -41 68 19 -38 68 19 minecraft:cracked_stone_bricks
fill -42 66 18 -41 67 20 minecraft:stone_bricks
fill -26 65 18 -20 65 20 minecraft:mossy_cobblestone
fill -26 66 19 -20 68 19 minecraft:mossy_stone_bricks
fill -25 69 19 -21 69 19 minecraft:cracked_stone_bricks
fill -26 66 18 -25 67 20 minecraft:stone_bricks
fill -34 65 18 -34 68 20 minecraft:mossy_stone_bricks
fill -34 69 19 -34 69 19 minecraft:cracked_stone_bricks
fill -28 65 18 -28 68 20 minecraft:mossy_stone_bricks
fill -28 69 19 -28 69 19 minecraft:cracked_stone_bricks
fill -34 69 19 -28 69 19 minecraft:stone_bricks
fill -33 65 18 -29 68 20 minecraft:air
setblock -35 65 17 minecraft:mossy_cobblestone
setblock -35 66 17 minecraft:stone_bricks
setblock -33 65 21 minecraft:cracked_stone_bricks
setblock -27 65 21 minecraft:mossy_cobblestone
setblock -27 66 21 minecraft:stone_bricks
setblock -29 65 17 minecraft:cracked_stone_bricks

# Ruin 29: replace solid X wall -18..4, 95..101
fill -18 65 95 4 69 101 minecraft:air
fill -18 65 97 -14 65 99 minecraft:mossy_cobblestone
fill -18 66 98 -14 68 98 minecraft:mossy_stone_bricks
fill -17 69 98 -15 69 98 minecraft:cracked_stone_bricks
fill -18 66 97 -17 67 99 minecraft:stone_bricks
fill -11 65 97 -7 65 99 minecraft:mossy_cobblestone
fill -11 66 98 -7 66 98 minecraft:stone_bricks
fill -11 66 97 -10 66 99 minecraft:stone_bricks
fill -1 65 97 4 65 99 minecraft:mossy_cobblestone
fill -1 66 98 4 67 98 minecraft:mossy_stone_bricks
fill 0 68 98 3 68 98 minecraft:cracked_stone_bricks
fill -1 66 97 0 67 99 minecraft:stone_bricks
setblock -11 65 96 minecraft:mossy_cobblestone
setblock -11 66 96 minecraft:stone_bricks
setblock -9 65 100 minecraft:cracked_stone_bricks
setblock -3 65 100 minecraft:mossy_cobblestone
setblock -3 66 100 minecraft:stone_bricks
setblock -5 65 96 minecraft:cracked_stone_bricks

# Ruin 30: replace solid X wall -103..-80, 169..175
fill -103 65 169 -80 69 175 minecraft:air
fill -103 65 171 -95 65 173 minecraft:mossy_cobblestone
fill -103 66 172 -95 68 172 minecraft:stone_bricks
fill -102 69 172 -96 69 172 minecraft:cracked_stone_bricks
fill -103 66 171 -102 67 173 minecraft:stone_bricks
fill -88 65 171 -80 65 173 minecraft:mossy_cobblestone
fill -88 66 172 -80 67 172 minecraft:mossy_stone_bricks
fill -87 68 172 -81 68 172 minecraft:cracked_stone_bricks
fill -88 66 171 -87 67 173 minecraft:stone_bricks
fill -90 65 171 -90 68 173 minecraft:mossy_stone_bricks
fill -90 69 172 -90 69 172 minecraft:cracked_stone_bricks
fill -84 65 171 -84 68 173 minecraft:mossy_stone_bricks
fill -84 69 172 -84 69 172 minecraft:cracked_stone_bricks
fill -90 69 172 -84 69 172 minecraft:stone_bricks
fill -89 65 171 -85 68 173 minecraft:air
setblock -95 65 170 minecraft:mossy_cobblestone
setblock -95 66 170 minecraft:stone_bricks
setblock -93 65 174 minecraft:cracked_stone_bricks
setblock -87 65 174 minecraft:mossy_cobblestone
setblock -87 66 174 minecraft:stone_bricks
setblock -89 65 170 minecraft:cracked_stone_bricks
setblock -91 65 173 minecraft:mossy_cobblestone
