# World of Addons v0.5.0 map repair / migration.
# Safe to run on both new generation and existing v0.4.x Rift saves.
function world_of_addons:worldgen/v050/objective_ruins
function world_of_addons:worldgen/v050/jungle_ruins
scoreboard players set #map_rev woa_world 5
execute if score #built woa_world matches 0 run bossbar set world_of_addons:generation value 99
execute if score #built woa_world matches 0 run schedule function world_of_addons:worldgen/finish 1t replace
execute if score #built woa_world matches 1 run tellraw @a [{"text":"World of Addons map upgraded: ","color":"gray"},{"text":"v0.5 ruin cleanup applied","color":"green"}]
