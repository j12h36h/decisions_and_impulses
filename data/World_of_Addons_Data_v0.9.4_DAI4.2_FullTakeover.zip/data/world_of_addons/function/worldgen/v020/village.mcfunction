# Scenic alpine ridge settlement — intentionally outside normal playable traversal.
fill -145 76 -145 -91 98 -145 minecraft:barrier
fill -145 76 -91 -91 98 -91 minecraft:barrier
fill -145 76 -145 -145 98 -91 minecraft:barrier
fill -91 76 -145 -91 98 -91 minecraft:barrier
execute positioned -124 85 -120 run function world_of_addons:worldgen/features/alpine_house
execute positioned -108 83 -127 run function world_of_addons:worldgen/features/alpine_house
execute positioned -132 82 -105 run function world_of_addons:worldgen/features/alpine_house
fill -139 82 -132 -95 82 -96 minecraft:dirt_path replace minecraft:grass_block
fill -138 83 -112 -129 83 -103 minecraft:farmland
fill -137 84 -111 -130 84 -104 minecraft:wheat[age=7]
fill -137 84 -107 -130 84 -107 minecraft:water
fill -140 83 -114 -127 84 -101 minecraft:spruce_fence outline
summon minecraft:villager -121 86 -119 {Tags:["woa_static","woa_scenery","woa_alpine_villager"],PersistenceRequired:1b,VillagerData:{profession:"minecraft:farmer",level:2,type:"minecraft:taiga"}}
summon minecraft:villager -111 84 -126 {Tags:["woa_static","woa_scenery","woa_alpine_villager"],PersistenceRequired:1b,VillagerData:{profession:"minecraft:toolsmith",level:2,type:"minecraft:taiga"}}
summon minecraft:villager -132 83 -106 {Tags:["woa_static","woa_scenery","woa_alpine_villager"],PersistenceRequired:1b,VillagerData:{profession:"minecraft:shepherd",level:2,type:"minecraft:taiga"}}
summon minecraft:goat -136 84 -116 {Tags:["woa_static","woa_scenery"],PersistenceRequired:1b}

# Distant Everglades stilt hamlet — visual world life, not a gameplay shortcut.
execute positioned 138 66 126 run function world_of_addons:worldgen/features/swamp_house
execute positioned 154 66 116 run function world_of_addons:worldgen/features/swamp_house
fill 130 61 108 162 61 136 minecraft:water
fill 130 60 108 162 60 136 minecraft:mud
fill 133 66 119 159 66 122 minecraft:mangrove_planks
summon minecraft:villager 138 67 126 {Tags:["woa_static","woa_scenery","woa_swamp_villager"],PersistenceRequired:1b,VillagerData:{profession:"minecraft:fisherman",level:2,type:"minecraft:swamp"}}
summon minecraft:villager 154 67 116 {Tags:["woa_static","woa_scenery","woa_swamp_villager"],PersistenceRequired:1b,VillagerData:{profession:"minecraft:farmer",level:2,type:"minecraft:swamp"}}
bossbar set world_of_addons:generation value 97
schedule function world_of_addons:worldgen/v050/repair 1t replace
