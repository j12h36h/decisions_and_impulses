# World of Addons Data v0.9.2 — DAI 4.1 Full Takeover Hotfix

- Explicitly binds the World of Addons shell presentation to
  `world_of_addons:world_of_addons` through the DAI 4.1 shell `experience` field.
- Works with the DAI Engine 4.1 Full Datapack Takeover Hotfix so WoA's
  shell-owned data screen, scenes, client actions and loading branding are
  available before a gameplay world is active.
- Keeps the v0.9.1 priority-50000 application-shell takeover.
- Preserves all Rift gameplay, save/worldgen identities, authority rules,
  menus, splash cinematic, loading art and resource companion identity.
