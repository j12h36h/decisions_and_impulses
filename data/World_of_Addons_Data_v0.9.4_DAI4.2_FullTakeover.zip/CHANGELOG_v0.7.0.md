# World of Addons v0.7.0 — Full 3D Experience Scene Pass

- Added Experience-owned `launch_transition` and `world_loading` scene hooks for the DAI 4.0 scene-ownership patch.
- Replaced the flat World of Addons title background with an animated 3D Rift overview.
- Added animated 3D Rift launch and world-loading scenes so the Experience no longer visually falls back to DAI's generic universe implosion after registry models are available.
- Added a first-join 3D Rift fly-in before Champion Select.
- Added a shorter 3D Rift-return scene when continuing an existing save.
- Rebuilt Champion Select, Runes, Shop, League Hub, Match Status and Pause scene environments with actual projected block/item models and animated cameras.
- Kept the complete scene set in the datapack and mirrored it into the Resource Pack, preserving data-only fallback while allowing the companion pack to visually override scenes.
- Preserved existing worldgen, champion, rune, shop, minion, tower and migration logic.
