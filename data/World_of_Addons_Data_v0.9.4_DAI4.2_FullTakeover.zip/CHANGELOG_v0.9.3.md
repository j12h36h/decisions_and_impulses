# World of Addons Data v0.9.3 — DAI 4.2

- Updated the Experience target to DAI Engine 4.2.
- Replaced the old `server_run_function -> kick @s -> close_screen` Return-to-DAI workaround.
- `world_of_addons:leave_rift` now uses the DAI 4.2 engine action `return_to_dai_universe`.
- Return to DAI Universe now performs a clean client world/server detach instead of only closing the pause screen.
- DAI 4.2 temporarily suspends the World of Addons application-shell takeover after this action so the player actually reaches the generic DAI Universe.
- Selecting World of Addons again restores its shell ownership and full Experience presentation.
- Existing Rift gameplay, champion state, worldgen identity, full title/loading takeover, authority rules and companion resource assets are unchanged.
