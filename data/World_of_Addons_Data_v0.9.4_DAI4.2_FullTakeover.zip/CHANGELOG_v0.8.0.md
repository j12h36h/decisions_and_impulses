# World of Addons Data v0.8.0 — DAI 4.1 Compatibility

- Updated pack metadata to stable DAI 4.1 `pack_id` + `version` identity.
- Updated Experience branding/version text to DAI 4.1.
- Preserved the v0.7.1 server-authority capability model and replay-safe first-join behavior.
- Explicitly moved the remaining default data-screen panel/border/title presentation choices into each screen JSON.
- Ready for DAI 4.1 dedicated-server presentation sync without requiring WoA-specific client code.
- Preserved worldgen, save identity, scoreboard state, champion IDs, addon recognition contracts, match rules and map migrations.
