# World of Addons Data v0.7.1 — DAI 4 Authority Compatibility

- Declares exact client-callable server function capabilities in datapack action JSON.
- Replaces the client-originated raw `server_command` leave flow with a fixed datapack-owned function capability.
- Makes first-join initialization idempotent against replay.
- Keeps all World of Addons presentation/gameplay ownership in the datapack; no WoA-specific engine code is required.
