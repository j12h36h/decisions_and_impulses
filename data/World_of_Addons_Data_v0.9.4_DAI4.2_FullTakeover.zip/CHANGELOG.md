# Changelog

## v0.9.0 — Full DAI 4.1 Experience Replacement
- Upgraded the selected World of Addons title loop into a fully branded Experience presentation while keeping the global DAI shell untouched until World of Addons is actually selected.
- Added Experience-owned loading background/logo assets through DAI 4.1 branding fields for safe transition and world-loading phases.
- Added a five-second, input-locked World of Addons splash cinematic on first entry before the Rift onboarding sequence.
- Converted Rift entry/return handoff screens to fullscreen scene presentation with no default DAI frame or title chrome.
- Enhanced the World of Addons title definition with pack-owned logo decoration, updated Rift copy and distinct START/CONTINUE styling.
- Preserved all v0.8.0 server-authority protections, save/worldgen IDs, map migrations, champion IDs, addon recognition and match rules.
- Deliberately does not install a global `dai_shell_presentations` override; installing the pack alone therefore cannot hijack unrelated DAI experiences.
