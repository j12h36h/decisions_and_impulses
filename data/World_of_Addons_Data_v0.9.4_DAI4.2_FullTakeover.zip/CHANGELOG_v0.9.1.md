# World of Addons Data v0.9.1 — DAI 4.1 Full Shell Takeover

- Added a high-priority `dai_shell_presentations` definition so World of Addons actually owns the DAI 4.1 boot shell when this MAIN Experience is installed.
- Replaces the DAI Engine boot title with `world_of_addons:shell_title`.
- Routes return-to-shell back into the World of Addons title instead of the generic DAI Universe title.
- Brands the resource-safe early loading veil as **OPENING THE RIFT** with World of Addons colors.
- Routes launch-transition and world-loading scene ownership to the existing World of Addons scenes.
- Added a fullscreen World of Addons shell-title data screen backed by the Rift overview scene.
- Added JSON-only shell navigation actions for Experience launch/continue selection, Rift worlds, Library, Creator, Settings and System/Quit.
- Preserves the existing v0.9.0 first-entry splash cinematic, loading art, pause replacement, League menus, gameplay, authority rules, champion IDs, save identity and worldgen.
- No DAI Engine code changes are required; this patch uses the DAI 4.1 shell takeover capability already present in the engine.
