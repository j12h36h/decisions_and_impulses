# Compatibility wrapper retained for integrations that call the old function ID.
function dai_time_reverse:freeze/runtime_tick
