# EchoTime v1.4.0 — inlined Chrono Anchor maintenance.
# Keeping the hot-path state write here avoids one nested function dispatch per
# frozen entity per tick while preserving the public freeze/tick function ID.
execute unless score @s tr_freeze matches 1.. run function dai_time_reverse:freeze/stop
execute unless entity @s[tag=tr_chrono_frozen] run return 0

data merge entity @s {NoGravity:1b,Motion:[0.0d,0.0d,0.0d]}
execute if score @s tr_freeze_hasnoai matches 1 run data merge entity @s {NoAI:1b}
scoreboard players remove @s tr_freeze 1
execute if score @s tr_freeze matches ..0 run function dai_time_reverse:freeze/stop
