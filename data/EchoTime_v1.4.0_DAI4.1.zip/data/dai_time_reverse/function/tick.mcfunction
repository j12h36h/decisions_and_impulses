# EchoTime v1.4.0 — DAI 4.1 authority + efficiency runtime.
# One global player pass, one frozen-entity pass, a bounded 10 Hz history pass,
# and low-frequency compatibility maintenance.

# Consolidated per-player control / cooldown / migration runtime.
execute as @a at @s run function dai_time_reverse:internal/player_tick

# Chrono Anchor remains maintained at 20 TPS through one shared selection.
execute as @e[tag=tr_chrono_frozen] at @s run function dai_time_reverse:freeze/runtime_tick

# Bounded history / playback pass: once every 2 ticks (10 Hz).
scoreboard players add #sample tr_tmp 1
execute if score #sample tr_tmp matches 2.. run scoreboard players add #epoch tr_tmp 1
execute if score #sample tr_tmp matches 2.. run function dai_time_reverse:internal/sample_tick
execute if score #sample tr_tmp matches 2.. run scoreboard players set #sample tr_tmp 0

# Manual /trigger compatibility does not need three enable operations per player
# every tick. Refresh it once per second and immediately after each trigger use.
scoreboard players add #maintenance tr_tmp 1
execute if score #maintenance tr_tmp matches 20.. as @a run function dai_time_reverse:internal/maintenance_player
execute if score #maintenance tr_tmp matches 20.. run scoreboard players set #maintenance tr_tmp 0
