# EchoTime v1.4.0 release
# Minecraft Java 26.2 / Data Pack 107.1 / DAI 4.1
#
# v1.3 keeps the bounded 10 Hz temporal history engine while reducing command
# pressure around migrations, trigger maintenance, active rewind helper state,
# frozen-entity dispatch, and non-player history retention.

scoreboard objectives add tr_id dummy
scoreboard objectives add tr_eid dummy
scoreboard objectives add tr_owner dummy
scoreboard objectives add tr_age dummy
scoreboard objectives add tr_mode dummy
scoreboard objectives add tr_ticks dummy
scoreboard objectives add tr_rticks dummy
scoreboard objectives add tr_hp dummy
scoreboard objectives add tr_resumehp dummy
scoreboard objectives add tr_invul dummy
scoreboard objectives add tr_nograv dummy
scoreboard objectives add tr_noai dummy
scoreboard objectives add tr_tmp dummy
scoreboard objectives add tr_loop dummy
scoreboard objectives add tr_cdemg dummy
scoreboard objectives add tr_cdfull dummy
scoreboard objectives add tr_cdarea dummy
scoreboard objectives add tr_recstamp dummy
scoreboard objectives add tr_agestamp dummy
scoreboard objectives add tr_playstamp dummy
scoreboard objectives add tr_lock dummy
scoreboard objectives add tr_hold dummy
scoreboard objectives add tr_dry dummy
scoreboard objectives add tr_freeze dummy
scoreboard objectives add tr_freeze_noai dummy
scoreboard objectives add tr_freeze_nograv dummy
scoreboard objectives add tr_freeze_hasnoai dummy
scoreboard objectives add tr_emergency trigger
scoreboard objectives add tr_full trigger
scoreboard objectives add tr_area trigger

scoreboard players add #next_player tr_tmp 0
scoreboard players add #next_entity tr_tmp 0
scoreboard players set #sample tr_tmp 0
scoreboard players set #epoch tr_tmp 0
scoreboard players set #maintenance tr_tmp 0

# A reload must never strand an entity in temporary rewind/freeze state.
execute as @e[tag=tr_chrono_frozen] at @s run function dai_time_reverse:freeze/stop
execute as @a[scores={tr_mode=1..}] at @s run function dai_time_reverse:player/stop
execute as @a at @s as @e[tag=tr_area_rewinding,distance=..96] at @s run function dai_time_reverse:entity/stop

# Purge runtime history once on reload. History is intentionally ephemeral and
# begins rebuilding immediately at 10 Hz after the reload completes.
execute as @a at @s run kill @e[type=minecraft:marker,tag=tr_snapshot,distance=..128]
execute as @a at @s run kill @e[type=minecraft:marker,tag=tr_resume_frame,distance=..128]
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=tr_snapshot]
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=tr_resume_frame]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=tr_snapshot]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=tr_resume_frame]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=tr_snapshot]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=tr_resume_frame]

# Clean obsolete/transient helper state from older EchoTime releases. v1.3
# rewind playback no longer needs tr_current_player/tr_current_entity tags.
tag @e[tag=tr_area_rewinding] remove tr_processed_tick
tag @e[tag=tr_recorded_tick] remove tr_recorded_tick
tag @e[tag=tr_current_entity] remove tr_current_entity
tag @e[type=minecraft:marker,tag=tr_selected] remove tr_selected
tag @a[tag=tr_current_player] remove tr_current_player

# Open only the v1.3 migration gate. Historical migrations are checked once
# inside init_player_v130 instead of being re-tested every server tick.
tag @a remove tr_init_v130

tellraw @a [{"text":"[EchoTime] ","color":"aqua","bold":true},{"text":"v1.4.0 loaded. ","color":"green","bold":false},{"text":"DAI 4.1 temporal runtime active.","color":"gray"}]
