# EchoTime v1.3.0 one-time DAI 4.0 migration gate.
# Historical migrations are evaluated here once instead of on every player tick.
# Existing IDs, cooldowns and item ownership remain non-destructive.
execute unless score @s tr_id matches 1.. run function dai_time_reverse:internal/assign_player_id
execute if entity @s[tag=!tr_init_v020] run function dai_time_reverse:internal/init_player_v020
execute if entity @s[tag=!tr_init_perfhotfix] run function dai_time_reverse:internal/init_player_perfhotfix
execute if entity @s[tag=!tr_init_v021] run function dai_time_reverse:internal/init_player_v021
execute if entity @s[tag=!tr_items_v022] run function dai_time_reverse:internal/init_player_v022
execute if entity @s[tag=!tr_items_v024] run function dai_time_reverse:internal/init_player_v024
execute if entity @s[tag=!tr_init_v120] run function dai_time_reverse:internal/init_player_v120

# v1.3 no longer uses current-player helper tags during rewind playback.
tag @s remove tr_current_player

# Manual /trigger controls are a compatibility/debug path. Enable them here;
# a low-frequency maintenance pass handles reconnects without 20 TPS re-enables.
scoreboard players enable @s tr_emergency
scoreboard players enable @s tr_full
scoreboard players enable @s tr_area

tag @s add tr_init_v130
