# EchoTime v1.4.0 — bounded 10 Hz temporal-history dispatcher.
#
# All player-local history work is consolidated behind one global @a selector.
# Epoch guards continue to deduplicate overlapping-player marker/entity work.
execute as @a at @s run function dai_time_reverse:internal/sample_player
