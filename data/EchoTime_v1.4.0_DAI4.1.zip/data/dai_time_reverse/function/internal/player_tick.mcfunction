# EchoTime v1.4.0 — consolidated DAI 4.1 player runtime.
# Historical migrations are collapsed behind one v1.3 gate so initialized
# players avoid six tag/score migration checks every server tick.
execute if entity @s[tag=!tr_init_v130] run function dai_time_reverse:internal/init_player_v130

# Temporal Stream hold-state watchdog.
scoreboard players remove @s[scores={tr_hold=1..}] tr_hold 1
execute if score @s tr_mode matches 3 if score @s tr_hold matches 0 at @s run function dai_time_reverse:player/stop
execute if score @s tr_dry matches 1.. if score @s tr_hold matches 0 run scoreboard players set @s tr_dry 0

# Real-tick cooldowns.
scoreboard players remove @s[scores={tr_cdemg=1..}] tr_cdemg 1
scoreboard players remove @s[scores={tr_cdfull=1..}] tr_cdfull 1
scoreboard players remove @s[scores={tr_cdarea=1..}] tr_cdarea 1

# Manual/test trigger controls remain available as compatibility/debug paths.
# Trigger enablement itself moved to a low-frequency maintenance pass.
execute if score @s tr_emergency matches 1.. at @s run function dai_time_reverse:internal/trigger_emergency
execute if score @s tr_full matches 1.. at @s run function dai_time_reverse:internal/trigger_full
execute if score @s tr_area matches 1.. at @s run function dai_time_reverse:internal/trigger_area
