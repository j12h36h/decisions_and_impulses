scoreboard players set @s tr_emergency 0
function dai_time_reverse:activate/emergency
scoreboard players enable @s tr_emergency
