# A marker can be reached from overlapping players, but may age only once for
# the current 10 Hz sample epoch.
execute if score @s tr_agestamp = #epoch tr_tmp run return 0
scoreboard players operation @s tr_agestamp = #epoch tr_tmp

# Entity frames selected for Reversal Field are lock-aged for 32 samples at
# cast time. Playback consumes only 30 samples, so the recorded past cannot
# expire underneath an active 3-second rewind. The timeout also guarantees
# orphaned locks recover if their rewinding entity disappears unexpectedly.
execute if entity @s[tag=tr_rewind_locked] if score @s tr_lock matches 1.. run scoreboard players remove @s tr_lock 1
execute if entity @s[tag=tr_rewind_locked] if score @s tr_lock matches 1.. run return 0
execute if entity @s[tag=tr_rewind_locked] run tag @s remove tr_rewind_locked

scoreboard players add @s tr_age 1

# Unlocked Reversal Field history only needs the 30 most recent 10 Hz frames;
# keep two guard frames for sample/cast ordering. Personal history keeps the
# existing six-second buffer required by the five-second Temporal Stream.
execute if entity @s[tag=tr_entity_snapshot] if score @s tr_age matches 32.. run kill @s
execute if entity @s[tag=tr_player_snapshot] if score @s tr_age matches 61.. run kill @s
