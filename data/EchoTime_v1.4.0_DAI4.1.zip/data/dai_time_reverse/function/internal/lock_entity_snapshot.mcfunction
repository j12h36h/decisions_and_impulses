# Called as an entity-history marker whose owner is entering Reversal Field.
tag @s add tr_rewind_locked
scoreboard players set @s tr_lock 32
