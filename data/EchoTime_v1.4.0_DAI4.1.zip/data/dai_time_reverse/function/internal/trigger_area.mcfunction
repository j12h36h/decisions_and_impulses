scoreboard players set @s tr_area 0
function dai_time_reverse:activate/area
scoreboard players enable @s tr_area
