# Low-frequency compatibility maintenance for manual /trigger controls.
scoreboard players enable @s tr_emergency
scoreboard players enable @s tr_full
scoreboard players enable @s tr_area
