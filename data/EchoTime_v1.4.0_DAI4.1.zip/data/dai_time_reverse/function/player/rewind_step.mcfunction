# Select this player's oldest remaining history frame.
tag @e[type=minecraft:marker,tag=tr_selected,distance=..64] remove tr_selected
scoreboard players operation #owner tr_tmp = @s tr_id
scoreboard players set #min tr_tmp 2147483647
execute as @e[type=minecraft:marker,tag=tr_player_snapshot,distance=..64] if score @s tr_owner = #owner tr_tmp if score @s tr_age < #min tr_tmp run scoreboard players operation #min tr_tmp = @s tr_age

# No more history: resume from the last historical frame we reached.
# Continuous Temporal Stream becomes dry until the held-use is actually released.
execute if score #min tr_tmp matches 2147483647 if score @s tr_mode matches 3 run scoreboard players set @s tr_dry 1
execute if score #min tr_tmp matches 2147483647 run function dai_time_reverse:player/stop
execute if score #min tr_tmp matches 2147483647 run return 0

execute as @e[type=minecraft:marker,tag=tr_player_snapshot,distance=..64] if score @s tr_owner = #owner tr_tmp if score @s tr_age = #min tr_tmp run tag @s add tr_selected

# Move backward to the selected historical position and facing. `at` and
# `rotated as` preserve the original player executor, avoiding the old
# tr_current_player helper-tag round trip.
execute at @e[type=minecraft:marker,tag=tr_selected,limit=1] rotated as @e[type=minecraft:marker,tag=tr_selected,limit=1] run tp @s ~ ~ ~ ~ ~

# Full rewind remembers the historical health value of the frame where it currently is.
execute if score @s tr_mode matches 2 run scoreboard players operation @s tr_resumehp = @e[type=minecraft:marker,tag=tr_selected,limit=1] tr_hp

# Replace this player's resume frame with the frame just consumed.
execute as @e[type=minecraft:marker,tag=tr_resume_frame,tag=tr_player_resume] if score @s tr_owner = #owner tr_tmp run kill @s
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] remove tr_player_snapshot
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] remove tr_snapshot
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] add tr_resume_frame
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] add tr_player_resume
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] remove tr_selected

function dai_time_reverse:hooks/player_rewind_tick
scoreboard players remove @s tr_ticks 1
execute if score @s tr_ticks matches ..0 if score @s tr_mode matches 3 run scoreboard players set @s tr_dry 1
execute if score @s tr_ticks matches ..0 run function dai_time_reverse:player/stop
