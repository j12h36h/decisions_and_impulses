# Select this entity's oldest remaining history frame.
tag @e[type=minecraft:marker,tag=tr_selected,distance=..64] remove tr_selected
scoreboard players operation #owner tr_tmp = @s tr_eid
scoreboard players set #min tr_tmp 2147483647
execute as @e[type=minecraft:marker,tag=tr_entity_snapshot,distance=..64] if score @s tr_owner = #owner tr_tmp if score @s tr_age < #min tr_tmp run scoreboard players operation #min tr_tmp = @s tr_age

execute if score #min tr_tmp matches 2147483647 run function dai_time_reverse:entity/stop
execute if score #min tr_tmp matches 2147483647 run return 0

execute as @e[type=minecraft:marker,tag=tr_entity_snapshot,distance=..64] if score @s tr_owner = #owner tr_tmp if score @s tr_age = #min tr_tmp run tag @s add tr_selected

# Historical transform. `at`/`rotated as` preserve the original executor, so
# the rewinding entity remains @s and no temporary current-entity tag is needed.
execute at @e[type=minecraft:marker,tag=tr_selected,limit=1] rotated as @e[type=minecraft:marker,tag=tr_selected,limit=1] run tp @s ~ ~ ~ ~ ~

# Historical entity state where vanilla safely permits direct NBT restoration.
execute if data entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.health run data modify entity @s Health set from entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.health
execute if data entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.fire run data modify entity @s Fire set from entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.fire
execute if data entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.air run data modify entity @s Air set from entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.air
execute if data entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.in_ground run data modify entity @s inGround set from entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.in_ground
execute if data entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.fall_distance run data modify entity @s FallDistance set from entity @e[type=minecraft:marker,tag=tr_selected,limit=1] data.fall_distance

# Rewind playback itself is positional. Do not leave reverse velocity on the entity.
data merge entity @s {Motion:[0.0d,0.0d,0.0d]}

# Keep the most recent consumed frame separately; its stored FORWARD motion is what resumes later.
execute as @e[type=minecraft:marker,tag=tr_resume_frame,tag=tr_entity_resume] if score @s tr_owner = #owner tr_tmp run kill @s
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] remove tr_entity_snapshot
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] remove tr_snapshot
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] add tr_resume_frame
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] add tr_entity_resume
tag @e[type=minecraft:marker,tag=tr_selected,limit=1] remove tr_selected

scoreboard players remove @s tr_rticks 1
execute if score @s tr_rticks matches ..0 run function dai_time_reverse:entity/stop
