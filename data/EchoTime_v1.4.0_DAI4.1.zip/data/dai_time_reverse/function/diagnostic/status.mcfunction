tellraw @s [{"text":"[EchoTime] ","color":"aqua","bold":true},{"text":"v1.4.0 is loaded.","color":"green","bold":false}]
tellraw @s [{"text":"DAI runtime: ","color":"gray"},{"text":"4.1 authority + efficiency compatibility","color":"white"}]
tellraw @s [{"text":"Chrono Anchor: ","color":"aqua"},{"text":"2-second time stop / 10-block radius","color":"white"}]
tellraw @s [{"text":"Internal namespace / stable addon id: ","color":"gray"},{"text":"dai_time_reverse","color":"white"}]
