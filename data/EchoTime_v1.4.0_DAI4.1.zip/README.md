# EchoTime

EchoTime v1.4.0 is a standalone **DAI Engine 4.1 temporal-ability addon** for Minecraft Java 26.2.

## Ability Items

- **Temporal Recall** — rewinds your recent movement and facing for up to 3 seconds. It renders as an enchanted Ender Eye.
- **Chrono Anchor** — stops nearby non-player entities in time for 2 seconds within a 10-block radius.
- **Reversal Field** — rewinds recorded nearby non-player entities within 10 blocks for up to 3 seconds.
- **Temporal Stream** — hold use to continuously rewind yourself for up to 5 seconds, then resume from the historical point reached.

Each player receives one copy of all four items automatically. If an item is lost, run:

`/function dai_time_reverse:starter/give`

The internal `dai_time_reverse` namespace, native item IDs, and stable DAI addon ID are retained for world, whitelist, and addon compatibility.

## DAI Engine 4.1

v1.4.0 keeps EchoTime as an **ADDON**, not an Experience Pack. It can therefore be layered into normal worlds or any DAI Experience that allows the stable addon ID `dai_time_reverse`.

The four registry-backed DAI items continue to use the DAI content/reaction runtime:

- `dai_time_reverse:temporal_recall`
- `dai_time_reverse:chrono_anchor`
- `dai_time_reverse:reversal_field`
- `dai_time_reverse:temporal_stream`

They are also exposed through the shared item tag `#dai_time_reverse:ability_items` for DAI 4.1 integrations and future pack-defined systems.

## v1.3 Runtime Efficiency Pass

EchoTime still records temporal history at 10 Hz because rewind abilities require history to exist *before* they are activated. v1.3 reduces the surrounding cost without weakening the four abilities:

- historical player migrations are collapsed behind one v1.3 initialization gate instead of six migration checks per player every tick
- manual `/trigger` compatibility controls are refreshed once per second rather than re-enabled three times per player every tick
- Reversal Field entity history now expires immediately after the 31-sample window needed for a 30-frame / 3-second rewind, roughly halving retained non-player history compared with v1.2
- personal history keeps the existing six-second safety buffer required by the five-second Temporal Stream
- personal and entity rewind playback no longer creates temporary `tr_current_player` / `tr_current_entity` selection state each history step
- Chrono Anchor maintenance is inlined into its shared frozen-entity dispatcher, removing one nested function dispatch per frozen entity per tick
- the existing 16-nearest-entity recording cap and overlap epoch guards remain in place

## Preserved Ability Behavior

- Temporal Recall: up to 3 seconds.
- Chrono Anchor: 2-second freeze within 10 blocks.
- Reversal Field: up to 3 seconds within 10 blocks.
- Temporal Stream: hold-to-rewind for up to 5 seconds.
- Reversal Field still records at most 16 nearby non-player timelines per player/sample.
- Existing cooldowns, health restoration, motion/facing restoration, item appearance, and native-item input routing remain unchanged.

## World of Addons

EchoTime remains independently usable, but its stable native content IDs remain compatible with World of Addons integrations that recognize the **Echo Anomaly** champion kit.

World of Addons is optional and is not a dependency.

## Compatibility

- Minecraft Java 26.2
- DAI Engine 4.1
- Data Pack format 107.1
- DAI role: `addon`
- Stable addon ID: `dai_time_reverse`
- Datapack only; no Resource Pack required


## v1.4.0 — DAI 4.1 Authority Compatibility

DAI 4.1 requires client-originated customization events to be explicitly exposed by the server-loaded datapack. EchoTime's four interactive dispatch definitions now opt in only to the exact `use` event.

- `flags.client_callable: true` enables the intended player request path.
- `properties.client_events: "use"` prevents clients from inventing other interactive event names.
- The server still resolves the actual EchoTime definition and fixed function target.
- Temporal history, cooldowns, rewind behavior, freeze behavior and stable item/function IDs are unchanged.
- No persistent-state migration or reset is required.
