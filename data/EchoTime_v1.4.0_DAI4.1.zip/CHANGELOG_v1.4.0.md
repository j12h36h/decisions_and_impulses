# EchoTime v1.4.0 — DAI 4.1 Authority Compatibility

- Updated EchoTime metadata/current documentation for **DAI Engine 4.1**.
- Added stable `dai.pack_id: dai_time_reverse` metadata while preserving the addon ID.
- Updated all four `dai_interactives` to explicitly allow only the player-facing `use` event through DAI 4.1's server authority gate.
- The client can no longer rely on trusted-datapack status alone to invoke an interactive's server function.
- Preserved all four ability items, temporal history limits, cooldowns, rewind/freeze behavior and World of Addons recognition IDs.
- No persistent-state migration or reset is required.
