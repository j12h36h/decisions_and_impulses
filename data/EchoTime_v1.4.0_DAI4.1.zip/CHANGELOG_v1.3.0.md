# EchoTime v1.3.0

## DAI 4.0 Compatibility + Capability / Efficiency Pass

- Updated the pack for DAI Engine 4.0 and retained `dai_time_reverse` as the stable ADDON ID used by DAI 4.0 Experience addon policies.
- Preserved all four registry-backed DAI ability items and all existing `dai_time_reverse:*` content/function IDs.
- Added the shared `#dai_time_reverse:ability_items` integration tag.
- Collapsed historical per-player migration checks behind one v1.3 initialization gate.
- Reduced manual `/trigger` enable maintenance from 20 TPS to 1 Hz, with immediate re-enable after use.
- Reduced Reversal Field non-player snapshot retention to the history actually consumed by its 3-second rewind while preserving the existing player-history window for Temporal Stream.
- Removed temporary current-player/current-entity helper tags from active rewind playback.
- Inlined Chrono Anchor's frozen-entity maintenance while retaining the historical `freeze/tick` function ID as a wrapper.
- Preserved the 10 Hz history cadence, 16-entity recording cap, cooldowns, rewind durations, health restoration, input behavior, item presentation, and World of Addons Echo Anomaly compatibility.
- Datapack-only; no Resource Pack required.
