# Changelog

## v1.4.0 — DAI 4.1 Authority Compatibility

- Updated EchoTime metadata/current documentation for **DAI Engine 4.1**.
- Added stable `dai.pack_id: dai_time_reverse` metadata while preserving the addon ID.
- Updated all four `dai_interactives` to explicitly allow only the player-facing `use` event through DAI 4.1's server authority gate.
- The client can no longer rely on trusted-datapack status alone to invoke an interactive's server function.
- Preserved all four ability items, temporal history limits, cooldowns, rewind/freeze behavior and World of Addons recognition IDs.
- No persistent-state migration or reset is required.

## v1.3.0 — DAI 4.0 Compatibility + Capability / Efficiency Pass

- Updated EchoTime metadata and documentation for **DAI Engine 4.0** while preserving the stable `dai_time_reverse` addon identity and all native content IDs.
- Kept EchoTime classified as an ADDON so DAI 4.0 Experience addon policies can allow/disable it by stable ID without version-specific whitelist entries.
- Added `#dai_time_reverse:ability_items`, exposing all four native EchoTime ability items through one integration-friendly DAI 4.0 item tag.
- Added a non-destructive v1.3.0 migration gate that evaluates historical player migrations once instead of repeating six migration/tag checks on every player every server tick.
- Moved manual `/trigger` objective re-enabling from the 20 TPS player hot path to a one-second compatibility maintenance pass, with immediate re-enable after a trigger is used.
- Reduced non-player temporal history retention from the old 61-sample shared lifetime to 31 usable samples plus expiry, matching the actual 30-frame / 3-second Reversal Field requirement while leaving the player history safety window unchanged.
- Removed active rewind dependence on temporary `tr_current_player` and `tr_current_entity` tags. Rewind transforms now preserve the original executor through `execute at` / `rotated as` and directly update `@s`.
- Inlined Chrono Anchor's per-entity freeze maintenance into the shared frozen-entity dispatcher, while retaining `freeze/tick` as a compatibility wrapper for existing integrations.
- Preserved the 10 Hz temporal history engine, 16-nearest-entity recording cap, overlap epoch deduplication, exact cooldowns, rewind durations, health restoration behavior, and native DAI reaction routing.
- Preserved World of Addons / Echo Anomaly compatibility and all existing `dai_time_reverse:*` item/function identities.
- No Resource Pack is required.

## v1.2.0 — DAI 3.3 Capability + Efficiency Pass

- Updated EchoTime for DAI 3.3 and bumped the managed addon version to `1.2.0`.
- Consolidated the 20 TPS player runtime behind one global player selection instead of repeated player-wide scans for initialization, cooldowns, held-use state, trigger controls, and ability routing.
- Consolidated Chrono Anchor maintenance behind one frozen-entity dispatcher instead of separate global active/expired frozen-entity scans.
- Consolidated the 10 Hz temporal-history pass behind one global player selection while preserving existing epoch-based overlap deduplication.
- Kept the v1.1.0 bounded history rules: at most 16 nearby non-player timelines per player/sample within the actual 10-block Reversal Field radius.
- Removed repeated global current-player/current-entity helper-tag clearing from active rewind steps; transient helper state is now released locally and cleaned once on load.
- Historical migration markers are no longer forcibly cleared on every `/reload`; missing migrations are handled locally by the consolidated player runtime.
- Added a v1.2.0 migration marker without resetting stable player IDs, cooldowns, or item state.
- Preserved all four native DAI ability items and their stable `dai_time_reverse:*` IDs.
- Preserved World of Addons recognition compatibility for Echo Anomaly.
- No Resource Pack is required.

## Preserved Ability Behavior

- Temporal Recall: up to 3 seconds.
- Chrono Anchor: 2-second freeze within 10 blocks.
- Reversal Field: up to 3 seconds within 10 blocks.
- Temporal Stream: hold-to-rewind for up to 5 seconds.
- Existing cooldowns, health restoration behavior, historical motion restoration, item appearance, and native-item input remain unchanged.
