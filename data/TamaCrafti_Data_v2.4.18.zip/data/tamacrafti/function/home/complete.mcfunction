# Finalize the starter home exactly once.
execute if score #home tc_home_complete matches 1 run return 0
scoreboard players set #home tc_home_active 0
scoreboard players set #home tc_home_complete 1
scoreboard players set #home tc_home_step 374
scoreboard players set #home tc_home_clock 0
advancement revoke @a only tamacrafti:state/home_building
advancement grant @a only tamacrafti:state/home_complete
tellraw @a [{"text":"[TamaCrafti] ","color":"light_purple","bold":true},{"text":"The garden is ready. Care milestones will unlock more farming rewards. Press V to open the TamaCrafti menu.","color":"white"}]
recipe take @a *
