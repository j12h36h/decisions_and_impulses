# TamaCrafti starter-home construction burst.
# Keep the established fast build rate, but stop the burst immediately once
# home/complete clears tc_home_active. This prevents repeated finalization in
# the same tick and recovers malformed/missing construction counters safely.

execute if score #home tc_home_active matches 1 unless score #home tc_home_step matches 0..374 run function tamacrafti:home/repair
execute if score #home tc_home_active matches 1 if score #home tc_home_step matches 374.. run function tamacrafti:home/complete
execute if score #home tc_home_active matches 1 run scoreboard players add #home tc_home_clock 1

execute if score #home tc_home_active matches 1 if score #home tc_home_clock matches 3.. run function tamacrafti:home/step
execute if score #home tc_home_active matches 1 if score #home tc_home_clock matches 3.. run function tamacrafti:home/step
execute if score #home tc_home_active matches 1 if score #home tc_home_clock matches 3.. run function tamacrafti:home/step
execute if score #home tc_home_active matches 1 if score #home tc_home_clock matches 3.. run function tamacrafti:home/step

execute if score #home tc_home_active matches 1 if score #home tc_home_clock matches 3.. run scoreboard players set #home tc_home_clock 0
