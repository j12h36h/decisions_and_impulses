
# Interaction tools + farming progression only. No raw building stock or crafting station.
give @s minecraft:iron_hoe 1
give @s minecraft:iron_shovel 1
give @s minecraft:iron_axe 1
give @s minecraft:iron_pickaxe 1
give @s minecraft:wheat_seeds 8
give @s minecraft:carrot 4
give @s minecraft:potato 4
give @s minecraft:bone_meal 4
recipe take @s *
