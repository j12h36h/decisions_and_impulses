# Resume an existing Journey without resetting a healthy save.
# Recovery is deliberately state-based instead of trusting only the DAI
# experience marker, because older handoff failures could mark a save as
# launched before the TamaCrafti bootstrap actually completed.

# Ensure the world-side Journey/home state exists.
execute unless score #world tc_world_init matches 1 run function tamacrafti:journey/world_init

# If the home is neither complete nor actively building, repair/restart the
# block-by-block home pass. This does not touch player inventory.
execute unless score #home tc_home_complete matches 1 unless score #home tc_home_active matches 1 run function tamacrafti:home/repair

# Ensure player state exists without resetting an already initialized pet.
execute unless score @s tc_init matches 1 run function tamacrafti:player/init

# Existing broken Journey saves may have tc_init/tc_journey state but never
# received the starter kit. Give it exactly once using a dedicated marker.
execute unless score @s tc_journeykit matches 1 run function tamacrafti:journey/starter_kit
execute unless score @s tc_journeykit matches 1 run scoreboard players set @s tc_journeykit 1

scoreboard players set @s tc_journey 1
advancement grant @s only tamacrafti:state/journey_active
function tamacrafti:state/sync
tellraw @s [{"text":"[TamaCrafti] ","color":"light_purple","bold":true},{"text":"Journey resumed. If the home is still building you will stay on the loading scene until it finishes. Otherwise, press V to open or close TamaCrafti. The key is remappable in Controls.","color":"gray"}]
recipe take @s *
