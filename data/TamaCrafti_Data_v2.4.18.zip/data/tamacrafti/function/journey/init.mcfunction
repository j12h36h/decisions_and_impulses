# One-time TamaCrafti Journey bootstrap for this player.
execute unless score #world tc_world_init matches 1 run function tamacrafti:journey/world_init
scoreboard players set @s tc_journey 1
scoreboard players set @s tc_recipeclk 0
advancement grant @s only tamacrafti:state/journey_active
teleport @s 0.5 200 0.5
spawnpoint @s 0 200 0
clear @s
recipe take @s *
execute unless score @s tc_journeykit matches 1 run function tamacrafti:journey/starter_kit
execute unless score @s tc_journeykit matches 1 run scoreboard players set @s tc_journeykit 1
function tamacrafti:state/sync
tellraw @s [{"text":"[TamaCrafti] ","color":"light_purple","bold":true},{"text":"Your little sky-home is being prepared now. A cozy loading scene will stay up until the home is ready.","color":"white"}]
tellraw @s [{"text":"[TamaCrafti] ","color":"light_purple","bold":true},{"text":"Once the home is complete, press V to open or close TamaCrafti. The key is remappable in Controls > Key Binds > TamaCrafti.","color":"gray"}]
