
function tamacrafti:cooldown/tick
function tamacrafti:request/tick
scoreboard players add @s tc_avclk 1
execute if score @s tc_avclk matches 20.. run function tamacrafti:state/availability
scoreboard players add @s tc_hclk 1
scoreboard players add @s tc_pclk 1
scoreboard players add @s tc_cclk 1
scoreboard players add @s tc_eclk 1
scoreboard players add @s tc_aclk 1
scoreboard players add @s tc_healclk 1
execute if score @s tc_sleeping matches 1 run function tamacrafti:sleep/tick
execute if score @s tc_hclk matches 1800.. run function tamacrafti:decay/hunger
execute if score @s tc_pclk matches 3600.. run function tamacrafti:decay/happy
execute if score @s tc_cclk matches 4800.. run function tamacrafti:decay/clean
execute if score @s tc_sleeping matches 0 if score @s tc_eclk matches 2400.. run function tamacrafti:decay/energy
execute if score @s tc_aclk matches 1200.. run function tamacrafti:decay/age
execute if score @s tc_healclk matches 1200.. run function tamacrafti:state/recover

# TamaCrafti Journey intentionally suppresses normal Minecraft crafting progression.
recipe take @s *

execute if dimension minecraft:overworld if entity @s[y=-64,dy=200] run function tamacrafti:state/position_recover
