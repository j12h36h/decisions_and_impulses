# DAI Comic Effects v1.4.0
# Display animation remains 20 TPS; expensive nearby-entity recognition is sampled at 10 Hz.
scoreboard players add @e[type=minecraft:text_display,tag=dai_cfx_effect] dai_cfx_age 1
execute as @e[type=minecraft:text_display,tag=dai_cfx_effect] at @s run tp @s ~ ~0.025 ~
kill @e[type=minecraft:text_display,tag=dai_cfx_effect,scores={dai_cfx_age=16..}]

scoreboard players add #scan dai_cfx_clock 1
execute if score #scan dai_cfx_clock matches 2.. run tag @e[tag=dai_cfx_scanned] remove dai_cfx_scanned
execute if score #scan dai_cfx_clock matches 2.. as @a at @s run function dai_comic_fx:runtime/scan_nearby
execute if score #scan dai_cfx_clock matches 2.. run scoreboard players set #scan dai_cfx_clock 0
