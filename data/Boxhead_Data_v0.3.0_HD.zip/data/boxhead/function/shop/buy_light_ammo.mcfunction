tag @s remove bh_purchase_ok
execute if score @s bh_money matches 100.. run tag @s add bh_purchase_ok
execute unless entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Need $100","color":"red"}
execute if entity @s[tag=bh_purchase_ok] run scoreboard players remove @s bh_money 100
execute if entity @s[tag=bh_purchase_ok] run give @s boxhead:light_round 30
execute if entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Purchased 30 light rounds.","color":"green"}
tag @s remove bh_purchase_ok
