tag @s remove bh_purchase_ok
execute if score @s bh_money matches 220.. run tag @s add bh_purchase_ok
execute unless entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Need $220","color":"red"}
execute if entity @s[tag=bh_purchase_ok] run scoreboard players remove @s bh_money 220
execute if entity @s[tag=bh_purchase_ok] run give @s boxhead:heavy_round 8
execute if entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Purchased 8 heavy rounds.","color":"green"}
tag @s remove bh_purchase_ok
