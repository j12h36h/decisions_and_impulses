tag @s remove bh_purchase_ok
execute if score @s bh_money matches 900.. run tag @s add bh_purchase_ok
execute unless entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Need $900","color":"red"}
execute if entity @s[tag=bh_purchase_ok] run scoreboard players remove @s bh_money 900
execute if entity @s[tag=bh_purchase_ok] run give @s boxhead:shotgun 1
execute if entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Purchased Pump Shotgun.","color":"green"}
tag @s remove bh_purchase_ok
