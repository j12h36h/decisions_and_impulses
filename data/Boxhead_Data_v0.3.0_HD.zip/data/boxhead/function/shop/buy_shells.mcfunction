tag @s remove bh_purchase_ok
execute if score @s bh_money matches 180.. run tag @s add bh_purchase_ok
execute unless entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Need $180","color":"red"}
execute if entity @s[tag=bh_purchase_ok] run scoreboard players remove @s bh_money 180
execute if entity @s[tag=bh_purchase_ok] run give @s boxhead:shotgun_shell 12
execute if entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Purchased 12 shotgun shells.","color":"green"}
tag @s remove bh_purchase_ok
