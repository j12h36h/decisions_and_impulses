tag @s remove bh_purchase_ok
execute if score @s bh_money matches 250.. if entity @e[type=minecraft:marker,tag=bh_barrier_socket,distance=..16,sort=nearest,limit=1] run tag @s add bh_purchase_ok
execute unless entity @e[type=minecraft:marker,tag=bh_barrier_socket,distance=..16,sort=nearest,limit=1] run title @s actionbar {"text":"No barricade socket nearby.","color":"red"}
execute if entity @e[type=minecraft:marker,tag=bh_barrier_socket,distance=..16,sort=nearest,limit=1] unless score @s bh_money matches 250.. run title @s actionbar {"text":"Need $250","color":"red"}
execute if entity @s[tag=bh_purchase_ok] run scoreboard players remove @s bh_money 250
execute if entity @s[tag=bh_purchase_ok] at @s as @e[type=minecraft:marker,tag=bh_barrier_socket,distance=..16,sort=nearest,limit=1] at @s run function boxhead:barrier/rebuild_basic
execute if entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Barricade repaired.","color":"green"}
tag @s remove bh_purchase_ok
