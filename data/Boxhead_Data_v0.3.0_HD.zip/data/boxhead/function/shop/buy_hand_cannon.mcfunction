tag @s remove bh_purchase_ok
execute if score @s bh_money matches 1200.. run tag @s add bh_purchase_ok
execute unless entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Need $1200","color":"red"}
execute if entity @s[tag=bh_purchase_ok] run scoreboard players remove @s bh_money 1200
execute if entity @s[tag=bh_purchase_ok] run give @s boxhead:hand_cannon 1
execute if entity @s[tag=bh_purchase_ok] run title @s actionbar {"text":"Purchased Hand Cannon.","color":"green"}
tag @s remove bh_purchase_ok
