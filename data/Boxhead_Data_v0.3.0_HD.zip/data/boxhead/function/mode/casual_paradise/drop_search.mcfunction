scoreboard players add @s bh_y 1
execute if block ~ ~ ~ minecraft:air if block ~ ~1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:water unless block ~ ~-1 ~ minecraft:lava run tp @s ~ ~ ~
execute if block ~ ~ ~ minecraft:air if block ~ ~1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:air unless block ~ ~-1 ~ minecraft:water unless block ~ ~-1 ~ minecraft:lava run tag @s add bh_respawn_found
execute unless entity @s[tag=bh_respawn_found] if score @s bh_y matches ..383 positioned ~ ~-1 ~ run function boxhead:mode/casual_paradise/drop_search
