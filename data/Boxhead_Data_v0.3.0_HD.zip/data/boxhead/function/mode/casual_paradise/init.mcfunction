scoreboard players set #game_mode bh_state 3
gamerule minecraft:keep_inventory true
