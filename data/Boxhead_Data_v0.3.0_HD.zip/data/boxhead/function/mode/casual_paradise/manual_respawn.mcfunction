execute unless score #game_mode bh_state matches 3 run title @s actionbar {"text":"Manual respawn is only available in Casual Paradise.","color":"red"}
execute if score #game_mode bh_state matches 3 unless entity @s[tag=bh_casual_dead] run title @s actionbar {"text":"You are already alive.","color":"yellow"}
execute if score #game_mode bh_state matches 3 if entity @s[tag=bh_casual_dead] run function boxhead:mode/casual_paradise/respawn_now
