tag @s remove bh_respawn_found
scoreboard players set @s bh_y 0
execute unless entity @s[x=-70,y=-64,z=-70,dx=140,dy=384,dz=140] run tp @s @e[type=minecraft:marker,tag=bh_player_spawn,sort=random,limit=1]
execute if entity @s[x=-70,y=-64,z=-70,dx=140,dy=384,dz=140] at @s run function boxhead:mode/casual_paradise/drop_search
execute unless entity @s[tag=bh_respawn_found] run tp @s @e[type=minecraft:marker,tag=bh_player_spawn,sort=random,limit=1]
gamemode adventure @s
tag @s remove bh_casual_dead
tag @s remove bh_respawn_found
execute if score #map_type bh_state matches 3 run attribute @s minecraft:gravity base set 0.04
execute unless score #map_type bh_state matches 3 run attribute @s minecraft:gravity base set 0.08
title @s actionbar {"text":"Respawned at your selected position.","color":"green"}
