tag @s add bh_casual_dead
gamemode spectator @s
title @s actionbar {"text":"Spectating — press ` and choose RESPAWN when ready.","color":"aqua"}
