tag @s add bh_eliminated
gamemode spectator @s
title @s title {"text":"LAST BREATH","color":"dark_red","bold":true}
title @s subtitle {"text":"Your run is over.","color":"gray"}
