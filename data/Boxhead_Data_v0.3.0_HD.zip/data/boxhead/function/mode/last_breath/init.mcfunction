scoreboard players set #game_mode bh_state 1
gamerule minecraft:keep_inventory false
