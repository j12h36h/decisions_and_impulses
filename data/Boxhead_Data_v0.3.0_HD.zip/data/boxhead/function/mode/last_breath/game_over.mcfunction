scoreboard players set #phase bh_state 4
gamemode spectator @a[tag=bh_player]
kill @e[type=boxhead:zombie]
kill @e[type=boxhead:mutant]
kill @e[type=boxhead:giant]
kill @e[type=boxhead:mangled]
title @a title {"text":"RUN OVER","color":"dark_red","bold":true}
title @a subtitle {"text":"Last Breath ended.","color":"gray"}
