scoreboard players operation #loss bh_state = @s bh_money
scoreboard players operation #loss bh_state /= #four bh_state
scoreboard players operation @s bh_money -= #loss bh_state
tag @s add bh_waiting
gamemode spectator @s
title @s actionbar {"text":"Dead — waiting for the next wave. 25% money lost.","color":"red"}
