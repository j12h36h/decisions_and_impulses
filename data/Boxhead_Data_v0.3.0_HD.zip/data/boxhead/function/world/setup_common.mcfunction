kill @e[tag=bh_runtime_marker]
kill @e[type=boxhead:zombie]
kill @e[type=boxhead:mutant]
kill @e[type=boxhead:giant]
kill @e[type=boxhead:mangled]
scoreboard players set #phase bh_state 0
scoreboard players set #wave bh_state 1
scoreboard players set #checkpoint bh_state 1
scoreboard players set #clock bh_state 0
scoreboard players set #alive bh_state 0
scoreboard players set #budget bh_state 0
scoreboard players set #spawn_timer bh_state 0
scoreboard players set #spawn_serial bh_state 0
scoreboard players set #intermission bh_state 0
scoreboard players set #game_mode bh_state 0
scoreboard players set #map_type bh_state 0
scoreboard players set #run_started bh_state 0
team add bh_infected
team modify bh_infected friendlyFire false
team modify bh_infected collisionRule always
time set midnight
weather clear
kill @e[tag=bh_projectile]
