scoreboard players set #clock bh_state 0
scoreboard players set #alive bh_state 0
execute as @e[tag=bh_infected] run scoreboard players add #alive bh_state 1
function boxhead:barrier/zombie_damage
execute as @e[type=minecraft:marker,tag=bh_barrier_socket] at @s run function boxhead:barrier/update
execute if score #game_mode bh_state matches 1 if score #phase bh_state matches 2..3 unless entity @a[tag=bh_player,gamemode=!spectator] run function boxhead:mode/last_breath/game_over
execute if score #game_mode bh_state matches 2 if score #phase bh_state matches 2..3 unless entity @a[tag=bh_player,gamemode=!spectator] if entity @a[tag=bh_waiting] run function boxhead:mode/infinite_dead/team_wipe
execute as @a[tag=bh_player] run function boxhead:ui/status
