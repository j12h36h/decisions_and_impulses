playsound minecraft:block.lever.click player @s ~ ~ ~ 0.5 1.7
title @s actionbar {"text":"EMPTY — buy ammunition with `","color":"red"}
