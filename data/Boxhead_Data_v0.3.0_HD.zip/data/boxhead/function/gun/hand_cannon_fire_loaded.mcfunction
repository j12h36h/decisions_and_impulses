clear @s boxhead:heavy_round 1
scoreboard players set @s bh_fire_cd 6
item modify entity @s weapon.mainhand boxhead:hand_cannon_fire
scoreboard players set @s bh_anim 2
playsound minecraft:entity.firework_rocket.large_blast player @s ~ ~ ~ 0.55 1.25
particle minecraft:smoke ^ ^-0.08 ^0.7 0.02 0.02 0.02 0.01 2 force @s
summon minecraft:item ^0.35 ^-0.20 ^0.15 {Item:{id:"boxhead:spent_casing",count:1},PickupDelay:32767,Age:5980,Motion:[0.10d,0.18d,0.02d]}
execute anchored eyes positioned ^ ^ ^0.45 run summon boxhead:bullet_heavy_entity ~ ~ ~ {Tags:["dai_projectile","bh_projectile","bh_new_heavy"]}
data modify entity @e[type=boxhead:bullet_heavy_entity,tag=bh_new_heavy,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:bullet_heavy_entity,tag=bh_new_heavy,sort=nearest,limit=1,distance=..3] add bh_aimed
scoreboard players set @e[type=boxhead:bullet_heavy_entity,tag=bh_new_heavy,sort=nearest,limit=1,distance=..3] bh_proj_age 0
tag @e[type=boxhead:bullet_heavy_entity,tag=bh_new_heavy,distance=..3] remove bh_new_heavy
