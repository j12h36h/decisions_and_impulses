clear @s boxhead:shotgun_shell 1
scoreboard players set @s bh_fire_cd 8
item modify entity @s weapon.mainhand boxhead:shotgun_fire
scoreboard players set @s bh_anim 2
playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.55 0.95
particle minecraft:smoke ^ ^-0.08 ^0.7 0.02 0.02 0.02 0.01 2 force @s
summon minecraft:item ^0.35 ^-0.20 ^0.15 {Item:{id:"boxhead:spent_casing",count:1},PickupDelay:32767,Age:5980,Motion:[0.10d,0.18d,0.02d]}
execute anchored eyes positioned ^ ^ ^0.45 run summon boxhead:pellet_entity ~ ~ ~ {Tags:["dai_projectile","bh_projectile","bh_new_pellet"]}
execute anchored eyes positioned ^ ^ ^0.45 run summon boxhead:pellet_entity ~ ~ ~ {Tags:["dai_projectile","bh_projectile","bh_new_pellet"]}
execute anchored eyes positioned ^ ^ ^0.45 run summon boxhead:pellet_entity ~ ~ ~ {Tags:["dai_projectile","bh_projectile","bh_new_pellet"]}
execute anchored eyes positioned ^ ^ ^0.45 run summon boxhead:pellet_entity ~ ~ ~ {Tags:["dai_projectile","bh_projectile","bh_new_pellet"]}
execute anchored eyes positioned ^ ^ ^0.45 run summon boxhead:pellet_entity ~ ~ ~ {Tags:["dai_projectile","bh_projectile","bh_new_pellet"]}
execute anchored eyes positioned ^ ^ ^0.45 run summon boxhead:pellet_entity ~ ~ ~ {Tags:["dai_projectile","bh_projectile","bh_new_pellet"]}
execute anchored eyes positioned ^ ^ ^0.45 run summon boxhead:pellet_entity ~ ~ ~ {Tags:["dai_projectile","bh_projectile","bh_new_pellet"]}
execute anchored eyes positioned ^ ^ ^0.45 run summon boxhead:pellet_entity ~ ~ ~ {Tags:["dai_projectile","bh_projectile","bh_new_pellet"]}
function boxhead:projectile/aim_pellets
scoreboard players set @e[type=boxhead:pellet_entity,tag=bh_new_pellet,distance=..3] bh_proj_age 0
tag @e[type=boxhead:pellet_entity,tag=bh_new_pellet,distance=..3] remove bh_new_pellet
