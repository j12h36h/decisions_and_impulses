scoreboard players add @s bh_fire_cd 0
scoreboard players set @s bh_shot 0
execute if score @s bh_fire_cd matches 0 store result score @s bh_shot run clear @s boxhead:heavy_round 0
execute if score @s bh_fire_cd matches 0 if score @s bh_shot matches 1.. run function boxhead:gun/hand_cannon_fire_loaded
execute if score @s bh_fire_cd matches 0 if score @s bh_shot matches 0 run function boxhead:gun/dry_fire
