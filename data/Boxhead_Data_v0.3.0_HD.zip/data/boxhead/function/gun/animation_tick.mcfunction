execute as @a[scores={bh_anim=1}] if items entity @s weapon.mainhand boxhead:pistol run item modify entity @s weapon.mainhand boxhead:pistol_idle
execute as @a[scores={bh_anim=1}] if items entity @s weapon.mainhand boxhead:shotgun run item modify entity @s weapon.mainhand boxhead:shotgun_idle
execute as @a[scores={bh_anim=1}] if items entity @s weapon.mainhand boxhead:hand_cannon run item modify entity @s weapon.mainhand boxhead:hand_cannon_idle
scoreboard players remove @a[scores={bh_anim=1..}] bh_anim 1
