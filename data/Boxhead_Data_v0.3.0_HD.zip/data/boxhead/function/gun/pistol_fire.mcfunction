# One atomic shot transaction. If this action was stale in D.A.I.'s queue,
# its runtime keybind_pressed condition prevents this function from running at all.
scoreboard players add @s bh_fire_cd 0
scoreboard players set @s bh_shot 0
execute if score @s bh_fire_cd matches 0 store result score @s bh_shot run clear @s boxhead:light_round 0
execute if score @s bh_fire_cd matches 0 if score @s bh_shot matches 1.. run function boxhead:gun/pistol_fire_loaded
execute if score @s bh_fire_cd matches 0 if score @s bh_shot matches 0 run function boxhead:gun/dry_fire
