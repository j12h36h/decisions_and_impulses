execute if entity @s[tag=bh_barrier_x] run fill ~-1 ~ ~ ~1 ~2 ~ air
execute if entity @s[tag=bh_barrier_z] run fill ~ ~ ~-1 ~ ~2 ~1 air
tag @s remove bh_barrier_active
tag @s remove bh_reinforced
scoreboard players set @s bh_barrier 0
playsound minecraft:block.wood.break block @a ~ ~ ~ 0.8 0.7
