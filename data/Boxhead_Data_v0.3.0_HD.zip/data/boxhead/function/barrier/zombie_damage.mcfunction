execute as @e[type=boxhead:zombie] at @s as @e[type=minecraft:marker,tag=bh_barrier_active,distance=..4,sort=nearest,limit=1] run scoreboard players remove @s bh_barrier 8
execute as @e[type=boxhead:mangled] at @s as @e[type=minecraft:marker,tag=bh_barrier_active,distance=..4,sort=nearest,limit=1] run scoreboard players remove @s bh_barrier 6
execute as @e[type=boxhead:mutant] at @s as @e[type=minecraft:marker,tag=bh_barrier_active,distance=..4.5,sort=nearest,limit=1] run scoreboard players remove @s bh_barrier 13
execute as @e[type=boxhead:giant] at @s as @e[type=minecraft:marker,tag=bh_barrier_active,distance=..5.5,sort=nearest,limit=1] run scoreboard players remove @s bh_barrier 42
