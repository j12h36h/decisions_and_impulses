scoreboard players set @s bh_barrier 180
scoreboard players set @s bh_bmax 180
tag @s add bh_barrier_active
tag @s remove bh_reinforced
execute if entity @s[tag=bh_barrier_x] run fill ~-1 ~ ~ ~1 ~2 ~ minecraft:oak_planks
execute if entity @s[tag=bh_barrier_z] run fill ~ ~ ~-1 ~ ~2 ~1 minecraft:oak_planks
