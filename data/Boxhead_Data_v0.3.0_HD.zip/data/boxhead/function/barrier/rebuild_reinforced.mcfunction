scoreboard players set @s bh_barrier 300
scoreboard players set @s bh_bmax 300
tag @s add bh_barrier_active
tag @s add bh_reinforced
execute if entity @s[tag=bh_barrier_x] run fill ~-1 ~ ~ ~1 ~2 ~ minecraft:dark_oak_planks
execute if entity @s[tag=bh_barrier_z] run fill ~ ~ ~-1 ~ ~2 ~1 minecraft:dark_oak_planks
