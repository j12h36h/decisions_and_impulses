execute if entity @s[tag=bh_barrier_x] run fill ~-1 ~ ~ ~1 ~2 ~ air
execute if entity @s[tag=bh_barrier_x] run setblock ~-1 ~1 ~ minecraft:oak_planks
execute if entity @s[tag=bh_barrier_x] run setblock ~1 ~1 ~ minecraft:oak_planks
execute if entity @s[tag=bh_barrier_z] run fill ~ ~ ~-1 ~ ~2 ~1 air
execute if entity @s[tag=bh_barrier_z] run setblock ~ ~1 ~-1 minecraft:oak_planks
execute if entity @s[tag=bh_barrier_z] run setblock ~ ~1 ~1 minecraft:oak_planks
