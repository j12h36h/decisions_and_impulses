execute if score @s bh_barrier matches ..0 run function boxhead:barrier/break
execute if entity @s[tag=bh_barrier_active] if score @s bh_barrier matches 1..60 run function boxhead:barrier/stage_low
execute if entity @s[tag=bh_barrier_active] if score @s bh_barrier matches 61..120 run function boxhead:barrier/stage_mid
