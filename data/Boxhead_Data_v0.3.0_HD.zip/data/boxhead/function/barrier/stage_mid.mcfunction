execute if entity @s[tag=bh_barrier_x] run setblock ~ ~1 ~ air
execute if entity @s[tag=bh_barrier_z] run setblock ~ ~1 ~ air
