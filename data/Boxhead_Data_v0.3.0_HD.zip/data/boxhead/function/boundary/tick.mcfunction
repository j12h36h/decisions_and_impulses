execute as @a[tag=bh_player,gamemode=!spectator] store result score @s bh_y run data get entity @s Pos[1] 1
execute as @a[tag=bh_player,gamemode=!spectator,scores={bh_y=..39}] run kill @s
