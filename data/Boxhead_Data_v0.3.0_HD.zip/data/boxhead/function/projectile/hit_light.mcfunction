tag @s add bh_proj_done
damage @e[tag=bh_hit_target,sort=nearest,limit=1] 5 minecraft:generic by @a[tag=bh_player,sort=nearest,limit=1]
execute at @e[tag=bh_hit_target,sort=nearest,limit=1] run particle minecraft:damage_indicator ~ ~0.95 ~ 0.16 0.28 0.16 0.05 4 force @a[distance=..40]
execute at @e[tag=bh_hit_target,sort=nearest,limit=1] run playsound minecraft:entity.player.attack.crit player @a[distance=..32] ~ ~ ~ 0.45 1.45
tag @e[tag=bh_hit_target] remove bh_hit_target
