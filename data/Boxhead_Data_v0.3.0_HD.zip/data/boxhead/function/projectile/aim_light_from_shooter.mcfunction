data modify entity @e[type=boxhead:bullet_light_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:bullet_light_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] add bh_aimed
