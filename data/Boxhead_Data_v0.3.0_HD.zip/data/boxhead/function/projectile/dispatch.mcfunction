# Runs as one already-selected Boxhead projectile.
execute if entity @s[type=boxhead:bullet_light_entity] run function boxhead:projectile/light_tick
execute if entity @s[type=boxhead:bullet_heavy_entity] run function boxhead:projectile/heavy_tick
execute if entity @s[type=boxhead:pellet_entity] run function boxhead:projectile/pellet_tick
