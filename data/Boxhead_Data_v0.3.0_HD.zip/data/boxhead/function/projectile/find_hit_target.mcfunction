# Minecraft distance selectors use the entity origin (feet for these mobs), not the visible body.
# Shift the projectile down by each archetype's half-height and use a body-sized sphere.
tag @e[tag=bh_hit_target] remove bh_hit_target
execute positioned ~ ~-1.45 ~ run tag @e[type=boxhead:giant,tag=bh_infected,sort=nearest,limit=1,distance=..1.68] add bh_hit_target
execute unless entity @e[tag=bh_hit_target] positioned ~ ~-1.025 ~ run tag @e[type=boxhead:mutant,tag=bh_infected,sort=nearest,limit=1,distance=..1.16] add bh_hit_target
execute unless entity @e[tag=bh_hit_target] positioned ~ ~-0.95 ~ run tag @e[type=boxhead:zombie,tag=bh_infected,sort=nearest,limit=1,distance=..1.06] add bh_hit_target
execute unless entity @e[tag=bh_hit_target] positioned ~ ~-0.425 ~ run tag @e[type=boxhead:mangled,tag=bh_infected,sort=nearest,limit=1,distance=..0.68] add bh_hit_target
