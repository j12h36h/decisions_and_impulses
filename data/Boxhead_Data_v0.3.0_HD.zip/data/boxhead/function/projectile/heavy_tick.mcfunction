execute unless entity @s[tag=bh_proj_done] run function boxhead:projectile/heavy_step
execute unless entity @s[tag=bh_proj_done] run function boxhead:projectile/heavy_step
execute unless entity @s[tag=bh_proj_done] run function boxhead:projectile/heavy_step
execute unless entity @s[tag=bh_proj_done] run function boxhead:projectile/heavy_step
execute unless entity @s[tag=bh_proj_done] run function boxhead:projectile/heavy_step
execute unless entity @s[tag=bh_proj_done] run function boxhead:projectile/heavy_step
execute unless entity @s[tag=bh_proj_done] run function boxhead:projectile/heavy_step
