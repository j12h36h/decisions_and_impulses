# Boxhead v0.3.0 projectile runtime.
# Pistol / Hand Cannon / Shotgun now create, tag and aim their Boxhead carriers directly
# in the fire functions, so the old per-type initialization and aim-fallback world scans
# are no longer required.

scoreboard players add @e[tag=bh_projectile] bh_proj_age 1

# One global projectile selection; type-specific movement is dispatched locally from @s.
execute as @e[tag=bh_projectile,tag=bh_aimed,tag=!bh_proj_done] at @s run function boxhead:projectile/dispatch

# Hard cleanup: arena-scale projectiles never need to live longer than this.
tag @e[tag=bh_projectile,scores={bh_proj_age=31..}] add bh_proj_done
kill @e[tag=bh_projectile,tag=bh_proj_done]
tag @e[tag=bh_hit_target] remove bh_hit_target
