# server_projectile_spawn places the carrier at the correctly offset muzzle position,
# but native DAI carrier Rotation defaults to world-forward. Copy the nearby shooter's
# actual yaw/pitch once, before the Boxhead movement loop advances the projectile.
execute if entity @a[tag=bh_player,sort=nearest,limit=1,distance=..3] run data modify entity @s Rotation set from entity @a[tag=bh_player,sort=nearest,limit=1,distance=..3] Rotation
execute if entity @a[tag=bh_player,sort=nearest,limit=1,distance=..3] run tag @s add bh_aimed
