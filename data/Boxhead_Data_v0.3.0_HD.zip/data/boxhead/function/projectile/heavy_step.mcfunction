execute at @s run tp @s ^ ^ ^0.60
execute at @s unless entity @s[tag=bh_proj_done] run function boxhead:projectile/find_hit_target
execute at @s unless entity @s[tag=bh_proj_done] if entity @e[tag=bh_hit_target,limit=1] run function boxhead:projectile/hit_heavy
execute at @s unless entity @s[tag=bh_proj_done] unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run tag @s add bh_proj_done
