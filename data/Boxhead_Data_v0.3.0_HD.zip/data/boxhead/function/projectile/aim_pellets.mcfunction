# Apply a simple eight-pellet Boxhead spread around the shooter's yaw/pitch.
# This is run as the firing player immediately after server_projectile_spawn.
# Each pellet first inherits the player Rotation, then receives a small relative yaw/pitch offset.

data modify entity @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] add bh_spread_1
execute as @e[type=boxhead:pellet_entity,tag=bh_spread_1,sort=nearest,limit=1,distance=..3] at @s run tp @s ~ ~ ~ ~-5 ~-2
tag @e[type=boxhead:pellet_entity,tag=bh_spread_1] add bh_aimed
tag @e[type=boxhead:pellet_entity,tag=bh_spread_1] remove bh_spread_1

data modify entity @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] add bh_spread_2
execute as @e[type=boxhead:pellet_entity,tag=bh_spread_2,sort=nearest,limit=1,distance=..3] at @s run tp @s ~ ~ ~ ~5 ~-2
tag @e[type=boxhead:pellet_entity,tag=bh_spread_2] add bh_aimed
tag @e[type=boxhead:pellet_entity,tag=bh_spread_2] remove bh_spread_2

data modify entity @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] add bh_spread_3
execute as @e[type=boxhead:pellet_entity,tag=bh_spread_3,sort=nearest,limit=1,distance=..3] at @s run tp @s ~ ~ ~ ~-3 ~2
tag @e[type=boxhead:pellet_entity,tag=bh_spread_3] add bh_aimed
tag @e[type=boxhead:pellet_entity,tag=bh_spread_3] remove bh_spread_3

data modify entity @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] add bh_spread_4
execute as @e[type=boxhead:pellet_entity,tag=bh_spread_4,sort=nearest,limit=1,distance=..3] at @s run tp @s ~ ~ ~ ~3 ~2
tag @e[type=boxhead:pellet_entity,tag=bh_spread_4] add bh_aimed
tag @e[type=boxhead:pellet_entity,tag=bh_spread_4] remove bh_spread_4

data modify entity @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] add bh_spread_5
execute as @e[type=boxhead:pellet_entity,tag=bh_spread_5,sort=nearest,limit=1,distance=..3] at @s run tp @s ~ ~ ~ ~-6 ~1
tag @e[type=boxhead:pellet_entity,tag=bh_spread_5] add bh_aimed
tag @e[type=boxhead:pellet_entity,tag=bh_spread_5] remove bh_spread_5

data modify entity @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] add bh_spread_6
execute as @e[type=boxhead:pellet_entity,tag=bh_spread_6,sort=nearest,limit=1,distance=..3] at @s run tp @s ~ ~ ~ ~6 ~1
tag @e[type=boxhead:pellet_entity,tag=bh_spread_6] add bh_aimed
tag @e[type=boxhead:pellet_entity,tag=bh_spread_6] remove bh_spread_6

data modify entity @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] add bh_spread_7
execute as @e[type=boxhead:pellet_entity,tag=bh_spread_7,sort=nearest,limit=1,distance=..3] at @s run tp @s ~ ~ ~ ~-2 ~-4
tag @e[type=boxhead:pellet_entity,tag=bh_spread_7] add bh_aimed
tag @e[type=boxhead:pellet_entity,tag=bh_spread_7] remove bh_spread_7

data modify entity @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] Rotation set from entity @s Rotation
tag @e[type=boxhead:pellet_entity,tag=dai_projectile,tag=!bh_aimed,sort=nearest,limit=1,distance=..3] add bh_spread_8
execute as @e[type=boxhead:pellet_entity,tag=bh_spread_8,sort=nearest,limit=1,distance=..3] at @s run tp @s ~ ~ ~ ~2 ~-4
tag @e[type=boxhead:pellet_entity,tag=bh_spread_8] add bh_aimed
tag @e[type=boxhead:pellet_entity,tag=bh_spread_8] remove bh_spread_8
