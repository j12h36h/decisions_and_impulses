summon minecraft:marker -28 65 -28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 28 73 28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -28 81 28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 28 89 -28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 97 -28 {Tags:["bh_runtime_marker","bh_zspawn"]}
