summon minecraft:marker -58 64 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 58 64 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 64 -58 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 64 58 {Tags:["bh_runtime_marker","bh_zspawn"]}
