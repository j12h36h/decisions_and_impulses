summon minecraft:marker -54 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 54 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 -54 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 54 {Tags:["bh_runtime_marker","bh_zspawn"]}
