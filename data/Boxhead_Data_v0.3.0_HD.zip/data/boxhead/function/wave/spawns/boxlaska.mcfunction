summon minecraft:marker -45 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 45 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 -45 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 45 {Tags:["bh_runtime_marker","bh_zspawn"]}
