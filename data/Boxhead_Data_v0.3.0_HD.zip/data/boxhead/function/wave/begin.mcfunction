function boxhead:wave/ensure_spawns
execute if score #game_mode bh_state matches 2 as @a run function boxhead:player/respawn_waiting
scoreboard players set #budget bh_state 8
scoreboard players operation #tmp bh_state = #wave bh_state
scoreboard players operation #tmp bh_state *= #two bh_state
scoreboard players operation #budget bh_state += #tmp bh_state
scoreboard players set #spawn_timer bh_state 0
scoreboard players set #phase bh_state 2
title @a title {"text":"WAVE","color":"red","bold":true}
title @a subtitle [{"text":"Wave ","color":"white"},{"score":{"name":"#wave","objective":"bh_state"},"color":"gold","bold":true}]
execute as @a run function boxhead:ui/status
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.18 1.85
particle minecraft:smoke ~ ~1 ~ 0.25 0.25 0.25 0.01 10 force @a
