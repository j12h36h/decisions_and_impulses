scoreboard players set #alive bh_state 0
execute as @e[tag=bh_infected] run scoreboard players add #alive bh_state 1
execute if score #phase bh_state matches 3 if score #budget bh_state matches ..0 if score #alive bh_state matches 0 run function boxhead:wave/complete
