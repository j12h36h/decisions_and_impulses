# Deterministic, data-owned infinite wave director.
execute if score #run_started bh_state matches 1 if score #phase bh_state matches 0 run function boxhead:wave/recover
execute if score #run_started bh_state matches 1 if score #phase bh_state matches 1 run function boxhead:wave/intermission_tick
execute if score #run_started bh_state matches 1 if score #phase bh_state matches 2 run function boxhead:wave/spawning_tick
execute if score #run_started bh_state matches 1 if score #phase bh_state matches 3 run function boxhead:wave/monitor
