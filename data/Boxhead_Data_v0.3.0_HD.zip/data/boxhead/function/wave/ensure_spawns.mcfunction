# Remove invalid/migrated spawn sockets that are embedded inside a solid block.
# This repairs v0.1.6 The Space worlds whose sockets were accidentally placed in the Y=64 floor.
execute as @e[type=minecraft:marker,tag=bh_zspawn] at @s unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:cave_air unless block ~ ~ ~ minecraft:void_air run kill @s

# Recreate the map's spawn sockets whenever cleanup/migration removed all of them.
execute unless entity @e[type=minecraft:marker,tag=bh_zspawn] if score #map_type bh_state matches 1 run function boxhead:wave/spawns/the_space
execute unless entity @e[type=minecraft:marker,tag=bh_zspawn] if score #map_type bh_state matches 2 run function boxhead:wave/spawns/box_town
execute unless entity @e[type=minecraft:marker,tag=bh_zspawn] if score #map_type bh_state matches 3 run function boxhead:wave/spawns/sky_scraper
execute unless entity @e[type=minecraft:marker,tag=bh_zspawn] if score #map_type bh_state matches 4 run function boxhead:wave/spawns/village_box
execute unless entity @e[type=minecraft:marker,tag=bh_zspawn] if score #map_type bh_state matches 5 run function boxhead:wave/spawns/boxlaska
