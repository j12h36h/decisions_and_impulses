function boxhead:wave/ensure_spawns
scoreboard players add #spawn_serial bh_state 1
scoreboard players set #spawned bh_state 0
scoreboard players operation #pick bh_state = #spawn_serial bh_state
scoreboard players operation #pick bh_state %= #thirteen bh_state
execute if score #wave bh_state matches 12.. if score #budget bh_state matches 10.. if score #pick bh_state matches 0 run function boxhead:enemy/spawn/giant
scoreboard players operation #pick bh_state = #spawn_serial bh_state
scoreboard players operation #pick bh_state %= #five bh_state
execute if score #spawned bh_state matches 0 if score #wave bh_state matches 6.. if score #budget bh_state matches 4.. if score #pick bh_state matches 0 run function boxhead:enemy/spawn/mutant
scoreboard players operation #pick bh_state = #spawn_serial bh_state
scoreboard players operation #pick bh_state %= #three bh_state
execute if score #spawned bh_state matches 0 if score #wave bh_state matches 3.. if score #budget bh_state matches 2.. if score #pick bh_state matches 0 run function boxhead:enemy/spawn/mangled
execute if score #spawned bh_state matches 0 if score #budget bh_state matches 1.. run function boxhead:enemy/spawn/zombie
execute if score #spawned bh_state matches 1 if score #budget bh_state matches 1.. run scoreboard players set #spawn_timer bh_state 5
execute if score #spawned bh_state matches 0 if score #budget bh_state matches 1.. run scoreboard players set #spawn_timer bh_state 20
execute if score #budget bh_state matches ..0 run scoreboard players set #phase bh_state 3
