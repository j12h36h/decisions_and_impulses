scoreboard players operation #checkpoint bh_state = #wave bh_state
scoreboard players add #wave bh_state 1
scoreboard players set #phase bh_state 1
scoreboard players set #intermission bh_state 100
scoreboard players set #spawn_timer bh_state 0
scoreboard players add @a[tag=bh_player,gamemode=!spectator] bh_money 50
title @a title {"text":"WAVE CLEARED","color":"green","bold":true}
title @a subtitle {"text":"+$50 survival bonus","color":"gold"}
title @a actionbar {"text":"Next wave in 5 seconds...","color":"yellow"}
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 0.50 1.25
