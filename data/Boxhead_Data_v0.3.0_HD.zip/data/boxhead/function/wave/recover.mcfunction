scoreboard players set #phase bh_state 1
scoreboard players set #intermission bh_state 40
scoreboard players set #spawn_timer bh_state 0
scoreboard players set #director_pending bh_state 0
title @a actionbar {"text":"Wave director recovered — next wave in 2 seconds...","color":"yellow"}
