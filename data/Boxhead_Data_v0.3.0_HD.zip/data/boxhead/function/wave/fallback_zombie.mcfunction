# Emergency spawn locations are known-open gameplay cells for each generated map.
# This path runs only when the normal marker-based summon failed, preventing a wave
# from silently soft-locking forever because of one malformed/blocked spawn socket.
execute if score #map_type bh_state matches 1 positioned 0 65 14 run function boxhead:enemy/spawn/at/zombie
execute if score #spawned bh_state matches 0 if score #map_type bh_state matches 2 positioned 0 64 28 run function boxhead:enemy/spawn/at/zombie
execute if score #spawned bh_state matches 0 if score #map_type bh_state matches 3 positioned 20 65 20 run function boxhead:enemy/spawn/at/zombie
execute if score #spawned bh_state matches 0 if score #map_type bh_state matches 4 positioned 0 65 30 run function boxhead:enemy/spawn/at/zombie
execute if score #spawned bh_state matches 0 if score #map_type bh_state matches 5 positioned 0 65 30 run function boxhead:enemy/spawn/at/zombie
