function boxhead:wave/ensure_spawns
execute if score #spawn_timer bh_state matches 1.. run scoreboard players remove #spawn_timer bh_state 1
execute if score #spawn_timer bh_state matches ..0 run function boxhead:wave/spawn_step
