execute if score #intermission bh_state matches 1.. run scoreboard players remove #intermission bh_state 1
execute if score #intermission bh_state matches ..0 run function boxhead:wave/begin
