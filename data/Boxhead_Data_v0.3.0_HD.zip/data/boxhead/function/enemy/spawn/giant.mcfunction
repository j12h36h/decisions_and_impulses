scoreboard players set #spawned bh_state 0
execute as @e[type=minecraft:marker,tag=bh_zspawn,sort=random,limit=1] at @s run function boxhead:enemy/spawn/at/giant
