summon boxhead:giant ~ ~ ~ {Tags:["bh_infected","bh_new_infected"]}
execute if entity @e[type=boxhead:giant,tag=bh_new_infected,sort=nearest,limit=1,distance=..3] run team join bh_infected @e[type=boxhead:giant,tag=bh_new_infected,sort=nearest,limit=1,distance=..3]
execute if entity @e[type=boxhead:giant,tag=bh_new_infected,sort=nearest,limit=1,distance=..3] run scoreboard players remove #budget bh_state 10
execute if entity @e[type=boxhead:giant,tag=bh_new_infected,sort=nearest,limit=1,distance=..3] run scoreboard players set #spawned bh_state 1
execute if entity @e[type=boxhead:giant,tag=bh_new_infected,sort=nearest,limit=1,distance=..3] run particle minecraft:smoke ~ ~0.35 ~ 0.22 0.28 0.22 0.01 6 force @a[distance=..40]
execute if entity @e[type=boxhead:giant,tag=bh_new_infected,sort=nearest,limit=1,distance=..3] run playsound minecraft:entity.ravager.ambient hostile @a[distance=..32] ~ ~ ~ 0.18 0.95
tag @e[type=boxhead:giant,tag=bh_new_infected,distance=..3] remove bh_new_infected
