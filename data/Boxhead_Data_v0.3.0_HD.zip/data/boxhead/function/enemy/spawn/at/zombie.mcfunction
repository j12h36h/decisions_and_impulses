summon boxhead:zombie ~ ~ ~ {Tags:["bh_infected","bh_new_infected"]}
execute if entity @e[type=boxhead:zombie,tag=bh_new_infected,sort=nearest,limit=1,distance=..2] run team join bh_infected @e[type=boxhead:zombie,tag=bh_new_infected,sort=nearest,limit=1,distance=..2]
execute if entity @e[type=boxhead:zombie,tag=bh_new_infected,sort=nearest,limit=1,distance=..2] run scoreboard players remove #budget bh_state 1
execute if entity @e[type=boxhead:zombie,tag=bh_new_infected,sort=nearest,limit=1,distance=..2] run scoreboard players set #spawned bh_state 1
execute if entity @e[type=boxhead:zombie,tag=bh_new_infected,sort=nearest,limit=1,distance=..2] run particle minecraft:smoke ~ ~0.35 ~ 0.22 0.28 0.22 0.01 6 force @a[distance=..40]
execute if entity @e[type=boxhead:zombie,tag=bh_new_infected,sort=nearest,limit=1,distance=..2] run playsound minecraft:entity.zombie.ambient hostile @a[distance=..32] ~ ~ ~ 0.18 0.95
tag @e[type=boxhead:zombie,tag=bh_new_infected,distance=..2] remove bh_new_infected
