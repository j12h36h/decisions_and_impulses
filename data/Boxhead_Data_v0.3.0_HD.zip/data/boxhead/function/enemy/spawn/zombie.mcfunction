scoreboard players set #spawned bh_state 0
execute as @e[type=minecraft:marker,tag=bh_zspawn,sort=random,limit=1] at @s run function boxhead:enemy/spawn/at/zombie
execute if score #spawned bh_state matches 0 run function boxhead:wave/fallback_zombie
