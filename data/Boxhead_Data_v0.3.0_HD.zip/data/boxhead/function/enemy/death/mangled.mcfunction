execute if entity @a[tag=dai_entity_killer_context] run scoreboard players add @a[tag=dai_entity_killer_context] bh_money 20
execute if entity @a[tag=dai_entity_killer_context] run scoreboard players add @a[tag=dai_entity_killer_context] bh_kills 1
execute if entity @a[tag=dai_entity_killer_context] run title @a[tag=dai_entity_killer_context] actionbar {"text":"+$20","color":"gold"}
execute unless entity @a[tag=dai_entity_killer_context] as @a[sort=nearest,limit=1,distance=..64] run scoreboard players add @s bh_money 20
execute unless entity @a[tag=dai_entity_killer_context] as @a[sort=nearest,limit=1,distance=..64] run scoreboard players add @s bh_kills 1
particle minecraft:smoke ~ ~0.8 ~ 0.28 0.45 0.28 0.02 10 force @a[distance=..48]
playsound minecraft:entity.spider.death hostile @a[distance=..48] ~ ~ ~ 0.55 1.1
