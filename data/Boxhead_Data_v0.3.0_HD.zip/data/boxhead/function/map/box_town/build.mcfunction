kill @e[type=minecraft:marker,tag=bh_runtime_marker]
scoreboard players set #map_type bh_state 2
fill -62 62 -62 62 62 62 minecraft:stone
fill -60 63 -60 60 63 60 minecraft:grass_block
fill -60 63 -9 60 63 9 minecraft:gray_concrete
fill -9 63 -60 9 63 60 minecraft:gray_concrete
fill -60 64 -11 60 64 -10 minecraft:smooth_stone
fill -60 64 10 60 64 11 minecraft:smooth_stone
fill -11 64 -60 -10 64 60 minecraft:smooth_stone
fill 10 64 -60 11 64 60 minecraft:smooth_stone
fill -50 64 -48 -22 72 -24 minecraft:red_terracotta hollow
fill -49 64 -47 -23 64 -25 minecraft:smooth_stone
fill -40 64 -24 -34 67 -24 air
fill -48 66 -24 -44 68 -24 minecraft:glass
fill -28 66 -24 -24 68 -24 minecraft:glass
fill -49 73 -47 -23 73 -25 minecraft:white_concrete
setblock -36 68 -23 minecraft:redstone_lamp[lit=true]
fill -52 64 24 -30 70 46 minecraft:bricks hollow
fill -51 64 25 -31 64 45 minecraft:smooth_stone
fill 26 64 -50 50 70 -28 minecraft:light_gray_concrete hollow
fill 27 64 -49 49 64 -29 minecraft:smooth_stone
fill 28 64 26 52 70 50 minecraft:spruce_planks hollow
fill 29 64 27 51 64 49 minecraft:smooth_stone
fill -42 64 24 -38 66 24 air
fill 38 64 -28 42 66 -28 air
fill 38 64 26 42 66 26 air
setblock -18 64 -45 minecraft:lantern
setblock -18 64 -25 minecraft:lantern
setblock -18 64 25 minecraft:lantern
setblock -18 64 45 minecraft:lantern
setblock 18 64 -45 minecraft:lantern
setblock 18 64 -25 minecraft:lantern
setblock 18 64 25 minecraft:lantern
setblock 18 64 45 minecraft:lantern
summon minecraft:marker -58 64 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 58 64 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 64 -58 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 64 58 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -5 64 -5 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 5 64 5 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -5 64 5 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 5 64 -5 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -50 64 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 50 64 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 0 64 -50 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
summon minecraft:marker 0 64 50 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_barrier 180
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_bmax 180
fill -50 64 -1 -50 66 1 minecraft:oak_planks
fill 50 64 -1 50 66 1 minecraft:oak_planks
fill -1 64 -50 1 66 -50 minecraft:oak_planks
fill -1 64 50 1 66 50 minecraft:oak_planks
setworldspawn 0 65 0
tp @a 0 65 0
