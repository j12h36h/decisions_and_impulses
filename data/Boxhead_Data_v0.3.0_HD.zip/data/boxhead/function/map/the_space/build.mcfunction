kill @e[type=minecraft:marker,tag=bh_runtime_marker]
scoreboard players set #map_type bh_state 1
fill -58 63 -58 58 63 58 minecraft:smooth_quartz
fill -58 64 -58 58 64 58 minecraft:white_concrete
fill -58 69 -58 58 69 58 minecraft:white_concrete
fill -58 65 -58 -58 68 58 minecraft:white_concrete
fill 58 65 -58 58 68 58 minecraft:white_concrete
fill -57 65 -58 57 68 -58 minecraft:white_concrete
fill -57 65 58 57 68 58 minecraft:white_concrete
fill -52 64 -52 0 68 52 air
fill 1 64 -52 52 68 52 air
fill -56 64 -4 -52 67 4 air
fill 52 64 -4 56 67 4 air
fill -4 64 -56 4 67 -52 air
fill -4 64 52 4 67 56 air
fill -36 64 -46 -36 68 46 minecraft:white_concrete
fill -18 64 -46 -18 68 46 minecraft:white_concrete
fill 18 64 -46 18 68 46 minecraft:white_concrete
fill 36 64 -46 36 68 46 minecraft:white_concrete
fill -46 64 -36 46 68 -36 minecraft:white_concrete
fill -46 64 -18 46 68 -18 minecraft:white_concrete
fill -46 64 18 46 68 18 minecraft:white_concrete
fill -46 64 36 46 68 36 minecraft:white_concrete
fill -36 64 -30 -36 66 -26 air
fill -36 64 6 -36 66 10 air
fill -18 64 -10 -18 66 -6 air
fill -18 64 26 -18 66 30 air
fill 18 64 -30 18 66 -26 air
fill 18 64 6 18 66 10 air
fill 36 64 -10 36 66 -6 air
fill 36 64 26 36 66 30 air
fill -30 64 -36 -26 66 -36 air
fill 6 64 -36 10 66 -36 air
fill -10 64 -18 -6 66 -18 air
fill 26 64 -18 30 66 -18 air
fill -30 64 18 -26 66 18 air
fill 6 64 18 10 66 18 air
fill -10 64 36 -6 66 36 air
fill 26 64 36 30 66 36 air
setblock -48 63 -48 minecraft:sea_lantern
setblock -48 63 -32 minecraft:sea_lantern
setblock -48 63 -16 minecraft:sea_lantern
setblock -48 63 0 minecraft:sea_lantern
setblock -48 63 16 minecraft:sea_lantern
setblock -48 63 32 minecraft:sea_lantern
setblock -48 63 48 minecraft:sea_lantern
setblock -32 63 -48 minecraft:sea_lantern
setblock -32 63 -32 minecraft:sea_lantern
setblock -32 63 -16 minecraft:sea_lantern
setblock -32 63 0 minecraft:sea_lantern
setblock -32 63 16 minecraft:sea_lantern
setblock -32 63 32 minecraft:sea_lantern
setblock -32 63 48 minecraft:sea_lantern
setblock -16 63 -48 minecraft:sea_lantern
setblock -16 63 -32 minecraft:sea_lantern
setblock -16 63 -16 minecraft:sea_lantern
setblock -16 63 0 minecraft:sea_lantern
setblock -16 63 16 minecraft:sea_lantern
setblock -16 63 32 minecraft:sea_lantern
setblock -16 63 48 minecraft:sea_lantern
setblock 0 63 -48 minecraft:sea_lantern
setblock 0 63 -32 minecraft:sea_lantern
setblock 0 63 -16 minecraft:sea_lantern
setblock 0 63 0 minecraft:sea_lantern
setblock 0 63 16 minecraft:sea_lantern
setblock 0 63 32 minecraft:sea_lantern
setblock 0 63 48 minecraft:sea_lantern
setblock 16 63 -48 minecraft:sea_lantern
setblock 16 63 -32 minecraft:sea_lantern
setblock 16 63 -16 minecraft:sea_lantern
setblock 16 63 0 minecraft:sea_lantern
setblock 16 63 16 minecraft:sea_lantern
setblock 16 63 32 minecraft:sea_lantern
setblock 16 63 48 minecraft:sea_lantern
setblock 32 63 -48 minecraft:sea_lantern
setblock 32 63 -32 minecraft:sea_lantern
setblock 32 63 -16 minecraft:sea_lantern
setblock 32 63 0 minecraft:sea_lantern
setblock 32 63 16 minecraft:sea_lantern
setblock 32 63 32 minecraft:sea_lantern
setblock 32 63 48 minecraft:sea_lantern
setblock 48 63 -48 minecraft:sea_lantern
setblock 48 63 -32 minecraft:sea_lantern
setblock 48 63 -16 minecraft:sea_lantern
setblock 48 63 0 minecraft:sea_lantern
setblock 48 63 16 minecraft:sea_lantern
setblock 48 63 32 minecraft:sea_lantern
setblock 48 63 48 minecraft:sea_lantern
summon minecraft:marker -54 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 54 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 -54 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 54 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -8 64 -8 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 8 64 8 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -8 64 8 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 8 64 -8 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -48 64 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 48 64 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 0 64 -48 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
summon minecraft:marker 0 64 48 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_barrier 180
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_bmax 180
fill -48 64 -1 -48 66 1 minecraft:oak_planks
fill 48 64 -1 48 66 1 minecraft:oak_planks
fill -1 64 -48 1 66 -48 minecraft:oak_planks
fill -1 64 48 1 66 48 minecraft:oak_planks
setworldspawn 0 65 0
tp @a 0 65 0
