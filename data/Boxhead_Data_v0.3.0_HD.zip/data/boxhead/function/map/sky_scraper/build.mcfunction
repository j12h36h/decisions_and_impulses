kill @e[type=minecraft:marker,tag=bh_runtime_marker]
scoreboard players set #map_type bh_state 3
fill -34 64 -34 34 64 34 minecraft:smooth_stone
fill -34 72 -34 34 72 34 minecraft:smooth_stone
fill -34 80 -34 34 80 34 minecraft:smooth_stone
fill -34 88 -34 34 88 34 minecraft:smooth_stone
fill -34 96 -34 34 96 34 minecraft:smooth_stone
fill -34 104 -34 34 104 34 minecraft:smooth_stone
fill -34 65 -34 -34 103 34 minecraft:tinted_glass
fill 34 65 -34 34 103 34 minecraft:tinted_glass
fill -33 65 -34 33 103 -34 minecraft:tinted_glass
fill -33 65 34 33 103 34 minecraft:tinted_glass
fill -4 65 -4 4 71 4 minecraft:polished_deepslate hollow
fill -1 65 -4 1 68 -4 air
fill -12 65 8 -11 65 12 minecraft:quartz_stairs[facing=west]
fill -10 66 8 -9 66 12 minecraft:quartz_stairs[facing=west]
fill -8 67 8 -7 67 12 minecraft:quartz_stairs[facing=west]
fill -6 68 8 -5 68 12 minecraft:quartz_stairs[facing=west]
fill -4 69 8 -3 69 12 minecraft:quartz_stairs[facing=west]
fill -2 70 8 -1 70 12 minecraft:quartz_stairs[facing=west]
fill 0 71 8 1 71 12 minecraft:quartz_stairs[facing=west]
fill -4 73 -4 4 79 4 minecraft:polished_deepslate hollow
fill -1 73 -4 1 76 -4 air
fill -12 73 8 -11 73 12 minecraft:quartz_stairs[facing=west]
fill -10 74 8 -9 74 12 minecraft:quartz_stairs[facing=west]
fill -8 75 8 -7 75 12 minecraft:quartz_stairs[facing=west]
fill -6 76 8 -5 76 12 minecraft:quartz_stairs[facing=west]
fill -4 77 8 -3 77 12 minecraft:quartz_stairs[facing=west]
fill -2 78 8 -1 78 12 minecraft:quartz_stairs[facing=west]
fill 0 79 8 1 79 12 minecraft:quartz_stairs[facing=west]
fill -4 81 -4 4 87 4 minecraft:polished_deepslate hollow
fill -1 81 -4 1 84 -4 air
fill -12 81 8 -11 81 12 minecraft:quartz_stairs[facing=west]
fill -10 82 8 -9 82 12 minecraft:quartz_stairs[facing=west]
fill -8 83 8 -7 83 12 minecraft:quartz_stairs[facing=west]
fill -6 84 8 -5 84 12 minecraft:quartz_stairs[facing=west]
fill -4 85 8 -3 85 12 minecraft:quartz_stairs[facing=west]
fill -2 86 8 -1 86 12 minecraft:quartz_stairs[facing=west]
fill 0 87 8 1 87 12 minecraft:quartz_stairs[facing=west]
fill -4 89 -4 4 95 4 minecraft:polished_deepslate hollow
fill -1 89 -4 1 92 -4 air
fill -12 89 8 -11 89 12 minecraft:quartz_stairs[facing=west]
fill -10 90 8 -9 90 12 minecraft:quartz_stairs[facing=west]
fill -8 91 8 -7 91 12 minecraft:quartz_stairs[facing=west]
fill -6 92 8 -5 92 12 minecraft:quartz_stairs[facing=west]
fill -4 93 8 -3 93 12 minecraft:quartz_stairs[facing=west]
fill -2 94 8 -1 94 12 minecraft:quartz_stairs[facing=west]
fill 0 95 8 1 95 12 minecraft:quartz_stairs[facing=west]
fill -4 97 -4 4 103 4 minecraft:polished_deepslate hollow
fill -1 97 -4 1 100 -4 air
fill -12 97 8 -11 97 12 minecraft:quartz_stairs[facing=west]
fill -10 98 8 -9 98 12 minecraft:quartz_stairs[facing=west]
fill -8 99 8 -7 99 12 minecraft:quartz_stairs[facing=west]
fill -6 100 8 -5 100 12 minecraft:quartz_stairs[facing=west]
fill -4 101 8 -3 101 12 minecraft:quartz_stairs[facing=west]
fill -2 102 8 -1 102 12 minecraft:quartz_stairs[facing=west]
fill 0 103 8 1 103 12 minecraft:quartz_stairs[facing=west]
fill -27 64 -18 -8 64 4 minecraft:light_blue_concrete
fill -26 64 -17 -9 64 3 minecraft:water
fill 8 65 -20 28 69 8 minecraft:white_concrete hollow
fill 12 65 -20 16 67 -20 air
fill -28 73 -27 -20 78 -10 minecraft:smooth_quartz hollow
fill -25 73 -10 -23 75 -10 air
fill -14 73 -27 -6 78 -10 minecraft:smooth_quartz hollow
fill -11 73 -10 -9 75 -10 air
fill 8 73 -27 16 78 -10 minecraft:smooth_quartz hollow
fill 11 73 -10 13 75 -10 air
fill 22 73 -27 30 78 -10 minecraft:smooth_quartz hollow
fill 25 73 -10 27 75 -10 air
fill -28 81 -28 28 86 28 minecraft:white_concrete hollow
fill -26 81 -26 26 81 26 minecraft:light_gray_concrete
fill -8 82 -8 8 85 8 minecraft:cyan_stained_glass hollow
setblock 0 82 0 minecraft:beacon
fill -24 82 18 -10 84 24 minecraft:iron_block hollow
fill 10 82 18 24 84 24 minecraft:iron_block hollow
fill -34 89 -34 -20 95 -20 air
fill 20 89 20 34 95 34 air
fill -18 89 -18 18 94 18 minecraft:gray_concrete hollow
fill -26 97 -26 26 102 26 minecraft:quartz_block hollow
fill -3 97 26 3 100 26 air
fill -3 103 -3 3 104 3 air
fill -34 105 -34 34 106 -34 minecraft:iron_bars
fill -34 105 34 34 106 34 minecraft:iron_bars
fill -34 105 -33 -34 106 33 minecraft:iron_bars
fill 34 105 -33 34 106 33 minecraft:iron_bars
summon minecraft:marker -28 65 -28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 28 73 28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -28 81 28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 28 89 -28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 97 -28 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -8 65 20 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 8 65 20 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 0 73 0 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 0 97 0 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -24 65 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 24 73 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 0 81 -24 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
summon minecraft:marker 0 89 24 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_barrier 180
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_bmax 180
fill -24 65 -1 -24 67 1 minecraft:oak_planks
fill 24 73 -1 24 75 1 minecraft:oak_planks
fill -1 81 -24 1 83 -24 minecraft:oak_planks
fill -1 89 24 1 91 24 minecraft:oak_planks
setworldspawn 0 65 22
tp @a 0 65 22
execute as @a run attribute @s minecraft:gravity base set 0.04
title @a actionbar {"text":"SKY SCRAPER — dimensional gravity: 50%","color":"aqua"}
