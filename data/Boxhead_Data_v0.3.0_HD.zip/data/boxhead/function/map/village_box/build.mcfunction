kill @e[type=minecraft:marker,tag=bh_runtime_marker]
scoreboard players set #map_type bh_state 4
fill -54 59 -54 0 61 54 minecraft:stone
fill 1 59 -54 54 61 54 minecraft:stone
fill -50 62 -50 50 63 50 minecraft:dirt
fill -48 64 -48 48 64 48 minecraft:grass_block
fill -48 59 -48 -36 64 -36 air
fill 36 59 -48 48 64 -36 air
fill -48 59 36 -36 64 48 air
fill 36 59 36 48 64 48 air
fill -48 64 -3 48 64 3 minecraft:dirt_path
fill -3 64 -48 3 64 48 minecraft:dirt_path
fill -38 65 -34 -24 70 -22 minecraft:oak_planks hollow
fill -39 71 -35 -23 71 -21 minecraft:spruce_planks
fill -33 65 -34 -30 67 -34 air
fill -36 67 -34 -34 68 -34 minecraft:glass
fill -12 65 -36 2 70 -24 minecraft:oak_planks hollow
fill -13 71 -37 3 71 -23 minecraft:spruce_planks
fill -7 65 -36 -4 67 -36 air
fill -10 67 -36 -8 68 -36 minecraft:glass
fill 18 65 -34 32 70 -22 minecraft:oak_planks hollow
fill 17 71 -35 33 71 -21 minecraft:spruce_planks
fill 23 65 -34 26 67 -34 air
fill 20 67 -34 22 68 -34 minecraft:glass
fill -38 65 18 -24 70 30 minecraft:oak_planks hollow
fill -39 71 17 -23 71 31 minecraft:spruce_planks
fill -33 65 18 -30 67 18 air
fill -36 67 18 -34 68 18 minecraft:glass
fill -10 65 20 4 70 32 minecraft:oak_planks hollow
fill -11 71 19 5 71 33 minecraft:spruce_planks
fill -5 65 20 -2 67 20 air
fill -8 67 20 -6 68 20 minecraft:glass
fill 20 65 18 34 70 30 minecraft:oak_planks hollow
fill 19 71 17 35 71 31 minecraft:spruce_planks
fill 25 65 18 28 67 18 air
fill 22 67 18 24 68 18 minecraft:glass
fill 20 64 -8 44 64 10 minecraft:farmland
fill 22 65 -6 42 65 -4 minecraft:wheat[age=7]
fill 22 65 0 42 65 2 minecraft:carrots[age=7]
fill -7 64 -7 7 64 7 minecraft:cobblestone
fill -4 65 -4 4 65 4 minecraft:water
setblock 0 66 0 minecraft:bell
fill -44 65 5 -44 69 5 minecraft:oak_log
fill -46 69 3 -42 72 7 minecraft:oak_leaves[persistent=true]
fill 44 65 -20 44 69 -20 minecraft:oak_log
fill 42 69 -22 46 72 -18 minecraft:oak_leaves[persistent=true]
fill 8 65 43 8 69 43 minecraft:oak_log
fill 6 69 41 10 72 45 minecraft:oak_leaves[persistent=true]
fill -20 65 44 -20 69 44 minecraft:oak_log
fill -22 69 42 -18 72 46 minecraft:oak_leaves[persistent=true]
summon minecraft:marker -45 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 45 65 0 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 -45 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker 0 65 45 {Tags:["bh_runtime_marker","bh_zspawn"]}
summon minecraft:marker -6 65 -6 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 6 65 6 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -6 65 6 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker 6 65 -6 {Tags:["bh_runtime_marker","bh_player_spawn"]}
summon minecraft:marker -40 65 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 40 65 0 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_z"]}
summon minecraft:marker 0 65 -40 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
summon minecraft:marker 0 65 40 {Tags:["bh_runtime_marker","bh_barrier_socket","bh_barrier_active","bh_barrier_x"]}
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_barrier 180
scoreboard players set @e[type=minecraft:marker,tag=bh_barrier_socket] bh_bmax 180
fill -40 65 -1 -40 67 1 minecraft:oak_planks
fill 40 65 -1 40 67 1 minecraft:oak_planks
fill -1 65 -40 1 67 -40 minecraft:oak_planks
fill -1 65 40 1 67 40 minecraft:oak_planks
setworldspawn 0 65 10
tp @a 0 65 10
