# Boxhead runtime scoreboards
scoreboard objectives add bh_money dummy
scoreboard objectives add bh_kills dummy
scoreboard objectives add bh_deaths deathCount
scoreboard objectives add bh_death_seen dummy
scoreboard objectives add bh_state dummy
scoreboard objectives add bh_barrier dummy
scoreboard objectives add bh_bmax dummy
scoreboard objectives add bh_anim dummy
scoreboard objectives add bh_y dummy
scoreboard objectives add bh_proj_age dummy
scoreboard objectives add bh_fire_cd dummy
scoreboard objectives add bh_shot dummy
scoreboard players set #one bh_state 1
scoreboard players set #two bh_state 2
scoreboard players set #three bh_state 3
scoreboard players set #four bh_state 4
scoreboard players set #five bh_state 5
scoreboard players set #ten bh_state 10
scoreboard players set #thirteen bh_state 13
scoreboard players set #twenty bh_state 20
execute unless score #director_pending bh_state matches -2147483648..2147483647 run scoreboard players set #director_pending bh_state 0

# Persistent director defaults. Missing fake-player scores must never stall startup.
execute unless score #run_started bh_state matches -2147483648..2147483647 run scoreboard players set #run_started bh_state 0
execute unless score #phase bh_state matches -2147483648..2147483647 run scoreboard players set #phase bh_state 0
execute unless score #wave bh_state matches -2147483648..2147483647 run scoreboard players set #wave bh_state 0
execute unless score #checkpoint bh_state matches -2147483648..2147483647 run scoreboard players set #checkpoint bh_state 1
execute unless score #intermission bh_state matches -2147483648..2147483647 run scoreboard players set #intermission bh_state 0
execute unless score #spawn_timer bh_state matches -2147483648..2147483647 run scoreboard players set #spawn_timer bh_state 0
execute unless score #spawn_serial bh_state matches -2147483648..2147483647 run scoreboard players set #spawn_serial bh_state 0
execute unless score #budget bh_state matches -2147483648..2147483647 run scoreboard players set #budget bh_state 0
execute unless score #alive bh_state matches -2147483648..2147483647 run scoreboard players set #alive bh_state 0
execute unless score #last_tick bh_state matches -2147483648..2147483647 run scoreboard players set #last_tick bh_state -1

# DAI 3.3 lifecycle recovery.
# Normal joins are initialized by the MAIN experience's on_first_join/on_join actions.
# This single load-time pass safely repairs players present during /reload without polling every tick.
execute as @a[tag=!bh_player] run function boxhead:player/initialize
execute if entity @a[tag=bh_player] run function boxhead:run/start_if_needed
