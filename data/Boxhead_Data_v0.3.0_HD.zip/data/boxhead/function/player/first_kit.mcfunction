give @s boxhead:pistol 1
give @s boxhead:light_round 48
scoreboard players set @s bh_money 250
title @s actionbar {"text":"Starter kit: Pistol + 48 rounds + $250","color":"gold"}
