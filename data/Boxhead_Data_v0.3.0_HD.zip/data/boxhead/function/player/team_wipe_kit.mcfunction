clear @s
give @s boxhead:pistol 1
give @s boxhead:light_round 48
