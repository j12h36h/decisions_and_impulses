# Detect a deathCount change even if the player has already immediate-respawned.
execute as @a unless score @s bh_death_seen = @s bh_deaths run function boxhead:player/on_death
