tp @s @e[type=minecraft:marker,tag=bh_player_spawn,sort=random,limit=1]
gamemode adventure @s
tag @s remove bh_waiting
tag @s remove bh_casual_dead
execute if score #map_type bh_state matches 3 run attribute @s minecraft:gravity base set 0.04
execute unless score #map_type bh_state matches 3 run attribute @s minecraft:gravity base set 0.08
