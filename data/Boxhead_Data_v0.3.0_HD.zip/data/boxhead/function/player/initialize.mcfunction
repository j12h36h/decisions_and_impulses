tag @s add bh_player
execute unless entity @s[gamemode=spectator] run gamemode adventure @s
scoreboard players add @s bh_money 0
scoreboard players add @s bh_kills 0
scoreboard players add @s bh_deaths 0
scoreboard players add @s bh_death_seen 0
execute if score #map_type bh_state matches 3 run attribute @s minecraft:gravity base set 0.04
execute unless score #map_type bh_state matches 3 run attribute @s minecraft:gravity base set 0.08
execute unless entity @s[tag=bh_initialized] run function boxhead:player/first_kit
tag @s add bh_initialized
