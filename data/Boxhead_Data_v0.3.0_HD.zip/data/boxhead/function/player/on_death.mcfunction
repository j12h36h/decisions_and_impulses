scoreboard players operation @s bh_death_seen = @s bh_deaths
tag @s add bh_player
execute if score #game_mode bh_state matches 1 run function boxhead:mode/last_breath/on_death
execute if score #game_mode bh_state matches 2 run function boxhead:mode/infinite_dead/on_death
execute if score #game_mode bh_state matches 3 run function boxhead:mode/casual_paradise/on_death
