# Boxhead v0.1.6: Minecraft's native function tick is the single authoritative
# runtime clock. Do NOT route this through D.A.I.'s action queue.
function boxhead:runtime/global_tick
