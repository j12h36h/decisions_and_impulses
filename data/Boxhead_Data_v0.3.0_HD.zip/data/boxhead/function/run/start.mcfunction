scoreboard players set #run_started bh_state 1
scoreboard players set #wave bh_state 1
scoreboard players set #checkpoint bh_state 1
scoreboard players set #phase bh_state 1
scoreboard players set #intermission bh_state 60
scoreboard players set #spawn_timer bh_state 0
scoreboard players set #director_pending bh_state 0
function boxhead:wave/ensure_spawns
title @a title {"text":"BOXHEAD","color":"red","bold":true}
title @a subtitle {"text":"Survive as long as you can.","color":"white"}
title @a actionbar {"text":"Wave 1 begins in 3 seconds...","color":"yellow"}
