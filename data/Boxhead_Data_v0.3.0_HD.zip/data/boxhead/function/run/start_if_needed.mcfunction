# Missing fake-player scores count as not started.
execute unless score #run_started bh_state matches 1.. run function boxhead:run/start
