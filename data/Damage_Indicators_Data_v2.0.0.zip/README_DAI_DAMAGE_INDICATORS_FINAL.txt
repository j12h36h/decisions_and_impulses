DAI Damage Indicators v2.0.0 Final
Minecraft Java 26.2 / DAI Engine 4.2

WHAT CHANGED
- DAI 4.2 datapack keybinding: Damage Indicator Customization (default V).
- Data-driven DAI customization screen with Default, Vanilla, Nether and End skins.
- Per-player skin preference via the persistent di_skin scoreboard.
- Optional Custom Resource Pack skin slot.
- Existing enable/disable/toggle functions remain available.

SKIN VALUES
0 Default (original v1.6.0 look)
1 Vanilla / Overworld grass style
2 Nether brick style
3 End stone style
4 Custom resource-pack style

RESOURCE PACK
Use the matching DAI_Damage_Indicators_Resource_v2.0.0_Final.zip for the themed bitmap fonts.
Without the resource pack, Default remains safe; themed font IDs require the companion resource pack.

CUSTOM SKIN API
The Custom slot renders font id: dai_damage_indicators:custom
A resource pack can override:
  assets/dai_damage_indicators/font/custom.json
  assets/dai_damage_indicators/textures/font/custom_digits.png
Keep the glyph order: 0123456789.-+
Place your custom pack ABOVE the included DAI Damage Indicators resource pack.
A starter template is shipped separately.
