tag @s add dai_di_display
scoreboard players set @s di_age 0
execute store result score @s di_tmp run data get storage dai_damage_indicators:runtime skin 1

execute if score @s di_tmp matches 1 run function dai_damage_indicators:display/skin/vanilla_heavy with storage dai_damage_indicators:runtime
execute if score @s di_tmp matches 2 run function dai_damage_indicators:display/skin/nether_heavy with storage dai_damage_indicators:runtime
execute if score @s di_tmp matches 3 run function dai_damage_indicators:display/skin/end_heavy with storage dai_damage_indicators:runtime
execute if score @s di_tmp matches 4 run function dai_damage_indicators:display/skin/custom_heavy with storage dai_damage_indicators:runtime
execute unless score @s di_tmp matches 1..4 run function dai_damage_indicators:display/skin/default_heavy with storage dai_damage_indicators:runtime
