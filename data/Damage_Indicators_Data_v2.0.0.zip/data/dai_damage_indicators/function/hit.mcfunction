# Minecraft's damage_dealt statistic is cumulative and stored in tenths of a
# health point. Split this tick's delta into a stable one-decimal value.
scoreboard players operation @s di_whole = @s di_delta
scoreboard players operation @s di_whole /= #ten di_const
scoreboard players operation @s di_dec = @s di_delta
scoreboard players operation @s di_dec %= #ten di_const

# Freeze the value into macro storage before the display is created.
execute store result storage dai_damage_indicators:runtime whole int 1 run scoreboard players get @s di_whole
execute store result storage dai_damage_indicators:runtime dec int 1 run scoreboard players get @s di_dec
execute store result storage dai_damage_indicators:runtime skin int 1 run scoreboard players get @s di_skin

# Keep attacker/victim scratch tags strictly scoped to this hit resolution.
tag @s add dai_di_attacker
tag @e[tag=dai_di_victim] remove dai_di_victim

# Resolve HurtTime once for nearby entities, then pin the nearest valid victim.
# DAI 4.2 native entities still expose normal living-entity HurtTime, so this
# remains compatible with vanilla, DAI-native, and other ordinary living targets.
scoreboard players set @e[distance=..8,tag=!dai_di_attacker,type=!minecraft:text_display] di_tmp 0
execute as @e[distance=..8,tag=!dai_di_attacker,type=!minecraft:text_display] store result score @s di_tmp run data get entity @s HurtTime 1
tag @e[distance=..8,tag=!dai_di_attacker,type=!minecraft:text_display,scores={di_tmp=1..},sort=nearest,limit=1] add dai_di_victim

# Only one severity route is executed. v1.5.0 repeated the same nearest-victim
# selector for all three tiers and again for all three fallback checks.
execute if score @s di_delta matches 1..39 run function dai_damage_indicators:display/route_light with storage dai_damage_indicators:runtime
execute if score @s di_delta matches 40..99 run function dai_damage_indicators:display/route_medium with storage dai_damage_indicators:runtime
execute if score @s di_delta matches 100.. run function dai_damage_indicators:display/route_heavy with storage dai_damage_indicators:runtime

tag @e[tag=dai_di_victim] remove dai_di_victim
tag @s remove dai_di_attacker
