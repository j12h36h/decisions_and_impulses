# DAI Damage Indicators v2.0.0 Final
# Minecraft Java 26.2 / DAI 4.2

scoreboard objectives add di_dealt minecraft.custom:minecraft.damage_dealt
scoreboard objectives add di_prev dummy
scoreboard objectives add di_delta dummy
scoreboard objectives add di_whole dummy
scoreboard objectives add di_dec dummy
scoreboard objectives add di_age dummy
scoreboard objectives add di_tmp dummy
scoreboard objectives add di_enable dummy
scoreboard objectives add di_skin dummy
scoreboard objectives add di_const dummy

scoreboard players set #ten di_const 10
scoreboard players set #display_clock di_const 0

# Force players to initialize from their CURRENT lifetime stat rather than
# showing all historic damage as one giant number after /reload.
tag @a remove dai_di_init

# Remove stale transient state from a previous load/reload.
tag @e[tag=dai_di_victim] remove dai_di_victim
tag @a remove dai_di_attacker
kill @e[type=minecraft:text_display,tag=dai_di_display]

tellraw @a [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'v2.0.0 Final loaded (DAI 4.2). Press the Damage Indicator Customization key to choose a skin.',color:'gray'}]
