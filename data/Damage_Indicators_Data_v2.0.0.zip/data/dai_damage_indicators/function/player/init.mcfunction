# Sync this player's rolling damage sample to the current lifetime statistic.
scoreboard players operation @s di_prev = @s di_dealt
scoreboard players set @s di_delta 0
scoreboard players set @s di_whole 0
scoreboard players set @s di_dec 0

# Preserve the player's indicator preference across /reload and reconnects.
# Older v1.3 worlds have no dai_di_disabled tag, so they remain enabled by default.
execute if entity @s[tag=dai_di_disabled] run scoreboard players set @s di_enable 0
execute unless entity @s[tag=dai_di_disabled] run scoreboard players set @s di_enable 1

tag @s add dai_di_init

# v2.0 skin preference. Existing scoreboard values survive reloads; new players
# default to 0 (the original v1.6 visual style).
execute unless score @s di_skin matches 0..4 run scoreboard players set @s di_skin 0
