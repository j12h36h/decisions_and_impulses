scoreboard players set @s di_skin 3
tellraw @s [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'Skin: End',color:'light_purple'}]
