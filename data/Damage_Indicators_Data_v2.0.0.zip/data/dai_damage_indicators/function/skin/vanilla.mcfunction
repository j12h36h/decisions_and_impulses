scoreboard players set @s di_skin 1
tellraw @s [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'Skin: Vanilla / Overworld',color:'green'}]
