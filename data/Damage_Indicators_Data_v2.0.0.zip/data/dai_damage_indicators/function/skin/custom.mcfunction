scoreboard players set @s di_skin 4
tellraw @s [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'Skin: Custom Resource Pack',color:'aqua'}]
