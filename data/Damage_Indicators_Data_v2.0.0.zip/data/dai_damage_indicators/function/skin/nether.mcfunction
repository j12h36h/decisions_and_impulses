scoreboard players set @s di_skin 2
tellraw @s [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'Skin: Nether',color:'dark_red'}]
