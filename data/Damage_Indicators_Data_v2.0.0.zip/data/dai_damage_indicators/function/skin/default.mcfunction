scoreboard players set @s di_skin 0
tellraw @s [{text:'[DAI Damage Indicators] ',color:'dark_red',bold:true},{text:'Skin: Default',color:'gray'}]
