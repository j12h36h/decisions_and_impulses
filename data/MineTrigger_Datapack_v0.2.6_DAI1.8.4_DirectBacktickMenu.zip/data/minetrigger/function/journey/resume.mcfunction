execute unless score @s wt_init matches 1 run function minetrigger:player/init
execute unless score #arena wt_world matches 2 run function minetrigger:world/ensure_training_sector
spawnpoint @s 0 -60 6
gamemode adventure @s
teleport @s 0.5 -60 6.5 180 0
effect give @s minecraft:resistance 5 4 true
effect give @s minecraft:slow_falling 5 0 true
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Agent link restored. Press ` to open the MineTrigger command interface.","color":"white"}]
