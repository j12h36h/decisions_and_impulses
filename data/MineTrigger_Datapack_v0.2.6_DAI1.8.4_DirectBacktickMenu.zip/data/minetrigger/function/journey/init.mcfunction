function minetrigger:player/init
execute unless score #arena wt_world matches 2 run function minetrigger:world/ensure_training_sector
spawnpoint @s 0 -60 6
teleport @s 0.5 -60 6.5 180 0
effect give @s minecraft:resistance 10 4 true
effect give @s minecraft:slow_falling 10 0 true
gamemode adventure @s
clear @s
kill @e[tag=wt_training_dummy]
summon minecraft:husk 24 -60 0 {CustomName:'{"text":"Training Trion Soldier","color":"aqua"}',PersistenceRequired:1b,NoAI:1b,Silent:1b,Tags:["wt_training_dummy"]}
summon minecraft:husk -24 -60 0 {CustomName:'{"text":"Training Trion Soldier","color":"aqua"}',PersistenceRequired:1b,NoAI:1b,Silent:1b,Tags:["wt_training_dummy"]}
summon minecraft:husk 0 -60 24 {CustomName:'{"text":"Training Trion Soldier","color":"aqua"}',PersistenceRequired:1b,NoAI:1b,Silent:1b,Tags:["wt_training_dummy"]}
summon minecraft:husk 0 -60 -24 {CustomName:'{"text":"Training Trion Soldier","color":"aqua"}',PersistenceRequired:1b,NoAI:1b,Silent:1b,Tags:["wt_training_dummy"]}
title @s title {"text":"BORDER","color":"aqua","bold":true}
title @s subtitle {"text":"Training Sector initialized","color":"white"}
tellraw @s [{"text":"[BORDER] ","color":"aqua","bold":true},{"text":"Press ` to open the MineTrigger command interface.","color":"white"}]
