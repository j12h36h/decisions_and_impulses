scoreboard players set @s wt_init 1
scoreboard players set @s wt_active 0
scoreboard players set @s wt_trion_max 100
scoreboard players set @s wt_trion 100
scoreboard players set @s wt_loadout 1
scoreboard players set @s wt_bagworm 0
scoreboard players set @s wt_chameleon 0
scoreboard players add @s wt_rank 0
advancement grant @s only minetrigger:state/border_agent
advancement grant @s only minetrigger:state/loadout_attacker
