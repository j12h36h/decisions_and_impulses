MineTrigger - Border Training Alpha v0.2.2
===============================================

Requires: Decisions & Impulses (D.A.I.) 1.8.3+
Recommended: MineTrigger Resource Pack v0.2.2
Namespace: minetrigger

MineTrigger is a D.A.I.-powered combat/ability experience inspired by trigger-based squad combat.
This alpha focuses on the playable Border Training loop and the systems needed to grow it into a full experience.

INSTALL
-------
1. Install D.A.I. 1.8.3 or newer.
2. Put MineTrigger_Datapack_v0.2.2.zip in the instance-level /datapacks folder.
3. Put MineTrigger_ResourcePack_v0.2.2.zip in /resourcepacks and enable it.
4. Restart/reload Minecraft so D.A.I. discovers the global experience.
5. Choose ENTER MINETRIGGER from the D.A.I. custom title screen.
6. D.A.I. creates/loads the "MineTrigger - Border Training" save and deploys the datapack into that save.

CURRENT SYSTEMS
---------------
- Trion resource with drain/regeneration
- Trigger On / Trigger Off
- Bail Out
- Attacker, Shooter, Sniper, and All-Rounder loadouts
- Kogetsu, Scorpion, Raygust
- Asteroid, Hound, Egret
- Shield, Grasshopper, Bagworm, Chameleon
- Thruster
- Radar Scan
- Training targets
- Melee Trion-cost reactions
- D.A.I. custom-content identities
- Dedicated experience title entry and save/world setup

UI
--
Press ` while MineTrigger is active to open the MineTrigger action menu directly. Press ` again to close it and return to gameplay.
A fully experience-owned MineTrigger terminal/HUD is planned for the next presentation pass.

DEVELOPER FUNCTIONS
-------------------
/function minetrigger:journey/init
/function minetrigger:trigger/on
/function minetrigger:trigger/off
/function minetrigger:trigger/bailout
/function minetrigger:ability/grasshopper
/function minetrigger:ability/thruster
/function minetrigger:ability/radar
/function minetrigger:status

RESOURCE PACK
-------------
The companion resource pack owns MineTrigger presentation/model resources. The datapack now points its D.A.I.
content models at the minetrigger namespace so custom models can evolve independently from the gameplay pack.

Version 0.2.3 keeps the MineTrigger identity/namespace and adds direct experience-owned grave-key menu routing.


0.2.1 stability fixes:
- Fixed first-spawn floor removal that caused players to fall from the floating training sector.
- Moved the safe HQ spawn to Y=65 and added short spawn protection.
- Compacted the training arena into reliably loaded spawn chunks.
- Added safe resume teleport to Border HQ.
- Fixed 17 invalid overlay texture resource identifiers.
- Removed unsupported gamerule commands reported by Minecraft 26.2.


0.2.2 grounded-world hotfix:
- Training Sector now occupies the native flat-world surface around Y=-61 instead of floating near Y=64.
- Player spawn is Y=-60, matching vanilla flat-world login height.
- New save id intentionally prevents reuse of the broken elevated alpha world.
- Arena construction is idempotent and tracked by wt_world/#arena.
- Resume/init can repair the arena if its world marker is missing.


0.2.3 UI UPDATE
- Direct grave-key routing: ` opens MineTrigger immediately instead of the generic D.A.I. root menu.
- The normal Actions > Automation > MINETRIGGER route remains available as a fallback.
