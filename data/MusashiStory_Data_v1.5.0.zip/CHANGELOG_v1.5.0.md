# Musashi Story v1.5.0 — HQ Environment + Traversal Hotfix

## Natural exterior terrain
- Added an HQ environmental pass around the castle town and every surrounding authored province.
- Breaks up broad rectangular terrain shelves with irregular low banks, soft contour mounds and blended ground treatment.
- Adds region-appropriate meadow/forest floor scatter, fallen logs, cedar/cherry growth and controlled foliage instead of leaving large clean fill planes exposed.
- Adds a dedicated castle-wall transition pass so the city remains the authored constructed core while the land outside reads as natural terrain.
- Existing generated worlds migrate safely: the central-city quality layer applies once on load and outer province passes apply when those regions are revisited.

## Wind Step double jump
- Removed Wind Step from physical loadouts/hotbars, including cleanup of the old Wind Step item when a style is re-equipped.
- Samples the player jump input every tick and treats the first grounded jump as the arm event.
- A fresh airborne jump press activates Wind Step; releasing and pressing jump again can chain further Wind Steps while Resolve remains available.
- Each successful Wind Step still costs 15 Resolve and fails cleanly when Resolve is insufficient.

## Intro presentation
- First-join equipment is deferred until `journey/after_intro` so item/recipe discovery notifications are not queued over the ERAS world-entry cinematic.
- Returning-player loadout restoration remains unchanged.

---

# Musashi Story v1.5.0 — City + Wind Step Hotfix

## Central castle-town generation
- Replaced the old central village grass/mound/pond terrain with a level constructed castle-town footprint.
- Added a formal street grid, perimeter wall, north/south gates, side gates, dense machiya blocks, market ring, dojo/shrine quarters and corner watchtowers.
- Added a one-time v1.5.0 retrofit that rebuilds already-generated central village geometry into the city while leaving surrounding provinces/progression intact.
- Removed central village terrain-mound calls from the authored region generation path.

## Wind Step input
- Wind Step is no longer granted in Duelist, Lancer or Vanguard hotbars.
- Wind Step now samples the vanilla jump input at 20 TPS and activates on a fresh second jump press while airborne.
- Airborne Wind Steps can be chained by releasing/re-pressing jump while Resolve remains available; each successful step still costs 15 Resolve.
- The first grounded jump only arms the ability and does not consume Resolve.

---

# Musashi Story v1.5.0 — Control Isolation Hotfix

## Musashi-specific DAI controls
- Disabled the default DAI Grave-key cursor toggle for Musashi Story.
- Disabled the default DAI menu opening on Grave for this experience so authored Musashi controls can own that input.
- Removed the experience-level `companion_id` request; the normal resource pack remains usable without DAI Companion auto-pairing.

---

# Musashi Story v1.5.0 — DAI 3.6 Cinematic & Combat Update

Musashi Story v1.5.0 moves the experience onto the modern DAI 3.6 runtime and is the first Musashi Story release to use an ERAS/Simple Animation Designer JSON cinematic directly in Minecraft.

## World-entry cinematic
- Adds the 24-second `MUSASHI STORY - WORLD ENTRY` ERAS project to both the datapack and resource pack.
- First-world entry now starts the cinematic after character setup, waits for it to finish, then returns control through `journey/after_intro`.
- HUD is hidden and gameplay input is locked while the cinematic plays.
- Province generation continues behind the cinematic instead of interrupting entry with the old loading-logo overlay/title sequence.
- The authored `PRESS OR TAP TO ENTER` text is currently visual only; the DAI 3.6 cinematic runtime automatically returns control when the 24-second project ends.
- ERAS gradients are approximated by the current Minecraft cinematic renderer, so the in-game result may not be pixel-identical to the browser designer.

## DAI 3.6 techniques
- The seven Musashi technique items now route through `dai_skills` / `skill_cast`.
- Existing Resolve scoreboard progression remains authoritative to avoid save/progression regression.
- Existing interactive definitions are retained as compatibility data, but current technique reactions no longer route through them.

## Combat correctness
- Iaijutsu, Gale Sweep and Mountain Breaker now preserve the exact casting player as their damage source.
- Directional sword trace samples now deduplicate targets, preventing overlapping trace spheres from damaging the same enemy multiple times during one swing.
- Enemy kill progression is awarded only to DAI's direct `dai_entity_killer_context`; environmental deaths no longer reward an arbitrary nearby player.

## Enemy runtime
- All eight authored enemies now use DAI-controlled behavior instead of vanilla AI.
- Acquisition is range-gated to each entity's configured follow range.
- Targets explicitly disengage outside follow range.
- Idle wandering is disabled unless a player is reasonably near the encounter.
- Fixed encounter slots have a 38-block home leash.
- Tengu Duelists gain a wind-burst pressure behavior.
- Oni Brutes gain a close-range slam.
- Shrine Wardens gain a close-range supernatural pressure wave.
- Existing articulated Musashi body-part visuals are intentionally retained because DAI native whole-mesh rendering does not yet replace their per-limb pose animation without a visual downgrade.

## Traversal
- Adopts MineTrigger's proven 5-block safe-fall distance and 0.5 fall-damage multiplier for Musashi's mountainous traversal and dash-heavy techniques.

Requires DAI Engine 3.6 with ERAS cinematic compatibility enabled.
