scoreboard players remove @s ms_resolve 30
playsound minecraft:entity.iron_golem.attack player @s ~ ~ ~ 0.9 0.55
particle minecraft:poof ~ ~0.2 ~ 2 0.2 2 0.15 80 force @a[distance=..32]
tag @s add ms_skill_attacker
execute at @s as @e[tag=ms_enemy,distance=..5,limit=10] run damage @s 11 minecraft:player_attack by @a[tag=ms_skill_attacker,limit=1,sort=nearest]
execute at @s as @e[tag=ms_enemy,distance=..5,limit=10] run effect give @s minecraft:slowness 2 2 true
tag @s remove ms_skill_attacker
title @s actionbar {"text":"MOUNTAIN BREAKER","color":"gold","bold":true}
