scoreboard players remove @s ms_resolve 25
playsound minecraft:entity.player.attack.sweep player @s ~ ~ ~ 1 0.7
particle minecraft:sweep_attack ~ ~1 ~ 2.4 0.4 2.4 0 24 force @a[distance=..32]
tag @s add ms_skill_attacker
execute at @s as @e[tag=ms_enemy,distance=..5,limit=12] run damage @s 7 minecraft:player_attack by @a[tag=ms_skill_attacker,limit=1,sort=nearest]
execute at @s as @e[tag=ms_enemy,distance=..5,limit=12] run effect give @s minecraft:slowness 2 3 true
tag @s remove ms_skill_attacker
title @s actionbar {"text":"GALE SWEEP","color":"green","bold":true}
