function musashi_story:loadout/clear
scoreboard players set @s ms_loadout 3
item replace entity @s hotbar.0 with musashi_story:naginata
item replace entity @s hotbar.1 with musashi_story:gale_sweep
item replace entity @s hotbar.2 with musashi_story:mushin
item replace entity @s armor.head with minecraft:chainmail_helmet
item replace entity @s armor.chest with minecraft:chainmail_chestplate
item replace entity @s armor.legs with minecraft:chainmail_leggings
item replace entity @s armor.feet with minecraft:iron_boots
execute unless items entity @s inventory.* musashi_story:wayfarer_seal run give @s musashi_story:wayfarer_seal
tellraw @s [{"text":"[MUSASHI] ","color":"red","bold":true},{"text":"Lancer style equipped — Naginata // Gale Sweep // Mushin // Wind Step: double jump","color":"gold"}]
