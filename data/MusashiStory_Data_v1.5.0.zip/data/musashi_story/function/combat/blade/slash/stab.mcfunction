function musashi_story:combat/blade/pose_stab
function musashi_story:combat/blade/fx_stab
playsound minecraft:entity.player.attack.strong player @s ~ ~ ~ 0.75 1.1
tag @e[tag=ms_enemy,tag=ms_blade_hit] remove ms_blade_hit
tag @s add ms_blade_attacker
execute anchored eyes positioned ^ ^-0.25 ^1.5 as @e[tag=ms_enemy,tag=!ms_blade_hit,distance=..0.85,limit=3,sort=nearest] run function musashi_story:combat/blade/hit_stab
execute anchored eyes positioned ^ ^-0.25 ^2.4 as @e[tag=ms_enemy,tag=!ms_blade_hit,distance=..0.85,limit=3,sort=nearest] run function musashi_story:combat/blade/hit_stab
execute anchored eyes positioned ^ ^-0.25 ^3.3 as @e[tag=ms_enemy,tag=!ms_blade_hit,distance=..0.85,limit=3,sort=nearest] run function musashi_story:combat/blade/hit_stab
execute anchored eyes positioned ^ ^-0.25 ^4.2 as @e[tag=ms_enemy,tag=!ms_blade_hit,distance=..0.85,limit=3,sort=nearest] run function musashi_story:combat/blade/hit_stab
tag @s remove ms_blade_attacker
tag @e[tag=ms_enemy,tag=ms_blade_hit] remove ms_blade_hit
