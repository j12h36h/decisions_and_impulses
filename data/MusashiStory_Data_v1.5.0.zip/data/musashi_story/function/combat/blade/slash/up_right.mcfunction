function musashi_story:combat/blade/pose_up_right
function musashi_story:combat/blade/fx_up_right
playsound minecraft:entity.player.attack.sweep player @s ~ ~ ~ 0.75 0.95
tag @e[tag=ms_enemy,tag=ms_blade_hit] remove ms_blade_hit
tag @s add ms_blade_attacker
execute anchored eyes positioned ^ ^-0.35 ^1.25 as @e[tag=ms_enemy,tag=!ms_blade_hit,distance=..1.45,limit=5,sort=nearest] run function musashi_story:combat/blade/hit_slash
execute anchored eyes positioned ^ ^-0.35 ^2.0 as @e[tag=ms_enemy,tag=!ms_blade_hit,distance=..1.45,limit=5,sort=nearest] run function musashi_story:combat/blade/hit_slash
execute anchored eyes positioned ^ ^-0.35 ^2.75 as @e[tag=ms_enemy,tag=!ms_blade_hit,distance=..1.45,limit=5,sort=nearest] run function musashi_story:combat/blade/hit_slash
execute anchored eyes positioned ^ ^-0.35 ^3.5 as @e[tag=ms_enemy,tag=!ms_blade_hit,distance=..1.45,limit=5,sort=nearest] run function musashi_story:combat/blade/hit_slash
tag @s remove ms_blade_attacker
tag @e[tag=ms_enemy,tag=ms_blade_hit] remove ms_blade_hit
