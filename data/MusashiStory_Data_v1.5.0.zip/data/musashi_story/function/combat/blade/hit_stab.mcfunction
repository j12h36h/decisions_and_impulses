# Executed as the struck enemy while ms_blade_attacker marks the exact source player.
tag @s add ms_blade_hit
damage @s 8 minecraft:player_attack by @a[tag=ms_blade_attacker,limit=1,sort=nearest]
