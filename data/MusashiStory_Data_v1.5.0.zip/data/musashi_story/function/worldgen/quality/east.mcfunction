# HQ environmental pass — East.
forceload add 250 -150 430 -15
execute positioned 278 0 -120 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 316 0 -145 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 410 0 -75 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 386 0 -35 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 272 0 -92 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 304 0 -128 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 364 0 -138 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 416 0 -112 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/bamboo
execute positioned 402 0 -48 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 286 0 -28 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
forceload remove 250 -150 430 -15
scoreboard players set #hq_east ms_world 1
data modify storage musashi_story:runtime hq_east set value 1b
