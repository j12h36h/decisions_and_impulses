# One-time HQ migration marker. The city applies immediately at spawn; outer region passes
# are applied by regions/pulse when a player revisits each already-generated province.
execute unless score #hq_city_v150 ms_world matches 1 run function musashi_story:worldgen/quality/city
scoreboard players set #hq_musashi_v150 ms_world 1
data modify storage musashi_story:runtime hq_environment_v150 set value 1b
