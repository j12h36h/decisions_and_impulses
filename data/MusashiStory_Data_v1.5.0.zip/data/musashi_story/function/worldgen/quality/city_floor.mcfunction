# HQ castle-town ground pass. Roads/plaza/structure floors are preserved; only open packed-mud lots weather.
# Merchant/residential lot wear
fill -57 64 -42 -54 64 -36 minecraft:coarse_dirt replace minecraft:packed_mud
fill -40 64 -51 -35 64 -48 minecraft:rooted_dirt replace minecraft:packed_mud
fill -55 64 34 -51 64 40 minecraft:coarse_dirt replace minecraft:packed_mud
fill -40 64 47 -34 64 50 minecraft:gravel replace minecraft:packed_mud
fill 34 64 -51 40 64 -48 minecraft:coarse_dirt replace minecraft:packed_mud
fill 51 64 -41 55 64 -35 minecraft:rooted_dirt replace minecraft:packed_mud
fill 35 64 48 41 64 51 minecraft:coarse_dirt replace minecraft:packed_mud
fill 51 64 35 55 64 41 minecraft:gravel replace minecraft:packed_mud
fill -24 64 -24 -21 64 -17 minecraft:coarse_dirt replace minecraft:packed_mud
fill 21 64 -24 24 64 -17 minecraft:rooted_dirt replace minecraft:packed_mud
fill -24 64 17 -21 64 24 minecraft:rooted_dirt replace minecraft:packed_mud
fill 21 64 17 24 64 24 minecraft:coarse_dirt replace minecraft:packed_mud

# Proper stone/gravel thresholds at machiya street fronts.
fill -49 64 -13 -43 64 -11 minecraft:gravel replace minecraft:packed_mud
fill -49 64 27 -43 64 29 minecraft:gravel replace minecraft:packed_mud
fill 43 64 -13 49 64 -11 minecraft:gravel replace minecraft:packed_mud
fill 43 64 27 49 64 29 minecraft:gravel replace minecraft:packed_mud
fill -21 64 -13 -15 64 -11 minecraft:polished_andesite replace minecraft:packed_mud
fill 15 64 -13 21 64 -11 minecraft:gravel replace minecraft:packed_mud
fill -21 64 27 -15 64 29 minecraft:gravel replace minecraft:packed_mud
fill 15 64 27 21 64 29 minecraft:polished_andesite replace minecraft:packed_mud

# Narrow drainage/edge stones give the grid a grounded, maintained-city read.
fill -58 64 -57 -57 64 57 minecraft:cobblestone replace minecraft:packed_mud
fill 56 64 -57 57 64 57 minecraft:cobblestone replace minecraft:packed_mud
fill -57 64 -58 57 64 -57 minecraft:cobblestone replace minecraft:packed_mud
fill -57 64 56 57 64 57 minecraft:cobblestone replace minecraft:packed_mud

# Sparse lived-in floor details in open courtyards.
setblock -52 65 -33 minecraft:barrel
setblock 52 65 33 minecraft:composter
setblock -34 65 53 minecraft:flower_pot
setblock 34 65 -53 minecraft:flower_pot
setblock -24 65 38 minecraft:pink_petals[flower_amount=3]
setblock 24 65 -38 minecraft:pink_petals[flower_amount=2]
setblock -37 65 24 minecraft:short_grass
setblock 37 65 -24 minecraft:short_grass
