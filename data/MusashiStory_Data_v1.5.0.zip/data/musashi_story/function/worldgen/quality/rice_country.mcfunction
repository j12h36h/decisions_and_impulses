# HQ environmental pass — Rice Country.
forceload add 180 110 390 315
execute positioned 196 0 190 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 274 0 126 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 382 0 184 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 334 0 296 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 194 0 258 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 260 0 302 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 380 0 256 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 330 0 138 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 378 0 300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 246 0 174 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
forceload remove 180 110 390 315
scoreboard players set #hq_rice_country ms_world 1
data modify storage musashi_story:runtime hq_rice_country set value 1b
