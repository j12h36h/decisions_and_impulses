# HQ environmental pass — River Province.
forceload add 255 -20 430 185
execute positioned 276 0 16 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 402 0 62 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 286 0 170 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 410 0 164 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 276 0 108 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 398 0 104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 286 0 38 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 408 0 30 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 300 0 152 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 390 0 176 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
forceload remove 255 -20 430 185
scoreboard players set #hq_river_province ms_world 1
data modify storage musashi_story:runtime hq_river_province set value 1b
