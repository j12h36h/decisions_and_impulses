# HQ environmental pass — Outskirts.
forceload add 72 20 216 144
execute positioned 86 0 46 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 184 0 70 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 96 0 116 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 190 0 122 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 82 0 83 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 126 0 108 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 178 0 42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 205 0 100 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 94 0 126 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 188 0 132 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 82 0 62 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
forceload remove 72 20 216 144
scoreboard players set #hq_outskirts ms_world 1
data modify storage musashi_story:runtime hq_outskirts set value 1b
