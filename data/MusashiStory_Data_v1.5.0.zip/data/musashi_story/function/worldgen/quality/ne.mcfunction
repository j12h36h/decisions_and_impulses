# HQ environmental pass — Ne.
forceload add 245 -445 445 -230
execute positioned 276 0 -286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 414 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 286 0 -416 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 416 0 -408 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 274 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned 414 0 -360 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned 326 0 -420 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 398 0 -250 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 284 0 -250 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned 410 0 -420 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
forceload remove 245 -445 445 -230
scoreboard players set #hq_ne ms_world 1
data modify storage musashi_story:runtime hq_ne set value 1b
