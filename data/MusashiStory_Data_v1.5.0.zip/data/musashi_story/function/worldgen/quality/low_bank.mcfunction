# Low asymmetric bank: blends a hard terrain edge without creating a new landmark hill.
fill ~-9 ~-2 ~-2 ~7 ~-1 ~2 minecraft:dirt
fill ~-6 ~-2 ~-4 ~4 ~-1 ~4 minecraft:dirt
fill ~-8 ~ ~-1 ~6 ~ ~1 minecraft:grass_block
fill ~-5 ~ ~-3 ~3 ~ ~3 minecraft:grass_block
fill ~-3 ~-1 ~-2 ~2 ~1 ~2 minecraft:dirt
fill ~-2 ~2 ~-1 ~1 ~2 ~1 minecraft:grass_block
setblock ~-6 ~1 ~2 minecraft:coarse_dirt
setblock ~3 ~1 ~-3 minecraft:podzol
setblock ~5 ~1 ~1 minecraft:short_grass
setblock ~-4 ~1 ~-2 minecraft:fern
