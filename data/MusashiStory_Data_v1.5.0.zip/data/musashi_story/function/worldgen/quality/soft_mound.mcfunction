# Small irregular contour mound used to break large flat/rectangular terrain shelves.
# Run positioned over motion_blocking_no_leaves.
fill ~-7 ~-2 ~-3 ~7 ~-1 ~3 minecraft:dirt
fill ~-5 ~-2 ~-5 ~5 ~-1 ~5 minecraft:dirt
fill ~-6 ~ ~-2 ~6 ~ ~2 minecraft:grass_block
fill ~-4 ~ ~-4 ~4 ~ ~4 minecraft:grass_block
fill ~-4 ~-1 ~-2 ~4 ~1 ~2 minecraft:dirt
fill ~-2 ~-1 ~-4 ~2 ~1 ~4 minecraft:dirt
fill ~-3 ~2 ~-1 ~3 ~2 ~1 minecraft:grass_block
fill ~-1 ~2 ~-3 ~1 ~2 ~3 minecraft:grass_block
setblock ~-4 ~1 ~3 minecraft:coarse_dirt
setblock ~4 ~1 ~-2 minecraft:rooted_dirt
setblock ~2 ~3 ~1 minecraft:short_grass
setblock ~-2 ~3 ~-1 minecraft:fern
