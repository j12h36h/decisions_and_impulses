# Naturalized transition immediately outside the fortified city wall.
# Cardinal road mouths remain clear; texture/foliage clusters occupy the diagonal shoulders.
forceload add -88 -88 88 88
execute positioned -76 0 -45 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned -82 0 28 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 76 0 44 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 84 0 -30 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned -42 0 -80 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 38 0 -76 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned -38 0 78 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 43 0 82 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned -72 0 -26 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 72 0 25 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned -31 0 -74 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 32 0 75 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned -80 0 42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 82 0 -45 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned -46 0 83 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_c
execute positioned 47 0 -82 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
forceload remove -88 -88 88 88
