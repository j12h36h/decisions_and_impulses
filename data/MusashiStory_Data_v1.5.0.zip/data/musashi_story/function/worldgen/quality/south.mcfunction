# HQ environmental pass — South.
forceload add -140 245 140 435
execute positioned -110 0 286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 108 0 300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned -106 0 400 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 104 0 414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned -86 0 270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 92 0 276 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned -104 0 352 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned 108 0 370 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned -70 0 414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 74 0 404 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
forceload remove -140 245 140 435
scoreboard players set #hq_south ms_world 1
data modify storage musashi_story:runtime hq_south set value 1b
