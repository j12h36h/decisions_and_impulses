# HQ environmental pass — North.
forceload add -130 -430 130 -245
execute positioned -108 0 -282 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 105 0 -300 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned -110 0 -390 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 106 0 -406 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned -92 0 -258 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 88 0 -270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned -104 0 -360 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 106 0 -368 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
execute positioned -68 0 -410 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 72 0 -402 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
forceload remove -130 -430 130 -245
scoreboard players set #hq_north ms_world 1
data modify storage musashi_story:runtime hq_north set value 1b
