# HQ environmental pass — Nw.
forceload add -450 -440 -235 -225
execute positioned -276 0 -286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned -414 0 -270 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned -286 0 -414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned -410 0 -410 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned -272 0 -360 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned -410 0 -350 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -340 0 -420 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -250 0 -286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned -420 0 -245 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -286 0 -236 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
forceload remove -450 -440 -235 -225
scoreboard players set #hq_nw ms_world 1
data modify storage musashi_story:runtime hq_nw set value 1b
