# HQ environmental pass — West.
forceload add -430 -120 -245 120
execute positioned -280 0 -104 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned -410 0 -88 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned -400 0 72 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned -286 0 106 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned -300 0 -86 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/forest_floor
execute positioned -404 0 -22 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree_b
execute positioned -292 0 92 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned -390 0 98 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned -412 0 42 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cedar_tree
execute positioned -270 0 38 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
forceload remove -430 -120 -245 120
scoreboard players set #hq_west ms_world 1
data modify storage musashi_story:runtime hq_west set value 1b
