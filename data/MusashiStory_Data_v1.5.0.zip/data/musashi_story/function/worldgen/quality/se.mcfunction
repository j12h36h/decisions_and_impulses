# HQ environmental pass — Se.
forceload add 180 225 430 445
execute positioned 214 0 286 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 258 0 414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 406 0 278 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/soft_mound
execute positioned 400 0 414 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/quality/low_bank
execute positioned 226 0 330 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 268 0 386 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/ground_scatter
execute positioned 390 0 322 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 416 0 378 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/fallen_log
execute positioned 338 0 424 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/meadow_patch
execute positioned 208 0 408 positioned over motion_blocking_no_leaves run function musashi_story:worldgen/features/cherry_tree
forceload remove 180 225 430 445
scoreboard players set #hq_se ms_world 1
data modify storage musashi_story:runtime hq_se set value 1b
