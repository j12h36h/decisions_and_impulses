# HQ authored pass for the castle town and immediate wall transition.
function musashi_story:worldgen/quality/city_floor
function musashi_story:worldgen/quality/city_transition
scoreboard players set #hq_city_v150 ms_world 1
data modify storage musashi_story:runtime hq_city_v150 set value 1b
