# Castle-town street grid.
# Main north/south and east/west avenues.
fill -5 64 -62 5 64 62 minecraft:gravel
fill -62 64 -5 62 64 5 minecraft:gravel
fill -1 64 -62 1 64 62 minecraft:polished_andesite
fill -62 64 -1 62 64 1 minecraft:polished_andesite

# Secondary lanes divide the city into dense walkable blocks.
fill -31 64 -58 -27 64 58 minecraft:coarse_dirt
fill 27 64 -58 31 64 58 minecraft:coarse_dirt
fill -58 64 -31 58 64 -27 minecraft:coarse_dirt
fill -58 64 27 58 64 31 minecraft:coarse_dirt

# Central meeting plaza kept clear around world spawn.
fill -13 64 -13 13 64 13 minecraft:stone_bricks
fill -10 64 -10 10 64 10 minecraft:polished_andesite
fill -4 64 -13 4 64 13 minecraft:gravel
fill -13 64 -4 13 64 4 minecraft:gravel
setblock 0 64 0 minecraft:chiseled_stone_bricks
