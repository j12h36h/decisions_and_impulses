# Compact castle-town gate sized for the central avenue.
fill ~-11 ~-4 ~-3 ~11 ~-1 ~3 minecraft:stone_bricks
fill ~-10 ~ ~-3 ~-6 ~7 ~3 minecraft:stone_bricks
fill ~6 ~ ~-3 ~10 ~7 ~3 minecraft:stone_bricks
fill ~-5 ~ ~-2 ~5 ~5 ~2 minecraft:air
fill ~-7 ~1 ~-4 ~-7 ~8 ~4 minecraft:stripped_dark_oak_log
fill ~7 ~1 ~-4 ~7 ~8 ~4 minecraft:stripped_dark_oak_log
fill ~-8 ~6 ~-4 ~8 ~7 ~4 minecraft:dark_oak_planks
fill ~-6 ~1 ~-3 ~-6 ~5 ~3 minecraft:red_concrete
fill ~6 ~1 ~-3 ~6 ~5 ~3 minecraft:red_concrete
fill ~-10 ~8 ~-5 ~10 ~8 ~5 minecraft:deepslate_tiles
fill ~-9 ~9 ~-4 ~9 ~9 ~4 minecraft:deepslate_tiles
fill ~-8 ~10 ~-2 ~8 ~10 ~2 minecraft:deepslate_tiles
fill ~-7 ~11 ~-1 ~7 ~11 ~1 minecraft:polished_blackstone
fill ~-11 ~8 ~-5 ~-11 ~8 ~5 minecraft:deepslate_tile_stairs[facing=east]
fill ~11 ~8 ~-5 ~11 ~8 ~5 minecraft:deepslate_tile_stairs[facing=west]
setblock ~-8 ~5 ~-4 minecraft:lantern[hanging=true]
setblock ~8 ~5 ~-4 minecraft:lantern[hanging=true]
