# Compact two-storey machiya for the central castle town.
# Stone cellar/foundation is deliberately tight so neighboring city lots can sit close together.
fill ~-6 ~-4 ~-8 ~6 ~-1 ~8 minecraft:stone_bricks
fill ~-5 ~ ~-7 ~5 ~ ~7 minecraft:dark_oak_planks

# Timber frame.
fill ~-6 ~ ~-8 ~-6 ~6 ~8 minecraft:stripped_dark_oak_log
fill ~6 ~ ~-8 ~6 ~6 ~8 minecraft:stripped_dark_oak_log
fill ~-5 ~ ~-8 ~5 ~6 ~-8 minecraft:stripped_dark_oak_log
fill ~-5 ~ ~8 ~5 ~6 ~8 minecraft:stripped_dark_oak_log
fill ~-5 ~3 ~-8 ~5 ~3 ~-8 minecraft:stripped_dark_oak_log[axis=x]
fill ~-5 ~3 ~8 ~5 ~3 ~8 minecraft:stripped_dark_oak_log[axis=x]
fill ~-6 ~3 ~-7 ~-6 ~3 ~7 minecraft:stripped_dark_oak_log[axis=z]
fill ~6 ~3 ~-7 ~6 ~3 ~7 minecraft:stripped_dark_oak_log[axis=z]

# White plaster infill on both storeys.
fill ~-5 ~1 ~-8 ~5 ~2 ~-8 minecraft:white_terracotta
fill ~-5 ~4 ~-8 ~5 ~5 ~-8 minecraft:white_terracotta
fill ~-5 ~1 ~8 ~5 ~2 ~8 minecraft:white_terracotta
fill ~-5 ~4 ~8 ~5 ~5 ~8 minecraft:white_terracotta
fill ~-6 ~1 ~-7 ~-6 ~2 ~7 minecraft:white_terracotta
fill ~-6 ~4 ~-7 ~-6 ~5 ~7 minecraft:white_terracotta
fill ~6 ~1 ~-7 ~6 ~2 ~7 minecraft:white_terracotta
fill ~6 ~4 ~-7 ~6 ~5 ~7 minecraft:white_terracotta

# Street frontage: double entry, shoji windows and a narrow shop awning.
fill ~-2 ~1 ~8 ~2 ~2 ~8 minecraft:air
setblock ~-1 ~1 ~8 minecraft:cherry_door[half=lower,facing=north,hinge=left]
setblock ~-1 ~2 ~8 minecraft:cherry_door[half=upper,facing=north,hinge=left]
setblock ~1 ~1 ~8 minecraft:cherry_door[half=lower,facing=north,hinge=right]
setblock ~1 ~2 ~8 minecraft:cherry_door[half=upper,facing=north,hinge=right]
fill ~-5 ~1 ~8 ~-3 ~2 ~8 minecraft:white_stained_glass_pane
fill ~3 ~1 ~8 ~5 ~2 ~8 minecraft:white_stained_glass_pane
fill ~-4 ~4 ~8 ~-2 ~5 ~8 minecraft:white_stained_glass_pane
fill ~2 ~4 ~8 ~4 ~5 ~8 minecraft:white_stained_glass_pane
fill ~-5 ~4 ~-8 ~-2 ~5 ~-8 minecraft:white_stained_glass_pane
fill ~2 ~4 ~-8 ~5 ~5 ~-8 minecraft:white_stained_glass_pane
fill ~-7 ~3 ~9 ~7 ~3 ~10 minecraft:cherry_slab[type=top]
setblock ~-5 ~2 ~9 minecraft:lantern[hanging=true]
setblock ~5 ~2 ~9 minecraft:lantern[hanging=true]

# Side windows break up long rows.
fill ~-6 ~1 ~-3 ~-6 ~2 ~-1 minecraft:white_stained_glass_pane
fill ~-6 ~1 ~2 ~-6 ~2 ~4 minecraft:white_stained_glass_pane
fill ~6 ~1 ~-3 ~6 ~2 ~-1 minecraft:white_stained_glass_pane
fill ~6 ~1 ~2 ~6 ~2 ~4 minecraft:white_stained_glass_pane

# Deep tiled gable roof/eaves.
fill ~-8 ~6 ~-10 ~8 ~6 ~10 minecraft:deepslate_tiles
fill ~-7 ~7 ~-8 ~7 ~7 ~8 minecraft:deepslate_tiles
fill ~-6 ~8 ~-6 ~6 ~8 ~6 minecraft:deepslate_tiles
fill ~-5 ~9 ~-4 ~5 ~9 ~4 minecraft:deepslate_tiles
fill ~-4 ~10 ~-2 ~4 ~10 ~2 minecraft:deepslate_tiles
fill ~-4 ~11 ~-1 ~4 ~11 ~1 minecraft:polished_blackstone
fill ~-9 ~6 ~-10 ~-9 ~6 ~10 minecraft:deepslate_tile_stairs[facing=east]
fill ~9 ~6 ~-10 ~9 ~6 ~10 minecraft:deepslate_tile_stairs[facing=west]

# Sparse lived-in interior.
fill ~-4 ~1 ~-5 ~4 ~1 ~5 minecraft:yellow_carpet
setblock ~-4 ~1 ~5 minecraft:barrel
setblock ~4 ~1 ~5 minecraft:crafting_table
setblock ~-4 ~2 ~-5 minecraft:lantern
