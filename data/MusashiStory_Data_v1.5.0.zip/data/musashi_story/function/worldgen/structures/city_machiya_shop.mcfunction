# Shopfront variant layered over the compact machiya shell.
function musashi_story:worldgen/structures/city_machiya
fill ~-5 ~ ~10 ~5 ~ ~11 minecraft:dark_oak_slab[type=top]
setblock ~-4 ~1 ~10 minecraft:barrel
setblock ~4 ~1 ~10 minecraft:barrel
setblock ~-2 ~1 ~10 minecraft:hay_block
setblock ~2 ~1 ~10 minecraft:composter
fill ~-4 ~4 ~9 ~4 ~4 ~9 minecraft:red_wool
