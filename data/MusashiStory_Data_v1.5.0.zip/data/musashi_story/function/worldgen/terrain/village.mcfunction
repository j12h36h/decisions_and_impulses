# Musashi central castle town — constructed urban footprint.
# The old village mounds/pond are intentionally gone: this core is level, built land surrounded by the natural provinces.
fill -64 60 -64 -1 62 63 minecraft:stone
fill 0 60 -64 63 62 63 minecraft:stone
fill -64 63 -64 63 63 63 minecraft:dirt
fill -64 64 -64 63 64 63 minecraft:packed_mud

# Stone perimeter apron/foundations around the castle-town wall.
fill -63 64 -63 62 64 -60 minecraft:stone_bricks
fill -63 64 59 62 64 62 minecraft:stone_bricks
fill -63 64 -59 -60 64 58 minecraft:stone_bricks
fill 59 64 -59 62 64 58 minecraft:stone_bricks
