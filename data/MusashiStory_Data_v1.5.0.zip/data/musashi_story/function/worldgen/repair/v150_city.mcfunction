# v1.5.0 central-city retrofit for worlds that already generated the former village terrain.
forceload add -64 -64 63 63
kill @e[tag=ms_static,x=-64,y=55,z=-64,dx=127,dy=70,dz=127]
fill -64 65 -64 -57 96 63 minecraft:air
fill -56 65 -64 -49 96 63 minecraft:air
fill -48 65 -64 -41 96 63 minecraft:air
fill -40 65 -64 -33 96 63 minecraft:air
fill -32 65 -64 -25 96 63 minecraft:air
fill -24 65 -64 -17 96 63 minecraft:air
fill -16 65 -64 -9 96 63 minecraft:air
fill -8 65 -64 -1 96 63 minecraft:air
fill 0 65 -64 7 96 63 minecraft:air
fill 8 65 -64 15 96 63 minecraft:air
fill 16 65 -64 23 96 63 minecraft:air
fill 24 65 -64 31 96 63 minecraft:air
fill 32 65 -64 39 96 63 minecraft:air
fill 40 65 -64 47 96 63 minecraft:air
fill 48 65 -64 55 96 63 minecraft:air
fill 56 65 -64 63 96 63 minecraft:air
function musashi_story:worldgen/terrain/village
function musashi_story:worldgen/regions/village/generate
function musashi_story:worldgen/quality/city
scoreboard players set #modern_v150 ms_world 1
data modify storage musashi_story:runtime city_core_v150 set value 1b
forceload remove -64 -64 63 63
tellraw @a[tag=ms_player] [{"text":"MUSASHI STORY // ","color":"gold","bold":true},{"text":"central village terrain rebuilt as the fortified castle town.","color":"gray"}]
