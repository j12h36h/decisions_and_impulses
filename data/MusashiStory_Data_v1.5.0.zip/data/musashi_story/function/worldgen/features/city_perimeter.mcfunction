# Castle-town wall: stone footing, plaster body, dark timber cap.
# North wall, central gate opening preserved.
fill -62 65 -62 -12 66 -60 minecraft:stone_bricks
fill 12 65 -62 62 66 -60 minecraft:stone_bricks
fill -62 67 -62 -12 69 -60 minecraft:white_terracotta
fill 12 67 -62 62 69 -60 minecraft:white_terracotta
fill -62 70 -62 -12 70 -60 minecraft:dark_oak_planks
fill 12 70 -62 62 70 -60 minecraft:dark_oak_planks
# South wall.
fill -62 65 60 -12 66 62 minecraft:stone_bricks
fill 12 65 60 62 66 62 minecraft:stone_bricks
fill -62 67 60 -12 69 62 minecraft:white_terracotta
fill 12 67 60 62 69 62 minecraft:white_terracotta
fill -62 70 60 -12 70 62 minecraft:dark_oak_planks
fill 12 70 60 62 70 62 minecraft:dark_oak_planks
# West/east walls, with smaller side-gate openings aligned to the east-west avenue.
fill -62 65 -59 -60 66 -9 minecraft:stone_bricks
fill -62 65 9 -60 66 59 minecraft:stone_bricks
fill 60 65 -59 62 66 -9 minecraft:stone_bricks
fill 60 65 9 62 66 59 minecraft:stone_bricks
fill -62 67 -59 -60 69 -9 minecraft:white_terracotta
fill -62 67 9 -60 69 59 minecraft:white_terracotta
fill 60 67 -59 62 69 -9 minecraft:white_terracotta
fill 60 67 9 62 69 59 minecraft:white_terracotta
fill -62 70 -59 -60 70 -9 minecraft:dark_oak_planks
fill -62 70 9 -60 70 59 minecraft:dark_oak_planks
fill 60 70 -59 62 70 -9 minecraft:dark_oak_planks
fill 60 70 9 62 70 59 minecraft:dark_oak_planks
# Side-gate timber frames.
fill -62 65 -9 -60 72 -7 minecraft:stripped_dark_oak_log
fill -62 65 7 -60 72 9 minecraft:stripped_dark_oak_log
fill -62 71 -7 -60 72 7 minecraft:red_concrete
fill 60 65 -9 62 72 -7 minecraft:stripped_dark_oak_log
fill 60 65 7 62 72 9 minecraft:stripped_dark_oak_log
fill 60 71 -7 62 72 7 minecraft:red_concrete
