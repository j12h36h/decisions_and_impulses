# Northern training quarter and southern shrine quarter are flanked by additional townhouses.
execute positioned 20 65 -45 run function musashi_story:worldgen/structures/city_machiya
execute positioned -20 65 45 run function musashi_story:worldgen/structures/city_machiya_shop

# Market ring around the spawn plaza.
execute positioned -18 65 -8 run function musashi_story:worldgen/features/market_stall
execute positioned 18 65 -8 run function musashi_story:worldgen/features/market_stall
execute positioned -18 65 8 run function musashi_story:worldgen/features/market_stall
execute positioned 18 65 8 run function musashi_story:worldgen/features/market_stall

# Courtyard clutter kept off the through-roads.
execute positioned -39 65 -7 run function musashi_story:worldgen/features/roadside_props
execute positioned 39 65 7 run function musashi_story:worldgen/features/roadside_props
