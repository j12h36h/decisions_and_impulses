# Central Musashi castle town. This replaces the former village-green terrain/mound layout.
function musashi_story:worldgen/roads/city_grid
function musashi_story:worldgen/features/city_perimeter

# Formal north/south gates anchor the main avenue; side gates are built into the wall helper.
execute positioned 0 65 -61 run function musashi_story:worldgen/structures/city_gate
execute positioned 0 65 61 run function musashi_story:worldgen/structures/city_gate

# Central waypoint remains at the established world-spawn coordinate.
execute positioned 0 65 0 run function musashi_story:worldgen/features/waypoint_shrine

# Civic anchors.
execute positioned -15 65 -44 run function musashi_story:worldgen/structures/dojo
execute positioned 15 65 44 run function musashi_story:worldgen/structures/shrine
execute positioned 15 65 31 run function musashi_story:worldgen/features/torii

# Dense city blocks are separated for readability but run synchronously while the core is force-loaded.
function musashi_story:worldgen/regions/village/detail_1
function musashi_story:worldgen/regions/village/detail_2
function musashi_story:worldgen/regions/village/detail_3

scoreboard players set #gen_village ms_world 1
function musashi_story:worldgen/quality/city
scoreboard players set #modern_v150 ms_world 1
data modify storage musashi_story:runtime city_core_v150 set value 1b
