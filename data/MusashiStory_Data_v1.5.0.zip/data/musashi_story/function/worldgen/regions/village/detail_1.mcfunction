# West/east merchant blocks.
execute positioned -46 65 -20 run function musashi_story:worldgen/structures/city_machiya
execute positioned -46 65 20 run function musashi_story:worldgen/structures/city_machiya_shop
execute positioned 46 65 -20 run function musashi_story:worldgen/structures/city_machiya_shop
execute positioned 46 65 20 run function musashi_story:worldgen/structures/city_machiya

# Inner residential blocks around the central plaza.
execute positioned -18 65 -20 run function musashi_story:worldgen/structures/city_machiya_shop
execute positioned 18 65 -20 run function musashi_story:worldgen/structures/city_machiya
execute positioned -18 65 20 run function musashi_story:worldgen/structures/city_machiya
execute positioned 18 65 20 run function musashi_story:worldgen/structures/city_machiya_shop
