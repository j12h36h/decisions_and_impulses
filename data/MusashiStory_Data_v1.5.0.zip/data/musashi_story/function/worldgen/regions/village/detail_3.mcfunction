# Corner watchtowers give the new central district an actual fortified silhouette.
execute positioned -51 65 -51 run function musashi_story:worldgen/structures/watchtower
execute positioned 51 65 -51 run function musashi_story:worldgen/structures/watchtower
execute positioned -51 65 51 run function musashi_story:worldgen/structures/watchtower
execute positioned 51 65 51 run function musashi_story:worldgen/structures/watchtower

# Small planted courtyards; no terrain hills/mounds are reintroduced.
execute positioned -41 65 39 run function musashi_story:worldgen/features/cherry_tree_b
execute positioned 41 65 -39 run function musashi_story:worldgen/features/cherry_tree_c
execute positioned -39 65 -39 run function musashi_story:worldgen/features/garden_patch
execute positioned 39 65 39 run function musashi_story:worldgen/features/garden_patch
execute positioned -24 65 10 run function musashi_story:worldgen/features/stone_lantern
execute positioned 24 65 -10 run function musashi_story:worldgen/features/stone_lantern
