execute unless score #built ms_world matches 1 run return 0
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned 140 65 70 if entity @s[distance=..330] unless score #gen_outskirts ms_world matches 1 run function musashi_story:worldgen/regions/outskirts/generate
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned 280 65 210 if entity @s[distance=..310] unless score #gen_rice ms_world matches 1 run function musashi_story:worldgen/regions/rice_country/generate
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned 340 65 80 if entity @s[distance=..310] unless score #gen_river ms_world matches 1 run function musashi_story:worldgen/regions/river_province/generate
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned 330 73 -70 if entity @s[distance=..330] unless score #gen_e ms_world matches 1 run function musashi_story:worldgen/regions/east/generate
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned 0 70 -320 if entity @s[distance=..330] unless score #gen_n ms_world matches 1 run function musashi_story:worldgen/regions/north/generate
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned -320 68 0 if entity @s[distance=..330] unless score #gen_w ms_world matches 1 run function musashi_story:worldgen/regions/west/generate
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned 0 75 340 if entity @s[distance=..330] unless score #gen_s ms_world matches 1 run function musashi_story:worldgen/regions/south/generate
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned 300 65 320 if entity @s[distance=..320] unless score #gen_se ms_world matches 1 run function musashi_story:worldgen/regions/se/generate
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned 350 95 -350 if entity @s[distance=..350] unless score #gen_ne ms_world matches 1 run function musashi_story:worldgen/regions/ne/generate
execute if score #region_cd ms_world matches 1.. run return 0
execute positioned -340 68 -320 if entity @s[distance=..340] unless score #gen_nw ms_world matches 1 run function musashi_story:worldgen/regions/nw/generate
# HQ terrain/detail migration: only runs for an already-generated province while a player is nearby.
execute positioned 140 65 70 if entity @s[distance=..330] if score #gen_outskirts ms_world matches 1 unless score #hq_outskirts ms_world matches 1 run function musashi_story:worldgen/quality/outskirts
execute positioned 280 65 210 if entity @s[distance=..310] if score #gen_rice ms_world matches 1 unless score #hq_rice_country ms_world matches 1 run function musashi_story:worldgen/quality/rice_country
execute positioned 340 65 80 if entity @s[distance=..310] if score #gen_river ms_world matches 1 unless score #hq_river_province ms_world matches 1 run function musashi_story:worldgen/quality/river_province
execute positioned 330 73 -70 if entity @s[distance=..330] if score #gen_e ms_world matches 1 unless score #hq_east ms_world matches 1 run function musashi_story:worldgen/quality/east
execute positioned 0 70 -320 if entity @s[distance=..330] if score #gen_n ms_world matches 1 unless score #hq_north ms_world matches 1 run function musashi_story:worldgen/quality/north
execute positioned -320 68 0 if entity @s[distance=..330] if score #gen_w ms_world matches 1 unless score #hq_west ms_world matches 1 run function musashi_story:worldgen/quality/west
execute positioned 0 75 340 if entity @s[distance=..330] if score #gen_s ms_world matches 1 unless score #hq_south ms_world matches 1 run function musashi_story:worldgen/quality/south
execute positioned 300 65 320 if entity @s[distance=..320] if score #gen_se ms_world matches 1 unless score #hq_se ms_world matches 1 run function musashi_story:worldgen/quality/se
execute positioned 350 95 -350 if entity @s[distance=..350] if score #gen_ne ms_world matches 1 unless score #hq_ne ms_world matches 1 run function musashi_story:worldgen/quality/ne
execute positioned -340 68 -320 if entity @s[distance=..340] if score #gen_nw ms_world matches 1 unless score #hq_nw ms_world matches 1 run function musashi_story:worldgen/quality/nw
