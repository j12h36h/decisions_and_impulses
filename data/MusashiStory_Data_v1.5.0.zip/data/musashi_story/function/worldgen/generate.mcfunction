
function musashi_story:bootstrap/ensure
kill @e[tag=ms_static]
kill @e[tag=ms_enemy]
kill @e[tag=ms_visual]
scoreboard players set #built ms_world 0
scoreboard players set #quality_v050 ms_world 1
scoreboard players set #region_cd ms_world 0
scoreboard players set #gen_cadence ms_world 0
scoreboard players set #modern_v120 ms_world 1
scoreboard players set #modern_v130 ms_world 1
scoreboard players set #modern_v131 ms_world 1
scoreboard players set #modern_v132 ms_world 1
scoreboard players set #modern_v134 ms_world 1
scoreboard players set #modern_v133 ms_world 1
scoreboard players set #hq_musashi_v150 ms_world 1
scoreboard players set #gen_active ms_world 1
scoreboard players set #build_step ms_world 0
scoreboard players set #gen_village ms_world 0
scoreboard players set #gen_outskirts ms_world 0
scoreboard players set #gen_e ms_world 0
scoreboard players set #gen_n ms_world 0
scoreboard players set #gen_w ms_world 0
scoreboard players set #gen_s ms_world 0
scoreboard players set #gen_se ms_world 0
scoreboard players set #gen_ne ms_world 0
scoreboard players set #gen_nw ms_world 0
scoreboard players set #gen_rice ms_world 0
scoreboard players set #gen_river ms_world 0
forceload add -64 -64 63 63
fill -64 60 -64 -1 62 63 minecraft:stone
fill 0 60 -64 63 62 63 minecraft:stone
fill -64 63 -64 63 63 63 minecraft:dirt
fill -64 64 -64 63 64 63 minecraft:grass_block
function musashi_story:worldgen/terrain/village
function musashi_story:worldgen/regions/village/generate
forceload remove -64 -64 63 63
bossbar set musashi_story:loading value 0
bossbar set musashi_story:loading visible true
data modify storage musashi_story:runtime generation_complete set value 0b
