# Wind Step double-jump controller — Minecraft 26.2 input predicates.
# First fresh Space press leaving the ground arms Wind Step. Each later fresh
# Space press while airborne casts it, and the chain remains armed until landing.

tag @s remove ms_ws_jump_now
tag @s remove ms_ws_ground_now
execute if predicate musashi_story:input/jump run tag @s add ms_ws_jump_now
execute if predicate musashi_story:input/on_ground run tag @s add ms_ws_ground_now

# A grounded sample primes the previous-ground state and fully resets an old air chain.
execute if entity @s[tag=ms_ws_ground_now] run tag @s remove ms_ws_armed
execute if entity @s[tag=ms_ws_ground_now] run tag @s add ms_ws_ground_prev

# Rising edge of Space immediately after a grounded sample = ordinary first jump / arm.
execute if entity @s[tag=ms_ws_jump_now,tag=!ms_ws_jump_down,tag=ms_ws_ground_prev] run tag @s add ms_ws_armed

# Any later rising Space edge in air while armed = Wind Step. The skill itself handles Resolve.
execute if entity @s[tag=ms_ws_jump_now,tag=!ms_ws_jump_down,tag=!ms_ws_ground_now,tag=ms_ws_armed] unless entity @s[tag=ms_ws_ground_prev] run function musashi_story:skill/wind_step

# Persist the current key state. Airborne sampling clears ground_prev only after edge tests,
# so the first takeoff tick can still be recognized reliably.
execute if entity @s[tag=ms_ws_jump_now] run tag @s add ms_ws_jump_down
execute unless entity @s[tag=ms_ws_jump_now] run tag @s remove ms_ws_jump_down
execute unless entity @s[tag=ms_ws_ground_now] run tag @s remove ms_ws_ground_prev

tag @s remove ms_ws_jump_now
tag @s remove ms_ws_ground_now
