function musashi_story:bootstrap/ensure
execute unless score #built ms_world matches 1 run function musashi_story:worldgen/generate
function musashi_story:worldgen/spawn_safety
tag @s add ms_player
execute unless score @s ms_init matches 1.. run function musashi_story:journey/first_join
gamemode adventure @s
attribute @s minecraft:safe_fall_distance base set 5.0
attribute @s minecraft:fall_damage_multiplier base set 0.5
execute unless items entity @s inventory.* musashi_story:wayfarer_seal run give @s musashi_story:wayfarer_seal
execute if score @s ms_loadout matches 1 run function musashi_story:loadout/duelist
execute if score @s ms_loadout matches 2 run function musashi_story:loadout/vanguard
execute if score @s ms_loadout matches 3 run function musashi_story:loadout/lancer
execute if score @s ms_loadout matches 4 run function musashi_story:loadout/shinobi

# Interrupted-cinematic recovery: resume restores the selected style and clears the pending marker.
tag @s remove ms_intro_pending
