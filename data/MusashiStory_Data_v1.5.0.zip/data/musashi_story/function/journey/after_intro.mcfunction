# Musashi Story v1.5.0 — returned control after the ERAS world-entry cinematic.
# Equipment is intentionally granted here, not before cinematic_play, so vanilla
# item/recipe discovery cannot queue top-right join toasts over the intro.
function musashi_story:worldgen/spawn_safety
execute if score @s ms_loadout matches 1 run function musashi_story:loadout/duelist
execute if score @s ms_loadout matches 2 run function musashi_story:loadout/vanguard
execute if score @s ms_loadout matches 3 run function musashi_story:loadout/lancer
execute if score @s ms_loadout matches 4 run function musashi_story:loadout/shinobi
tag @s remove ms_intro_pending
effect give @s minecraft:resistance 5 2 true
effect give @s minecraft:slow_falling 4 0 true
playsound minecraft:block.bell.resonate player @s ~ ~ ~ 0.55 1.25
title @s actionbar {"text":"THE ROAD IS OPEN","color":"gold","bold":true}
tellraw @s [{"text":"[MUSASHI STORY] ","color":"dark_red","bold":true},{"text":"The province awaits beyond the blossoms.","color":"gold"}]
