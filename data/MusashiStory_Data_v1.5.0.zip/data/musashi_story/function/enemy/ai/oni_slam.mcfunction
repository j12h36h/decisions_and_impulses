# Exact-source close-range Oni impact.
tag @e[tag=ms_ai_source] remove ms_ai_source
tag @s add ms_ai_source
playsound minecraft:entity.iron_golem.attack hostile @a[distance=..32] ~ ~ ~ 1.0 0.55
particle minecraft:poof ~ ~0.3 ~ 2.1 0.25 2.1 0.14 70 force @a[distance=..32]
execute at @s as @a[tag=ms_player,distance=..4.5] run damage @s 7 minecraft:mob_attack by @e[tag=ms_ai_source,limit=1,sort=nearest]
execute at @s as @a[tag=ms_player,distance=..4.5] run effect give @s minecraft:slowness 2 1 true
tag @s remove ms_ai_source
