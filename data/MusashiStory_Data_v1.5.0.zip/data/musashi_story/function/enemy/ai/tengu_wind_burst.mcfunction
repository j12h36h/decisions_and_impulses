# Fast evasive pressure without teleporting through authored terrain.
playsound minecraft:entity.breeze.wind_burst hostile @a[distance=..28] ~ ~ ~ 0.65 1.35
particle minecraft:cloud ~ ~1 ~ 0.55 0.45 0.55 0.06 18 force @a[distance=..32]
effect give @s minecraft:speed 2 2 true
effect give @s minecraft:jump_boost 2 1 true
