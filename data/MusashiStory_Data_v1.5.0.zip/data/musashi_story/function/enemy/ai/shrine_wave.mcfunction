# Shrine Warden pressure wave; player damage is attributed to this exact actor.
tag @e[tag=ms_ai_source] remove ms_ai_source
tag @s add ms_ai_source
playsound minecraft:block.respawn_anchor.deplete hostile @a[distance=..40] ~ ~ ~ 0.8 0.7
particle minecraft:reverse_portal ~ ~1.2 ~ 3.2 0.7 3.2 0.04 100 force @a[distance=..40]
execute at @s as @a[tag=ms_player,distance=..7.5] run damage @s 6 minecraft:magic by @e[tag=ms_ai_source,limit=1,sort=nearest]
execute at @s as @a[tag=ms_player,distance=..7.5] run effect give @s minecraft:slowness 2 1 true
tag @s remove ms_ai_source
