# Musashi Story v1.5.0 — DAI 3.6 direct-killer reward dispatch.
# DAI tags the direct player killer with dai_entity_killer_context while this hook executes.
execute as @a[tag=ms_player,tag=dai_entity_killer_context,limit=1] run function musashi_story:progress/kill_tengu_duelist
