# Musashi Story v1.5.0 — 1 TPS safety + authored encounter leashes.
execute as @e[tag=ms_enemy] run data merge entity @s {Fire:-20s}
item replace entity @e[tag=ms_enemy] weapon.mainhand with minecraft:air
item replace entity @e[tag=ms_enemy] weapon.offhand with minecraft:air

# Fixed authored encounter mobs remain within 38 blocks of their intended home.
execute positioned 300 0 -55 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_e1] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned 372 0 -42 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_e2] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned 350 0 -382 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_e3] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned -36 0 -292 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_n1] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned 0 0 -354 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_n2] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned -290 0 36 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_w1] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned -352 0 -30 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_w2] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned -382 0 58 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_w3] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned -42 0 318 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_s1] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned 42 0 344 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_s2] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned 0 0 406 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_s3] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned -398 0 -366 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_nw1] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned -286 0 -282 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_nw2] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned 260 0 278 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_se1] unless entity @s[distance=..38] run tp @s ~ ~1 ~
execute positioned 390 0 -330 positioned over motion_blocking_no_leaves as @e[tag=ms_enemy,tag=ms_spawn_ne1] unless entity @s[distance=..38] run tp @s ~ ~1 ~
