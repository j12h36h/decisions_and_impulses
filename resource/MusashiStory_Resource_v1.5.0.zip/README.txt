Musashi Story Resource v1.5.0
DAI 3.6 synchronized cinematic resource-pack release.

- Synchronized with Musashi Story Data v1.5.0.
- Adds the ERAS/Simple Animation Designer world-entry cinematic as a native DAI cinematic resource.
- DAI Companion auto-activation/pairing is disabled for Musashi Story.
- Refines third-person katana, wakizashi and nodachi grip placement with a second palm-anchor pass while preserving all first-person transforms.
- Preserves authored HD textures, articulated enemy rigs, weapon models, directional poses and loading presentation.
- No destructive texture resize or detail reduction was applied.
- Existing articulated enemy visuals remain in place while the underlying enemy logic moves to DAI-controlled behavior.
