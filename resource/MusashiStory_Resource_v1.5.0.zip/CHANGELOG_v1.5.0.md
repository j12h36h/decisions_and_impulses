# Musashi Story Resource v1.5.0 — Third-Person Grip Pass 2

## Sword hand anchoring
- Refined the third-person hilt anchor for katana, wakizashi and nodachi after the first grip correction.
- Moves the grip back into the player palm and raises the weapon without disturbing the authored first-person presentation.
- Applied consistently to base, idle, drawn, drawn-ready, guard and all directional slash states.
- First-person transforms and non-display model geometry remain unchanged.

---

# Musashi Story Resource v1.5.0 — Third-Person Grip + Companion Isolation Hotfix

## Third-person weapon placement
- Corrected the common third-person hand anchor for katana, wakizashi and nodachi models.
- Applied the correction across base, idle, drawn, ready, guard and directional slash states.
- Preserved every first-person display transform exactly as authored.
- Preserved each combat state's existing rotation/animation delta; only the common hand-position offset was corrected.

## DAI Companion isolation
- Disabled automatic DAI Companion activation/pairing for Musashi Story.
- The resource pack remains the normal Musashi Story resource pack and retains all authored assets.

---

# Musashi Story v1.5.0 — DAI 3.6 Cinematic & Combat Update

Musashi Story v1.5.0 moves the experience onto the modern DAI 3.6 runtime and is the first Musashi Story release to use an ERAS/Simple Animation Designer JSON cinematic directly in Minecraft.

## World-entry cinematic
- Adds the 24-second `MUSASHI STORY - WORLD ENTRY` ERAS project to both the datapack and resource pack.
- First-world entry now starts the cinematic after character setup, waits for it to finish, then returns control through `journey/after_intro`.
- HUD is hidden and gameplay input is locked while the cinematic plays.
- Province generation continues behind the cinematic instead of interrupting entry with the old loading-logo overlay/title sequence.
- The authored `PRESS OR TAP TO ENTER` text is currently visual only; the DAI 3.6 cinematic runtime automatically returns control when the 24-second project ends.
- ERAS gradients are approximated by the current Minecraft cinematic renderer, so the in-game result may not be pixel-identical to the browser designer.

## DAI 3.6 techniques
- The seven Musashi technique items now route through `dai_skills` / `skill_cast`.
- Existing Resolve scoreboard progression remains authoritative to avoid save/progression regression.
- Existing interactive definitions are retained as compatibility data, but current technique reactions no longer route through them.

## Combat correctness
- Iaijutsu, Gale Sweep and Mountain Breaker now preserve the exact casting player as their damage source.
- Directional sword trace samples now deduplicate targets, preventing overlapping trace spheres from damaging the same enemy multiple times during one swing.
- Enemy kill progression is awarded only to DAI's direct `dai_entity_killer_context`; environmental deaths no longer reward an arbitrary nearby player.

## Enemy runtime
- All eight authored enemies now use DAI-controlled behavior instead of vanilla AI.
- Acquisition is range-gated to each entity's configured follow range.
- Targets explicitly disengage outside follow range.
- Idle wandering is disabled unless a player is reasonably near the encounter.
- Fixed encounter slots have a 38-block home leash.
- Tengu Duelists gain a wind-burst pressure behavior.
- Oni Brutes gain a close-range slam.
- Shrine Wardens gain a close-range supernatural pressure wave.
- Existing articulated Musashi body-part visuals are intentionally retained because DAI native whole-mesh rendering does not yet replace their per-limb pose animation without a visual downgrade.

## Traversal
- Adopts MineTrigger's proven 5-block safe-fall distance and 0.5 fall-damage multiplier for Musashi's mountainous traversal and dash-heavy techniques.

Requires DAI Engine 3.6 with ERAS cinematic compatibility enabled.
