Musashi Story Resource v1.3.2
Samurai-style idle sword stance refinement.
- Katana, Wakizashi and Nodachi now use explicit idle stance models when selected with no active clicks.
- Idle stance holds the drawn blade low at the hip in the palm.
- Guard/block and attack transforms from v1.3.1 are preserved.
