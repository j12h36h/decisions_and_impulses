MineTrigger Resource Pack v0.4.3
================================
Companion presentation pack for MineTrigger Border Training v0.4.0.
Minecraft 26.2 / D.A.I. 1.9.9+.

DAI companion metadata:
- auto_enable: true
- companion_id: minetrigger
- version: 0.3.3

0.3.3
-----
- Updated companion metadata for DAI 1.9.9.
- Added managed companion version 0.3.3.
- Preserved stable companion identity minetrigger.
- Preserved all existing Trigger item model IDs and native registry item-definition files.
- Preserved the official MineTrigger logo and pack icon.
- No working visual asset identifiers were renamed.


v0.4.0 adds dedicated MineTrigger item textures/models plus the Border Wheel radial UI texture set.


v0.4.3
------
- Added dedicated Force Blaster item artwork/model for the Attacker slot-2 push sidearm.
- Added dedicated Trigger On and Trigger Off hotbar control artwork/models.
- Synchronized managed companion version to 0.4.3.
- Preserved all v0.4.1 loading, intro, item, and Border Wheel assets.
