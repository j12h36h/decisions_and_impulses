# World of Addons — Rift HUD Layout

The HUD deliberately keeps Minecraft's native hotbar selection system so existing keybind customization continues to work.

| Hotbar | Rift role | Champion convention |
|---|---|---|
| 1 | Ability Q | Primary / quick ability |
| 2 | Ability W | Secondary ability |
| 3 | Ability E | Third ability / main kit |
| 4 | Ability R | Ultimate |
| 5 | Utility 1 | Summoner / mobility / consumable |
| 6 | Utility 2 | Summoner / defensive / consumable |
| 7 | Ward | Vision / placement utility |
| 8 | Item 1 | Purchased active/combat item |
| 9 | Item 2 | Purchased active/sustain item |

The slot art is visual only: players can still remap Minecraft's Hotbar Slot 1–9 controls normally. Recognized World of Addons champion addons may opt into the convention by placing their ability items into slots 1–4 when they detect the Rift context.
