# World of Addons Resource v0.9.7 — Split Rift HUD

- Replaced the continuous hotbar art with a transparent logical hotbar plus split DAI HUD deck.
- Added distinct Abilities, Utility, Ward and Items visual groups.
- Added Q/W/E/R labels to slots 1–4 while retaining Hotbar Slot 1–9 as the actual controls.
- Added a Rift crest/status plate and gold plate around the combat controls.
- Reworked selected-slot art into compact cyan/gold corner markers.
- Preserved the v0.9.5 item textures, scenes, menus and full-takeover visuals.
- DAI Engine 4.2 is unchanged.
