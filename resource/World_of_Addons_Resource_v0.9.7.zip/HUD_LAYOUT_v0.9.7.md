# Split Rift HUD — v0.9.7

The visual deck is split into separate combat groups while the logical controls remain Minecraft's normal Hotbar Slot keybinds, so users can remap 1–9 in Controls without a custom input system.

| Logical slot | Rift role | Visual group |
|---|---|---|
| 1 | Q / Ability 1 | Abilities |
| 2 | W / Ability 2 | Abilities |
| 3 | E / Ability 3 | Abilities |
| 4 | R / Ultimate | Abilities |
| 5 | Utility 1 | Utility |
| 6 | Utility 2 | Utility |
| 7 | Ward / Vision | Ward |
| 8 | Item 1 | Items |
| 9 | Item 2 | Items |

Slot 7 is intentionally reserved so a ward addon/mechanic can occupy it without another HUD redesign.

The resource pack makes Minecraft's continuous hotbar chassis transparent and draws separate ability / utility / ward / item groups as a DAI HUD overlay. Vanilla item icons and the selected-slot state still come from the real logical hotbar underneath, which keeps normal key remapping and addon behavior intact.
