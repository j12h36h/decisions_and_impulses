# World of Addons Resource v0.9.5 — League HUD

- Rebuilt the in-game hotbar into a League-inspired dark metal / gold-trimmed HUD frame.
- Gave every one of the nine vanilla hotbar positions its own dedicated slot treatment.
- Split the bar into functional groups while retaining Minecraft's normal 1–9 hotbar keybinds:
  - 1–4: Q / W / E / R ability cluster
  - 5–6: utility / summoner-style slots
  - 7: ward slot
  - 8–9: item slots
- Rebuilt the selected-slot frame with a stronger gold/cyan active-state treatment.
- Updated the XP bar into a matching slim resource-style meter.
- No vanilla hotbar keybind is replaced; the HUD is still driven by the player's normal 1–9 controls.
