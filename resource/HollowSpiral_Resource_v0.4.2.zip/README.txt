HOLLOW SPIRAL v0.4.2 — COMPANION RESOURCE PACK

Visual companion pack for Hollow Spiral on DAI 1.9.9 / Minecraft 26.2.

INSTALL / DAI 1.9.9
1. Place the Hollow Spiral datapack in DAI's global datapack library.
2. Place this ZIP in the normal Minecraft /resourcepacks folder.
3. DAI can automatically detect and select this companion when managed resource packs are enabled.

The resource pack declares:
- dai.auto_enable = true
- dai.companion_id = hollow_spire
- dai.version = 0.4.0

NAMING / COMPATIBILITY
- Player-facing branding is Hollow Spiral everywhere.
- The internal assets/hollow_spire namespace is retained because the datapack already references those assets.
- The internal companion_id hollow_spire is retained as a legacy compatibility key so DAI can replace older installed Hollow Spiral companion versions instead of treating them as a separate pack.

CURRENT VISUAL MODE
- Industrial/cyber-ruin environmental block textures remain active.
- Hollow Spiral namespaced custom item/model assets are retained for future or optional content.
- Legacy vanilla-item model overrides remain removed so normal vanilla items keep their native presentation.
- Vanilla entity rendering remains intact because Hollow Spiral currently uses ordinary minecraft:* encounter mobs.

This pack is synchronized with Hollow Spiral v0.4.2.


HOTFIX 0.4.1
- Adds the missing Hollow Spiral loading_background and loading_logo GUI textures referenced by the experience branding.
- Keeps the proven internal companion key hollow_spire.
- Includes both supported DAI companion metadata spellings for defensive auto-enable compatibility.
