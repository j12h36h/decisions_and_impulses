Musashi Story Resource v1.4.0
DAI 3.3 synchronized companion release.

- Synchronized with Musashi Story Data v1.4.0.
- Preserves automatic companion-pack activation.
- Preserves all authored HD textures, articulated enemy rigs, weapon models, directional poses and loading presentation.
- No destructive texture resize or detail reduction was applied.
- Compatible with the data pack's lower-cost interpolated articulated-entity runtime.
