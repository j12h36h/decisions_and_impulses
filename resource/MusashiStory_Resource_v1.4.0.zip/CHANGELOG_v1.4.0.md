# Musashi Story Resource — v1.3.4 → v1.4.0

## DAI 3.3 Companion Update
- Updated companion metadata to **v1.4.0**.
- Synchronized the resource pack with Musashi Story Data v1.4.0.
- Preserved automatic DAI companion-pack activation through `companion_id: musashi_story`.
- Preserved Minecraft 26.2 resource-pack compatibility.

## Articulated Entity Compatibility
- Preserved all existing articulated enemy body-part models and textures.
- Updated companion documentation for the data pack's new **5 TPS / four-tick interpolated** rig-follow runtime.
- No model scale, UV, material, animation pose, or enemy silhouette changes were required.

## Weapon Presentation
- Preserved the corrected v1.3.4 idle blade rotation.
- Katana, Wakizashi and Nodachi low hip-side idle presentation remains unchanged.
- Attack-ready, slash, directional attack, and guard/block transforms remain unchanged.

## Asset Efficiency
- Audited the complete PNG set for additional lossless optimization.
- Existing assets were already efficiently encoded, so no destructive resizing or texture-detail reduction was performed.
- Repacked at maximum ZIP compression while preserving the existing authored artwork pixel-for-pixel.

## Compatibility
- Resource pack version: **1.4.0**
- Companion Data pack version: **1.4.0**
- Runtime target: **DAI 3.3**
