
DAI Damage Indicators v1.0 — RESOURCE PACK
Minecraft Java Edition 26.2
Resource Pack version: 88.0

This resource pack provides the custom bitmap font used by the datapack's floating damage numbers.
Enable it together with the DAI Damage Indicators datapack.
