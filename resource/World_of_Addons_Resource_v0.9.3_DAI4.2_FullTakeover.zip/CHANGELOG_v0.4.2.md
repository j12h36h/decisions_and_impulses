# World of Addons Resource v0.4.2

- visual layer intentionally preserved from v0.4.1 because the graphical menu/HUD direction is already approved
- version synchronized with the v0.4.2 functional datapack hotfix
- retains custom hotbar, menu art, terrain materials, Kitty's Dagger models, and EchoTime models
- remains optional; World of Addons datapack functionality does not depend on this resource pack
