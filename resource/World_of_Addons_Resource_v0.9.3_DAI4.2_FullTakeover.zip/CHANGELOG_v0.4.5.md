# World of Addons Resource v0.4.5

- version-sync companion release for World of Addons Data v0.4.5
- retains the v0.4.4 material opacity, foliage cutout, alpha-edge padding, HUD, menu, and addon visual fixes unchanged
- no additional gameplay dependency is introduced; World of Addons Data remains standalone-capable
