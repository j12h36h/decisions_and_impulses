# World of Addons Resource v0.9.0 — Full Experience Visual Replacement

- Added dedicated `loading_background.png` and `world_of_addons_logo.png` GUI assets used by the DAI 4.1 Experience loading runtime.
- Updated the five-second World Entry cinematic into the v0.9.0 splash intro with `ENTER THE RIFT` and `A DAI 4.1 EXPERIENCE` presentation beats.
- Keeps the existing Rift title, launch, loading, menu, pause and transition scene assets intact.
- Preserves every existing item model, HUD asset, Minecraft texture override, addon visual and sound path.
- Stable companion identity remains `world_of_addons` for automatic DAI 4.1 activation.
