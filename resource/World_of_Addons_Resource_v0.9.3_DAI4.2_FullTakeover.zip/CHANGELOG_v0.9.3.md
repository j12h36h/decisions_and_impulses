# World of Addons Resource v0.9.3 — DAI 4.2

- Updated companion metadata for DAI Engine 4.2.
- Pairs with World of Addons Data v0.9.3.
- No visual content was removed or downgraded.
- Existing custom title, loading, launch, return and splash assets are preserved.
