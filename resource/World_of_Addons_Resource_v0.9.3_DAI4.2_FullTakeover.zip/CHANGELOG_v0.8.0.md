# World of Addons Resource v0.8.0 — DAI 4.1 Companion Compatibility

- Updated resource-pack metadata and visible compatibility text for DAI Engine 4.1.
- Preserved stable `dai.companion_id: world_of_addons` automatic activation.
- Preserved all 3D scene assets, menu art, HUD textures, item models and the World Entry cinematic.
- No visual asset IDs or Minecraft resource paths changed.
