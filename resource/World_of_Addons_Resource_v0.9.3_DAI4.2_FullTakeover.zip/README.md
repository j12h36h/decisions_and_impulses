# World of Addons — Resource v0.9.3

Optional **D.A.I. Engine 4.2** visual companion for **World of Addons Data v0.9.3** on Minecraft **26.2**.

## Full Experience UI companion

v0.6.0 adds Resource Pack scene definitions for the World of Addons-owned DAI screens:

- League Menu
- Champion Select
- Rune Loadout
- Shop
- Match Status
- Rift Pause

The screens use the existing World of Addons menu artwork as low-opacity scene composition behind the functional DAI 4.2 data-screen widgets. The Data Pack includes gradient fallbacks, so the Experience remains functional if this companion is missing.

## Automatic lifecycle

- `dai.auto_enable: true`
- `dai.companion_id: world_of_addons`
- DAI 4.2 can activate this pack immediately before the World of Addons world load.
- The active live PackRepository receives the companion at high priority before world entry.
- Leaving the Experience restores the prior resource-pack stack.

## Preserved visual content

- Rift terrain/material redraws.
- Custom hotbar, selector, crosshair and experience bar.
- Kitty's Dagger and EchoTime item visuals.
- Champion / Rune / Shop menu art.
- Five-second World Entry cinematic.
- Toast suppression and repaired foliage/material alpha behavior.

## Compatibility

- Minecraft Java 26.2
- DAI Engine 4.2
- Resource Pack format 88.0
- Companion ID: `world_of_addons`
- Pairing target: World of Addons Data v0.9.3

## v0.7.0 3D Experience Scene Companion

Adds the resource-pack copies of the World of Addons 3D title, launch, world-loading, Rift-entry, Rift-return, Champion Select, Runes, Shop, League Hub, Status and Pause scenes. These override the datapack scene fallbacks when the companion is active while keeping the pack optional for gameplay.


## v0.8.0 — DAI 4.2 Companion Compatibility

- Updated companion metadata/versioning for DAI Engine 4.2.
- Keeps the stable `world_of_addons` companion identity so DAI can replace older versioned companion ZIPs automatically.
- Existing textures, models, HUD art, scene assets and cinematic timing are unchanged.
- Pairs with World of Addons Data v0.9.2 and remains optional for gameplay.


## v0.9.0 — Experience Replacement Art

Adds dedicated World of Addons loading/background and logo textures, and promotes the existing five-second World Entry cinematic into the official first-entry splash intro. Together with the datapack title/scene definitions, this companion supplies the full DAI 4.2 presentation layer for the Experience.


## v0.9.2 — Shell Takeover Companion

Pairs with World of Addons Data v0.9.2. No existing art was removed: the Rift overview, loading background, logo, transition scenes and first-entry splash assets now serve the datapack's DAI 4.2 boot-shell takeover.


## v0.9.3 — DAI 4.2 Companion

Pairs with World of Addons Data v0.9.3 and DAI Engine 4.2. Visual assets are
unchanged; the update aligns the companion version with the corrected
Return-to-DAI-Universe lifecycle.
