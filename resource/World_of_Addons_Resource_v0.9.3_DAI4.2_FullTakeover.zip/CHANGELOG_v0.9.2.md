# World of Addons Resource v0.9.2

- Companion version bump for the DAI 4.1 full-takeover hotfix.
- Existing Rift title/loading/logo/splash assets are unchanged and now become
  available at the shell bootstrap stage through the engine hotfix.
