# World of Addons Resource v0.6.0 — Experience UI Scene Pass

- Added DAI 4.0 `scene_environments` for League Menu, Champion Select, Runes, Shop, Match Status and Rift Pause.
- Reused the existing World of Addons Champion / Rune / Shop artwork as Experience-owned screen composition instead of introducing a second unrelated visual language.
- Preserved the stable `world_of_addons` companion identity and auto-enable behavior.
- Preserved all existing terrain, HUD, item, cinematic, sound and alpha/cutout repairs from v0.5.0.
- Resource Pack format remains 88.0 for Minecraft 26.2.
