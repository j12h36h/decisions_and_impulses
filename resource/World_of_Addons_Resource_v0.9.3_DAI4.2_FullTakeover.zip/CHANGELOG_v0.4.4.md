# World of Addons Resource v0.4.4

## Material / transparency cleanup
- removes accidental transparency from solid terrain, stone, wood, metal, soil, lane, and structural textures
- converts foliage to stable cutout alpha for Minecraft block rendering
- dilates foliage edge RGB into transparent pixels to prevent bright/dirty mipmap fringes
- preserves intentional water transparency and animation
- preserves the v0.4.x hotbar, menus, champion item visuals, and cinematic art
