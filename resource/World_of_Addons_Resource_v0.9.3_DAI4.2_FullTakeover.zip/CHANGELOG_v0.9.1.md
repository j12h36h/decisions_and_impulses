# World of Addons Resource v0.9.1 — DAI 4.1 Shell Takeover Companion

- Bumped companion metadata to v0.9.1 for the World of Addons Data v0.9.1 shell-takeover release.
- Keeps all v0.9.0 visual assets intact.
- Existing Rift overview, loading, launch-transition, return and splash assets are now used by the datapack-owned DAI 4.1 shell flow.
- Stable companion ID remains `world_of_addons`.
