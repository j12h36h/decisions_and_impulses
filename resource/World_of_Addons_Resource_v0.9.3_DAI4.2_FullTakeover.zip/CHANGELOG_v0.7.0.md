# World of Addons Resource v0.7.0

- Added the complete model-backed 3D Rift scene set for DAI 4.0 Experience scene ownership.
- Added animated Rift overview, launch transition, world loading, first-entry and resume scenes.
- Rebuilt Champion Select, Runes, Shop, League Hub, Match Status and Pause backgrounds as 3D block/item-model environments.
- Scene visuals remain mirrored by datapack definitions so gameplay and UI continue to function without this companion pack.
