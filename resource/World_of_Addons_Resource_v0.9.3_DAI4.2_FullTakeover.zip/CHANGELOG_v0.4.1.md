# World of Addons Resource v0.4.1

- rebuilt the Rift hotbar/selector/crosshair with dark metal, gold, and cyan fantasy HUD framing
- rebuilt the shared menu background as an ornate modular game panel
- deeper hand-drawn-style terrain palette for grass, soil, stone, ruins, logs, planks, foliage, swamp ground, and water
- added animated stylized water textures for cleaner waterfalls and basin presentation
- enhanced Kitty's Dagger and EchoTime custom item art while retaining their native DAI item IDs
- toast chrome remains fully transparent and common toast headings are blanked
- resource pack remains optional; World of Addons gameplay does not require it
