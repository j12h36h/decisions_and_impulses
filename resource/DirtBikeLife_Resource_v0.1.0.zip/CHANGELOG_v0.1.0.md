# DirtBikeLife v0.1.0 — Initial Release

- Added the first DirtBikeLife native DAI dirtbike.
- Added a custom detailed motocross-style mesh and authored textures.
- Added custom engine start, four RPM bands, shift, brake, crash, and Echo reset audio.
- Added LMB-held throttle.
- Added RMB tap upshift, double-tap downshift, and 1-second hold full braking.
- Added 50% soft braking during the unresolved RMB input window.
- Added five manual gears with gear-specific torque and speed limits.
- Added A/D steering with high-speed steering reduction.
- Added W/S rider lean.
- Added physics-driven wheelies, balance behavior, loop-outs, airborne pitch correction, and hard-landing crash detection.
- Added a 3-second Echo Crash simulation.
- Added rider-authoritative rewind: safe XYZ/yaw/pitch are restored while the bike is rebuilt upright from the rider direction with zero momentum.
- Added persistent per-world Crash Counter sidebar statistics.
- Added DirtBikeLife Key deployment and auto-mount flow.
- Added DirtBikeLife pack art to both Data and Resource packs.
