# DirtBikeLife v0.1.0

Resource companion for the DAI-powered manual dirtbike prototype.

Controls
- Hold Left Mouse: throttle
- Right Mouse tap: upshift
- Right Mouse double-tap: downshift
- Right Mouse hold: immediate 50% soft brake, then full brake after 1 second
- A / D: steer
- W / S: rider lean forward / backward
- Shift: dismount

Physics
- Five-speed transmission with gear-dependent torque and speed caps
- RPM-driven engine sound bands
- Speed-sensitive steering and lateral grip
- Dynamic wheelies from throttle + rearward rider lean
- Balance point and loop-out behavior
- Air pitch correction through rider lean

Echo Crash
- DirtBikeLife continuously keeps the last safe rider frame while the bike is recoverable.
- A loop-out or hard landing starts a three-second crash simulation.
- Crash Counter increments once.
- After the simulation, the rider is restored to the safe XYZ + yaw/pitch.
- The bike is reset upright from the restored rider direction, momentum is cleared, Gear 1 is selected, and the rider is automatically reattached.

Compatibility
The advanced mouse/manual-motorcycle controller requires the included DAI 3.3 DirtBikeLife Vehicle Patch source changes to be integrated into the DAI 3.3 mod build.
