# Space Between Blocks Resource v0.4.3

Companion resource pack for Space Between Blocks v0.4.3. Includes terminal, shard, foliage, and Aurod vine visual updates.
