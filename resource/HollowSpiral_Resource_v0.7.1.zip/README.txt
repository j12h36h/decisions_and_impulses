HOLLOW SPIRAL v0.7.1 — COMPANION RESOURCE PACK

Visual companion for Hollow Spiral on DAI 3.3 / Minecraft 26.2.

INSTALL
1. Place the Hollow Spiral Data Pack in DAI's instance/global datapack library.
2. Place this ZIP in the normal Minecraft resourcepacks folder.
3. DAI automatically associates it through companion_id hollow_spire.

DAI METADATA
- auto_enable: true
- companion_id: hollow_spire
- version: 0.6.0

VISUAL MODE
- Industrial/cyber-ruin environmental visuals remain active.
- Hollow Spiral namespaced custom item/model assets remain available.
- Vanilla item and vanilla entity rendering remain untouched where Hollow Spiral uses ordinary Minecraft content.
- Loading background, loading emblem and expedition-terminal GUI assets are preserved.

Synchronized with Hollow Spiral Data v0.7.1.
