HOLLOW SPIRE v0.1.2 — HOLLOW SPIRAL COMPANION RESOURCE PACK

Visual companion pack for Hollow Spiral on DAI 1.9.5 / Minecraft 26.2.

INSTALL / DAI 1.9.5
1. Place the Hollow Spiral datapack in DAI's global datapack library.
2. Place this ZIP in the normal Minecraft /resourcepacks folder.
3. DAI can automatically detect and select this companion when managed resource packs are enabled.

The resource pack declares:
- dai.auto_enable = true
- dai.companion_id = hollow_spire

The stable companion identity lets DAI replace stale versioned filenames with the newest matching HollowSpire pack without changing unrelated user-selected resource packs.

CURRENT VISUAL MODE
- Industrial/cyber-ruin environmental block textures remain active.
- HollowSpire namespaced custom item/model assets are retained for future or optional content.
- Legacy vanilla-item model overrides from the older vertical-slice build were removed so normal bows, swords, compasses and other vanilla items keep their native presentation.
- Vanilla entity rendering is intentionally left intact because Hollow Spiral currently uses ordinary minecraft:* encounter mobs.

This pack is the visual companion to Hollow Spiral v0.3.7.
