ClayGrounds Resource Pack v0.4.6 — DAI 1.9.9

CURRENT COMPANION SETTINGS
- Companion ID: claygrounds
- Auto Enable: true
- Managed version: 0.4.6
- Minecraft Java Resource Pack format: 88.0
- Paired with ClayGrounds Datapack v0.4.6.
- Visual assets remain unchanged; v0.4.6 synchronizes the companion pack with the fast-worldgen and Solmere-polish datapack release.

ClayGrounds v0.3.0 Resource Pack

Paired with ClayGrounds v0.3.0 Ocean-First DataPack.
Visual assets are byte-identical to v0.2.9; this version bump synchronizes the pair with the ocean-first world-build architecture.
The working ClayGrounds particle atlas registration and all existing models/textures are preserved.


=== v0.3.4 ===
Paired with the native DAI entity datapack. Visual assets remain unchanged from v0.3.3.


v0.3.5: Visual assets unchanged from v0.3.4; paired datapack now synchronizes entity model displays independently instead of mounting them as passengers.
