MineTrigger Resource Pack v0.6.0
================================
Companion presentation pack for MineTrigger Border Training Data v0.6.0.
Minecraft 26.2 / D.A.I. 3.3+.

DAI companion metadata:
- auto_enable: true
- companion_id: minetrigger
- version: 0.6.0

v0.6.0 DAI 3.3 SYNCHRONIZATION
------------------------------
- Synchronized managed companion metadata with MineTrigger Data v0.6.0.
- Preserved all 15 native Trigger item identities and modern Minecraft item-model mappings.
- Preserved the Border Wheel radial interface and all mobility/stealth/loadout icons.
- Preserved MineTrigger loading, intro, logo, lab, and pack presentation artwork.
- Audited model-to-texture references; no working visual identifiers were renamed.
- No artwork was resized, degraded, or destructively recompressed.

v0.5.0
------
- Added explicit particle texture fallbacks to the Trigger item models.
- Preserved existing item art, HUD, title/loading visuals for the DAI 3.0 baseline.

v0.4.3
------
- Added dedicated Force Blaster item artwork/model.
- Added dedicated Trigger On and Trigger Off hotbar control artwork/models.
- Preserved all v0.4.1 loading, intro, item, and Border Wheel assets.
