Musashi Story Resource v0.7.0
- Clean 256px world-material pass with scratch artifacts removed.
- Cutout cherry/spruce foliage for less cubic tree crowns.
- Original 512px weapon icons redrawn around long blade + scabbard presentation.
- Katana/Nodachi/Wakizashi/Naginata now use dimensional vanilla item models with first/third-person and GUI transforms inspired by the presentation approach used by SlashBlade; no SlashBlade assets are redistributed.
