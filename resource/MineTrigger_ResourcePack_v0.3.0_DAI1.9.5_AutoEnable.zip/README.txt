MineTrigger Resource Pack v0.3.0
================================
Companion presentation pack for MineTrigger Border Training v0.3.0.
Minecraft 26.2 / D.A.I. 1.9.5+.

DAI companion metadata:
- auto_enable: true
- companion_id: minetrigger

0.3.0
-----
- Corrected resource-pack metadata to 26.2 resource format 88.0.
- Added DAI automatic companion enablement.
- Added stable companion identity minetrigger.
- Existing item model IDs now directly back registry-native minetrigger:* Trigger items.
- Preserved the MineTrigger logo, icon, and all existing model identifiers.
