THE HOLLOW SPIRE v0.1.0

A vertical DAI Engine RPG experience built as a datapack + resource pack pair.

INSTALL
1. Place HollowSpire_v0.1.0_DataPack.zip in the DAI global /datapacks folder.
2. Place HollowSpire_v0.1.0_ResourcePack.zip in /resourcepacks and enable it.
3. Launch THE HOLLOW SPIRE from DAI's title screen.

VERTICAL SLICE
- Undersettlement hub at Y11.
- Verdant Breach at Y63.
- Transit Grave at Y115.
- Flooded Archive at Y167.
- Black Foundry at Y219.
- Spire Core at Y271.
- Four progression gates plus the Core Warden finale.
- Five native DAI custom entity identities.
- Multi-part articulated display rigs synchronized to native gameplay bodies.
- Custom combat reactions: Spireblade, Pulse Dash, Arc Burst, Repair Gel, Anchor Beacon.
- Persistent kills, scrap, story state and checkpoint recall.
- DAI Experience save ownership, custom void world preset, custom title screen and structure recognition definitions.

DESIGN
The world is one enormous vertical machine suspended in a void. Reactivating each sector changes the ascent state and opens the next lift.

Requires DAI 1.9.1 / Minecraft 26.2.
