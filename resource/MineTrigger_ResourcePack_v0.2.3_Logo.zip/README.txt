MineTrigger Resource Pack v0.2.3
================================

Companion presentation pack for MineTrigger - Border Training Alpha v0.2.3.
Designed for Minecraft 26.2 and Decisions & Impulses 1.8.3+.

This initial resource-pack release establishes stable MineTrigger item-model IDs for every current Trigger.
The v0.2.3 models intentionally inherit/fallback to Minecraft models while the dedicated MineTrigger art pass,
custom geometry, UI sprites, sounds, and future avatar/Trion-body presentation are developed.

Install in the normal Minecraft /resourcepacks directory and enable it when playing MineTrigger.


0.2.3 VISUAL UPDATE
- Added official MineTrigger pack icon (pack.png).
- Added reusable MineTrigger logo texture at assets/minetrigger/textures/gui/logo.png.
- Kept existing Trigger model/resource identifiers compatible with the v0.2.x datapack line.
