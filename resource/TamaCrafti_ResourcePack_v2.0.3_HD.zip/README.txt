TamaCrafti Resource Pack v2.0.1 HD

Fixes after the first HD runtime test:
- restores transparent blank.png used for invisible clickable hitboxes
- removes the black/magenta missing-texture bars
- adds HD actions_button.png for the bottom Actions control
- retains the v2.0 HD concept-art sprites
