# DAI Comic Effects Resource — v1.4.0 → v1.5.0

## DAI 3.3 Companion Update
- Updated the companion Resource Pack for DAI 3.3.
- Updated managed companion metadata to v1.5.0.
- Preserved stable companion ID:
  - `dai_comic_fx`
- Automatic DAI companion activation remains enabled.

## Comic Artwork Preservation
- Preserved all authored comic artwork unchanged.
- Preserved static:
  - POW
  - BAM
  - WHAM
  - KAPOW
  - WHACK
  - BOOM
  - ZAP
  - SPLASH
  - CRASH
  - Burst artwork
- Preserved the animated KAPOW sprite sheet.

## World-Space Bitmap Font
- Preserved the custom comic bitmap font used by environmental world-space effects.
- Existing CRASH, ZAP, SPLASH, and BOOM glyph mappings remain unchanged.
- Font ascent, glyph height, and texture paths remain unchanged.

## Overlay Compatibility
- Existing DAI overlay-sprite definitions remain compatible with the v1.5.0 Data Pack.
- No texture IDs or paths were renamed.
- No dimensions or visual positioning were changed.
- Existing clickable comic overlay behavior remains intact.

## Visual Integrity
- No artwork was resized.
- No texture detail was reduced.
- No destructive recompression was applied.
- The v1.5.0 release is visually identical to v1.4.0; the matching Data Pack contains the runtime efficiency and correctness improvements.
