TamaCrafti Resource Pack v2.0.4 HD

Current HD client assets for TamaCrafti.

- Transparent blank.png remains available for invisible clickable hitboxes.
- Added main_menu_button.png for the persistent bottom-right Main Menu control.
- actions_button.png is retained for backward compatibility but is no longer used by the v2.3.2 Journey HUD.
- Bloxie pet textures remain 384x96 four-frame sprite sheets (96x96 frames).
- Status meter artwork is unchanged; the datapack now lays it out wider and more cleanly.
- pack.mcmeta declares DAI companion auto-enable with stable companion_id = tamacrafti.
- No texture/model change was required for the newer DAI Java architecture; the datapack carries the functional modernization.
